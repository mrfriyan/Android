exports.ids = [0];
exports.modules = {

/***/ "./node_modules/sapper/sapper-dev-client.js":
/*!**************************************************!*\
  !*** ./node_modules/sapper/sapper-dev-client.js ***!
  \**************************************************/
/*! exports provided: connect */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"connect\", function() { return connect; });\nlet source;\n\nfunction check() {\n\tif (false) {}\n\n\tif (module.hot.status() === 'idle') {\n\t\tmodule.hot.check(true).then(modules => {\n\t\t\tconsole.log(`[SAPPER] applied HMR update`);\n\t\t});\n\t}\n}\n\nfunction connect(port) {\n\tif (source || !window.EventSource) return;\n\n\tsource = new EventSource(`http://${window.location.hostname}:${port}/__sapper__`);\n\n\twindow.source = source;\n\n\tsource.onopen = function(event) {\n\t\tconsole.log(`[SAPPER] dev client connected`);\n\t};\n\n\tsource.onerror = function(error) {\n\t\tconsole.error(error);\n\t};\n\n\tsource.onmessage = function(event) {\n\t\tconst data = JSON.parse(event.data);\n\t\tif (!data) return; // just a heartbeat\n\n\t\tif (data.action === 'reload') {\n\t\t\twindow.location.reload();\n\t\t}\n\n\t\tif (data.status === 'completed') {\n\t\t\tcheck();\n\t\t}\n\t};\n\n\t// Close the event source before the window is unloaded to prevent an error\n\t// (\"The connection was interrupted while the page was loading.\") in Firefox\n\t// when the page is reloaded.\n\twindow.addEventListener('beforeunload', function() {\n\t\tsource.close();\n\t});\n}\n\n/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../webpack/buildin/harmony-module.js */ \"./node_modules/webpack/buildin/harmony-module.js\")(module)))\n\n//# sourceURL=webpack:///./node_modules/sapper/sapper-dev-client.js?");

/***/ }),

/***/ "./node_modules/webpack/buildin/harmony-module.js":
/*!*******************************************!*\
  !*** (webpack)/buildin/harmony-module.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = function(originalModule) {\n\tif (!originalModule.webpackPolyfill) {\n\t\tvar module = Object.create(originalModule);\n\t\t// module.parent = undefined by default\n\t\tif (!module.children) module.children = [];\n\t\tObject.defineProperty(module, \"loaded\", {\n\t\t\tenumerable: true,\n\t\t\tget: function() {\n\t\t\t\treturn module.l;\n\t\t\t}\n\t\t});\n\t\tObject.defineProperty(module, \"id\", {\n\t\t\tenumerable: true,\n\t\t\tget: function() {\n\t\t\t\treturn module.i;\n\t\t\t}\n\t\t});\n\t\tObject.defineProperty(module, \"exports\", {\n\t\t\tenumerable: true\n\t\t});\n\t\tmodule.webpackPolyfill = 1;\n\t}\n\treturn module;\n};\n\n\n//# sourceURL=webpack:///(webpack)/buildin/harmony-module.js?");

/***/ })

};;