(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vendors~AlterConfirmation~AlterOutput~CampaignOutput~Confirmation~Disclaimer~Verification~index"],{

/***/ "./node_modules/browser-detect/dist/browser-detect.es5.js":
/*!****************************************************************!*\
  !*** ./node_modules/browser-detect/dist/browser-detect.es5.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(process) {/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */

var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

var browsers = [
    ['firefox', /Firefox\/([0-9\.]+)(?:\s|$)/],
    ['opera', /Opera\/([0-9\.]+)(?:\s|$)/],
    ['opera', /OPR\/([0-9\.]+)(:?\s|$)$/],
    ['edge', /Edge\/([0-9\._]+)/],
    ['ie', /Trident\/7\.0.*rv\:([0-9\.]+)\).*Gecko$/],
    ['ie', /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
    ['ie', /MSIE\s(7\.0)/],
    ['safari', /Version\/([0-9\._]+).*Safari/],
    ['chrome', /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
    ['bb10', /BB10;\sTouch.*Version\/([0-9\.]+)/],
    ['android', /Android\s([0-9\.]+)/],
    ['ios', /Version\/([0-9\._]+).*Mobile.*Safari.*/],
    ['yandexbrowser', /YaBrowser\/([0-9\._]+)/],
    ['crios', /CriOS\/([0-9\.]+)(:?\s|$)/]
];
var os = [
    'Windows Phone',
    'Android',
    'CentOS',
    { name: 'Chrome OS', pattern: 'CrOS' },
    'Debian',
    'Fedora',
    'FreeBSD',
    'Gentoo',
    'Haiku',
    'Kubuntu',
    'Linux Mint',
    'OpenBSD',
    'Red Hat',
    'SuSE',
    'Ubuntu',
    'Xubuntu',
    'Cygwin',
    'Symbian OS',
    'hpwOS',
    'webOS ',
    'webOS',
    'Tablet OS',
    'Tizen',
    'Linux',
    'Mac OS X',
    'Macintosh',
    'Mac',
    'Windows 98;',
    'Windows '
];
var osVersions = {
    '10.0': '10',
    '6.4': '10 Technical Preview',
    '6.3': '8.1',
    '6.2': '8',
    '6.1': 'Server 2008 R2 / 7',
    '6.0': 'Server 2008 / Vista',
    '5.2': 'Server 2003 / XP 64-bit',
    '5.1': 'XP',
    '5.01': '2000 SP1',
    '5.0': '2000',
    '4.0': 'NT',
    '4.90': 'ME'
};

var mobileRegExp = new RegExp(['(android|bb\\d+|meego).+mobile|avantgo|bada\\/|blackberry|blazer|',
    'compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|',
    'midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)',
    '\\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\\.(browser|link)|vodafone|',
    'wap|windows ce|xda|xiino'].join(''), 'i');
var mobilePrefixRegExp = new RegExp(['1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\\-)|',
    'ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\\-m|r |s )|',
    'avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\\-(n|u)|c55\\/|capi|ccwa|cdm\\-|',
    'cell|chtm|cldc|cmd\\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\\-s|devi|dica|dmob|do(c|p)o|',
    'ds(12|\\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\\-|_)|',
    'g1 u|g560|gene|gf\\-5|g\\-mo|go(\\.w|od)|gr(ad|un)|haie|hcit|hd\\-(m|p|t)|hei\\-|',
    'hi(pt|ta)|hp( i|ip)|hs\\-c|ht(c(\\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\\-(20|go|ma)|',
    'i230|iac( |\\-|\\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|',
    'kddi|keji|kgt( |\\/)|klon|kpt |kwc\\-|kyo(c|k)|le(no|xi)|lg( g|\\/(k|l|u)|50|54|\\-[a-w])',
    '|libw|lynx|m1\\-w|m3ga|m50\\/|ma(te|ui|xo)|mc(01|21|ca)|m\\-cr|me(rc|ri)|mi(o8|oa|ts)|',
    'mmef|mo(01|02|bi|de|do|t(\\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|',
    'n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|',
    'op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\\-2|',
    'po(ck|rt|se)|prox|psio|pt\\-g|qa\\-a|qc(07|12|21|32|60|\\-[2-7]|i\\-)|qtek|r380|r600|',
    'raks|rim9|ro(ve|zo)|s55\\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\\-|oo|p\\-)|sdk\\/|',
    'se(c(\\-|0|1)|47|mc|nd|ri)|sgh\\-|shar|sie(\\-|m)|k\\-0|sl(45|id)|sm(al|ar|b3|it|t5)|',
    'so(ft|ny)|sp(01|h\\-|v\\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\\-|tdg\\-|',
    'tel(i|m)|tim\\-|t\\-mo|to(pl|sh)|ts(70|m\\-|m3|m5)|tx\\-9|up(\\.b|g1|si)|utst|v400|v750|',
    'veri|vi(rg|te)|vk(40|5[0-3]|\\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|',
    'w3c(\\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\\-|your|zeto|zte\\-'].join(''), 'i');

var Detector = /** @class */ (function () {
    function Detector(userAgent, navigator, process) {
        this.navigator = navigator;
        this.process = process;
        this.userAgent = userAgent
            ? userAgent
            : this.navigator ? (navigator.userAgent || navigator.vendor) : '';
    }
    Detector.prototype.detect = function () {
        if (this.process && !this.userAgent) {
            var version = this.process.version.slice(1).split('.').slice(0, 3);
            var versionTail = Array.prototype.slice.call(version, 1).join('') || '0';
            return {
                name: 'node',
                version: version.join('.'),
                versionNumber: parseFloat(version[0] + "." + versionTail),
                mobile: false,
                os: this.process.platform
            };
        }
        if (!this.userAgent)
            this.handleMissingError();
        return __assign({}, this.checkBrowser(), this.checkMobile(), this.checkOs());
    };
    Detector.prototype.checkBrowser = function () {
        var _this = this;
        return browsers
            .filter(function (definition) { return definition[1].test(_this.userAgent); })
            .map(function (definition) {
            var match = definition[1].exec(_this.userAgent);
            var version = match && match[1].split(/[._]/).slice(0, 3);
            var versionTails = Array.prototype.slice.call(version, 1).join('') || '0';
            if (version && version.length < 3)
                Array.prototype.push.apply(version, version.length === 1 ? [0, 0] : [0]);
            return {
                name: String(definition[0]),
                version: version.join('.'),
                versionNumber: Number(version[0] + "." + versionTails)
            };
        })
            .shift();
    };
    Detector.prototype.checkMobile = function () {
        var agentPrefix = this.userAgent.substr(0, 4);
        var mobile = mobileRegExp.test(this.userAgent) || mobilePrefixRegExp.test(agentPrefix);
        return { mobile: mobile };
    };
    Detector.prototype.checkOs = function () {
        var _this = this;
        return os
            .map(function (definition) {
            var name = definition.name || definition;
            var pattern = _this.getOsPattern(definition);
            return {
                name: name,
                pattern: pattern,
                value: RegExp("\\b" + pattern.replace(/([ -])(?!$)/g, '$1?') + "(?:x?[\\d._]+|[ \\w.]*)", 'i').exec(_this.userAgent)
            };
        })
            .filter(function (definition) { return definition.value; })
            .map(function (definition) {
            var os$$1 = definition.value[0] || '';
            var osSuffix;
            if (definition.pattern &&
                definition.name &&
                /^Win/i.test(os$$1) &&
                !/^Windows Phone /i.test(os$$1) &&
                (osSuffix = osVersions[os$$1.replace(/[^\d.]/g, '')]))
                os$$1 = "Windows " + osSuffix;
            if (definition.pattern && definition.name)
                os$$1 = os$$1.replace(RegExp(definition.pattern, 'i'), definition.name);
            os$$1 = os$$1
                .replace(/ ce$/i, ' CE')
                .replace(/\bhpw/i, 'web')
                .replace(/\bMacintosh\b/, 'Mac OS')
                .replace(/_PowerPC\b/i, ' OS')
                .replace(/\b(OS X) [^ \d]+/i, '$1')
                .replace(/\bMac (OS X)\b/, '$1')
                .replace(/\/(\d)/, ' $1')
                .replace(/_/g, '.')
                .replace(/(?: BePC|[ .]*fc[ \d.]+)$/i, '')
                .replace(/\bx86\.64\b/gi, 'x86_64')
                .replace(/\b(Windows Phone) OS\b/, '$1')
                .replace(/\b(Chrome OS \w+) [\d.]+\b/, '$1')
                .split(' on ')[0]
                .trim();
            os$$1 = /^(?:webOS|i(?:OS|P))/.test(os$$1)
                ? os$$1
                : (os$$1.charAt(0).toUpperCase() + os$$1.slice(1));
            return { os: os$$1 };
        })
            .shift();
    };
    Detector.prototype.getOsPattern = function (definition) {
        var definitionInterface = definition;
        return (typeof definition === 'string'
            ? definition
            : undefined) ||
            definitionInterface.pattern ||
            definitionInterface.name;
    };
    Detector.prototype.handleMissingError = function () {
        throw new Error('Please give user-agent.\n> browser(navigator.userAgent or res.headers[\'user-agent\']).');
    };
    return Detector;
}());

function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

var _global = createCommonjsModule(function (module) {
// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef
});

var _core = createCommonjsModule(function (module) {
var core = module.exports = { version: '2.5.7' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef
});
var _core_1 = _core.version;

var _isObject = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};

var _anObject = function (it) {
  if (!_isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};

var _fails = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};

// Thank's IE8 for his funny defineProperty
var _descriptors = !_fails(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});

var document = _global.document;
// typeof document.createElement is 'object' in old IE
var is = _isObject(document) && _isObject(document.createElement);
var _domCreate = function (it) {
  return is ? document.createElement(it) : {};
};

var _ie8DomDefine = !_descriptors && !_fails(function () {
  return Object.defineProperty(_domCreate('div'), 'a', { get: function () { return 7; } }).a != 7;
});

// 7.1.1 ToPrimitive(input [, PreferredType])

// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
var _toPrimitive = function (it, S) {
  if (!_isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !_isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !_isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !_isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};

var dP = Object.defineProperty;

var f = _descriptors ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  _anObject(O);
  P = _toPrimitive(P, true);
  _anObject(Attributes);
  if (_ie8DomDefine) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

var _objectDp = {
	f: f
};

var _propertyDesc = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

var _hide = _descriptors ? function (object, key, value) {
  return _objectDp.f(object, key, _propertyDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

var hasOwnProperty = {}.hasOwnProperty;
var _has = function (it, key) {
  return hasOwnProperty.call(it, key);
};

var id = 0;
var px = Math.random();
var _uid = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};

var _redefine = createCommonjsModule(function (module) {
var SRC = _uid('src');
var TO_STRING = 'toString';
var $toString = Function[TO_STRING];
var TPL = ('' + $toString).split(TO_STRING);

_core.inspectSource = function (it) {
  return $toString.call(it);
};

(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) _has(val, 'name') || _hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) _has(val, SRC) || _hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === _global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    _hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    _hide(O, key, val);
  }
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});
});

var _aFunction = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};

// optional / simple context binding

var _ctx = function (fn, that, length) {
  _aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};

var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var target = IS_GLOBAL ? _global : IS_STATIC ? _global[name] || (_global[name] = {}) : (_global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? _core : _core[name] || (_core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? _ctx(out, _global) : IS_PROTO && typeof out == 'function' ? _ctx(Function.call, out) : out;
    // extend global
    if (target) _redefine(target, key, out, type & $export.U);
    // export
    if (exports[key] != out) _hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
_global.core = _core;
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
var _export = $export;

var toString = {}.toString;

var _cof = function (it) {
  return toString.call(it).slice(8, -1);
};

// fallback for non-array-like ES3 and non-enumerable old V8 strings

// eslint-disable-next-line no-prototype-builtins
var _iobject = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return _cof(it) == 'String' ? it.split('') : Object(it);
};

// 7.2.1 RequireObjectCoercible(argument)
var _defined = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};

// 7.1.13 ToObject(argument)

var _toObject = function (it) {
  return Object(_defined(it));
};

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
var _toInteger = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};

// 7.1.15 ToLength

var min = Math.min;
var _toLength = function (it) {
  return it > 0 ? min(_toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};

// 7.2.2 IsArray(argument)

var _isArray = Array.isArray || function isArray(arg) {
  return _cof(arg) == 'Array';
};

var _shared = createCommonjsModule(function (module) {
var SHARED = '__core-js_shared__';
var store = _global[SHARED] || (_global[SHARED] = {});

(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: _core.version,
  mode: 'global',
  copyright: '© 2018 Denis Pushkarev (zloirock.ru)'
});
});

var _wks = createCommonjsModule(function (module) {
var store = _shared('wks');

var Symbol = _global.Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : _uid)('Symbol.' + name));
};

$exports.store = store;
});

var SPECIES = _wks('species');

var _arraySpeciesConstructor = function (original) {
  var C;
  if (_isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || _isArray(C.prototype))) C = undefined;
    if (_isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)


var _arraySpeciesCreate = function (original, length) {
  return new (_arraySpeciesConstructor(original))(length);
};

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex





var _arrayMethods = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || _arraySpeciesCreate;
  return function ($this, callbackfn, that) {
    var O = _toObject($this);
    var self = _iobject(O);
    var f = _ctx(callbackfn, that, 3);
    var length = _toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};

var _strictMethod = function (method, arg) {
  return !!method && _fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () { /* empty */ }, 1) : method.call(null);
  });
};

var $filter = _arrayMethods(2);

_export(_export.P + _export.F * !_strictMethod([].filter, true), 'Array', {
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments[1]);
  }
});

var filter = _core.Array.filter;

var $map = _arrayMethods(1);

_export(_export.P + _export.F * !_strictMethod([].map, true), 'Array', {
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments[1]);
  }
});

var map = _core.Array.map;

var _stringWs = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
  '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';

var space = '[' + _stringWs + ']';
var non = '\u200b\u0085';
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');

var exporter = function (KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = _fails(function () {
    return !!_stringWs[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim) : _stringWs[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  _export(_export.P + _export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = exporter.trim = function (string, TYPE) {
  string = String(_defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};

var _stringTrim = exporter;

// 21.1.3.25 String.prototype.trim()
_stringTrim('trim', function ($trim) {
  return function trim() {
    return $trim(this, 3);
  };
});

var trim$1 = _core.String.trim;

var injectableNavigator = typeof window !== 'undefined'
    ? window.navigator
    : undefined;
var injectableProcess = typeof process !== 'undefined'
    ? process
    : undefined;
function browserDetect (userAgent) {
    var detector = new Detector(userAgent, injectableNavigator, injectableProcess);
    return detector.detect();
}

/* harmony default export */ __webpack_exports__["default"] = (browserDetect);
//# sourceMappingURL=browser-detect.es5.js.map

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../process/browser.js */ "./node_modules/process/browser.js")))

/***/ }),

/***/ "./node_modules/process/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/process/browser.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvYnJvd3Nlci1kZXRlY3QvZGlzdC9icm93c2VyLWRldGVjdC5lczUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3Byb2Nlc3MvYnJvd3Nlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUNBO0FBQ0EsK0RBQStEO0FBQy9EO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsNENBQTRDLE9BQU87QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUsscUNBQXFDO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsNENBQTRDLEVBQUU7QUFDekY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCwyQ0FBMkMseUJBQXlCLEVBQUU7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQjtBQUNwQixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQSxrQkFBa0IsWUFBWSxFQUFFO0FBQ2hDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QyxDQUFDOztBQUVEO0FBQ0EsNkJBQTZCO0FBQzdCLHVDQUF1QztBQUN2QyxDQUFDO0FBQ0Q7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGlDQUFpQyxRQUFRLG1CQUFtQixVQUFVLEVBQUUsRUFBRTtBQUMxRSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHdEQUF3RCxtQkFBbUIsVUFBVSxFQUFFLEVBQUU7QUFDekYsQ0FBQzs7QUFFRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLFlBQVk7QUFDZjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTs7QUFFQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQSxDQUFDO0FBQ0QsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUZBQXFGLHdCQUF3QjtBQUM3RyxvRUFBb0U7QUFDcEUsK0RBQStEO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZCxjQUFjO0FBQ2QsY0FBYztBQUNkLGNBQWM7QUFDZCxlQUFlO0FBQ2YsZUFBZTtBQUNmLGVBQWU7QUFDZixnQkFBZ0I7QUFDaEI7O0FBRUEsaUJBQWlCOztBQUVqQjtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSw0REFBNEQ7QUFDNUQ7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxvREFBb0Q7O0FBRXBEO0FBQ0EscUVBQXFFO0FBQ3JFLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsQ0FBQzs7QUFFRDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxDQUFDOztBQUVEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7OztBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSxlQUFlO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QztBQUNBLDhCQUE4QjtBQUM5Qiw2QkFBNkI7QUFDN0IsK0JBQStCO0FBQy9CLG1DQUFtQztBQUNuQyxTQUFTLGlDQUFpQztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxjQUFjO0FBQ3ZELEdBQUc7QUFDSDs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZSw0RUFBYSxFQUFDO0FBQzdCOzs7Ozs7Ozs7Ozs7O0FDbm9CQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEscUNBQXFDOztBQUVyQztBQUNBO0FBQ0E7O0FBRUEsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixVQUFVIiwiZmlsZSI6IjVjYWJhYTUyOWY3MWI0MTA1NWFiL3ZlbmRvcnN+QWx0ZXJDb25maXJtYXRpb25+QWx0ZXJPdXRwdXR+Q2FtcGFpZ25PdXRwdXR+Q29uZmlybWF0aW9ufkRpc2NsYWltZXJ+VmVyaWZpY2F0aW9ufmluZGV4LnZlbmRvcnN+QWx0ZXJDb25maXJtYXRpb25+QWx0ZXJPdXRwdXR+Q2FtcGFpZ25PdXRwdXR+Q29uZmlybWF0aW9ufkRpc2NsYWltZXJ+VmVyaWZpY2F0aW9ufmluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyohICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpOyB5b3UgbWF5IG5vdCB1c2VcclxudGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGVcclxuTGljZW5zZSBhdCBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuXHJcblRISVMgQ09ERSBJUyBQUk9WSURFRCBPTiBBTiAqQVMgSVMqIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcclxuS0lORCwgRUlUSEVSIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIFdJVEhPVVQgTElNSVRBVElPTiBBTlkgSU1QTElFRFxyXG5XQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgVElUTEUsIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLFxyXG5NRVJDSEFOVEFCTElUWSBPUiBOT04tSU5GUklOR0VNRU5ULlxyXG5cclxuU2VlIHRoZSBBcGFjaGUgVmVyc2lvbiAyLjAgTGljZW5zZSBmb3Igc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXHJcbmFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cclxuXHJcbnZhciBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gX19hc3NpZ24odCkge1xyXG4gICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcclxuICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpIHRbcF0gPSBzW3BdO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHQ7XHJcbn07XHJcblxyXG52YXIgYnJvd3NlcnMgPSBbXHJcbiAgICBbJ2ZpcmVmb3gnLCAvRmlyZWZveFxcLyhbMC05XFwuXSspKD86XFxzfCQpL10sXHJcbiAgICBbJ29wZXJhJywgL09wZXJhXFwvKFswLTlcXC5dKykoPzpcXHN8JCkvXSxcclxuICAgIFsnb3BlcmEnLCAvT1BSXFwvKFswLTlcXC5dKykoOj9cXHN8JCkkL10sXHJcbiAgICBbJ2VkZ2UnLCAvRWRnZVxcLyhbMC05XFwuX10rKS9dLFxyXG4gICAgWydpZScsIC9UcmlkZW50XFwvN1xcLjAuKnJ2XFw6KFswLTlcXC5dKylcXCkuKkdlY2tvJC9dLFxyXG4gICAgWydpZScsIC9NU0lFXFxzKFswLTlcXC5dKyk7LipUcmlkZW50XFwvWzQtN10uMC9dLFxyXG4gICAgWydpZScsIC9NU0lFXFxzKDdcXC4wKS9dLFxyXG4gICAgWydzYWZhcmknLCAvVmVyc2lvblxcLyhbMC05XFwuX10rKS4qU2FmYXJpL10sXHJcbiAgICBbJ2Nocm9tZScsIC8oPyFDaHJvbS4qT1BSKUNocm9tKD86ZXxpdW0pXFwvKFswLTlcXC5dKykoOj9cXHN8JCkvXSxcclxuICAgIFsnYmIxMCcsIC9CQjEwO1xcc1RvdWNoLipWZXJzaW9uXFwvKFswLTlcXC5dKykvXSxcclxuICAgIFsnYW5kcm9pZCcsIC9BbmRyb2lkXFxzKFswLTlcXC5dKykvXSxcclxuICAgIFsnaW9zJywgL1ZlcnNpb25cXC8oWzAtOVxcLl9dKykuKk1vYmlsZS4qU2FmYXJpLiovXSxcclxuICAgIFsneWFuZGV4YnJvd3NlcicsIC9ZYUJyb3dzZXJcXC8oWzAtOVxcLl9dKykvXSxcclxuICAgIFsnY3Jpb3MnLCAvQ3JpT1NcXC8oWzAtOVxcLl0rKSg6P1xcc3wkKS9dXHJcbl07XHJcbnZhciBvcyA9IFtcclxuICAgICdXaW5kb3dzIFBob25lJyxcclxuICAgICdBbmRyb2lkJyxcclxuICAgICdDZW50T1MnLFxyXG4gICAgeyBuYW1lOiAnQ2hyb21lIE9TJywgcGF0dGVybjogJ0NyT1MnIH0sXHJcbiAgICAnRGViaWFuJyxcclxuICAgICdGZWRvcmEnLFxyXG4gICAgJ0ZyZWVCU0QnLFxyXG4gICAgJ0dlbnRvbycsXHJcbiAgICAnSGFpa3UnLFxyXG4gICAgJ0t1YnVudHUnLFxyXG4gICAgJ0xpbnV4IE1pbnQnLFxyXG4gICAgJ09wZW5CU0QnLFxyXG4gICAgJ1JlZCBIYXQnLFxyXG4gICAgJ1N1U0UnLFxyXG4gICAgJ1VidW50dScsXHJcbiAgICAnWHVidW50dScsXHJcbiAgICAnQ3lnd2luJyxcclxuICAgICdTeW1iaWFuIE9TJyxcclxuICAgICdocHdPUycsXHJcbiAgICAnd2ViT1MgJyxcclxuICAgICd3ZWJPUycsXHJcbiAgICAnVGFibGV0IE9TJyxcclxuICAgICdUaXplbicsXHJcbiAgICAnTGludXgnLFxyXG4gICAgJ01hYyBPUyBYJyxcclxuICAgICdNYWNpbnRvc2gnLFxyXG4gICAgJ01hYycsXHJcbiAgICAnV2luZG93cyA5ODsnLFxyXG4gICAgJ1dpbmRvd3MgJ1xyXG5dO1xyXG52YXIgb3NWZXJzaW9ucyA9IHtcclxuICAgICcxMC4wJzogJzEwJyxcclxuICAgICc2LjQnOiAnMTAgVGVjaG5pY2FsIFByZXZpZXcnLFxyXG4gICAgJzYuMyc6ICc4LjEnLFxyXG4gICAgJzYuMic6ICc4JyxcclxuICAgICc2LjEnOiAnU2VydmVyIDIwMDggUjIgLyA3JyxcclxuICAgICc2LjAnOiAnU2VydmVyIDIwMDggLyBWaXN0YScsXHJcbiAgICAnNS4yJzogJ1NlcnZlciAyMDAzIC8gWFAgNjQtYml0JyxcclxuICAgICc1LjEnOiAnWFAnLFxyXG4gICAgJzUuMDEnOiAnMjAwMCBTUDEnLFxyXG4gICAgJzUuMCc6ICcyMDAwJyxcclxuICAgICc0LjAnOiAnTlQnLFxyXG4gICAgJzQuOTAnOiAnTUUnXHJcbn07XHJcblxyXG52YXIgbW9iaWxlUmVnRXhwID0gbmV3IFJlZ0V4cChbJyhhbmRyb2lkfGJiXFxcXGQrfG1lZWdvKS4rbW9iaWxlfGF2YW50Z298YmFkYVxcXFwvfGJsYWNrYmVycnl8YmxhemVyfCcsXHJcbiAgICAnY29tcGFsfGVsYWluZXxmZW5uZWN8aGlwdG9wfGllbW9iaWxlfGlwKGhvbmV8b2R8YWQpfGlyaXN8a2luZGxlfGxnZSB8bWFlbW98JyxcclxuICAgICdtaWRwfG1tcHxtb2JpbGUuK2ZpcmVmb3h8bmV0ZnJvbnR8b3BlcmEgbShvYnxpbilpfHBhbG0oIG9zKT98cGhvbmV8cChpeGl8cmUpJyxcclxuICAgICdcXFxcL3xwbHVja2VyfHBvY2tldHxwc3B8c2VyaWVzKDR8NikwfHN5bWJpYW58dHJlb3x1cFxcXFwuKGJyb3dzZXJ8bGluayl8dm9kYWZvbmV8JyxcclxuICAgICd3YXB8d2luZG93cyBjZXx4ZGF8eGlpbm8nXS5qb2luKCcnKSwgJ2knKTtcclxudmFyIG1vYmlsZVByZWZpeFJlZ0V4cCA9IG5ldyBSZWdFeHAoWycxMjA3fDYzMTB8NjU5MHwzZ3NvfDR0aHB8NTBbMS02XWl8Nzcwc3w4MDJzfGEgd2F8YWJhY3xhYyhlcnxvb3xzXFxcXC0pfCcsXHJcbiAgICAnYWkoa298cm4pfGFsKGF2fGNhfGNvKXxhbW9pfGFuKGV4fG55fHl3KXxhcHR1fGFyKGNofGdvKXxhcyh0ZXx1cyl8YXR0d3xhdShkaXxcXFxcLW18ciB8cyApfCcsXHJcbiAgICAnYXZhbnxiZShja3xsbHxucSl8YmkobGJ8cmQpfGJsKGFjfGF6KXxicihlfHYpd3xidW1ifGJ3XFxcXC0obnx1KXxjNTVcXFxcL3xjYXBpfGNjd2F8Y2RtXFxcXC18JyxcclxuICAgICdjZWxsfGNodG18Y2xkY3xjbWRcXFxcLXxjbyhtcHxuZCl8Y3Jhd3xkYShpdHxsbHxuZyl8ZGJ0ZXxkY1xcXFwtc3xkZXZpfGRpY2F8ZG1vYnxkbyhjfHApb3wnLFxyXG4gICAgJ2RzKDEyfFxcXFwtZCl8ZWwoNDl8YWkpfGVtKGwyfHVsKXxlcihpY3xrMCl8ZXNsOHxleihbNC03XTB8b3N8d2F8emUpfGZldGN8Zmx5KFxcXFwtfF8pfCcsXHJcbiAgICAnZzEgdXxnNTYwfGdlbmV8Z2ZcXFxcLTV8Z1xcXFwtbW98Z28oXFxcXC53fG9kKXxncihhZHx1bil8aGFpZXxoY2l0fGhkXFxcXC0obXxwfHQpfGhlaVxcXFwtfCcsXHJcbiAgICAnaGkocHR8dGEpfGhwKCBpfGlwKXxoc1xcXFwtY3xodChjKFxcXFwtfCB8X3xhfGd8cHxzfHQpfHRwKXxodShhd3x0Yyl8aVxcXFwtKDIwfGdvfG1hKXwnLFxyXG4gICAgJ2kyMzB8aWFjKCB8XFxcXC18XFxcXC8pfGlicm98aWRlYXxpZzAxfGlrb218aW0xa3xpbm5vfGlwYXF8aXJpc3xqYSh0fHYpYXxqYnJvfGplbXV8amlnc3wnLFxyXG4gICAgJ2tkZGl8a2VqaXxrZ3QoIHxcXFxcLyl8a2xvbnxrcHQgfGt3Y1xcXFwtfGt5byhjfGspfGxlKG5vfHhpKXxsZyggZ3xcXFxcLyhrfGx8dSl8NTB8NTR8XFxcXC1bYS13XSknLFxyXG4gICAgJ3xsaWJ3fGx5bnh8bTFcXFxcLXd8bTNnYXxtNTBcXFxcL3xtYSh0ZXx1aXx4byl8bWMoMDF8MjF8Y2EpfG1cXFxcLWNyfG1lKHJjfHJpKXxtaShvOHxvYXx0cyl8JyxcclxuICAgICdtbWVmfG1vKDAxfDAyfGJpfGRlfGRvfHQoXFxcXC18IHxvfHYpfHp6KXxtdCg1MHxwMXx2ICl8bXdicHxteXdhfG4xMFswLTJdfG4yMFsyLTNdfCcsXHJcbiAgICAnbjMwKDB8Mil8bjUwKDB8Mnw1KXxuNygwKDB8MSl8MTApfG5lKChjfG0pXFxcXC18b258dGZ8d2Z8d2d8d3QpfG5vayg2fGkpfG56cGh8bzJpbXwnLFxyXG4gICAgJ29wKHRpfHd2KXxvcmFufG93ZzF8cDgwMHxwYW4oYXxkfHQpfHBkeGd8cGcoMTN8XFxcXC0oWzEtOF18YykpfHBoaWx8cGlyZXxwbChheXx1Yyl8cG5cXFxcLTJ8JyxcclxuICAgICdwbyhja3xydHxzZSl8cHJveHxwc2lvfHB0XFxcXC1nfHFhXFxcXC1hfHFjKDA3fDEyfDIxfDMyfDYwfFxcXFwtWzItN118aVxcXFwtKXxxdGVrfHIzODB8cjYwMHwnLFxyXG4gICAgJ3Jha3N8cmltOXxybyh2ZXx6byl8czU1XFxcXC98c2EoZ2V8bWF8bW18bXN8bnl8dmEpfHNjKDAxfGhcXFxcLXxvb3xwXFxcXC0pfHNka1xcXFwvfCcsXHJcbiAgICAnc2UoYyhcXFxcLXwwfDEpfDQ3fG1jfG5kfHJpKXxzZ2hcXFxcLXxzaGFyfHNpZShcXFxcLXxtKXxrXFxcXC0wfHNsKDQ1fGlkKXxzbShhbHxhcnxiM3xpdHx0NSl8JyxcclxuICAgICdzbyhmdHxueSl8c3AoMDF8aFxcXFwtfHZcXFxcLXx2ICl8c3koMDF8bWIpfHQyKDE4fDUwKXx0NigwMHwxMHwxOCl8dGEoZ3R8bGspfHRjbFxcXFwtfHRkZ1xcXFwtfCcsXHJcbiAgICAndGVsKGl8bSl8dGltXFxcXC18dFxcXFwtbW98dG8ocGx8c2gpfHRzKDcwfG1cXFxcLXxtM3xtNSl8dHhcXFxcLTl8dXAoXFxcXC5ifGcxfHNpKXx1dHN0fHY0MDB8djc1MHwnLFxyXG4gICAgJ3Zlcml8dmkocmd8dGUpfHZrKDQwfDVbMC0zXXxcXFxcLXYpfHZtNDB8dm9kYXx2dWxjfHZ4KDUyfDUzfDYwfDYxfDcwfDgwfDgxfDgzfDg1fDk4KXwnLFxyXG4gICAgJ3czYyhcXFxcLXwgKXx3ZWJjfHdoaXR8d2koZyB8bmN8bncpfHdtbGJ8d29udXx4NzAwfHlhc1xcXFwtfHlvdXJ8emV0b3x6dGVcXFxcLSddLmpvaW4oJycpLCAnaScpO1xyXG5cclxudmFyIERldGVjdG9yID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xyXG4gICAgZnVuY3Rpb24gRGV0ZWN0b3IodXNlckFnZW50LCBuYXZpZ2F0b3IsIHByb2Nlc3MpIHtcclxuICAgICAgICB0aGlzLm5hdmlnYXRvciA9IG5hdmlnYXRvcjtcclxuICAgICAgICB0aGlzLnByb2Nlc3MgPSBwcm9jZXNzO1xyXG4gICAgICAgIHRoaXMudXNlckFnZW50ID0gdXNlckFnZW50XHJcbiAgICAgICAgICAgID8gdXNlckFnZW50XHJcbiAgICAgICAgICAgIDogdGhpcy5uYXZpZ2F0b3IgPyAobmF2aWdhdG9yLnVzZXJBZ2VudCB8fCBuYXZpZ2F0b3IudmVuZG9yKSA6ICcnO1xyXG4gICAgfVxyXG4gICAgRGV0ZWN0b3IucHJvdG90eXBlLmRldGVjdCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBpZiAodGhpcy5wcm9jZXNzICYmICF0aGlzLnVzZXJBZ2VudCkge1xyXG4gICAgICAgICAgICB2YXIgdmVyc2lvbiA9IHRoaXMucHJvY2Vzcy52ZXJzaW9uLnNsaWNlKDEpLnNwbGl0KCcuJykuc2xpY2UoMCwgMyk7XHJcbiAgICAgICAgICAgIHZhciB2ZXJzaW9uVGFpbCA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKHZlcnNpb24sIDEpLmpvaW4oJycpIHx8ICcwJztcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICdub2RlJyxcclxuICAgICAgICAgICAgICAgIHZlcnNpb246IHZlcnNpb24uam9pbignLicpLFxyXG4gICAgICAgICAgICAgICAgdmVyc2lvbk51bWJlcjogcGFyc2VGbG9hdCh2ZXJzaW9uWzBdICsgXCIuXCIgKyB2ZXJzaW9uVGFpbCksXHJcbiAgICAgICAgICAgICAgICBtb2JpbGU6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgb3M6IHRoaXMucHJvY2Vzcy5wbGF0Zm9ybVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMudXNlckFnZW50KVxyXG4gICAgICAgICAgICB0aGlzLmhhbmRsZU1pc3NpbmdFcnJvcigpO1xyXG4gICAgICAgIHJldHVybiBfX2Fzc2lnbih7fSwgdGhpcy5jaGVja0Jyb3dzZXIoKSwgdGhpcy5jaGVja01vYmlsZSgpLCB0aGlzLmNoZWNrT3MoKSk7XHJcbiAgICB9O1xyXG4gICAgRGV0ZWN0b3IucHJvdG90eXBlLmNoZWNrQnJvd3NlciA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xyXG4gICAgICAgIHJldHVybiBicm93c2Vyc1xyXG4gICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChkZWZpbml0aW9uKSB7IHJldHVybiBkZWZpbml0aW9uWzFdLnRlc3QoX3RoaXMudXNlckFnZW50KTsgfSlcclxuICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoZGVmaW5pdGlvbikge1xyXG4gICAgICAgICAgICB2YXIgbWF0Y2ggPSBkZWZpbml0aW9uWzFdLmV4ZWMoX3RoaXMudXNlckFnZW50KTtcclxuICAgICAgICAgICAgdmFyIHZlcnNpb24gPSBtYXRjaCAmJiBtYXRjaFsxXS5zcGxpdCgvWy5fXS8pLnNsaWNlKDAsIDMpO1xyXG4gICAgICAgICAgICB2YXIgdmVyc2lvblRhaWxzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwodmVyc2lvbiwgMSkuam9pbignJykgfHwgJzAnO1xyXG4gICAgICAgICAgICBpZiAodmVyc2lvbiAmJiB2ZXJzaW9uLmxlbmd0aCA8IDMpXHJcbiAgICAgICAgICAgICAgICBBcnJheS5wcm90b3R5cGUucHVzaC5hcHBseSh2ZXJzaW9uLCB2ZXJzaW9uLmxlbmd0aCA9PT0gMSA/IFswLCAwXSA6IFswXSk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiBTdHJpbmcoZGVmaW5pdGlvblswXSksXHJcbiAgICAgICAgICAgICAgICB2ZXJzaW9uOiB2ZXJzaW9uLmpvaW4oJy4nKSxcclxuICAgICAgICAgICAgICAgIHZlcnNpb25OdW1iZXI6IE51bWJlcih2ZXJzaW9uWzBdICsgXCIuXCIgKyB2ZXJzaW9uVGFpbHMpXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSlcclxuICAgICAgICAgICAgLnNoaWZ0KCk7XHJcbiAgICB9O1xyXG4gICAgRGV0ZWN0b3IucHJvdG90eXBlLmNoZWNrTW9iaWxlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBhZ2VudFByZWZpeCA9IHRoaXMudXNlckFnZW50LnN1YnN0cigwLCA0KTtcclxuICAgICAgICB2YXIgbW9iaWxlID0gbW9iaWxlUmVnRXhwLnRlc3QodGhpcy51c2VyQWdlbnQpIHx8IG1vYmlsZVByZWZpeFJlZ0V4cC50ZXN0KGFnZW50UHJlZml4KTtcclxuICAgICAgICByZXR1cm4geyBtb2JpbGU6IG1vYmlsZSB9O1xyXG4gICAgfTtcclxuICAgIERldGVjdG9yLnByb3RvdHlwZS5jaGVja09zID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XHJcbiAgICAgICAgcmV0dXJuIG9zXHJcbiAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGRlZmluaXRpb24pIHtcclxuICAgICAgICAgICAgdmFyIG5hbWUgPSBkZWZpbml0aW9uLm5hbWUgfHwgZGVmaW5pdGlvbjtcclxuICAgICAgICAgICAgdmFyIHBhdHRlcm4gPSBfdGhpcy5nZXRPc1BhdHRlcm4oZGVmaW5pdGlvbik7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxyXG4gICAgICAgICAgICAgICAgcGF0dGVybjogcGF0dGVybixcclxuICAgICAgICAgICAgICAgIHZhbHVlOiBSZWdFeHAoXCJcXFxcYlwiICsgcGF0dGVybi5yZXBsYWNlKC8oWyAtXSkoPyEkKS9nLCAnJDE/JykgKyBcIig/Ong/W1xcXFxkLl9dK3xbIFxcXFx3Ll0qKVwiLCAnaScpLmV4ZWMoX3RoaXMudXNlckFnZW50KVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKGRlZmluaXRpb24pIHsgcmV0dXJuIGRlZmluaXRpb24udmFsdWU7IH0pXHJcbiAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGRlZmluaXRpb24pIHtcclxuICAgICAgICAgICAgdmFyIG9zJCQxID0gZGVmaW5pdGlvbi52YWx1ZVswXSB8fCAnJztcclxuICAgICAgICAgICAgdmFyIG9zU3VmZml4O1xyXG4gICAgICAgICAgICBpZiAoZGVmaW5pdGlvbi5wYXR0ZXJuICYmXHJcbiAgICAgICAgICAgICAgICBkZWZpbml0aW9uLm5hbWUgJiZcclxuICAgICAgICAgICAgICAgIC9eV2luL2kudGVzdChvcyQkMSkgJiZcclxuICAgICAgICAgICAgICAgICEvXldpbmRvd3MgUGhvbmUgL2kudGVzdChvcyQkMSkgJiZcclxuICAgICAgICAgICAgICAgIChvc1N1ZmZpeCA9IG9zVmVyc2lvbnNbb3MkJDEucmVwbGFjZSgvW15cXGQuXS9nLCAnJyldKSlcclxuICAgICAgICAgICAgICAgIG9zJCQxID0gXCJXaW5kb3dzIFwiICsgb3NTdWZmaXg7XHJcbiAgICAgICAgICAgIGlmIChkZWZpbml0aW9uLnBhdHRlcm4gJiYgZGVmaW5pdGlvbi5uYW1lKVxyXG4gICAgICAgICAgICAgICAgb3MkJDEgPSBvcyQkMS5yZXBsYWNlKFJlZ0V4cChkZWZpbml0aW9uLnBhdHRlcm4sICdpJyksIGRlZmluaXRpb24ubmFtZSk7XHJcbiAgICAgICAgICAgIG9zJCQxID0gb3MkJDFcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8gY2UkL2ksICcgQ0UnKVxyXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcYmhwdy9pLCAnd2ViJylcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXGJNYWNpbnRvc2hcXGIvLCAnTWFjIE9TJylcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9fUG93ZXJQQ1xcYi9pLCAnIE9TJylcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXGIoT1MgWCkgW14gXFxkXSsvaSwgJyQxJylcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXGJNYWMgKE9TIFgpXFxiLywgJyQxJylcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXC8oXFxkKS8sICcgJDEnKVxyXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoL18vZywgJy4nKVxyXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoLyg/OiBCZVBDfFsgLl0qZmNbIFxcZC5dKykkL2ksICcnKVxyXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcYng4NlxcLjY0XFxiL2dpLCAneDg2XzY0JylcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXGIoV2luZG93cyBQaG9uZSkgT1NcXGIvLCAnJDEnKVxyXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcYihDaHJvbWUgT1MgXFx3KykgW1xcZC5dK1xcYi8sICckMScpXHJcbiAgICAgICAgICAgICAgICAuc3BsaXQoJyBvbiAnKVswXVxyXG4gICAgICAgICAgICAgICAgLnRyaW0oKTtcclxuICAgICAgICAgICAgb3MkJDEgPSAvXig/OndlYk9TfGkoPzpPU3xQKSkvLnRlc3Qob3MkJDEpXHJcbiAgICAgICAgICAgICAgICA/IG9zJCQxXHJcbiAgICAgICAgICAgICAgICA6IChvcyQkMS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIG9zJCQxLnNsaWNlKDEpKTtcclxuICAgICAgICAgICAgcmV0dXJuIHsgb3M6IG9zJCQxIH07XHJcbiAgICAgICAgfSlcclxuICAgICAgICAgICAgLnNoaWZ0KCk7XHJcbiAgICB9O1xyXG4gICAgRGV0ZWN0b3IucHJvdG90eXBlLmdldE9zUGF0dGVybiA9IGZ1bmN0aW9uIChkZWZpbml0aW9uKSB7XHJcbiAgICAgICAgdmFyIGRlZmluaXRpb25JbnRlcmZhY2UgPSBkZWZpbml0aW9uO1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIGRlZmluaXRpb24gPT09ICdzdHJpbmcnXHJcbiAgICAgICAgICAgID8gZGVmaW5pdGlvblxyXG4gICAgICAgICAgICA6IHVuZGVmaW5lZCkgfHxcclxuICAgICAgICAgICAgZGVmaW5pdGlvbkludGVyZmFjZS5wYXR0ZXJuIHx8XHJcbiAgICAgICAgICAgIGRlZmluaXRpb25JbnRlcmZhY2UubmFtZTtcclxuICAgIH07XHJcbiAgICBEZXRlY3Rvci5wcm90b3R5cGUuaGFuZGxlTWlzc2luZ0Vycm9yID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUGxlYXNlIGdpdmUgdXNlci1hZ2VudC5cXG4+IGJyb3dzZXIobmF2aWdhdG9yLnVzZXJBZ2VudCBvciByZXMuaGVhZGVyc1tcXCd1c2VyLWFnZW50XFwnXSkuJyk7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIERldGVjdG9yO1xyXG59KCkpO1xyXG5cclxuZnVuY3Rpb24gY3JlYXRlQ29tbW9uanNNb2R1bGUoZm4sIG1vZHVsZSkge1xyXG5cdHJldHVybiBtb2R1bGUgPSB7IGV4cG9ydHM6IHt9IH0sIGZuKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMpLCBtb2R1bGUuZXhwb3J0cztcclxufVxyXG5cclxudmFyIF9nbG9iYWwgPSBjcmVhdGVDb21tb25qc01vZHVsZShmdW5jdGlvbiAobW9kdWxlKSB7XHJcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS96bG9pcm9jay9jb3JlLWpzL2lzc3Vlcy84NiNpc3N1ZWNvbW1lbnQtMTE1NzU5MDI4XHJcbnZhciBnbG9iYWwgPSBtb2R1bGUuZXhwb3J0cyA9IHR5cGVvZiB3aW5kb3cgIT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93Lk1hdGggPT0gTWF0aFxyXG4gID8gd2luZG93IDogdHlwZW9mIHNlbGYgIT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5NYXRoID09IE1hdGggPyBzZWxmXHJcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLW5ldy1mdW5jXHJcbiAgOiBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xyXG5pZiAodHlwZW9mIF9fZyA9PSAnbnVtYmVyJykgX19nID0gZ2xvYmFsOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVuZGVmXHJcbn0pO1xyXG5cclxudmFyIF9jb3JlID0gY3JlYXRlQ29tbW9uanNNb2R1bGUoZnVuY3Rpb24gKG1vZHVsZSkge1xyXG52YXIgY29yZSA9IG1vZHVsZS5leHBvcnRzID0geyB2ZXJzaW9uOiAnMi41LjcnIH07XHJcbmlmICh0eXBlb2YgX19lID09ICdudW1iZXInKSBfX2UgPSBjb3JlOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVuZGVmXHJcbn0pO1xyXG52YXIgX2NvcmVfMSA9IF9jb3JlLnZlcnNpb247XHJcblxyXG52YXIgX2lzT2JqZWN0ID0gZnVuY3Rpb24gKGl0KSB7XHJcbiAgcmV0dXJuIHR5cGVvZiBpdCA9PT0gJ29iamVjdCcgPyBpdCAhPT0gbnVsbCA6IHR5cGVvZiBpdCA9PT0gJ2Z1bmN0aW9uJztcclxufTtcclxuXHJcbnZhciBfYW5PYmplY3QgPSBmdW5jdGlvbiAoaXQpIHtcclxuICBpZiAoIV9pc09iamVjdChpdCkpIHRocm93IFR5cGVFcnJvcihpdCArICcgaXMgbm90IGFuIG9iamVjdCEnKTtcclxuICByZXR1cm4gaXQ7XHJcbn07XHJcblxyXG52YXIgX2ZhaWxzID0gZnVuY3Rpb24gKGV4ZWMpIHtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuICEhZXhlYygpO1xyXG4gIH0gY2F0Y2ggKGUpIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxufTtcclxuXHJcbi8vIFRoYW5rJ3MgSUU4IGZvciBoaXMgZnVubnkgZGVmaW5lUHJvcGVydHlcclxudmFyIF9kZXNjcmlwdG9ycyA9ICFfZmFpbHMoZnVuY3Rpb24gKCkge1xyXG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoe30sICdhJywgeyBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIDc7IH0gfSkuYSAhPSA3O1xyXG59KTtcclxuXHJcbnZhciBkb2N1bWVudCA9IF9nbG9iYWwuZG9jdW1lbnQ7XHJcbi8vIHR5cGVvZiBkb2N1bWVudC5jcmVhdGVFbGVtZW50IGlzICdvYmplY3QnIGluIG9sZCBJRVxyXG52YXIgaXMgPSBfaXNPYmplY3QoZG9jdW1lbnQpICYmIF9pc09iamVjdChkb2N1bWVudC5jcmVhdGVFbGVtZW50KTtcclxudmFyIF9kb21DcmVhdGUgPSBmdW5jdGlvbiAoaXQpIHtcclxuICByZXR1cm4gaXMgPyBkb2N1bWVudC5jcmVhdGVFbGVtZW50KGl0KSA6IHt9O1xyXG59O1xyXG5cclxudmFyIF9pZThEb21EZWZpbmUgPSAhX2Rlc2NyaXB0b3JzICYmICFfZmFpbHMoZnVuY3Rpb24gKCkge1xyXG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoX2RvbUNyZWF0ZSgnZGl2JyksICdhJywgeyBnZXQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIDc7IH0gfSkuYSAhPSA3O1xyXG59KTtcclxuXHJcbi8vIDcuMS4xIFRvUHJpbWl0aXZlKGlucHV0IFssIFByZWZlcnJlZFR5cGVdKVxyXG5cclxuLy8gaW5zdGVhZCBvZiB0aGUgRVM2IHNwZWMgdmVyc2lvbiwgd2UgZGlkbid0IGltcGxlbWVudCBAQHRvUHJpbWl0aXZlIGNhc2VcclxuLy8gYW5kIHRoZSBzZWNvbmQgYXJndW1lbnQgLSBmbGFnIC0gcHJlZmVycmVkIHR5cGUgaXMgYSBzdHJpbmdcclxudmFyIF90b1ByaW1pdGl2ZSA9IGZ1bmN0aW9uIChpdCwgUykge1xyXG4gIGlmICghX2lzT2JqZWN0KGl0KSkgcmV0dXJuIGl0O1xyXG4gIHZhciBmbiwgdmFsO1xyXG4gIGlmIChTICYmIHR5cGVvZiAoZm4gPSBpdC50b1N0cmluZykgPT0gJ2Z1bmN0aW9uJyAmJiAhX2lzT2JqZWN0KHZhbCA9IGZuLmNhbGwoaXQpKSkgcmV0dXJuIHZhbDtcclxuICBpZiAodHlwZW9mIChmbiA9IGl0LnZhbHVlT2YpID09ICdmdW5jdGlvbicgJiYgIV9pc09iamVjdCh2YWwgPSBmbi5jYWxsKGl0KSkpIHJldHVybiB2YWw7XHJcbiAgaWYgKCFTICYmIHR5cGVvZiAoZm4gPSBpdC50b1N0cmluZykgPT0gJ2Z1bmN0aW9uJyAmJiAhX2lzT2JqZWN0KHZhbCA9IGZuLmNhbGwoaXQpKSkgcmV0dXJuIHZhbDtcclxuICB0aHJvdyBUeXBlRXJyb3IoXCJDYW4ndCBjb252ZXJ0IG9iamVjdCB0byBwcmltaXRpdmUgdmFsdWVcIik7XHJcbn07XHJcblxyXG52YXIgZFAgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XHJcblxyXG52YXIgZiA9IF9kZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSA6IGZ1bmN0aW9uIGRlZmluZVByb3BlcnR5KE8sIFAsIEF0dHJpYnV0ZXMpIHtcclxuICBfYW5PYmplY3QoTyk7XHJcbiAgUCA9IF90b1ByaW1pdGl2ZShQLCB0cnVlKTtcclxuICBfYW5PYmplY3QoQXR0cmlidXRlcyk7XHJcbiAgaWYgKF9pZThEb21EZWZpbmUpIHRyeSB7XHJcbiAgICByZXR1cm4gZFAoTywgUCwgQXR0cmlidXRlcyk7XHJcbiAgfSBjYXRjaCAoZSkgeyAvKiBlbXB0eSAqLyB9XHJcbiAgaWYgKCdnZXQnIGluIEF0dHJpYnV0ZXMgfHwgJ3NldCcgaW4gQXR0cmlidXRlcykgdGhyb3cgVHlwZUVycm9yKCdBY2Nlc3NvcnMgbm90IHN1cHBvcnRlZCEnKTtcclxuICBpZiAoJ3ZhbHVlJyBpbiBBdHRyaWJ1dGVzKSBPW1BdID0gQXR0cmlidXRlcy52YWx1ZTtcclxuICByZXR1cm4gTztcclxufTtcclxuXHJcbnZhciBfb2JqZWN0RHAgPSB7XHJcblx0ZjogZlxyXG59O1xyXG5cclxudmFyIF9wcm9wZXJ0eURlc2MgPSBmdW5jdGlvbiAoYml0bWFwLCB2YWx1ZSkge1xyXG4gIHJldHVybiB7XHJcbiAgICBlbnVtZXJhYmxlOiAhKGJpdG1hcCAmIDEpLFxyXG4gICAgY29uZmlndXJhYmxlOiAhKGJpdG1hcCAmIDIpLFxyXG4gICAgd3JpdGFibGU6ICEoYml0bWFwICYgNCksXHJcbiAgICB2YWx1ZTogdmFsdWVcclxuICB9O1xyXG59O1xyXG5cclxudmFyIF9oaWRlID0gX2Rlc2NyaXB0b3JzID8gZnVuY3Rpb24gKG9iamVjdCwga2V5LCB2YWx1ZSkge1xyXG4gIHJldHVybiBfb2JqZWN0RHAuZihvYmplY3QsIGtleSwgX3Byb3BlcnR5RGVzYygxLCB2YWx1ZSkpO1xyXG59IDogZnVuY3Rpb24gKG9iamVjdCwga2V5LCB2YWx1ZSkge1xyXG4gIG9iamVjdFtrZXldID0gdmFsdWU7XHJcbiAgcmV0dXJuIG9iamVjdDtcclxufTtcclxuXHJcbnZhciBoYXNPd25Qcm9wZXJ0eSA9IHt9Lmhhc093blByb3BlcnR5O1xyXG52YXIgX2hhcyA9IGZ1bmN0aW9uIChpdCwga2V5KSB7XHJcbiAgcmV0dXJuIGhhc093blByb3BlcnR5LmNhbGwoaXQsIGtleSk7XHJcbn07XHJcblxyXG52YXIgaWQgPSAwO1xyXG52YXIgcHggPSBNYXRoLnJhbmRvbSgpO1xyXG52YXIgX3VpZCA9IGZ1bmN0aW9uIChrZXkpIHtcclxuICByZXR1cm4gJ1N5bWJvbCgnLmNvbmNhdChrZXkgPT09IHVuZGVmaW5lZCA/ICcnIDoga2V5LCAnKV8nLCAoKytpZCArIHB4KS50b1N0cmluZygzNikpO1xyXG59O1xyXG5cclxudmFyIF9yZWRlZmluZSA9IGNyZWF0ZUNvbW1vbmpzTW9kdWxlKGZ1bmN0aW9uIChtb2R1bGUpIHtcclxudmFyIFNSQyA9IF91aWQoJ3NyYycpO1xyXG52YXIgVE9fU1RSSU5HID0gJ3RvU3RyaW5nJztcclxudmFyICR0b1N0cmluZyA9IEZ1bmN0aW9uW1RPX1NUUklOR107XHJcbnZhciBUUEwgPSAoJycgKyAkdG9TdHJpbmcpLnNwbGl0KFRPX1NUUklORyk7XHJcblxyXG5fY29yZS5pbnNwZWN0U291cmNlID0gZnVuY3Rpb24gKGl0KSB7XHJcbiAgcmV0dXJuICR0b1N0cmluZy5jYWxsKGl0KTtcclxufTtcclxuXHJcbihtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChPLCBrZXksIHZhbCwgc2FmZSkge1xyXG4gIHZhciBpc0Z1bmN0aW9uID0gdHlwZW9mIHZhbCA9PSAnZnVuY3Rpb24nO1xyXG4gIGlmIChpc0Z1bmN0aW9uKSBfaGFzKHZhbCwgJ25hbWUnKSB8fCBfaGlkZSh2YWwsICduYW1lJywga2V5KTtcclxuICBpZiAoT1trZXldID09PSB2YWwpIHJldHVybjtcclxuICBpZiAoaXNGdW5jdGlvbikgX2hhcyh2YWwsIFNSQykgfHwgX2hpZGUodmFsLCBTUkMsIE9ba2V5XSA/ICcnICsgT1trZXldIDogVFBMLmpvaW4oU3RyaW5nKGtleSkpKTtcclxuICBpZiAoTyA9PT0gX2dsb2JhbCkge1xyXG4gICAgT1trZXldID0gdmFsO1xyXG4gIH0gZWxzZSBpZiAoIXNhZmUpIHtcclxuICAgIGRlbGV0ZSBPW2tleV07XHJcbiAgICBfaGlkZShPLCBrZXksIHZhbCk7XHJcbiAgfSBlbHNlIGlmIChPW2tleV0pIHtcclxuICAgIE9ba2V5XSA9IHZhbDtcclxuICB9IGVsc2Uge1xyXG4gICAgX2hpZGUoTywga2V5LCB2YWwpO1xyXG4gIH1cclxuLy8gYWRkIGZha2UgRnVuY3Rpb24jdG9TdHJpbmcgZm9yIGNvcnJlY3Qgd29yayB3cmFwcGVkIG1ldGhvZHMgLyBjb25zdHJ1Y3RvcnMgd2l0aCBtZXRob2RzIGxpa2UgTG9EYXNoIGlzTmF0aXZlXHJcbn0pKEZ1bmN0aW9uLnByb3RvdHlwZSwgVE9fU1RSSU5HLCBmdW5jdGlvbiB0b1N0cmluZygpIHtcclxuICByZXR1cm4gdHlwZW9mIHRoaXMgPT0gJ2Z1bmN0aW9uJyAmJiB0aGlzW1NSQ10gfHwgJHRvU3RyaW5nLmNhbGwodGhpcyk7XHJcbn0pO1xyXG59KTtcclxuXHJcbnZhciBfYUZ1bmN0aW9uID0gZnVuY3Rpb24gKGl0KSB7XHJcbiAgaWYgKHR5cGVvZiBpdCAhPSAnZnVuY3Rpb24nKSB0aHJvdyBUeXBlRXJyb3IoaXQgKyAnIGlzIG5vdCBhIGZ1bmN0aW9uIScpO1xyXG4gIHJldHVybiBpdDtcclxufTtcclxuXHJcbi8vIG9wdGlvbmFsIC8gc2ltcGxlIGNvbnRleHQgYmluZGluZ1xyXG5cclxudmFyIF9jdHggPSBmdW5jdGlvbiAoZm4sIHRoYXQsIGxlbmd0aCkge1xyXG4gIF9hRnVuY3Rpb24oZm4pO1xyXG4gIGlmICh0aGF0ID09PSB1bmRlZmluZWQpIHJldHVybiBmbjtcclxuICBzd2l0Y2ggKGxlbmd0aCkge1xyXG4gICAgY2FzZSAxOiByZXR1cm4gZnVuY3Rpb24gKGEpIHtcclxuICAgICAgcmV0dXJuIGZuLmNhbGwodGhhdCwgYSk7XHJcbiAgICB9O1xyXG4gICAgY2FzZSAyOiByZXR1cm4gZnVuY3Rpb24gKGEsIGIpIHtcclxuICAgICAgcmV0dXJuIGZuLmNhbGwodGhhdCwgYSwgYik7XHJcbiAgICB9O1xyXG4gICAgY2FzZSAzOiByZXR1cm4gZnVuY3Rpb24gKGEsIGIsIGMpIHtcclxuICAgICAgcmV0dXJuIGZuLmNhbGwodGhhdCwgYSwgYiwgYyk7XHJcbiAgICB9O1xyXG4gIH1cclxuICByZXR1cm4gZnVuY3Rpb24gKC8qIC4uLmFyZ3MgKi8pIHtcclxuICAgIHJldHVybiBmbi5hcHBseSh0aGF0LCBhcmd1bWVudHMpO1xyXG4gIH07XHJcbn07XHJcblxyXG52YXIgUFJPVE9UWVBFID0gJ3Byb3RvdHlwZSc7XHJcblxyXG52YXIgJGV4cG9ydCA9IGZ1bmN0aW9uICh0eXBlLCBuYW1lLCBzb3VyY2UpIHtcclxuICB2YXIgSVNfRk9SQ0VEID0gdHlwZSAmICRleHBvcnQuRjtcclxuICB2YXIgSVNfR0xPQkFMID0gdHlwZSAmICRleHBvcnQuRztcclxuICB2YXIgSVNfU1RBVElDID0gdHlwZSAmICRleHBvcnQuUztcclxuICB2YXIgSVNfUFJPVE8gPSB0eXBlICYgJGV4cG9ydC5QO1xyXG4gIHZhciBJU19CSU5EID0gdHlwZSAmICRleHBvcnQuQjtcclxuICB2YXIgdGFyZ2V0ID0gSVNfR0xPQkFMID8gX2dsb2JhbCA6IElTX1NUQVRJQyA/IF9nbG9iYWxbbmFtZV0gfHwgKF9nbG9iYWxbbmFtZV0gPSB7fSkgOiAoX2dsb2JhbFtuYW1lXSB8fCB7fSlbUFJPVE9UWVBFXTtcclxuICB2YXIgZXhwb3J0cyA9IElTX0dMT0JBTCA/IF9jb3JlIDogX2NvcmVbbmFtZV0gfHwgKF9jb3JlW25hbWVdID0ge30pO1xyXG4gIHZhciBleHBQcm90byA9IGV4cG9ydHNbUFJPVE9UWVBFXSB8fCAoZXhwb3J0c1tQUk9UT1RZUEVdID0ge30pO1xyXG4gIHZhciBrZXksIG93biwgb3V0LCBleHA7XHJcbiAgaWYgKElTX0dMT0JBTCkgc291cmNlID0gbmFtZTtcclxuICBmb3IgKGtleSBpbiBzb3VyY2UpIHtcclxuICAgIC8vIGNvbnRhaW5zIGluIG5hdGl2ZVxyXG4gICAgb3duID0gIUlTX0ZPUkNFRCAmJiB0YXJnZXQgJiYgdGFyZ2V0W2tleV0gIT09IHVuZGVmaW5lZDtcclxuICAgIC8vIGV4cG9ydCBuYXRpdmUgb3IgcGFzc2VkXHJcbiAgICBvdXQgPSAob3duID8gdGFyZ2V0IDogc291cmNlKVtrZXldO1xyXG4gICAgLy8gYmluZCB0aW1lcnMgdG8gZ2xvYmFsIGZvciBjYWxsIGZyb20gZXhwb3J0IGNvbnRleHRcclxuICAgIGV4cCA9IElTX0JJTkQgJiYgb3duID8gX2N0eChvdXQsIF9nbG9iYWwpIDogSVNfUFJPVE8gJiYgdHlwZW9mIG91dCA9PSAnZnVuY3Rpb24nID8gX2N0eChGdW5jdGlvbi5jYWxsLCBvdXQpIDogb3V0O1xyXG4gICAgLy8gZXh0ZW5kIGdsb2JhbFxyXG4gICAgaWYgKHRhcmdldCkgX3JlZGVmaW5lKHRhcmdldCwga2V5LCBvdXQsIHR5cGUgJiAkZXhwb3J0LlUpO1xyXG4gICAgLy8gZXhwb3J0XHJcbiAgICBpZiAoZXhwb3J0c1trZXldICE9IG91dCkgX2hpZGUoZXhwb3J0cywga2V5LCBleHApO1xyXG4gICAgaWYgKElTX1BST1RPICYmIGV4cFByb3RvW2tleV0gIT0gb3V0KSBleHBQcm90b1trZXldID0gb3V0O1xyXG4gIH1cclxufTtcclxuX2dsb2JhbC5jb3JlID0gX2NvcmU7XHJcbi8vIHR5cGUgYml0bWFwXHJcbiRleHBvcnQuRiA9IDE7ICAgLy8gZm9yY2VkXHJcbiRleHBvcnQuRyA9IDI7ICAgLy8gZ2xvYmFsXHJcbiRleHBvcnQuUyA9IDQ7ICAgLy8gc3RhdGljXHJcbiRleHBvcnQuUCA9IDg7ICAgLy8gcHJvdG9cclxuJGV4cG9ydC5CID0gMTY7ICAvLyBiaW5kXHJcbiRleHBvcnQuVyA9IDMyOyAgLy8gd3JhcFxyXG4kZXhwb3J0LlUgPSA2NDsgIC8vIHNhZmVcclxuJGV4cG9ydC5SID0gMTI4OyAvLyByZWFsIHByb3RvIG1ldGhvZCBmb3IgYGxpYnJhcnlgXHJcbnZhciBfZXhwb3J0ID0gJGV4cG9ydDtcclxuXHJcbnZhciB0b1N0cmluZyA9IHt9LnRvU3RyaW5nO1xyXG5cclxudmFyIF9jb2YgPSBmdW5jdGlvbiAoaXQpIHtcclxuICByZXR1cm4gdG9TdHJpbmcuY2FsbChpdCkuc2xpY2UoOCwgLTEpO1xyXG59O1xyXG5cclxuLy8gZmFsbGJhY2sgZm9yIG5vbi1hcnJheS1saWtlIEVTMyBhbmQgbm9uLWVudW1lcmFibGUgb2xkIFY4IHN0cmluZ3NcclxuXHJcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wcm90b3R5cGUtYnVpbHRpbnNcclxudmFyIF9pb2JqZWN0ID0gT2JqZWN0KCd6JykucHJvcGVydHlJc0VudW1lcmFibGUoMCkgPyBPYmplY3QgOiBmdW5jdGlvbiAoaXQpIHtcclxuICByZXR1cm4gX2NvZihpdCkgPT0gJ1N0cmluZycgPyBpdC5zcGxpdCgnJykgOiBPYmplY3QoaXQpO1xyXG59O1xyXG5cclxuLy8gNy4yLjEgUmVxdWlyZU9iamVjdENvZXJjaWJsZShhcmd1bWVudClcclxudmFyIF9kZWZpbmVkID0gZnVuY3Rpb24gKGl0KSB7XHJcbiAgaWYgKGl0ID09IHVuZGVmaW5lZCkgdGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY2FsbCBtZXRob2Qgb24gIFwiICsgaXQpO1xyXG4gIHJldHVybiBpdDtcclxufTtcclxuXHJcbi8vIDcuMS4xMyBUb09iamVjdChhcmd1bWVudClcclxuXHJcbnZhciBfdG9PYmplY3QgPSBmdW5jdGlvbiAoaXQpIHtcclxuICByZXR1cm4gT2JqZWN0KF9kZWZpbmVkKGl0KSk7XHJcbn07XHJcblxyXG4vLyA3LjEuNCBUb0ludGVnZXJcclxudmFyIGNlaWwgPSBNYXRoLmNlaWw7XHJcbnZhciBmbG9vciA9IE1hdGguZmxvb3I7XHJcbnZhciBfdG9JbnRlZ2VyID0gZnVuY3Rpb24gKGl0KSB7XHJcbiAgcmV0dXJuIGlzTmFOKGl0ID0gK2l0KSA/IDAgOiAoaXQgPiAwID8gZmxvb3IgOiBjZWlsKShpdCk7XHJcbn07XHJcblxyXG4vLyA3LjEuMTUgVG9MZW5ndGhcclxuXHJcbnZhciBtaW4gPSBNYXRoLm1pbjtcclxudmFyIF90b0xlbmd0aCA9IGZ1bmN0aW9uIChpdCkge1xyXG4gIHJldHVybiBpdCA+IDAgPyBtaW4oX3RvSW50ZWdlcihpdCksIDB4MWZmZmZmZmZmZmZmZmYpIDogMDsgLy8gcG93KDIsIDUzKSAtIDEgPT0gOTAwNzE5OTI1NDc0MDk5MVxyXG59O1xyXG5cclxuLy8gNy4yLjIgSXNBcnJheShhcmd1bWVudClcclxuXHJcbnZhciBfaXNBcnJheSA9IEFycmF5LmlzQXJyYXkgfHwgZnVuY3Rpb24gaXNBcnJheShhcmcpIHtcclxuICByZXR1cm4gX2NvZihhcmcpID09ICdBcnJheSc7XHJcbn07XHJcblxyXG52YXIgX3NoYXJlZCA9IGNyZWF0ZUNvbW1vbmpzTW9kdWxlKGZ1bmN0aW9uIChtb2R1bGUpIHtcclxudmFyIFNIQVJFRCA9ICdfX2NvcmUtanNfc2hhcmVkX18nO1xyXG52YXIgc3RvcmUgPSBfZ2xvYmFsW1NIQVJFRF0gfHwgKF9nbG9iYWxbU0hBUkVEXSA9IHt9KTtcclxuXHJcbihtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChrZXksIHZhbHVlKSB7XHJcbiAgcmV0dXJuIHN0b3JlW2tleV0gfHwgKHN0b3JlW2tleV0gPSB2YWx1ZSAhPT0gdW5kZWZpbmVkID8gdmFsdWUgOiB7fSk7XHJcbn0pKCd2ZXJzaW9ucycsIFtdKS5wdXNoKHtcclxuICB2ZXJzaW9uOiBfY29yZS52ZXJzaW9uLFxyXG4gIG1vZGU6ICdnbG9iYWwnLFxyXG4gIGNvcHlyaWdodDogJ8KpIDIwMTggRGVuaXMgUHVzaGthcmV2ICh6bG9pcm9jay5ydSknXHJcbn0pO1xyXG59KTtcclxuXHJcbnZhciBfd2tzID0gY3JlYXRlQ29tbW9uanNNb2R1bGUoZnVuY3Rpb24gKG1vZHVsZSkge1xyXG52YXIgc3RvcmUgPSBfc2hhcmVkKCd3a3MnKTtcclxuXHJcbnZhciBTeW1ib2wgPSBfZ2xvYmFsLlN5bWJvbDtcclxudmFyIFVTRV9TWU1CT0wgPSB0eXBlb2YgU3ltYm9sID09ICdmdW5jdGlvbic7XHJcblxyXG52YXIgJGV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChuYW1lKSB7XHJcbiAgcmV0dXJuIHN0b3JlW25hbWVdIHx8IChzdG9yZVtuYW1lXSA9XHJcbiAgICBVU0VfU1lNQk9MICYmIFN5bWJvbFtuYW1lXSB8fCAoVVNFX1NZTUJPTCA/IFN5bWJvbCA6IF91aWQpKCdTeW1ib2wuJyArIG5hbWUpKTtcclxufTtcclxuXHJcbiRleHBvcnRzLnN0b3JlID0gc3RvcmU7XHJcbn0pO1xyXG5cclxudmFyIFNQRUNJRVMgPSBfd2tzKCdzcGVjaWVzJyk7XHJcblxyXG52YXIgX2FycmF5U3BlY2llc0NvbnN0cnVjdG9yID0gZnVuY3Rpb24gKG9yaWdpbmFsKSB7XHJcbiAgdmFyIEM7XHJcbiAgaWYgKF9pc0FycmF5KG9yaWdpbmFsKSkge1xyXG4gICAgQyA9IG9yaWdpbmFsLmNvbnN0cnVjdG9yO1xyXG4gICAgLy8gY3Jvc3MtcmVhbG0gZmFsbGJhY2tcclxuICAgIGlmICh0eXBlb2YgQyA9PSAnZnVuY3Rpb24nICYmIChDID09PSBBcnJheSB8fCBfaXNBcnJheShDLnByb3RvdHlwZSkpKSBDID0gdW5kZWZpbmVkO1xyXG4gICAgaWYgKF9pc09iamVjdChDKSkge1xyXG4gICAgICBDID0gQ1tTUEVDSUVTXTtcclxuICAgICAgaWYgKEMgPT09IG51bGwpIEMgPSB1bmRlZmluZWQ7XHJcbiAgICB9XHJcbiAgfSByZXR1cm4gQyA9PT0gdW5kZWZpbmVkID8gQXJyYXkgOiBDO1xyXG59O1xyXG5cclxuLy8gOS40LjIuMyBBcnJheVNwZWNpZXNDcmVhdGUob3JpZ2luYWxBcnJheSwgbGVuZ3RoKVxyXG5cclxuXHJcbnZhciBfYXJyYXlTcGVjaWVzQ3JlYXRlID0gZnVuY3Rpb24gKG9yaWdpbmFsLCBsZW5ndGgpIHtcclxuICByZXR1cm4gbmV3IChfYXJyYXlTcGVjaWVzQ29uc3RydWN0b3Iob3JpZ2luYWwpKShsZW5ndGgpO1xyXG59O1xyXG5cclxuLy8gMCAtPiBBcnJheSNmb3JFYWNoXHJcbi8vIDEgLT4gQXJyYXkjbWFwXHJcbi8vIDIgLT4gQXJyYXkjZmlsdGVyXHJcbi8vIDMgLT4gQXJyYXkjc29tZVxyXG4vLyA0IC0+IEFycmF5I2V2ZXJ5XHJcbi8vIDUgLT4gQXJyYXkjZmluZFxyXG4vLyA2IC0+IEFycmF5I2ZpbmRJbmRleFxyXG5cclxuXHJcblxyXG5cclxuXHJcbnZhciBfYXJyYXlNZXRob2RzID0gZnVuY3Rpb24gKFRZUEUsICRjcmVhdGUpIHtcclxuICB2YXIgSVNfTUFQID0gVFlQRSA9PSAxO1xyXG4gIHZhciBJU19GSUxURVIgPSBUWVBFID09IDI7XHJcbiAgdmFyIElTX1NPTUUgPSBUWVBFID09IDM7XHJcbiAgdmFyIElTX0VWRVJZID0gVFlQRSA9PSA0O1xyXG4gIHZhciBJU19GSU5EX0lOREVYID0gVFlQRSA9PSA2O1xyXG4gIHZhciBOT19IT0xFUyA9IFRZUEUgPT0gNSB8fCBJU19GSU5EX0lOREVYO1xyXG4gIHZhciBjcmVhdGUgPSAkY3JlYXRlIHx8IF9hcnJheVNwZWNpZXNDcmVhdGU7XHJcbiAgcmV0dXJuIGZ1bmN0aW9uICgkdGhpcywgY2FsbGJhY2tmbiwgdGhhdCkge1xyXG4gICAgdmFyIE8gPSBfdG9PYmplY3QoJHRoaXMpO1xyXG4gICAgdmFyIHNlbGYgPSBfaW9iamVjdChPKTtcclxuICAgIHZhciBmID0gX2N0eChjYWxsYmFja2ZuLCB0aGF0LCAzKTtcclxuICAgIHZhciBsZW5ndGggPSBfdG9MZW5ndGgoc2VsZi5sZW5ndGgpO1xyXG4gICAgdmFyIGluZGV4ID0gMDtcclxuICAgIHZhciByZXN1bHQgPSBJU19NQVAgPyBjcmVhdGUoJHRoaXMsIGxlbmd0aCkgOiBJU19GSUxURVIgPyBjcmVhdGUoJHRoaXMsIDApIDogdW5kZWZpbmVkO1xyXG4gICAgdmFyIHZhbCwgcmVzO1xyXG4gICAgZm9yICg7bGVuZ3RoID4gaW5kZXg7IGluZGV4KyspIGlmIChOT19IT0xFUyB8fCBpbmRleCBpbiBzZWxmKSB7XHJcbiAgICAgIHZhbCA9IHNlbGZbaW5kZXhdO1xyXG4gICAgICByZXMgPSBmKHZhbCwgaW5kZXgsIE8pO1xyXG4gICAgICBpZiAoVFlQRSkge1xyXG4gICAgICAgIGlmIChJU19NQVApIHJlc3VsdFtpbmRleF0gPSByZXM7ICAgLy8gbWFwXHJcbiAgICAgICAgZWxzZSBpZiAocmVzKSBzd2l0Y2ggKFRZUEUpIHtcclxuICAgICAgICAgIGNhc2UgMzogcmV0dXJuIHRydWU7ICAgICAgICAgICAgIC8vIHNvbWVcclxuICAgICAgICAgIGNhc2UgNTogcmV0dXJuIHZhbDsgICAgICAgICAgICAgIC8vIGZpbmRcclxuICAgICAgICAgIGNhc2UgNjogcmV0dXJuIGluZGV4OyAgICAgICAgICAgIC8vIGZpbmRJbmRleFxyXG4gICAgICAgICAgY2FzZSAyOiByZXN1bHQucHVzaCh2YWwpOyAgICAgICAgLy8gZmlsdGVyXHJcbiAgICAgICAgfSBlbHNlIGlmIChJU19FVkVSWSkgcmV0dXJuIGZhbHNlOyAvLyBldmVyeVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gSVNfRklORF9JTkRFWCA/IC0xIDogSVNfU09NRSB8fCBJU19FVkVSWSA/IElTX0VWRVJZIDogcmVzdWx0O1xyXG4gIH07XHJcbn07XHJcblxyXG52YXIgX3N0cmljdE1ldGhvZCA9IGZ1bmN0aW9uIChtZXRob2QsIGFyZykge1xyXG4gIHJldHVybiAhIW1ldGhvZCAmJiBfZmFpbHMoZnVuY3Rpb24gKCkge1xyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZWxlc3MtY2FsbFxyXG4gICAgYXJnID8gbWV0aG9kLmNhbGwobnVsbCwgZnVuY3Rpb24gKCkgeyAvKiBlbXB0eSAqLyB9LCAxKSA6IG1ldGhvZC5jYWxsKG51bGwpO1xyXG4gIH0pO1xyXG59O1xyXG5cclxudmFyICRmaWx0ZXIgPSBfYXJyYXlNZXRob2RzKDIpO1xyXG5cclxuX2V4cG9ydChfZXhwb3J0LlAgKyBfZXhwb3J0LkYgKiAhX3N0cmljdE1ldGhvZChbXS5maWx0ZXIsIHRydWUpLCAnQXJyYXknLCB7XHJcbiAgLy8gMjIuMS4zLjcgLyAxNS40LjQuMjAgQXJyYXkucHJvdG90eXBlLmZpbHRlcihjYWxsYmFja2ZuIFssIHRoaXNBcmddKVxyXG4gIGZpbHRlcjogZnVuY3Rpb24gZmlsdGVyKGNhbGxiYWNrZm4gLyogLCB0aGlzQXJnICovKSB7XHJcbiAgICByZXR1cm4gJGZpbHRlcih0aGlzLCBjYWxsYmFja2ZuLCBhcmd1bWVudHNbMV0pO1xyXG4gIH1cclxufSk7XHJcblxyXG52YXIgZmlsdGVyID0gX2NvcmUuQXJyYXkuZmlsdGVyO1xyXG5cclxudmFyICRtYXAgPSBfYXJyYXlNZXRob2RzKDEpO1xyXG5cclxuX2V4cG9ydChfZXhwb3J0LlAgKyBfZXhwb3J0LkYgKiAhX3N0cmljdE1ldGhvZChbXS5tYXAsIHRydWUpLCAnQXJyYXknLCB7XHJcbiAgLy8gMjIuMS4zLjE1IC8gMTUuNC40LjE5IEFycmF5LnByb3RvdHlwZS5tYXAoY2FsbGJhY2tmbiBbLCB0aGlzQXJnXSlcclxuICBtYXA6IGZ1bmN0aW9uIG1hcChjYWxsYmFja2ZuIC8qICwgdGhpc0FyZyAqLykge1xyXG4gICAgcmV0dXJuICRtYXAodGhpcywgY2FsbGJhY2tmbiwgYXJndW1lbnRzWzFdKTtcclxuICB9XHJcbn0pO1xyXG5cclxudmFyIG1hcCA9IF9jb3JlLkFycmF5Lm1hcDtcclxuXHJcbnZhciBfc3RyaW5nV3MgPSAnXFx4MDlcXHgwQVxceDBCXFx4MENcXHgwRFxceDIwXFx4QTBcXHUxNjgwXFx1MTgwRVxcdTIwMDBcXHUyMDAxXFx1MjAwMlxcdTIwMDMnICtcclxuICAnXFx1MjAwNFxcdTIwMDVcXHUyMDA2XFx1MjAwN1xcdTIwMDhcXHUyMDA5XFx1MjAwQVxcdTIwMkZcXHUyMDVGXFx1MzAwMFxcdTIwMjhcXHUyMDI5XFx1RkVGRic7XHJcblxyXG52YXIgc3BhY2UgPSAnWycgKyBfc3RyaW5nV3MgKyAnXSc7XHJcbnZhciBub24gPSAnXFx1MjAwYlxcdTAwODUnO1xyXG52YXIgbHRyaW0gPSBSZWdFeHAoJ14nICsgc3BhY2UgKyBzcGFjZSArICcqJyk7XHJcbnZhciBydHJpbSA9IFJlZ0V4cChzcGFjZSArIHNwYWNlICsgJyokJyk7XHJcblxyXG52YXIgZXhwb3J0ZXIgPSBmdW5jdGlvbiAoS0VZLCBleGVjLCBBTElBUykge1xyXG4gIHZhciBleHAgPSB7fTtcclxuICB2YXIgRk9SQ0UgPSBfZmFpbHMoZnVuY3Rpb24gKCkge1xyXG4gICAgcmV0dXJuICEhX3N0cmluZ1dzW0tFWV0oKSB8fCBub25bS0VZXSgpICE9IG5vbjtcclxuICB9KTtcclxuICB2YXIgZm4gPSBleHBbS0VZXSA9IEZPUkNFID8gZXhlYyh0cmltKSA6IF9zdHJpbmdXc1tLRVldO1xyXG4gIGlmIChBTElBUykgZXhwW0FMSUFTXSA9IGZuO1xyXG4gIF9leHBvcnQoX2V4cG9ydC5QICsgX2V4cG9ydC5GICogRk9SQ0UsICdTdHJpbmcnLCBleHApO1xyXG59O1xyXG5cclxuLy8gMSAtPiBTdHJpbmcjdHJpbUxlZnRcclxuLy8gMiAtPiBTdHJpbmcjdHJpbVJpZ2h0XHJcbi8vIDMgLT4gU3RyaW5nI3RyaW1cclxudmFyIHRyaW0gPSBleHBvcnRlci50cmltID0gZnVuY3Rpb24gKHN0cmluZywgVFlQRSkge1xyXG4gIHN0cmluZyA9IFN0cmluZyhfZGVmaW5lZChzdHJpbmcpKTtcclxuICBpZiAoVFlQRSAmIDEpIHN0cmluZyA9IHN0cmluZy5yZXBsYWNlKGx0cmltLCAnJyk7XHJcbiAgaWYgKFRZUEUgJiAyKSBzdHJpbmcgPSBzdHJpbmcucmVwbGFjZShydHJpbSwgJycpO1xyXG4gIHJldHVybiBzdHJpbmc7XHJcbn07XHJcblxyXG52YXIgX3N0cmluZ1RyaW0gPSBleHBvcnRlcjtcclxuXHJcbi8vIDIxLjEuMy4yNSBTdHJpbmcucHJvdG90eXBlLnRyaW0oKVxyXG5fc3RyaW5nVHJpbSgndHJpbScsIGZ1bmN0aW9uICgkdHJpbSkge1xyXG4gIHJldHVybiBmdW5jdGlvbiB0cmltKCkge1xyXG4gICAgcmV0dXJuICR0cmltKHRoaXMsIDMpO1xyXG4gIH07XHJcbn0pO1xyXG5cclxudmFyIHRyaW0kMSA9IF9jb3JlLlN0cmluZy50cmltO1xyXG5cclxudmFyIGluamVjdGFibGVOYXZpZ2F0b3IgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xyXG4gICAgPyB3aW5kb3cubmF2aWdhdG9yXHJcbiAgICA6IHVuZGVmaW5lZDtcclxudmFyIGluamVjdGFibGVQcm9jZXNzID0gdHlwZW9mIHByb2Nlc3MgIT09ICd1bmRlZmluZWQnXHJcbiAgICA/IHByb2Nlc3NcclxuICAgIDogdW5kZWZpbmVkO1xyXG5mdW5jdGlvbiBicm93c2VyRGV0ZWN0ICh1c2VyQWdlbnQpIHtcclxuICAgIHZhciBkZXRlY3RvciA9IG5ldyBEZXRlY3Rvcih1c2VyQWdlbnQsIGluamVjdGFibGVOYXZpZ2F0b3IsIGluamVjdGFibGVQcm9jZXNzKTtcclxuICAgIHJldHVybiBkZXRlY3Rvci5kZXRlY3QoKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYnJvd3NlckRldGVjdDtcclxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnJvd3Nlci1kZXRlY3QuZXM1LmpzLm1hcFxyXG4iLCIvLyBzaGltIGZvciB1c2luZyBwcm9jZXNzIGluIGJyb3dzZXJcbnZhciBwcm9jZXNzID0gbW9kdWxlLmV4cG9ydHMgPSB7fTtcblxuLy8gY2FjaGVkIGZyb20gd2hhdGV2ZXIgZ2xvYmFsIGlzIHByZXNlbnQgc28gdGhhdCB0ZXN0IHJ1bm5lcnMgdGhhdCBzdHViIGl0XG4vLyBkb24ndCBicmVhayB0aGluZ3MuICBCdXQgd2UgbmVlZCB0byB3cmFwIGl0IGluIGEgdHJ5IGNhdGNoIGluIGNhc2UgaXQgaXNcbi8vIHdyYXBwZWQgaW4gc3RyaWN0IG1vZGUgY29kZSB3aGljaCBkb2Vzbid0IGRlZmluZSBhbnkgZ2xvYmFscy4gIEl0J3MgaW5zaWRlIGFcbi8vIGZ1bmN0aW9uIGJlY2F1c2UgdHJ5L2NhdGNoZXMgZGVvcHRpbWl6ZSBpbiBjZXJ0YWluIGVuZ2luZXMuXG5cbnZhciBjYWNoZWRTZXRUaW1lb3V0O1xudmFyIGNhY2hlZENsZWFyVGltZW91dDtcblxuZnVuY3Rpb24gZGVmYXVsdFNldFRpbW91dCgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3NldFRpbWVvdXQgaGFzIG5vdCBiZWVuIGRlZmluZWQnKTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRDbGVhclRpbWVvdXQgKCkge1xuICAgIHRocm93IG5ldyBFcnJvcignY2xlYXJUaW1lb3V0IGhhcyBub3QgYmVlbiBkZWZpbmVkJyk7XG59XG4oZnVuY3Rpb24gKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGlmICh0eXBlb2Ygc2V0VGltZW91dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgY2FjaGVkU2V0VGltZW91dCA9IHNldFRpbWVvdXQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYWNoZWRTZXRUaW1lb3V0ID0gZGVmYXVsdFNldFRpbW91dDtcbiAgICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY2FjaGVkU2V0VGltZW91dCA9IGRlZmF1bHRTZXRUaW1vdXQ7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGlmICh0eXBlb2YgY2xlYXJUaW1lb3V0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBjbGVhclRpbWVvdXQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBkZWZhdWx0Q2xlYXJUaW1lb3V0O1xuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjYWNoZWRDbGVhclRpbWVvdXQgPSBkZWZhdWx0Q2xlYXJUaW1lb3V0O1xuICAgIH1cbn0gKCkpXG5mdW5jdGlvbiBydW5UaW1lb3V0KGZ1bikge1xuICAgIGlmIChjYWNoZWRTZXRUaW1lb3V0ID09PSBzZXRUaW1lb3V0KSB7XG4gICAgICAgIC8vbm9ybWFsIGVudmlyb21lbnRzIGluIHNhbmUgc2l0dWF0aW9uc1xuICAgICAgICByZXR1cm4gc2V0VGltZW91dChmdW4sIDApO1xuICAgIH1cbiAgICAvLyBpZiBzZXRUaW1lb3V0IHdhc24ndCBhdmFpbGFibGUgYnV0IHdhcyBsYXR0ZXIgZGVmaW5lZFxuICAgIGlmICgoY2FjaGVkU2V0VGltZW91dCA9PT0gZGVmYXVsdFNldFRpbW91dCB8fCAhY2FjaGVkU2V0VGltZW91dCkgJiYgc2V0VGltZW91dCkge1xuICAgICAgICBjYWNoZWRTZXRUaW1lb3V0ID0gc2V0VGltZW91dDtcbiAgICAgICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuLCAwKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gd2hlbiB3aGVuIHNvbWVib2R5IGhhcyBzY3Jld2VkIHdpdGggc2V0VGltZW91dCBidXQgbm8gSS5FLiBtYWRkbmVzc1xuICAgICAgICByZXR1cm4gY2FjaGVkU2V0VGltZW91dChmdW4sIDApO1xuICAgIH0gY2F0Y2goZSl7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBXaGVuIHdlIGFyZSBpbiBJLkUuIGJ1dCB0aGUgc2NyaXB0IGhhcyBiZWVuIGV2YWxlZCBzbyBJLkUuIGRvZXNuJ3QgdHJ1c3QgdGhlIGdsb2JhbCBvYmplY3Qgd2hlbiBjYWxsZWQgbm9ybWFsbHlcbiAgICAgICAgICAgIHJldHVybiBjYWNoZWRTZXRUaW1lb3V0LmNhbGwobnVsbCwgZnVuLCAwKTtcbiAgICAgICAgfSBjYXRjaChlKXtcbiAgICAgICAgICAgIC8vIHNhbWUgYXMgYWJvdmUgYnV0IHdoZW4gaXQncyBhIHZlcnNpb24gb2YgSS5FLiB0aGF0IG11c3QgaGF2ZSB0aGUgZ2xvYmFsIG9iamVjdCBmb3IgJ3RoaXMnLCBob3BmdWxseSBvdXIgY29udGV4dCBjb3JyZWN0IG90aGVyd2lzZSBpdCB3aWxsIHRocm93IGEgZ2xvYmFsIGVycm9yXG4gICAgICAgICAgICByZXR1cm4gY2FjaGVkU2V0VGltZW91dC5jYWxsKHRoaXMsIGZ1biwgMCk7XG4gICAgICAgIH1cbiAgICB9XG5cblxufVxuZnVuY3Rpb24gcnVuQ2xlYXJUaW1lb3V0KG1hcmtlcikge1xuICAgIGlmIChjYWNoZWRDbGVhclRpbWVvdXQgPT09IGNsZWFyVGltZW91dCkge1xuICAgICAgICAvL25vcm1hbCBlbnZpcm9tZW50cyBpbiBzYW5lIHNpdHVhdGlvbnNcbiAgICAgICAgcmV0dXJuIGNsZWFyVGltZW91dChtYXJrZXIpO1xuICAgIH1cbiAgICAvLyBpZiBjbGVhclRpbWVvdXQgd2Fzbid0IGF2YWlsYWJsZSBidXQgd2FzIGxhdHRlciBkZWZpbmVkXG4gICAgaWYgKChjYWNoZWRDbGVhclRpbWVvdXQgPT09IGRlZmF1bHRDbGVhclRpbWVvdXQgfHwgIWNhY2hlZENsZWFyVGltZW91dCkgJiYgY2xlYXJUaW1lb3V0KSB7XG4gICAgICAgIGNhY2hlZENsZWFyVGltZW91dCA9IGNsZWFyVGltZW91dDtcbiAgICAgICAgcmV0dXJuIGNsZWFyVGltZW91dChtYXJrZXIpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICAvLyB3aGVuIHdoZW4gc29tZWJvZHkgaGFzIHNjcmV3ZWQgd2l0aCBzZXRUaW1lb3V0IGJ1dCBubyBJLkUuIG1hZGRuZXNzXG4gICAgICAgIHJldHVybiBjYWNoZWRDbGVhclRpbWVvdXQobWFya2VyKTtcbiAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIFdoZW4gd2UgYXJlIGluIEkuRS4gYnV0IHRoZSBzY3JpcHQgaGFzIGJlZW4gZXZhbGVkIHNvIEkuRS4gZG9lc24ndCAgdHJ1c3QgdGhlIGdsb2JhbCBvYmplY3Qgd2hlbiBjYWxsZWQgbm9ybWFsbHlcbiAgICAgICAgICAgIHJldHVybiBjYWNoZWRDbGVhclRpbWVvdXQuY2FsbChudWxsLCBtYXJrZXIpO1xuICAgICAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgICAgIC8vIHNhbWUgYXMgYWJvdmUgYnV0IHdoZW4gaXQncyBhIHZlcnNpb24gb2YgSS5FLiB0aGF0IG11c3QgaGF2ZSB0aGUgZ2xvYmFsIG9iamVjdCBmb3IgJ3RoaXMnLCBob3BmdWxseSBvdXIgY29udGV4dCBjb3JyZWN0IG90aGVyd2lzZSBpdCB3aWxsIHRocm93IGEgZ2xvYmFsIGVycm9yLlxuICAgICAgICAgICAgLy8gU29tZSB2ZXJzaW9ucyBvZiBJLkUuIGhhdmUgZGlmZmVyZW50IHJ1bGVzIGZvciBjbGVhclRpbWVvdXQgdnMgc2V0VGltZW91dFxuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZENsZWFyVGltZW91dC5jYWxsKHRoaXMsIG1hcmtlcik7XG4gICAgICAgIH1cbiAgICB9XG5cblxuXG59XG52YXIgcXVldWUgPSBbXTtcbnZhciBkcmFpbmluZyA9IGZhbHNlO1xudmFyIGN1cnJlbnRRdWV1ZTtcbnZhciBxdWV1ZUluZGV4ID0gLTE7XG5cbmZ1bmN0aW9uIGNsZWFuVXBOZXh0VGljaygpIHtcbiAgICBpZiAoIWRyYWluaW5nIHx8ICFjdXJyZW50UXVldWUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBkcmFpbmluZyA9IGZhbHNlO1xuICAgIGlmIChjdXJyZW50UXVldWUubGVuZ3RoKSB7XG4gICAgICAgIHF1ZXVlID0gY3VycmVudFF1ZXVlLmNvbmNhdChxdWV1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcXVldWVJbmRleCA9IC0xO1xuICAgIH1cbiAgICBpZiAocXVldWUubGVuZ3RoKSB7XG4gICAgICAgIGRyYWluUXVldWUoKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGRyYWluUXVldWUoKSB7XG4gICAgaWYgKGRyYWluaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIHRpbWVvdXQgPSBydW5UaW1lb3V0KGNsZWFuVXBOZXh0VGljayk7XG4gICAgZHJhaW5pbmcgPSB0cnVlO1xuXG4gICAgdmFyIGxlbiA9IHF1ZXVlLmxlbmd0aDtcbiAgICB3aGlsZShsZW4pIHtcbiAgICAgICAgY3VycmVudFF1ZXVlID0gcXVldWU7XG4gICAgICAgIHF1ZXVlID0gW107XG4gICAgICAgIHdoaWxlICgrK3F1ZXVlSW5kZXggPCBsZW4pIHtcbiAgICAgICAgICAgIGlmIChjdXJyZW50UXVldWUpIHtcbiAgICAgICAgICAgICAgICBjdXJyZW50UXVldWVbcXVldWVJbmRleF0ucnVuKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcXVldWVJbmRleCA9IC0xO1xuICAgICAgICBsZW4gPSBxdWV1ZS5sZW5ndGg7XG4gICAgfVxuICAgIGN1cnJlbnRRdWV1ZSA9IG51bGw7XG4gICAgZHJhaW5pbmcgPSBmYWxzZTtcbiAgICBydW5DbGVhclRpbWVvdXQodGltZW91dCk7XG59XG5cbnByb2Nlc3MubmV4dFRpY2sgPSBmdW5jdGlvbiAoZnVuKSB7XG4gICAgdmFyIGFyZ3MgPSBuZXcgQXJyYXkoYXJndW1lbnRzLmxlbmd0aCAtIDEpO1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgYXJnc1tpIC0gMV0gPSBhcmd1bWVudHNbaV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcXVldWUucHVzaChuZXcgSXRlbShmdW4sIGFyZ3MpKTtcbiAgICBpZiAocXVldWUubGVuZ3RoID09PSAxICYmICFkcmFpbmluZykge1xuICAgICAgICBydW5UaW1lb3V0KGRyYWluUXVldWUpO1xuICAgIH1cbn07XG5cbi8vIHY4IGxpa2VzIHByZWRpY3RpYmxlIG9iamVjdHNcbmZ1bmN0aW9uIEl0ZW0oZnVuLCBhcnJheSkge1xuICAgIHRoaXMuZnVuID0gZnVuO1xuICAgIHRoaXMuYXJyYXkgPSBhcnJheTtcbn1cbkl0ZW0ucHJvdG90eXBlLnJ1biA9IGZ1bmN0aW9uICgpIHtcbiAgICB0aGlzLmZ1bi5hcHBseShudWxsLCB0aGlzLmFycmF5KTtcbn07XG5wcm9jZXNzLnRpdGxlID0gJ2Jyb3dzZXInO1xucHJvY2Vzcy5icm93c2VyID0gdHJ1ZTtcbnByb2Nlc3MuZW52ID0ge307XG5wcm9jZXNzLmFyZ3YgPSBbXTtcbnByb2Nlc3MudmVyc2lvbiA9ICcnOyAvLyBlbXB0eSBzdHJpbmcgdG8gYXZvaWQgcmVnZXhwIGlzc3Vlc1xucHJvY2Vzcy52ZXJzaW9ucyA9IHt9O1xuXG5mdW5jdGlvbiBub29wKCkge31cblxucHJvY2Vzcy5vbiA9IG5vb3A7XG5wcm9jZXNzLmFkZExpc3RlbmVyID0gbm9vcDtcbnByb2Nlc3Mub25jZSA9IG5vb3A7XG5wcm9jZXNzLm9mZiA9IG5vb3A7XG5wcm9jZXNzLnJlbW92ZUxpc3RlbmVyID0gbm9vcDtcbnByb2Nlc3MucmVtb3ZlQWxsTGlzdGVuZXJzID0gbm9vcDtcbnByb2Nlc3MuZW1pdCA9IG5vb3A7XG5wcm9jZXNzLnByZXBlbmRMaXN0ZW5lciA9IG5vb3A7XG5wcm9jZXNzLnByZXBlbmRPbmNlTGlzdGVuZXIgPSBub29wO1xuXG5wcm9jZXNzLmxpc3RlbmVycyA9IGZ1bmN0aW9uIChuYW1lKSB7IHJldHVybiBbXSB9XG5cbnByb2Nlc3MuYmluZGluZyA9IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdwcm9jZXNzLmJpbmRpbmcgaXMgbm90IHN1cHBvcnRlZCcpO1xufTtcblxucHJvY2Vzcy5jd2QgPSBmdW5jdGlvbiAoKSB7IHJldHVybiAnLycgfTtcbnByb2Nlc3MuY2hkaXIgPSBmdW5jdGlvbiAoZGlyKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdwcm9jZXNzLmNoZGlyIGlzIG5vdCBzdXBwb3J0ZWQnKTtcbn07XG5wcm9jZXNzLnVtYXNrID0gZnVuY3Rpb24oKSB7IHJldHVybiAwOyB9O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==