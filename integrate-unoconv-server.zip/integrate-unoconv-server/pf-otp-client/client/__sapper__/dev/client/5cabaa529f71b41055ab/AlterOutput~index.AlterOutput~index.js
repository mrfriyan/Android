(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["AlterOutput~index"],{

/***/ "./src/routes/AlterOutput/PDFGenerator.js":
/*!************************************************!*\
  !*** ./src/routes/AlterOutput/PDFGenerator.js ***!
  \************************************************/
/*! exports provided: currentPageIndex, pageMode, cursorIndex, pdfInstance, totalPagesCount, scale, scaleMobile, scaleWeb, zoomIn, zoomOut, initPDFViewer, onPagerButtonsClick, initPager, onPageModeChange, initPageMode, render, renderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currentPageIndex", function() { return currentPageIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pageMode", function() { return pageMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cursorIndex", function() { return cursorIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pdfInstance", function() { return pdfInstance; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "totalPagesCount", function() { return totalPagesCount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scale", function() { return scale; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scaleMobile", function() { return scaleMobile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scaleWeb", function() { return scaleWeb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "zoomIn", function() { return zoomIn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "zoomOut", function() { return zoomOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initPDFViewer", function() { return initPDFViewer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onPagerButtonsClick", function() { return onPagerButtonsClick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initPager", function() { return initPager; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onPageModeChange", function() { return onPageModeChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initPageMode", function() { return initPageMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renderPage", function() { return renderPage; });
let currentPageIndex = 0;
let pageMode = 50;
let cursorIndex = Math.floor(currentPageIndex / pageMode);
let pdfInstance = null;
let totalPagesCount = 0;
let scale = 0.4;


// import * as pdfjsLib from 'pdfjs-dist';
// const pdfjsLib = require("pdfjs-dist/webpack");

const scaleMobile = function(){
    scale = 0.4;
}
const scaleWeb = function(){
    scale = 1.0;
    
}

const zoomIn = function(){
    if(scale >= 0.2){
        scale = scale - 0.05;
        // console.log(scale);
        render();
    }
}

const zoomOut = function(){
    if(scale <= 0.4){
        scale = scale + 0.05;
        // console.log(scale);
        render();
    }
}




const initPDFViewer = function(pdfURL) {
    pdfjsLib.getDocument(pdfURL).then(pdf => {
    pdfInstance = pdf;
    totalPagesCount = pdf.numPages - 1;
    initPager();
    // initPageMode();
    render();
    });
};

function onPagerButtonsClick(event) {
    const action = event.target.getAttribute("data-pager");
    
    if (action === "prev") {
    if (currentPageIndex === 0) {
        return;
    }
    currentPageIndex -= pageMode;
    if (currentPageIndex < 0) {
        currentPageIndex = 0;
    }
    render();
    }
    
    if (action === "next") {
    if (currentPageIndex === totalPagesCount - 1) {
        return;
    }
    currentPageIndex += pageMode;
    if (currentPageIndex > totalPagesCount - 1) {
        currentPageIndex = totalPagesCount - 1;
    }
    render();
    }
}

function initPager() {
    const pager = document.querySelector("#pager");
    pager.addEventListener("click", onPagerButtonsClick);
    // I like this pattern, but this is never actually called, is it?
    return () => {
    pager.removeEventListener("click", onPagerButtonsClick);
    };
}

function onPageModeChange(event) {
    pageMode = Number(event.target.value);
    render();
}
function initPageMode() {
    const input = document.querySelector("#page-mode input");
    input.setAttribute("max", totalPagesCount);
    input.addEventListener("change", onPageModeChange);
    // Same here.
    return () => {
    input.removeEventListener("change", onPageModeChange);
    };
}

function render() {
    cursorIndex = Math.floor(currentPageIndex / pageMode);
    // Could also be:
    // const startPageIndex = currentPageIndex - (currentPageIndex % pageMode);
    const startPageIndex = cursorIndex * pageMode;
    const endPageIndex =
    startPageIndex + pageMode < totalPagesCount
        ? startPageIndex + pageMode - 1
        : totalPagesCount - 1;

    const renderPagesPromises = [];
    for (let i = startPageIndex; i <= endPageIndex; i++) {
    renderPagesPromises.push(pdfInstance.getPage(i + 1));
    }

    Promise.all(renderPagesPromises).then(pages => {
    const pagesHTML = `<div style="width: ${
        pageMode > 1 ? "100%" : "100%"
    }"><canvas id="zoom"></canvas></div>`.repeat(pages.length);
    viewport.innerHTML = pagesHTML;
    pages.forEach(renderPage);
    });
}

function renderPage(page) {
    // console.log(scale);
    let pdfViewport = page.getViewport(scale);
    const container = viewport.children[page.pageIndex - cursorIndex * pageMode];
    pdfViewport = page.getViewport(container.offsetWidth / pdfViewport.width);
    const canvas = container.children[0];
    const context = canvas.getContext("2d");
    canvas.height = pdfViewport.height;
    canvas.width = pdfViewport.width;

    page.render({
    canvasContext: context,
    viewport: pdfViewport,
    });
}



/***/ }),

/***/ "./src/routes/AlterOutput/index.svelte":
/*!*********************************************!*\
  !*** ./src/routes/AlterOutput/index.svelte ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var svelte_internal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! svelte/internal */ "./node_modules/svelte/internal/index.mjs");
/* harmony import */ var svelte__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! svelte */ "./node_modules/svelte/index.mjs");
/* harmony import */ var _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PDFGenerator */ "./src/routes/AlterOutput/PDFGenerator.js");
/* harmony import */ var _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Button */ "./node_modules/sveltestrap/src/Button.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Input */ "./node_modules/sveltestrap/src/Input.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_ButtonGroup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/ButtonGroup */ "./node_modules/sveltestrap/src/ButtonGroup.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Navbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Navbar */ "./node_modules/sveltestrap/src/Navbar.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Col__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Col */ "./node_modules/sveltestrap/src/Col.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Row__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Row */ "./node_modules/sveltestrap/src/Row.svelte");
/* harmony import */ var svelte_icons_fa_FaPlus_svelte__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! svelte-icons/fa/FaPlus.svelte */ "./node_modules/svelte-icons/fa/FaPlus.svelte");
/* harmony import */ var svelte_icons_fa_FaMinus_svelte__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! svelte-icons/fa/FaMinus.svelte */ "./node_modules/svelte-icons/fa/FaMinus.svelte");
/* harmony import */ var browser_detect__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! browser-detect */ "./node_modules/browser-detect/dist/browser-detect.es5.js");
/* src/routes/AlterOutput/index.svelte generated by Svelte v3.9.2 */

const { document: document_1 } = svelte_internal__WEBPACK_IMPORTED_MODULE_0__["globals"];












// (116:18) <Button                     class="btn btn-dark btn-sm mb-2"                     style="border-radius:100%;">
function create_default_slot_5(ctx) {
	var div, current, dispose;

	var zoomin_1 = new svelte_icons_fa_FaPlus_svelte__WEBPACK_IMPORTED_MODULE_9__["default"]({});

	return {
		c() {
			div = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			zoomin_1.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div, "id", "zoomin");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "font-size", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "width", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "margin-bottom", "1px");
			dispose = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["listen"])(div, "click", zoomin);
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(zoomin_1, div, null);
			current = true;
		},

		p: svelte_internal__WEBPACK_IMPORTED_MODULE_0__["noop"],

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(zoomin_1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(zoomin_1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(zoomin_1);

			dispose();
		}
	};
}

// (126:18) <Button                     class="btn btn-dark btn-sm mb-2"                     style="border-radius:100%;">
function create_default_slot_4(ctx) {
	var div, current, dispose;

	var zoomout_1 = new svelte_icons_fa_FaMinus_svelte__WEBPACK_IMPORTED_MODULE_10__["default"]({});

	return {
		c() {
			div = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			zoomout_1.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div, "id", "zoomout");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "font-size", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "width", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "margin-bottom", "1px");
			dispose = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["listen"])(div, "click", zoomout);
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(zoomout_1, div, null);
			current = true;
		},

		p: svelte_internal__WEBPACK_IMPORTED_MODULE_0__["noop"],

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(zoomout_1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(zoomout_1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(zoomout_1);

			dispose();
		}
	};
}

// (113:12) <Navbar class="navbar navbar-expand-xs fixed-bottom">
function create_default_slot_3(ctx) {
	var ul, div, t, current;

	var button0 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		class: "btn btn-dark btn-sm mb-2",
		style: "border-radius:100%;",
		$$slots: { default: [create_default_slot_5] },
		$$scope: { ctx }
	}
	});

	var button1 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		class: "btn btn-dark btn-sm mb-2",
		style: "border-radius:100%;",
		$$slots: { default: [create_default_slot_4] },
		$$scope: { ctx }
	}
	});

	return {
		c() {
			ul = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("ul");
			div = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			button0.$$.fragment.c();
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			button1.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div, "class", "col-12 fixed mb-5 pb-5");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(ul, "class", "navbar-nav ml-auto");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, ul, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(ul, div);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button0, div, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div, t);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button1, div, null);
			current = true;
		},

		p(changed, ctx) {
			var button0_changes = {};
			if (changed.$$scope) button0_changes.$$scope = { changed, ctx };
			button0.$set(button0_changes);

			var button1_changes = {};
			if (changed.$$scope) button1_changes.$$scope = { changed, ctx };
			button1.$set(button1_changes);
		},

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button0.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button0.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(ul);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button0);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button1);
		}
	};
}

// (143:14) <Button                 name="lanjutkan"                 on:click={actionLanjutkan}                 class="btn btn-danger"                 block                 style="display:none">
function create_default_slot_2(ctx) {
	var t;

	return {
		c() {
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Lanjutkan");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}
		}
	};
}

// (153:14) <Button                 name="dlanjutkan"                 block                 disabled                 class="btn btn-danger"                 style="display:block">
function create_default_slot_1(ctx) {
	var t;

	return {
		c() {
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Lanjutkan");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}
		}
	};
}

// (140:12) <Navbar id="pager" class="navbar bg-white fixed-bottom shadow-lg">
function create_default_slot(ctx) {
	var t, current;

	var button0 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		name: "lanjutkan",
		class: "btn btn-danger",
		block: true,
		style: "display:none",
		$$slots: { default: [create_default_slot_2] },
		$$scope: { ctx }
	}
	});
	button0.$on("click", ctx.actionLanjutkan);

	var button1 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		name: "dlanjutkan",
		block: true,
		disabled: true,
		class: "btn btn-danger",
		style: "display:block",
		$$slots: { default: [create_default_slot_1] },
		$$scope: { ctx }
	}
	});

	return {
		c() {
			button0.$$.fragment.c();
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			button1.$$.fragment.c();
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button0, target, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button1, target, anchor);
			current = true;
		},

		p(changed, ctx) {
			var button0_changes = {};
			if (changed.$$scope) button0_changes.$$scope = { changed, ctx };
			button0.$set(button0_changes);

			var button1_changes = {};
			if (changed.$$scope) button1_changes.$$scope = { changed, ctx };
			button1.$set(button1_changes);
		},

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button0.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button0.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button0, detaching);

			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button1, detaching);
		}
	};
}

function create_fragment(ctx) {
	var t0, main, div5, div4, div3, div2, div1, div0, t1, t2, current;

	var navbar0 = new _node_modules_sveltestrap_src_Navbar__WEBPACK_IMPORTED_MODULE_6__["default"]({
		props: {
		class: "navbar navbar-expand-xs fixed-bottom",
		$$slots: { default: [create_default_slot_3] },
		$$scope: { ctx }
	}
	});

	var navbar1 = new _node_modules_sveltestrap_src_Navbar__WEBPACK_IMPORTED_MODULE_6__["default"]({
		props: {
		id: "pager",
		class: "navbar bg-white fixed-bottom shadow-lg",
		$$slots: { default: [create_default_slot] },
		$$scope: { ctx }
	}
	});

	return {
		c() {
			t0 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			main = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("main");
			div5 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div4 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div3 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div2 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div1 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div0 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			t1 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			navbar0.$$.fragment.c();
			t2 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			navbar1.$$.fragment.c();
			document_1.title = "PDF Viewer";
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div0, "role", "main");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div0, "id", "viewport");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div1, "id", "viewport-container");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div1, "name", "container_terms");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div2, "id", "pdf-container");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div2, "onresize", "resize");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div3, "class", "justify-content-center align-items-center");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div4, "class", "col-12");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div4, "height", "100%");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div4, "position", "fixed");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div5, "id", "pdf-viewer");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div5, "class", "row justify-content-center animate-bottom ");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t0, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, main, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(main, div5);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div5, div4);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div4, div3);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div3, div2);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div2, div1);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div1, div0);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div1, t1);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(navbar0, div1, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div1, t2);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(navbar1, div1, null);
			current = true;
		},

		p(changed, ctx) {
			var navbar0_changes = {};
			if (changed.$$scope) navbar0_changes.$$scope = { changed, ctx };
			navbar0.$set(navbar0_changes);

			var navbar1_changes = {};
			if (changed.$$scope) navbar1_changes.$$scope = { changed, ctx };
			navbar1.$set(navbar1_changes);
		},

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(navbar0.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(navbar1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(navbar0.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(navbar1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t0);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(main);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(navbar0);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(navbar1);
		}
	};
}

function lanjutkan() {
  document.getElementById("lanjutkan").style.display = "block";
  document.getElementById("pdf-container").style.display = "none";
  document.getElementById("pager").style.display = "none";
  return false;
}

function tidaksetuju() {
  document.getElementById("tidaksetuju").style.display = "block ";
  document.getElementById("pdf-container").style.display = "none";
  document.getElementById("pager").style.display = "none";
  return false;
}

function zoomin() {
  _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["zoomIn"]();
  var pdfzoom = document.getElementById("viewport");
  var currWidth = pdfzoom.clientWidth;
  if (currWidth == 2500) return false;
  else {
    pdfzoom.style.width = currWidth + 100 + "px";
  }
}

function zoomout() {
  _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["zoomOut"]();
  var pdfzoom = document.getElementById("viewport");
  var currWidth = pdfzoom.clientWidth;
  if (currWidth == 100) return false;
  else {
    pdfzoom.style.width = currWidth - 100 + "px";
  }
}

let time = "23:59";

function instance($$self, $$props, $$invalidate) {
	

  let today = new Date();
  let date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  let dateTime = date + " " + time;
  let { dataPdfAlter, actionLanjutkan } = $$props;

  Object(svelte__WEBPACK_IMPORTED_MODULE_1__["onMount"])(() => {
    document
      .getElementsByName("container_terms")[0]
      .addEventListener("scroll", checkScrollHeight, false);
    function checkScrollHeight() {
      var agreementTextElement = document.getElementsByName(
        "container_terms"
      )[0];
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= agreementTextElement.scrollHeight) {
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= 1000) {
      if (
        agreementTextElement.clientHeight + agreementTextElement.scrollTop >=
        agreementTextElement.scrollHeight - 400
      ) {
        document.getElementsByName("dlanjutkan")[0].style.display = "none";
        document.getElementsByName("lanjutkan")[0].style.display = "block";
      }
    }
    const viewport = document.querySelector("#viewport");
    console.log(dataPdfAlter);
    console.log("data base 64 ada di atas");
    _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["initPDFViewer"]({ data: atob(dataPdfAlter) });
    // PDFGenerator.initPDFViewer("output.pdf");

    const browserDetect = Object(browser_detect__WEBPACK_IMPORTED_MODULE_11__["default"])();
    // console.log(browserDetect.mobile);
    var scale;
    if (browserDetect.mobile === true) {
      scale = _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["scaleMobile"]();
      document.getElementById("viewport-container").style.paddingBottom = "20%";
      document.getElementById("pager").style.fontSize = "10px";
    } else if (browserDetect.mobile === false) {
      scale = _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["scaleWeb"]();
      document.getElementById("viewport-container").style.paddingTop = "5%";
      document.getElementById("zoomin").style.width = "20px";
      document.getElementById("zoomout").style.width = "20px";
    }
  });

  window.addEventListener("resize", function(e) {
    _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["render"]();
  });

	$$self.$set = $$props => {
		if ('dataPdfAlter' in $$props) $$invalidate('dataPdfAlter', dataPdfAlter = $$props.dataPdfAlter);
		if ('actionLanjutkan' in $$props) $$invalidate('actionLanjutkan', actionLanjutkan = $$props.actionLanjutkan);
	};

	return { dataPdfAlter, actionLanjutkan };
}

class AlterOutput extends svelte_internal__WEBPACK_IMPORTED_MODULE_0__["SvelteComponent"] {
	constructor(options) {
		super();
		Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["init"])(this, options, instance, create_fragment, svelte_internal__WEBPACK_IMPORTED_MODULE_0__["safe_not_equal"], ["dataPdfAlter", "actionLanjutkan"]);
	}
}

/* harmony default export */ __webpack_exports__["default"] = (AlterOutput);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcm91dGVzL0FsdGVyT3V0cHV0L1BERkdlbmVyYXRvci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcm91dGVzL0FsdGVyT3V0cHV0L2luZGV4LnN2ZWx0ZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU87QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHUDtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7O0FBRUE7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FBS087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRU87QUFDUDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZ0NBQWdDLG1CQUFtQjtBQUNuRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBGQ2RnQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBGQVVOLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQWFiLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQS9JdkMsU0FBUyxTQUFTLEdBQUc7QUFDckIsRUFBRSxRQUFRLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0FBQy9ELEVBQUUsUUFBUSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztBQUNsRSxFQUFFLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7QUFDMUQsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUNmLENBQUM7O0FBRUQsU0FBUyxXQUFXLEdBQUc7QUFDdkIsRUFBRSxRQUFRLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO0FBQ2xFLEVBQUUsUUFBUSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztBQUNsRSxFQUFFLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7QUFDMUQsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUNmLENBQUM7O0FBRUQsU0FBUyxNQUFNLEdBQUc7QUFDbEIsRUFBRSxvREFBbUIsRUFBRSxDQUFDO0FBQ3hCLEVBQUUsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwRCxFQUFFLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDdEMsRUFBRSxJQUFJLFNBQVMsSUFBSSxJQUFJLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFDdEMsT0FBTztBQUNQLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7QUFDakQsR0FBRztBQUNILENBQUM7O0FBRUQsU0FBUyxPQUFPLEdBQUc7QUFDbkIsRUFBRSxxREFBb0IsRUFBRSxDQUFDO0FBQ3pCLEVBQUUsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwRCxFQUFFLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDdEMsRUFBRSxJQUFJLFNBQVMsSUFBSSxHQUFHLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFDckMsT0FBTztBQUNQLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7QUFDakQsR0FBRztBQUNILENBQUM7O0FBb0JELElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQzs7O0NBTGtCOztFQUVyQyxJQUFJLEtBQUssR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO0VBQ3ZCLElBQUksSUFBSTtJQUNOLEtBQUssQ0FBQyxXQUFXLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FDekQ7RUFDbkIsSUFBSSxRQUFRLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7RUFDMUIsTUFBSSxZQUFZLEVBQ1osMkJBQWUsQ0FBQzs7RUFFM0Isc0RBQU8sQ0FBQyxNQUFNO0lBQ1osUUFBUTtPQUNMLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO09BQ3ZDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4RCxTQUFTLGlCQUFpQixHQUFHO01BQzNCLElBQUksb0JBQW9CLEdBQUcsUUFBUSxDQUFDLGlCQUFpQjtRQUNuRCxpQkFBaUI7T0FDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O01BR0w7UUFDRSxvQkFBb0IsQ0FBQyxZQUFZLEdBQUcsb0JBQW9CLENBQUMsU0FBUztRQUNsRSxvQkFBb0IsQ0FBQyxZQUFZLEdBQUcsR0FBRztRQUN2QztRQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztRQUNuRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7T0FDcEU7S0FDRjtJQUNELE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDeEMsMkRBQTBCLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQzs7O0lBR3pELE1BQU0sYUFBYSxHQUFHLCtEQUFPLEVBQUUsQ0FBQzs7SUFFaEMsSUFBSSxLQUFLLENBQUM7SUFDVixJQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO01BQ2pDLEtBQUssR0FBRyx5REFBd0IsRUFBRSxDQUFDO01BQ25DLFFBQVEsQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztNQUMxRSxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO0tBQzFELE1BQU0sSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLEtBQUssRUFBRTtNQUN6QyxLQUFLLEdBQUcsc0RBQXFCLEVBQUUsQ0FBQztNQUNoQyxRQUFRLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7TUFDdEUsUUFBUSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQztNQUN2RCxRQUFRLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO0tBQ3pEO0dBQ0YsQ0FBQyxDQUFDOztFQUVILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLEVBQUU7SUFDNUMsb0RBQW1CLEVBQUUsQ0FBQztHQUN2QixDQUFDLENBQUMiLCJmaWxlIjoiNWNhYmFhNTI5ZjcxYjQxMDU1YWIvQWx0ZXJPdXRwdXR+aW5kZXguQWx0ZXJPdXRwdXR+aW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgbGV0IGN1cnJlbnRQYWdlSW5kZXggPSAwO1xuZXhwb3J0IGxldCBwYWdlTW9kZSA9IDUwO1xuZXhwb3J0IGxldCBjdXJzb3JJbmRleCA9IE1hdGguZmxvb3IoY3VycmVudFBhZ2VJbmRleCAvIHBhZ2VNb2RlKTtcbmV4cG9ydCBsZXQgcGRmSW5zdGFuY2UgPSBudWxsO1xuZXhwb3J0IGxldCB0b3RhbFBhZ2VzQ291bnQgPSAwO1xuZXhwb3J0IGxldCBzY2FsZSA9IDAuNDtcblxuXG4vLyBpbXBvcnQgKiBhcyBwZGZqc0xpYiBmcm9tICdwZGZqcy1kaXN0Jztcbi8vIGNvbnN0IHBkZmpzTGliID0gcmVxdWlyZShcInBkZmpzLWRpc3Qvd2VicGFja1wiKTtcblxuZXhwb3J0IGNvbnN0IHNjYWxlTW9iaWxlID0gZnVuY3Rpb24oKXtcbiAgICBzY2FsZSA9IDAuNDtcbn1cbmV4cG9ydCBjb25zdCBzY2FsZVdlYiA9IGZ1bmN0aW9uKCl7XG4gICAgc2NhbGUgPSAxLjA7XG4gICAgXG59XG5cbmV4cG9ydCBjb25zdCB6b29tSW4gPSBmdW5jdGlvbigpe1xuICAgIGlmKHNjYWxlID49IDAuMil7XG4gICAgICAgIHNjYWxlID0gc2NhbGUgLSAwLjA1O1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhzY2FsZSk7XG4gICAgICAgIHJlbmRlcigpO1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IHpvb21PdXQgPSBmdW5jdGlvbigpe1xuICAgIGlmKHNjYWxlIDw9IDAuNCl7XG4gICAgICAgIHNjYWxlID0gc2NhbGUgKyAwLjA1O1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhzY2FsZSk7XG4gICAgICAgIHJlbmRlcigpO1xuICAgIH1cbn1cblxuXG5cblxuZXhwb3J0IGNvbnN0IGluaXRQREZWaWV3ZXIgPSBmdW5jdGlvbihwZGZVUkwpIHtcbiAgICBwZGZqc0xpYi5nZXREb2N1bWVudChwZGZVUkwpLnRoZW4ocGRmID0+IHtcbiAgICBwZGZJbnN0YW5jZSA9IHBkZjtcbiAgICB0b3RhbFBhZ2VzQ291bnQgPSBwZGYubnVtUGFnZXMgLSAxO1xuICAgIGluaXRQYWdlcigpO1xuICAgIC8vIGluaXRQYWdlTW9kZSgpO1xuICAgIHJlbmRlcigpO1xuICAgIH0pO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIG9uUGFnZXJCdXR0b25zQ2xpY2soZXZlbnQpIHtcbiAgICBjb25zdCBhY3Rpb24gPSBldmVudC50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1wYWdlclwiKTtcbiAgICBcbiAgICBpZiAoYWN0aW9uID09PSBcInByZXZcIikge1xuICAgIGlmIChjdXJyZW50UGFnZUluZGV4ID09PSAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY3VycmVudFBhZ2VJbmRleCAtPSBwYWdlTW9kZTtcbiAgICBpZiAoY3VycmVudFBhZ2VJbmRleCA8IDApIHtcbiAgICAgICAgY3VycmVudFBhZ2VJbmRleCA9IDA7XG4gICAgfVxuICAgIHJlbmRlcigpO1xuICAgIH1cbiAgICBcbiAgICBpZiAoYWN0aW9uID09PSBcIm5leHRcIikge1xuICAgIGlmIChjdXJyZW50UGFnZUluZGV4ID09PSB0b3RhbFBhZ2VzQ291bnQgLSAxKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY3VycmVudFBhZ2VJbmRleCArPSBwYWdlTW9kZTtcbiAgICBpZiAoY3VycmVudFBhZ2VJbmRleCA+IHRvdGFsUGFnZXNDb3VudCAtIDEpIHtcbiAgICAgICAgY3VycmVudFBhZ2VJbmRleCA9IHRvdGFsUGFnZXNDb3VudCAtIDE7XG4gICAgfVxuICAgIHJlbmRlcigpO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluaXRQYWdlcigpIHtcbiAgICBjb25zdCBwYWdlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcGFnZXJcIik7XG4gICAgcGFnZXIuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIG9uUGFnZXJCdXR0b25zQ2xpY2spO1xuICAgIC8vIEkgbGlrZSB0aGlzIHBhdHRlcm4sIGJ1dCB0aGlzIGlzIG5ldmVyIGFjdHVhbGx5IGNhbGxlZCwgaXMgaXQ/XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICBwYWdlci5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgb25QYWdlckJ1dHRvbnNDbGljayk7XG4gICAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG9uUGFnZU1vZGVDaGFuZ2UoZXZlbnQpIHtcbiAgICBwYWdlTW9kZSA9IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpO1xuICAgIHJlbmRlcigpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGluaXRQYWdlTW9kZSgpIHtcbiAgICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcGFnZS1tb2RlIGlucHV0XCIpO1xuICAgIGlucHV0LnNldEF0dHJpYnV0ZShcIm1heFwiLCB0b3RhbFBhZ2VzQ291bnQpO1xuICAgIGlucHV0LmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgb25QYWdlTW9kZUNoYW5nZSk7XG4gICAgLy8gU2FtZSBoZXJlLlxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgaW5wdXQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBvblBhZ2VNb2RlQ2hhbmdlKTtcbiAgICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgIGN1cnNvckluZGV4ID0gTWF0aC5mbG9vcihjdXJyZW50UGFnZUluZGV4IC8gcGFnZU1vZGUpO1xuICAgIC8vIENvdWxkIGFsc28gYmU6XG4gICAgLy8gY29uc3Qgc3RhcnRQYWdlSW5kZXggPSBjdXJyZW50UGFnZUluZGV4IC0gKGN1cnJlbnRQYWdlSW5kZXggJSBwYWdlTW9kZSk7XG4gICAgY29uc3Qgc3RhcnRQYWdlSW5kZXggPSBjdXJzb3JJbmRleCAqIHBhZ2VNb2RlO1xuICAgIGNvbnN0IGVuZFBhZ2VJbmRleCA9XG4gICAgc3RhcnRQYWdlSW5kZXggKyBwYWdlTW9kZSA8IHRvdGFsUGFnZXNDb3VudFxuICAgICAgICA/IHN0YXJ0UGFnZUluZGV4ICsgcGFnZU1vZGUgLSAxXG4gICAgICAgIDogdG90YWxQYWdlc0NvdW50IC0gMTtcblxuICAgIGNvbnN0IHJlbmRlclBhZ2VzUHJvbWlzZXMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gc3RhcnRQYWdlSW5kZXg7IGkgPD0gZW5kUGFnZUluZGV4OyBpKyspIHtcbiAgICByZW5kZXJQYWdlc1Byb21pc2VzLnB1c2gocGRmSW5zdGFuY2UuZ2V0UGFnZShpICsgMSkpO1xuICAgIH1cblxuICAgIFByb21pc2UuYWxsKHJlbmRlclBhZ2VzUHJvbWlzZXMpLnRoZW4ocGFnZXMgPT4ge1xuICAgIGNvbnN0IHBhZ2VzSFRNTCA9IGA8ZGl2IHN0eWxlPVwid2lkdGg6ICR7XG4gICAgICAgIHBhZ2VNb2RlID4gMSA/IFwiMTAwJVwiIDogXCIxMDAlXCJcbiAgICB9XCI+PGNhbnZhcyBpZD1cInpvb21cIj48L2NhbnZhcz48L2Rpdj5gLnJlcGVhdChwYWdlcy5sZW5ndGgpO1xuICAgIHZpZXdwb3J0LmlubmVySFRNTCA9IHBhZ2VzSFRNTDtcbiAgICBwYWdlcy5mb3JFYWNoKHJlbmRlclBhZ2UpO1xuICAgIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVuZGVyUGFnZShwYWdlKSB7XG4gICAgLy8gY29uc29sZS5sb2coc2NhbGUpO1xuICAgIGxldCBwZGZWaWV3cG9ydCA9IHBhZ2UuZ2V0Vmlld3BvcnQoc2NhbGUpO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IHZpZXdwb3J0LmNoaWxkcmVuW3BhZ2UucGFnZUluZGV4IC0gY3Vyc29ySW5kZXggKiBwYWdlTW9kZV07XG4gICAgcGRmVmlld3BvcnQgPSBwYWdlLmdldFZpZXdwb3J0KGNvbnRhaW5lci5vZmZzZXRXaWR0aCAvIHBkZlZpZXdwb3J0LndpZHRoKTtcbiAgICBjb25zdCBjYW52YXMgPSBjb250YWluZXIuY2hpbGRyZW5bMF07XG4gICAgY29uc3QgY29udGV4dCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgY2FudmFzLmhlaWdodCA9IHBkZlZpZXdwb3J0LmhlaWdodDtcbiAgICBjYW52YXMud2lkdGggPSBwZGZWaWV3cG9ydC53aWR0aDtcblxuICAgIHBhZ2UucmVuZGVyKHtcbiAgICBjYW52YXNDb250ZXh0OiBjb250ZXh0LFxuICAgIHZpZXdwb3J0OiBwZGZWaWV3cG9ydCxcbiAgICB9KTtcbn1cblxuIiwiPHNjcmlwdCBjb250ZXh0PVwibW9kdWxlXCI+XG4gIGZ1bmN0aW9uIGxhbmp1dGthbigpIHtcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImxhbmp1dGthblwiKS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGRmLWNvbnRhaW5lclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwYWdlclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgZnVuY3Rpb24gdGlkYWtzZXR1anUoKSB7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0aWRha3NldHVqdVwiKS5zdHlsZS5kaXNwbGF5ID0gXCJibG9jayBcIjtcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBkZi1jb250YWluZXJcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGFnZXJcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHpvb21pbigpIHtcbiAgICBQREZHZW5lcmF0b3Iuem9vbUluKCk7XG4gICAgdmFyIHBkZnpvb20gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInZpZXdwb3J0XCIpO1xuICAgIHZhciBjdXJyV2lkdGggPSBwZGZ6b29tLmNsaWVudFdpZHRoO1xuICAgIGlmIChjdXJyV2lkdGggPT0gMjUwMCkgcmV0dXJuIGZhbHNlO1xuICAgIGVsc2Uge1xuICAgICAgcGRmem9vbS5zdHlsZS53aWR0aCA9IGN1cnJXaWR0aCArIDEwMCArIFwicHhcIjtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiB6b29tb3V0KCkge1xuICAgIFBERkdlbmVyYXRvci56b29tT3V0KCk7XG4gICAgdmFyIHBkZnpvb20gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInZpZXdwb3J0XCIpO1xuICAgIHZhciBjdXJyV2lkdGggPSBwZGZ6b29tLmNsaWVudFdpZHRoO1xuICAgIGlmIChjdXJyV2lkdGggPT0gMTAwKSByZXR1cm4gZmFsc2U7XG4gICAgZWxzZSB7XG4gICAgICBwZGZ6b29tLnN0eWxlLndpZHRoID0gY3VycldpZHRoIC0gMTAwICsgXCJweFwiO1xuICAgIH1cbiAgfVxuPC9zY3JpcHQ+XG5cbjxzY3JpcHQ+XG4gIGltcG9ydCB7IG9uTW91bnQgfSBmcm9tIFwic3ZlbHRlXCI7XG4gIGltcG9ydCAqIGFzIFBERkdlbmVyYXRvciBmcm9tIFwiLi9QREZHZW5lcmF0b3JcIjtcbiAgLy8gaW1wb3J0IHsgQnV0dG9uLElucHV0LCBCdXR0b25Hcm91cCxOYXZiYXIsIENvbCwgUm93IH0gZnJvbSAnc3ZlbHRlc3RyYXAnO1xuICBpbXBvcnQgQnV0dG9uIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlc3RyYXAvc3JjL0J1dHRvblwiO1xuICBpbXBvcnQgSW5wdXQgZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvSW5wdXRcIjtcbiAgaW1wb3J0IEJ1dHRvbkdyb3VwIGZyb20gXCIuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlc3RyYXAvc3JjL0J1dHRvbkdyb3VwXCI7XG4gIGltcG9ydCBOYXZiYXIgZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvTmF2YmFyXCI7XG4gIGltcG9ydCBDb2wgZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvQ29sXCI7XG4gIGltcG9ydCBSb3cgZnJvbSBcIi4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvUm93XCI7XG4gIGltcG9ydCBab29taW4gZnJvbSBcInN2ZWx0ZS1pY29ucy9mYS9GYVBsdXMuc3ZlbHRlXCI7XG4gIGltcG9ydCBab29tb3V0IGZyb20gXCJzdmVsdGUtaWNvbnMvZmEvRmFNaW51cy5zdmVsdGVcIjtcbiAgaW1wb3J0IGJyb3dzZXIgZnJvbSBcImJyb3dzZXItZGV0ZWN0XCI7XG5cbiAgbGV0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgbGV0IGRhdGUgPVxuICAgIHRvZGF5LmdldEZ1bGxZZWFyKCkgKyBcIi1cIiArICh0b2RheS5nZXRNb250aCgpICsgMSkgKyBcIi1cIiArIHRvZGF5LmdldERhdGUoKTtcbiAgbGV0IHRpbWUgPSBcIjIzOjU5XCI7XG4gIGxldCBkYXRlVGltZSA9IGRhdGUgKyBcIiBcIiArIHRpbWU7XG4gIGV4cG9ydCBsZXQgZGF0YVBkZkFsdGVyO1xuICBleHBvcnQgbGV0IGFjdGlvbkxhbmp1dGthbjtcblxuICBvbk1vdW50KCgpID0+IHtcbiAgICBkb2N1bWVudFxuICAgICAgLmdldEVsZW1lbnRzQnlOYW1lKFwiY29udGFpbmVyX3Rlcm1zXCIpWzBdXG4gICAgICAuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBjaGVja1Njcm9sbEhlaWdodCwgZmFsc2UpO1xuICAgIGZ1bmN0aW9uIGNoZWNrU2Nyb2xsSGVpZ2h0KCkge1xuICAgICAgdmFyIGFncmVlbWVudFRleHRFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUoXG4gICAgICAgIFwiY29udGFpbmVyX3Rlcm1zXCJcbiAgICAgIClbMF07XG4gICAgICAvLyBpZiAoYWdyZWVtZW50VGV4dEVsZW1lbnQuY2xpZW50SGVpZ2h0ICsgYWdyZWVtZW50VGV4dEVsZW1lbnQuc2Nyb2xsVG9wID49IGFncmVlbWVudFRleHRFbGVtZW50LnNjcm9sbEhlaWdodCkge1xuICAgICAgLy8gaWYgKGFncmVlbWVudFRleHRFbGVtZW50LmNsaWVudEhlaWdodCArIGFncmVlbWVudFRleHRFbGVtZW50LnNjcm9sbFRvcCA+PSAxMDAwKSB7XG4gICAgICBpZiAoXG4gICAgICAgIGFncmVlbWVudFRleHRFbGVtZW50LmNsaWVudEhlaWdodCArIGFncmVlbWVudFRleHRFbGVtZW50LnNjcm9sbFRvcCA+PVxuICAgICAgICBhZ3JlZW1lbnRUZXh0RWxlbWVudC5zY3JvbGxIZWlnaHQgLSA0MDBcbiAgICAgICkge1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5TmFtZShcImRsYW5qdXRrYW5cIilbMF0uc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5TmFtZShcImxhbmp1dGthblwiKVswXS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCB2aWV3cG9ydCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjdmlld3BvcnRcIik7XG4gICAgY29uc29sZS5sb2coZGF0YVBkZkFsdGVyKTtcbiAgICBjb25zb2xlLmxvZyhcImRhdGEgYmFzZSA2NCBhZGEgZGkgYXRhc1wiKTtcbiAgICBQREZHZW5lcmF0b3IuaW5pdFBERlZpZXdlcih7IGRhdGE6IGF0b2IoZGF0YVBkZkFsdGVyKSB9KTtcbiAgICAvLyBQREZHZW5lcmF0b3IuaW5pdFBERlZpZXdlcihcIm91dHB1dC5wZGZcIik7XG5cbiAgICBjb25zdCBicm93c2VyRGV0ZWN0ID0gYnJvd3NlcigpO1xuICAgIC8vIGNvbnNvbGUubG9nKGJyb3dzZXJEZXRlY3QubW9iaWxlKTtcbiAgICB2YXIgc2NhbGU7XG4gICAgaWYgKGJyb3dzZXJEZXRlY3QubW9iaWxlID09PSB0cnVlKSB7XG4gICAgICBzY2FsZSA9IFBERkdlbmVyYXRvci5zY2FsZU1vYmlsZSgpO1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ2aWV3cG9ydC1jb250YWluZXJcIikuc3R5bGUucGFkZGluZ0JvdHRvbSA9IFwiMjAlXCI7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBhZ2VyXCIpLnN0eWxlLmZvbnRTaXplID0gXCIxMHB4XCI7XG4gICAgfSBlbHNlIGlmIChicm93c2VyRGV0ZWN0Lm1vYmlsZSA9PT0gZmFsc2UpIHtcbiAgICAgIHNjYWxlID0gUERGR2VuZXJhdG9yLnNjYWxlV2ViKCk7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInZpZXdwb3J0LWNvbnRhaW5lclwiKS5zdHlsZS5wYWRkaW5nVG9wID0gXCI1JVwiO1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ6b29taW5cIikuc3R5bGUud2lkdGggPSBcIjIwcHhcIjtcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiem9vbW91dFwiKS5zdHlsZS53aWR0aCA9IFwiMjBweFwiO1xuICAgIH1cbiAgfSk7XG5cbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgZnVuY3Rpb24oZSkge1xuICAgIFBERkdlbmVyYXRvci5yZW5kZXIoKTtcbiAgfSk7XG48L3NjcmlwdD5cblxuPHN2ZWx0ZTpoZWFkPlxuICA8dGl0bGU+UERGIFZpZXdlcjwvdGl0bGU+XG48L3N2ZWx0ZTpoZWFkPlxuPG1haW4+XG4gIDxkaXYgaWQ9XCJwZGYtdmlld2VyXCIgY2xhc3M9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBhbmltYXRlLWJvdHRvbSBcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLTEyXCIgc3R5bGU9XCJoZWlnaHQ6IDEwMCU7IHBvc2l0aW9uOiBmaXhlZDtcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGlkPVwicGRmLWNvbnRhaW5lclwiIG9ucmVzaXplPVwicmVzaXplXCI+XG4gICAgICAgICAgPGRpdiBpZD1cInZpZXdwb3J0LWNvbnRhaW5lclwiIG5hbWU9XCJjb250YWluZXJfdGVybXNcIj5cbiAgICAgICAgICAgIDxkaXYgcm9sZT1cIm1haW5cIiBpZD1cInZpZXdwb3J0XCIgLz5cbiAgICAgICAgICAgIDxOYXZiYXIgY2xhc3M9XCJuYXZiYXIgbmF2YmFyLWV4cGFuZC14cyBmaXhlZC1ib3R0b21cIj5cbiAgICAgICAgICAgICAgPHVsIGNsYXNzPVwibmF2YmFyLW5hdiBtbC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMiBmaXhlZCBtYi01IHBiLTVcIj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLWRhcmsgYnRuLXNtIG1iLTJcIlxuICAgICAgICAgICAgICAgICAgICBzdHlsZT1cImJvcmRlci1yYWRpdXM6MTAwJTtcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiem9vbWluXCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT1cImZvbnQtc2l6ZTo4cHg7IHdpZHRoOiA4cHg7IG1hcmdpbi1ib3R0b206MXB4O1wiXG4gICAgICAgICAgICAgICAgICAgICAgb246Y2xpY2s9e3pvb21pbn0+XG4gICAgICAgICAgICAgICAgICAgICAgPFpvb21pbiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0biBidG4tZGFyayBidG4tc20gbWItMlwiXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPVwiYm9yZGVyLXJhZGl1czoxMDAlO1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ6b29tb3V0XCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT1cImZvbnQtc2l6ZTo4cHg7IHdpZHRoOiA4cHg7IG1hcmdpbi1ib3R0b206MXB4O1wiXG4gICAgICAgICAgICAgICAgICAgICAgb246Y2xpY2s9e3pvb21vdXR9PlxuICAgICAgICAgICAgICAgICAgICAgIDxab29tb3V0IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L05hdmJhcj5cblxuICAgICAgICAgICAgPE5hdmJhciBpZD1cInBhZ2VyXCIgY2xhc3M9XCJuYXZiYXIgYmctd2hpdGUgZml4ZWQtYm90dG9tIHNoYWRvdy1sZ1wiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPCEtLWVuYWJsZSBidXR0b24tLT5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIG5hbWU9XCJsYW5qdXRrYW5cIlxuICAgICAgICAgICAgICAgIG9uOmNsaWNrPXthY3Rpb25MYW5qdXRrYW59XG4gICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLWRhbmdlclwiXG4gICAgICAgICAgICAgICAgYmxvY2tcbiAgICAgICAgICAgICAgICBzdHlsZT1cImRpc3BsYXk6bm9uZVwiPlxuICAgICAgICAgICAgICAgIExhbmp1dGthblxuICAgICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgICA8IS0tZGlzYWJsZSBidXR0b24tLT5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIG5hbWU9XCJkbGFuanV0a2FuXCJcbiAgICAgICAgICAgICAgICBibG9ja1xuICAgICAgICAgICAgICAgIGRpc2FibGVkXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJidG4gYnRuLWRhbmdlclwiXG4gICAgICAgICAgICAgICAgc3R5bGU9XCJkaXNwbGF5OmJsb2NrXCI+XG4gICAgICAgICAgICAgICAgTGFuanV0a2FuXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9OYXZiYXI+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9tYWluPlxuIl0sInNvdXJjZVJvb3QiOiIifQ==