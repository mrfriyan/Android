(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["CampaignOutput~Verification~index"],{

/***/ "./src/routes/CampaignOutput/PDFGenerator.js":
/*!***************************************************!*\
  !*** ./src/routes/CampaignOutput/PDFGenerator.js ***!
  \***************************************************/
/*! exports provided: currentPageIndex, pageMode, cursorIndex, pdfInstance, totalPagesCount, scale, scaleMobile, scaleWeb, zoomIn, zoomOut, initPDFViewer, onPagerButtonsClick, initPager, onPageModeChange, initPageMode, render, renderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currentPageIndex", function() { return currentPageIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pageMode", function() { return pageMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cursorIndex", function() { return cursorIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pdfInstance", function() { return pdfInstance; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "totalPagesCount", function() { return totalPagesCount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scale", function() { return scale; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scaleMobile", function() { return scaleMobile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scaleWeb", function() { return scaleWeb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "zoomIn", function() { return zoomIn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "zoomOut", function() { return zoomOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initPDFViewer", function() { return initPDFViewer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onPagerButtonsClick", function() { return onPagerButtonsClick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initPager", function() { return initPager; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onPageModeChange", function() { return onPageModeChange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initPageMode", function() { return initPageMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renderPage", function() { return renderPage; });
let currentPageIndex = 0;
let pageMode = 50;
let cursorIndex = Math.floor(currentPageIndex / pageMode);
let pdfInstance = null;
let totalPagesCount = 0;
let scale = 0.4;


// import * as pdfjsLib from 'pdfjs-dist';
// const pdfjsLib = require("pdfjs-dist/webpack");

const scaleMobile = function(){
    scale = 0.4;
}
const scaleWeb = function(){
    scale = 1.0;
    
}

const zoomIn = function(){
    if(scale >= 0.2){
        scale = scale - 0.05;
        // console.log(scale);
        render();
    }
}

const zoomOut = function(){
    if(scale <= 0.4){
        scale = scale + 0.05;
        // console.log(scale);
        render();
    }
}



// export const viewport = document.querySelector("#viewport");
const initPDFViewer = function(pdfURL) {
    pdfjsLib.getDocument(pdfURL).then(pdf => {
    pdfInstance = pdf;
    totalPagesCount = pdf.numPages;
    initPager();
    // initPageMode();
    render();
    });
};

function onPagerButtonsClick(event) {
    const action = event.target.getAttribute("data-pager");
    
    if (action === "prev") {
    if (currentPageIndex === 0) {
        return;
    }
    currentPageIndex -= pageMode;
    if (currentPageIndex < 0) {
        currentPageIndex = 0;
    }
    render();
    }
    
    if (action === "next") {
    if (currentPageIndex === totalPagesCount - 1) {
        return;
    }
    currentPageIndex += pageMode;
    if (currentPageIndex > totalPagesCount - 1) {
        currentPageIndex = totalPagesCount - 1;
    }
    render();
    }
}

function initPager() {
    const pager = document.querySelector("#pager");
    pager.addEventListener("click", onPagerButtonsClick);
    // I like this pattern, but this is never actually called, is it?
    return () => {
    pager.removeEventListener("click", onPagerButtonsClick);
    };
}

function onPageModeChange(event) {
    pageMode = Number(event.target.value);
    render();
}
function initPageMode() {
    const input = document.querySelector("#page-mode input");
    input.setAttribute("max", totalPagesCount);
    input.addEventListener("change", onPageModeChange);
    // Same here.
    return () => {
    input.removeEventListener("change", onPageModeChange);
    };
}

function render() {
    cursorIndex = Math.floor(currentPageIndex / pageMode);
    // Could also be:
    // const startPageIndex = currentPageIndex - (currentPageIndex % pageMode);
    const startPageIndex = cursorIndex * pageMode;
    const endPageIndex =
    startPageIndex + pageMode < totalPagesCount
        ? startPageIndex + pageMode - 1
        : totalPagesCount - 1;

    const renderPagesPromises = [];
    for (let i = startPageIndex; i <= endPageIndex; i++) {
    renderPagesPromises.push(pdfInstance.getPage(i + 1));
    }

    Promise.all(renderPagesPromises).then(pages => {
    const pagesHTML = `<div style="width: ${
        pageMode > 1 ? "100%" : "100%"
    }"><canvas id="zoom"></canvas></div>`.repeat(pages.length);
    viewport.innerHTML = pagesHTML;
    pages.forEach(renderPage);
    });
}

function renderPage(page) {
    // console.log(scale);
    let pdfViewport = page.getViewport(scale);
    const container = viewport.children[page.pageIndex - cursorIndex * pageMode];
    pdfViewport = page.getViewport(container.offsetWidth / pdfViewport.width);
    const canvas = container.children[0];
    const context = canvas.getContext("2d");
    canvas.height = pdfViewport.height;
    canvas.width = pdfViewport.width;

    page.render({
    canvasContext: context,
    viewport: pdfViewport,
    });
}



/***/ }),

/***/ "./src/routes/CampaignOutput/index.svelte":
/*!************************************************!*\
  !*** ./src/routes/CampaignOutput/index.svelte ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var svelte_internal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! svelte/internal */ "./node_modules/svelte/internal/index.mjs");
/* harmony import */ var svelte__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! svelte */ "./node_modules/svelte/index.mjs");
/* harmony import */ var _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PDFGenerator */ "./src/routes/CampaignOutput/PDFGenerator.js");
/* harmony import */ var _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Button */ "./node_modules/sveltestrap/src/Button.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Input */ "./node_modules/sveltestrap/src/Input.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_ButtonGroup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/ButtonGroup */ "./node_modules/sveltestrap/src/ButtonGroup.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Navbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Navbar */ "./node_modules/sveltestrap/src/Navbar.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Col__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Col */ "./node_modules/sveltestrap/src/Col.svelte");
/* harmony import */ var _node_modules_sveltestrap_src_Row__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../node_modules/sveltestrap/src/Row */ "./node_modules/sveltestrap/src/Row.svelte");
/* harmony import */ var svelte_icons_fa_FaPlus_svelte__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! svelte-icons/fa/FaPlus.svelte */ "./node_modules/svelte-icons/fa/FaPlus.svelte");
/* harmony import */ var svelte_icons_fa_FaMinus_svelte__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! svelte-icons/fa/FaMinus.svelte */ "./node_modules/svelte-icons/fa/FaMinus.svelte");
/* harmony import */ var browser_detect__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! browser-detect */ "./node_modules/browser-detect/dist/browser-detect.es5.js");
/* src/routes/CampaignOutput/index.svelte generated by Svelte v3.9.2 */

const { document: document_1 } = svelte_internal__WEBPACK_IMPORTED_MODULE_0__["globals"];












// (125:14) <Button name="notsetuju" on:click = {action_tidak_setuju} class="btn btn-secondary" block style="display:none">
function create_default_slot_7(ctx) {
	var t;

	return {
		c() {
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Tidak Setuju");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}
		}
	};
}

// (128:14) <Button  name="setuju" on:click = {action_setuju} class="btn btn-danger" block style="display:none">
function create_default_slot_6(ctx) {
	var t;

	return {
		c() {
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Setuju");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}
		}
	};
}

// (133:14) <Button name="dnotsetuju" block disabled class="btn btn-secondary" style="display:block">
function create_default_slot_5(ctx) {
	var t;

	return {
		c() {
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Tidak Setuju");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}
		}
	};
}

// (136:14) <Button  name="dsetuju" block disabled class="btn btn-secondary" style="display:block">
function create_default_slot_4(ctx) {
	var t;

	return {
		c() {
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Setuju");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			}
		}
	};
}

// (142:20) <Button class="btn btn-dark btn-sm" style="border-radius:100%;">
function create_default_slot_3(ctx) {
	var div, current, dispose;

	var zoomin_1 = new svelte_icons_fa_FaPlus_svelte__WEBPACK_IMPORTED_MODULE_9__["default"]({});

	return {
		c() {
			div = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			zoomin_1.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div, "id", "zoomin");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "font-size", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "width", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "margin-bottom", "1px");
			dispose = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["listen"])(div, "click", zoomin);
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(zoomin_1, div, null);
			current = true;
		},

		p: svelte_internal__WEBPACK_IMPORTED_MODULE_0__["noop"],

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(zoomin_1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(zoomin_1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(zoomin_1);

			dispose();
		}
	};
}

// (143:20) <Button class="btn btn-dark btn-sm" style="border-radius:100%;">
function create_default_slot_2(ctx) {
	var div, current, dispose;

	var zoomout_1 = new svelte_icons_fa_FaMinus_svelte__WEBPACK_IMPORTED_MODULE_10__["default"]({});

	return {
		c() {
			div = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			zoomout_1.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div, "id", "zoomout");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "font-size", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "width", "8px");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div, "margin-bottom", "1px");
			dispose = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["listen"])(div, "click", zoomout);
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(zoomout_1, div, null);
			current = true;
		},

		p: svelte_internal__WEBPACK_IMPORTED_MODULE_0__["noop"],

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(zoomout_1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(zoomout_1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(zoomout_1);

			dispose();
		}
	};
}

// (139:12) <Navbar  class="navbar navbar-expand-xs fixed-bottom   mb-5 pb-5">
function create_default_slot_1(ctx) {
	var ul, div, t, current;

	var button0 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		class: "btn btn-dark btn-sm",
		style: "border-radius:100%;",
		$$slots: { default: [create_default_slot_3] },
		$$scope: { ctx }
	}
	});

	var button1 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		class: "btn btn-dark btn-sm",
		style: "border-radius:100%;",
		$$slots: { default: [create_default_slot_2] },
		$$scope: { ctx }
	}
	});

	return {
		c() {
			ul = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("ul");
			div = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			button0.$$.fragment.c();
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			button1.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div, "class", "col-12  fixed mb-5 pb-5");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(ul, "class", "navbar-nav  ml-auto");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, ul, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(ul, div);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button0, div, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div, t);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button1, div, null);
			current = true;
		},

		p(changed, ctx) {
			var button0_changes = {};
			if (changed.$$scope) button0_changes.$$scope = { changed, ctx };
			button0.$set(button0_changes);

			var button1_changes = {};
			if (changed.$$scope) button1_changes.$$scope = { changed, ctx };
			button1.$set(button1_changes);
		},

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button0.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button1.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button0.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button1.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(ul);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button0);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button1);
		}
	};
}

// (116:8) <Navbar id="pager" class="navbar bg-white fixed-bottom shadow-lg">
function create_default_slot(ctx) {
	var div0, p, t2, small, t3, strong, t4, t5, div1, t6, div2, t7, div3, t8, div4, t9, current;

	var button0 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		name: "notsetuju",
		class: "btn btn-secondary",
		block: true,
		style: "display:none",
		$$slots: { default: [create_default_slot_7] },
		$$scope: { ctx }
	}
	});
	button0.$on("click", ctx.action_tidak_setuju);

	var button1 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		name: "setuju",
		class: "btn btn-danger",
		block: true,
		style: "display:none",
		$$slots: { default: [create_default_slot_6] },
		$$scope: { ctx }
	}
	});
	button1.$on("click", ctx.action_setuju);

	var button2 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		name: "dnotsetuju",
		block: true,
		disabled: true,
		class: "btn btn-secondary",
		style: "display:block",
		$$slots: { default: [create_default_slot_5] },
		$$scope: { ctx }
	}
	});

	var button3 = new _node_modules_sveltestrap_src_Button__WEBPACK_IMPORTED_MODULE_3__["default"]({
		props: {
		name: "dsetuju",
		block: true,
		disabled: true,
		class: "btn btn-secondary",
		style: "display:block",
		$$slots: { default: [create_default_slot_4] },
		$$scope: { ctx }
	}
	});

	var navbar = new _node_modules_sveltestrap_src_Navbar__WEBPACK_IMPORTED_MODULE_6__["default"]({
		props: {
		class: "navbar navbar-expand-xs fixed-bottom   mb-5 pb-5",
		$$slots: { default: [create_default_slot_1] },
		$$scope: { ctx }
	}
	});

	return {
		c() {
			div0 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			p = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("p");
			p.innerHTML = `Gulirkan layar hingga detail penawaran ini selesai untuk menyetujui. <br> Apakah anda setuju dengan penawaran ini ?`;
			t2 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			small = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("small");
			t3 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])("Penawaran ini berlaku hingga ");
			strong = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("strong");
			t4 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["text"])(ctx.dateTime);
			t5 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			div1 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			button0.$$.fragment.c();
			t6 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			div2 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			button1.$$.fragment.c();
			t7 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			div3 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			button2.$$.fragment.c();
			t8 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			div4 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			button3.$$.fragment.c();
			t9 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			navbar.$$.fragment.c();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(p, "class", "pt-2");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(strong, "class", "text-danger");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(small, "class", "font-italic font-weight-small");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div0, "class", "col-12");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div1, "class", "col-6");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div2, "class", "col-6");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div3, "class", "col-6");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div4, "class", "col-6");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div0, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div0, p);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div0, t2);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div0, small);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(small, t3);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(small, strong);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(strong, t4);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t5, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div1, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button0, div1, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t6, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div2, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button1, div2, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t7, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div3, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button2, div3, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t8, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, div4, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(button3, div4, null);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t9, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(navbar, target, anchor);
			current = true;
		},

		p(changed, ctx) {
			var button0_changes = {};
			if (changed.$$scope) button0_changes.$$scope = { changed, ctx };
			button0.$set(button0_changes);

			var button1_changes = {};
			if (changed.$$scope) button1_changes.$$scope = { changed, ctx };
			button1.$set(button1_changes);

			var button2_changes = {};
			if (changed.$$scope) button2_changes.$$scope = { changed, ctx };
			button2.$set(button2_changes);

			var button3_changes = {};
			if (changed.$$scope) button3_changes.$$scope = { changed, ctx };
			button3.$set(button3_changes);

			var navbar_changes = {};
			if (changed.$$scope) navbar_changes.$$scope = { changed, ctx };
			navbar.$set(navbar_changes);
		},

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button0.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button1.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button2.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(button3.$$.fragment, local);

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(navbar.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button0.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button1.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button2.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(button3.$$.fragment, local);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(navbar.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div0);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t5);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div1);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button0);

			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t6);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div2);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button1);

			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t7);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div3);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button2);

			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t8);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(div4);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(button3);

			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t9);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(navbar, detaching);
		}
	};
}

function create_fragment(ctx) {
	var t0, main, div5, div4, div3, div2, t1, current;

	var navbar = new _node_modules_sveltestrap_src_Navbar__WEBPACK_IMPORTED_MODULE_6__["default"]({
		props: {
		id: "pager",
		class: "navbar bg-white fixed-bottom shadow-lg",
		$$slots: { default: [create_default_slot] },
		$$scope: { ctx }
	}
	});

	return {
		c() {
			t0 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			main = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("main");
			div5 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div4 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div3 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div2 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["element"])("div");
			div2.innerHTML = `<div id="viewport-container" name="container_terms"><div role="main" id="viewport"></div></div>`;
			t1 = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			navbar.$$.fragment.c();
			document_1.title = "PDF Viewer";
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div2, "id", "pdf-container");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div2, "onresize", "resize");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div3, "class", "justify-content-center align-items-center");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div4, "class", "col-12");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div4, "height", "100%");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_style"])(div4, "position", "fixed");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div5, "id", "pdf-viewer");
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["attr"])(div5, "class", "row justify-content-center animate-bottom ");
		},

		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t0, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, main, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(main, div5);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div5, div4);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div4, div3);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div3, div2);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["append"])(div3, t1);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(navbar, div3, null);
			current = true;
		},

		p(changed, ctx) {
			var navbar_changes = {};
			if (changed.$$scope) navbar_changes.$$scope = { changed, ctx };
			navbar.$set(navbar_changes);
		},

		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(navbar.$$.fragment, local);

			current = true;
		},

		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(navbar.$$.fragment, local);
			current = false;
		},

		d(detaching) {
			if (detaching) {
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t0);
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(main);
			}

			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(navbar);
		}
	};
}

function setuju(){
    document.getElementById("setuju").style.display = "block";
    document.getElementById("pdf-container").style.display = "none";
    document.getElementById("pager").style.display = "none";
			return false;
}

function tidaksetuju(){      
    document.getElementById("tidaksetuju").style.display = "block ";
    document.getElementById("pdf-container").style.display = "none";
    document.getElementById("pager").style.display = "none";
			return false;
}

function zoomin(){
  _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["zoomIn"]();
  var pdfzoom = document.getElementById("viewport");
  var currWidth = pdfzoom.clientWidth;
  if(currWidth == 2500) return false;
   else{
      pdfzoom.style.width = (currWidth + 100) + "px";
  } 
}

function zoomout(){
  _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["zoomOut"]();
  var pdfzoom = document.getElementById("viewport");
  var currWidth = pdfzoom.clientWidth;
  if(currWidth == 100) return false;
   else{
      pdfzoom.style.width = (currWidth - 100) + "px";
  }
}

let time = "23:59";

function instance($$self, $$props, $$invalidate) {
	

  let today = new Date();
  let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
  let dateTime = date+' '+time;
  let { dataPdf, action_setuju, action_tidak_setuju } = $$props;
  
  Object(svelte__WEBPACK_IMPORTED_MODULE_1__["onMount"])(() => {
    document.getElementsByName("container_terms")[0].addEventListener("scroll", checkScrollHeight, false);
    function checkScrollHeight() {
      var agreementTextElement = document.getElementsByName("container_terms")[0];
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= agreementTextElement.scrollHeight) {
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= 1000) {
      if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= agreementTextElement.scrollHeight - 450) {
        document.getElementsByName("dsetuju")[0].style.display = "none";	
        document.getElementsByName("dnotsetuju")[0].style.display = "none";
        document.getElementsByName("setuju")[0].style.display = "block";	
        document.getElementsByName("notsetuju")[0].style.display = "block";	
      }
    }
    const viewport = document.querySelector("#viewport");
    // console.log(dataPdf);
    _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["initPDFViewer"]({data:atob(dataPdf)});
    
    const browserDetect = Object(browser_detect__WEBPACK_IMPORTED_MODULE_11__["default"])();
    // console.log(browserDetect.mobile);
    var scale;
	  if(browserDetect.mobile === true){
        scale = _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["scaleMobile"]();
        document.getElementById("viewport-container").style.paddingBottom = "25%";
        document.getElementById("pager").style.fontSize="12px";
      } else if(browserDetect.mobile === false) {
        scale = _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["scaleWeb"](); 
        document.getElementById("viewport-container").style.paddingTop = "5%";
        document.getElementById("zoomin").style.width = "20px";
        document.getElementById("zoomout").style.width = "20px";
        
    }
  
  });

  window.addEventListener("resize", function(e){
    // console.log("resize");
    _PDFGenerator__WEBPACK_IMPORTED_MODULE_2__["render"]();
  });

	$$self.$set = $$props => {
		if ('dataPdf' in $$props) $$invalidate('dataPdf', dataPdf = $$props.dataPdf);
		if ('action_setuju' in $$props) $$invalidate('action_setuju', action_setuju = $$props.action_setuju);
		if ('action_tidak_setuju' in $$props) $$invalidate('action_tidak_setuju', action_tidak_setuju = $$props.action_tidak_setuju);
	};

	return {
		dateTime,
		dataPdf,
		action_setuju,
		action_tidak_setuju
	};
}

class CampaignOutput extends svelte_internal__WEBPACK_IMPORTED_MODULE_0__["SvelteComponent"] {
	constructor(options) {
		super();
		Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["init"])(this, options, instance, create_fragment, svelte_internal__WEBPACK_IMPORTED_MODULE_0__["safe_not_equal"], ["dataPdf", "action_setuju", "action_tidak_setuju"]);
	}
}

/* harmony default export */ __webpack_exports__["default"] = (CampaignOutput);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcm91dGVzL0NhbXBhaWduT3V0cHV0L1BERkdlbmVyYXRvci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcm91dGVzL0NhbXBhaWduT3V0cHV0L2luZGV4LnN2ZWx0ZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU87QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHUDtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7O0FBRUE7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFJQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVPO0FBQ1A7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGdDQUFnQyxtQkFBbUI7QUFDbkQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswRkNNd0ssTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswRkFDTCxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFsQjdILG1CQUFtQjs7Ozs7Ozs7Ozs7OzBCQUdyQixhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lFQVJ3RCxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoSDlILFNBQVMsTUFBTSxFQUFFO0FBQ2YsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0FBQzlELElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztBQUNwRSxJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7R0FDM0QsT0FBTyxLQUFLLENBQUM7Q0FDZjs7QUFFRCxTQUFTLFdBQVcsRUFBRTtBQUNwQixJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7QUFDcEUsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO0FBQ3BFLElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztHQUMzRCxPQUFPLEtBQUssQ0FBQztDQUNmOztBQUVELFNBQVMsTUFBTSxFQUFFO0FBQ2YsRUFBRSxvREFBbUIsRUFBRSxDQUFDO0FBQ3hCLEVBQUUsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNwRCxFQUFFLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDdEMsRUFBRSxHQUFHLFNBQVMsSUFBSSxJQUFJLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFDckMsT0FBTztBQUNQLE1BQU0sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO0FBQ3JELEdBQUc7Q0FDSjs7QUFFRCxTQUFTLE9BQU8sRUFBRTtBQUNoQixFQUFFLHFEQUFvQixFQUFFLENBQUM7QUFDekIsRUFBRSxJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BELEVBQUUsSUFBSSxTQUFTLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQztBQUN0QyxFQUFFLEdBQUcsU0FBUyxJQUFJLEdBQUcsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUNwQyxPQUFPO0FBQ1AsTUFBTSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7QUFDckQsR0FBRztDQUNKOztBQW9CQyxJQUFJLElBQUksR0FBRyxPQUFPLENBQUM7OztDQUprQjs7RUFFckMsSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztFQUN2QixJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQ3hEO0VBQ25CLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0VBQ3RCLE1BQUksT0FBTyxFQUNQLGFBQWEsRUFDYiwrQkFBbUIsQ0FBQzs7RUFFL0Isc0RBQU8sQ0FBQyxNQUFNO0lBQ1osUUFBUSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3RHLFNBQVMsaUJBQWlCLEdBQUc7TUFDM0IsSUFBSSxvQkFBb0IsR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O01BRzVFLElBQUksb0JBQW9CLENBQUMsWUFBWSxHQUFHLG9CQUFvQixDQUFDLFNBQVMsSUFBSSxvQkFBb0IsQ0FBQyxZQUFZLEdBQUcsR0FBRyxFQUFFO1FBQ2pILFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztRQUNoRSxRQUFRLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7UUFDbkUsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ2hFLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztPQUNwRTtLQUNGO0lBQ0QsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQzs7SUFFckQsMkRBQTBCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzs7SUFFakQsTUFBTSxhQUFhLEdBQUcsK0RBQU8sRUFBRSxDQUFDOztJQUVoQyxJQUFJLEtBQUssQ0FBQztHQUNYLEdBQUcsYUFBYSxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUM7UUFDNUIsS0FBSyxHQUFHLHlEQUF3QixFQUFFLENBQUM7UUFDbkMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzFFLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7T0FDeEQsTUFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLEtBQUssS0FBSyxFQUFFO1FBQ3hDLEtBQUssR0FBRyxzREFBcUIsRUFBRSxDQUFDO1FBQ2hDLFFBQVEsQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN0RSxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1FBQ3ZELFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7O0tBRTNEOztHQUVGLENBQUMsQ0FBQzs7RUFFSCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDOztJQUUzQyxvREFBbUIsRUFBRSxDQUFDO0dBQ3ZCLENBQUMsQ0FBQyIsImZpbGUiOiI1Y2FiYWE1MjlmNzFiNDEwNTVhYi9DYW1wYWlnbk91dHB1dH5WZXJpZmljYXRpb25+aW5kZXguQ2FtcGFpZ25PdXRwdXR+VmVyaWZpY2F0aW9ufmluZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGxldCBjdXJyZW50UGFnZUluZGV4ID0gMDtcbmV4cG9ydCBsZXQgcGFnZU1vZGUgPSA1MDtcbmV4cG9ydCBsZXQgY3Vyc29ySW5kZXggPSBNYXRoLmZsb29yKGN1cnJlbnRQYWdlSW5kZXggLyBwYWdlTW9kZSk7XG5leHBvcnQgbGV0IHBkZkluc3RhbmNlID0gbnVsbDtcbmV4cG9ydCBsZXQgdG90YWxQYWdlc0NvdW50ID0gMDtcbmV4cG9ydCBsZXQgc2NhbGUgPSAwLjQ7XG5cblxuLy8gaW1wb3J0ICogYXMgcGRmanNMaWIgZnJvbSAncGRmanMtZGlzdCc7XG4vLyBjb25zdCBwZGZqc0xpYiA9IHJlcXVpcmUoXCJwZGZqcy1kaXN0L3dlYnBhY2tcIik7XG5cbmV4cG9ydCBjb25zdCBzY2FsZU1vYmlsZSA9IGZ1bmN0aW9uKCl7XG4gICAgc2NhbGUgPSAwLjQ7XG59XG5leHBvcnQgY29uc3Qgc2NhbGVXZWIgPSBmdW5jdGlvbigpe1xuICAgIHNjYWxlID0gMS4wO1xuICAgIFxufVxuXG5leHBvcnQgY29uc3Qgem9vbUluID0gZnVuY3Rpb24oKXtcbiAgICBpZihzY2FsZSA+PSAwLjIpe1xuICAgICAgICBzY2FsZSA9IHNjYWxlIC0gMC4wNTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coc2NhbGUpO1xuICAgICAgICByZW5kZXIoKTtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCB6b29tT3V0ID0gZnVuY3Rpb24oKXtcbiAgICBpZihzY2FsZSA8PSAwLjQpe1xuICAgICAgICBzY2FsZSA9IHNjYWxlICsgMC4wNTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coc2NhbGUpO1xuICAgICAgICByZW5kZXIoKTtcbiAgICB9XG59XG5cblxuXG4vLyBleHBvcnQgY29uc3Qgdmlld3BvcnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3ZpZXdwb3J0XCIpO1xuZXhwb3J0IGNvbnN0IGluaXRQREZWaWV3ZXIgPSBmdW5jdGlvbihwZGZVUkwpIHtcbiAgICBwZGZqc0xpYi5nZXREb2N1bWVudChwZGZVUkwpLnRoZW4ocGRmID0+IHtcbiAgICBwZGZJbnN0YW5jZSA9IHBkZjtcbiAgICB0b3RhbFBhZ2VzQ291bnQgPSBwZGYubnVtUGFnZXM7XG4gICAgaW5pdFBhZ2VyKCk7XG4gICAgLy8gaW5pdFBhZ2VNb2RlKCk7XG4gICAgcmVuZGVyKCk7XG4gICAgfSk7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gb25QYWdlckJ1dHRvbnNDbGljayhldmVudCkge1xuICAgIGNvbnN0IGFjdGlvbiA9IGV2ZW50LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXBhZ2VyXCIpO1xuICAgIFxuICAgIGlmIChhY3Rpb24gPT09IFwicHJldlwiKSB7XG4gICAgaWYgKGN1cnJlbnRQYWdlSW5kZXggPT09IDApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjdXJyZW50UGFnZUluZGV4IC09IHBhZ2VNb2RlO1xuICAgIGlmIChjdXJyZW50UGFnZUluZGV4IDwgMCkge1xuICAgICAgICBjdXJyZW50UGFnZUluZGV4ID0gMDtcbiAgICB9XG4gICAgcmVuZGVyKCk7XG4gICAgfVxuICAgIFxuICAgIGlmIChhY3Rpb24gPT09IFwibmV4dFwiKSB7XG4gICAgaWYgKGN1cnJlbnRQYWdlSW5kZXggPT09IHRvdGFsUGFnZXNDb3VudCAtIDEpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjdXJyZW50UGFnZUluZGV4ICs9IHBhZ2VNb2RlO1xuICAgIGlmIChjdXJyZW50UGFnZUluZGV4ID4gdG90YWxQYWdlc0NvdW50IC0gMSkge1xuICAgICAgICBjdXJyZW50UGFnZUluZGV4ID0gdG90YWxQYWdlc0NvdW50IC0gMTtcbiAgICB9XG4gICAgcmVuZGVyKCk7XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaW5pdFBhZ2VyKCkge1xuICAgIGNvbnN0IHBhZ2VyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNwYWdlclwiKTtcbiAgICBwYWdlci5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgb25QYWdlckJ1dHRvbnNDbGljayk7XG4gICAgLy8gSSBsaWtlIHRoaXMgcGF0dGVybiwgYnV0IHRoaXMgaXMgbmV2ZXIgYWN0dWFsbHkgY2FsbGVkLCBpcyBpdD9cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgIHBhZ2VyLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBvblBhZ2VyQnV0dG9uc0NsaWNrKTtcbiAgICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gb25QYWdlTW9kZUNoYW5nZShldmVudCkge1xuICAgIHBhZ2VNb2RlID0gTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgcmVuZGVyKCk7XG59XG5leHBvcnQgZnVuY3Rpb24gaW5pdFBhZ2VNb2RlKCkge1xuICAgIGNvbnN0IGlucHV0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNwYWdlLW1vZGUgaW5wdXRcIik7XG4gICAgaW5wdXQuc2V0QXR0cmlidXRlKFwibWF4XCIsIHRvdGFsUGFnZXNDb3VudCk7XG4gICAgaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBvblBhZ2VNb2RlQ2hhbmdlKTtcbiAgICAvLyBTYW1lIGhlcmUuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICBpbnB1dC5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2hhbmdlXCIsIG9uUGFnZU1vZGVDaGFuZ2UpO1xuICAgIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZW5kZXIoKSB7XG4gICAgY3Vyc29ySW5kZXggPSBNYXRoLmZsb29yKGN1cnJlbnRQYWdlSW5kZXggLyBwYWdlTW9kZSk7XG4gICAgLy8gQ291bGQgYWxzbyBiZTpcbiAgICAvLyBjb25zdCBzdGFydFBhZ2VJbmRleCA9IGN1cnJlbnRQYWdlSW5kZXggLSAoY3VycmVudFBhZ2VJbmRleCAlIHBhZ2VNb2RlKTtcbiAgICBjb25zdCBzdGFydFBhZ2VJbmRleCA9IGN1cnNvckluZGV4ICogcGFnZU1vZGU7XG4gICAgY29uc3QgZW5kUGFnZUluZGV4ID1cbiAgICBzdGFydFBhZ2VJbmRleCArIHBhZ2VNb2RlIDwgdG90YWxQYWdlc0NvdW50XG4gICAgICAgID8gc3RhcnRQYWdlSW5kZXggKyBwYWdlTW9kZSAtIDFcbiAgICAgICAgOiB0b3RhbFBhZ2VzQ291bnQgLSAxO1xuXG4gICAgY29uc3QgcmVuZGVyUGFnZXNQcm9taXNlcyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSBzdGFydFBhZ2VJbmRleDsgaSA8PSBlbmRQYWdlSW5kZXg7IGkrKykge1xuICAgIHJlbmRlclBhZ2VzUHJvbWlzZXMucHVzaChwZGZJbnN0YW5jZS5nZXRQYWdlKGkgKyAxKSk7XG4gICAgfVxuXG4gICAgUHJvbWlzZS5hbGwocmVuZGVyUGFnZXNQcm9taXNlcykudGhlbihwYWdlcyA9PiB7XG4gICAgY29uc3QgcGFnZXNIVE1MID0gYDxkaXYgc3R5bGU9XCJ3aWR0aDogJHtcbiAgICAgICAgcGFnZU1vZGUgPiAxID8gXCIxMDAlXCIgOiBcIjEwMCVcIlxuICAgIH1cIj48Y2FudmFzIGlkPVwiem9vbVwiPjwvY2FudmFzPjwvZGl2PmAucmVwZWF0KHBhZ2VzLmxlbmd0aCk7XG4gICAgdmlld3BvcnQuaW5uZXJIVE1MID0gcGFnZXNIVE1MO1xuICAgIHBhZ2VzLmZvckVhY2gocmVuZGVyUGFnZSk7XG4gICAgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZW5kZXJQYWdlKHBhZ2UpIHtcbiAgICAvLyBjb25zb2xlLmxvZyhzY2FsZSk7XG4gICAgbGV0IHBkZlZpZXdwb3J0ID0gcGFnZS5nZXRWaWV3cG9ydChzY2FsZSk7XG4gICAgY29uc3QgY29udGFpbmVyID0gdmlld3BvcnQuY2hpbGRyZW5bcGFnZS5wYWdlSW5kZXggLSBjdXJzb3JJbmRleCAqIHBhZ2VNb2RlXTtcbiAgICBwZGZWaWV3cG9ydCA9IHBhZ2UuZ2V0Vmlld3BvcnQoY29udGFpbmVyLm9mZnNldFdpZHRoIC8gcGRmVmlld3BvcnQud2lkdGgpO1xuICAgIGNvbnN0IGNhbnZhcyA9IGNvbnRhaW5lci5jaGlsZHJlblswXTtcbiAgICBjb25zdCBjb250ZXh0ID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcbiAgICBjYW52YXMuaGVpZ2h0ID0gcGRmVmlld3BvcnQuaGVpZ2h0O1xuICAgIGNhbnZhcy53aWR0aCA9IHBkZlZpZXdwb3J0LndpZHRoO1xuXG4gICAgcGFnZS5yZW5kZXIoe1xuICAgIGNhbnZhc0NvbnRleHQ6IGNvbnRleHQsXG4gICAgdmlld3BvcnQ6IHBkZlZpZXdwb3J0LFxuICAgIH0pO1xufVxuXG4iLCJcbjxzdmVsdGU6aGVhZD5cblx0PHRpdGxlPlBERiBWaWV3ZXI8L3RpdGxlPlxuPC9zdmVsdGU6aGVhZD5cblxuPHNjcmlwdCBjb250ZXh0PVwibW9kdWxlXCI+XG5cbmZ1bmN0aW9uIHNldHVqdSgpe1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZXR1anVcIikuc3R5bGUuZGlzcGxheSA9IFwiYmxvY2tcIjtcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGRmLWNvbnRhaW5lclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBhZ2VyXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcblx0XHRcdHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gdGlkYWtzZXR1anUoKXsgICAgICBcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGlkYWtzZXR1anVcIikuc3R5bGUuZGlzcGxheSA9IFwiYmxvY2sgXCI7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBkZi1jb250YWluZXJcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwYWdlclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIHpvb21pbigpe1xuICAgIFBERkdlbmVyYXRvci56b29tSW4oKTtcbiAgICB2YXIgcGRmem9vbSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidmlld3BvcnRcIik7XG4gICAgdmFyIGN1cnJXaWR0aCA9IHBkZnpvb20uY2xpZW50V2lkdGg7XG4gICAgaWYoY3VycldpZHRoID09IDI1MDApIHJldHVybiBmYWxzZTtcbiAgICAgZWxzZXtcbiAgICAgICAgcGRmem9vbS5zdHlsZS53aWR0aCA9IChjdXJyV2lkdGggKyAxMDApICsgXCJweFwiO1xuICAgIH0gXG59XG5cbmZ1bmN0aW9uIHpvb21vdXQoKXtcbiAgICBQREZHZW5lcmF0b3Iuem9vbU91dCgpO1xuICAgIHZhciBwZGZ6b29tID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ2aWV3cG9ydFwiKTtcbiAgICB2YXIgY3VycldpZHRoID0gcGRmem9vbS5jbGllbnRXaWR0aDtcbiAgICBpZihjdXJyV2lkdGggPT0gMTAwKSByZXR1cm4gZmFsc2U7XG4gICAgIGVsc2V7XG4gICAgICAgIHBkZnpvb20uc3R5bGUud2lkdGggPSAoY3VycldpZHRoIC0gMTAwKSArIFwicHhcIjtcbiAgICB9XG59XG5cbjwvc2NyaXB0PlxuXG48c2NyaXB0PlxuICBpbXBvcnQgeyBvbk1vdW50IH0gZnJvbSAnc3ZlbHRlJztcbiAgaW1wb3J0ICogYXMgUERGR2VuZXJhdG9yIGZyb20gJy4vUERGR2VuZXJhdG9yJztcbiAgLy8gaW1wb3J0IHsgQnV0dG9uLElucHV0LCBCdXR0b25Hcm91cCxOYXZiYXIsIENvbCwgUm93IH0gZnJvbSAnc3ZlbHRlc3RyYXAnO1xuICBpbXBvcnQgQnV0dG9uIGZyb20gJy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvQnV0dG9uJztcbiAgaW1wb3J0IElucHV0IGZyb20gJy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvSW5wdXQnO1xuICBpbXBvcnQgQnV0dG9uR3JvdXAgZnJvbSAnLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N2ZWx0ZXN0cmFwL3NyYy9CdXR0b25Hcm91cCc7XG4gIGltcG9ydCBOYXZiYXIgZnJvbSAnLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N2ZWx0ZXN0cmFwL3NyYy9OYXZiYXInO1xuICBpbXBvcnQgQ29sIGZyb20gJy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdmVsdGVzdHJhcC9zcmMvQ29sJztcbiAgaW1wb3J0IFJvdyBmcm9tICcuLi8uLi8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlc3RyYXAvc3JjL1Jvdyc7XG4gIGltcG9ydCBab29taW4gZnJvbSAnc3ZlbHRlLWljb25zL2ZhL0ZhUGx1cy5zdmVsdGUnO1xuICBpbXBvcnQgWm9vbW91dCBmcm9tICdzdmVsdGUtaWNvbnMvZmEvRmFNaW51cy5zdmVsdGUnO1xuICBpbXBvcnQgYnJvd3NlciBmcm9tICdicm93c2VyLWRldGVjdCc7XG5cbiAgbGV0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgbGV0IGRhdGUgPSB0b2RheS5nZXRGdWxsWWVhcigpKyctJysodG9kYXkuZ2V0TW9udGgoKSsxKSsnLScrdG9kYXkuZ2V0RGF0ZSgpO1xuICBsZXQgdGltZSA9IFwiMjM6NTlcIjtcbiAgbGV0IGRhdGVUaW1lID0gZGF0ZSsnICcrdGltZTtcbiAgZXhwb3J0IGxldCBkYXRhUGRmO1xuICBleHBvcnQgbGV0IGFjdGlvbl9zZXR1anU7XG4gIGV4cG9ydCBsZXQgYWN0aW9uX3RpZGFrX3NldHVqdTtcbiAgXG4gIG9uTW91bnQoKCkgPT4ge1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlOYW1lKFwiY29udGFpbmVyX3Rlcm1zXCIpWzBdLmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgY2hlY2tTY3JvbGxIZWlnaHQsIGZhbHNlKTtcbiAgICBmdW5jdGlvbiBjaGVja1Njcm9sbEhlaWdodCgpIHtcbiAgICAgIHZhciBhZ3JlZW1lbnRUZXh0RWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlOYW1lKFwiY29udGFpbmVyX3Rlcm1zXCIpWzBdO1xuICAgICAgLy8gaWYgKGFncmVlbWVudFRleHRFbGVtZW50LmNsaWVudEhlaWdodCArIGFncmVlbWVudFRleHRFbGVtZW50LnNjcm9sbFRvcCA+PSBhZ3JlZW1lbnRUZXh0RWxlbWVudC5zY3JvbGxIZWlnaHQpIHtcbiAgICAgIC8vIGlmIChhZ3JlZW1lbnRUZXh0RWxlbWVudC5jbGllbnRIZWlnaHQgKyBhZ3JlZW1lbnRUZXh0RWxlbWVudC5zY3JvbGxUb3AgPj0gMTAwMCkge1xuICAgICAgaWYgKGFncmVlbWVudFRleHRFbGVtZW50LmNsaWVudEhlaWdodCArIGFncmVlbWVudFRleHRFbGVtZW50LnNjcm9sbFRvcCA+PSBhZ3JlZW1lbnRUZXh0RWxlbWVudC5zY3JvbGxIZWlnaHQgLSA0NTApIHtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUoXCJkc2V0dWp1XCIpWzBdLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcdFxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5TmFtZShcImRub3RzZXR1anVcIilbMF0uc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5TmFtZShcInNldHVqdVwiKVswXS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1x0XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlOYW1lKFwibm90c2V0dWp1XCIpWzBdLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XHRcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgdmlld3BvcnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3ZpZXdwb3J0XCIpO1xuICAgIC8vIGNvbnNvbGUubG9nKGRhdGFQZGYpO1xuICAgIFBERkdlbmVyYXRvci5pbml0UERGVmlld2VyKHtkYXRhOmF0b2IoZGF0YVBkZil9KTtcbiAgICBcbiAgICBjb25zdCBicm93c2VyRGV0ZWN0ID0gYnJvd3NlcigpO1xuICAgIC8vIGNvbnNvbGUubG9nKGJyb3dzZXJEZXRlY3QubW9iaWxlKTtcbiAgICB2YXIgc2NhbGU7XG5cdCAgaWYoYnJvd3NlckRldGVjdC5tb2JpbGUgPT09IHRydWUpe1xuICAgICAgICBzY2FsZSA9IFBERkdlbmVyYXRvci5zY2FsZU1vYmlsZSgpO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInZpZXdwb3J0LWNvbnRhaW5lclwiKS5zdHlsZS5wYWRkaW5nQm90dG9tID0gXCIyNSVcIjtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwYWdlclwiKS5zdHlsZS5mb250U2l6ZT1cIjEycHhcIjtcbiAgICAgIH0gZWxzZSBpZihicm93c2VyRGV0ZWN0Lm1vYmlsZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgc2NhbGUgPSBQREZHZW5lcmF0b3Iuc2NhbGVXZWIoKTsgXG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidmlld3BvcnQtY29udGFpbmVyXCIpLnN0eWxlLnBhZGRpbmdUb3AgPSBcIjUlXCI7XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiem9vbWluXCIpLnN0eWxlLndpZHRoID0gXCIyMHB4XCI7XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiem9vbW91dFwiKS5zdHlsZS53aWR0aCA9IFwiMjBweFwiO1xuICAgICAgICBcbiAgICB9XG4gIFxuICB9KTtcblxuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCBmdW5jdGlvbihlKXtcbiAgICAvLyBjb25zb2xlLmxvZyhcInJlc2l6ZVwiKTtcbiAgICBQREZHZW5lcmF0b3IucmVuZGVyKCk7XG4gIH0pO1xuXG48L3NjcmlwdD5cblxuPG1haW4+XG4gIDxkaXYgaWQ9XCJwZGYtdmlld2VyXCIgY2xhc3M9XCJyb3cganVzdGlmeS1jb250ZW50LWNlbnRlciBhbmltYXRlLWJvdHRvbSBcIj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sLTEyXCIgc3R5bGU9XCJoZWlnaHQ6IDEwMCU7IHBvc2l0aW9uOiBmaXhlZDtcIiA+XG4gICAgICA8ZGl2IGNsYXNzPVwianVzdGlmeS1jb250ZW50LWNlbnRlciBhbGlnbi1pdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBpZD1cInBkZi1jb250YWluZXJcIiBvbnJlc2l6ZT1cInJlc2l6ZVwiPlxuICAgICAgICAgIDxkaXYgaWQ9XCJ2aWV3cG9ydC1jb250YWluZXJcIiAgbmFtZT1cImNvbnRhaW5lcl90ZXJtc1wiID5cbiAgICAgICAgICAgIDxkaXYgIHJvbGU9XCJtYWluXCIgaWQ9XCJ2aWV3cG9ydFwiPjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj4gXG4gICAgICAgIDxOYXZiYXIgaWQ9XCJwYWdlclwiIGNsYXNzPVwibmF2YmFyIGJnLXdoaXRlIGZpeGVkLWJvdHRvbSBzaGFkb3ctbGdcIj4gIFxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC0xMlwiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJwdC0yXCI+R3VsaXJrYW4gbGF5YXIgaGluZ2dhIGRldGFpbCBwZW5hd2FyYW4gaW5pIHNlbGVzYWkgdW50dWsgbWVueWV0dWp1aS4gPGJyPiBBcGFrYWggYW5kYSBzZXR1anUgZGVuZ2FuIHBlbmF3YXJhbiBpbmkgPzwvcD5cbiAgICAgICAgICAgICAgPHNtYWxsICBjbGFzcz1cImZvbnQtaXRhbGljIGZvbnQtd2VpZ2h0LXNtYWxsXCI+UGVuYXdhcmFuIGluaSBiZXJsYWt1IGhpbmdnYSA8c3Ryb25nIGNsYXNzPVwidGV4dC1kYW5nZXJcIj57ZGF0ZVRpbWV9PC9zdHJvbmc+PC9zbWFsbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8IS0tZW5hYmxlIGJ1dHRvbi0tPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC02XCI+XG4gICAgICAgICAgICAgIDxCdXR0b24gbmFtZT1cIm5vdHNldHVqdVwiIG9uOmNsaWNrID0ge2FjdGlvbl90aWRha19zZXR1anV9IGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBibG9jayBzdHlsZT1cImRpc3BsYXk6bm9uZVwiPlRpZGFrIFNldHVqdTwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLTZcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiAgbmFtZT1cInNldHVqdVwiIG9uOmNsaWNrID0ge2FjdGlvbl9zZXR1anV9IGNsYXNzPVwiYnRuIGJ0bi1kYW5nZXJcIiBibG9jayBzdHlsZT1cImRpc3BsYXk6bm9uZVwiPlNldHVqdTwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwhLS1kaXNhYmxlIGJ1dHRvbi0tPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC02XCI+XG4gICAgICAgICAgICAgIDxCdXR0b24gbmFtZT1cImRub3RzZXR1anVcIiBibG9jayBkaXNhYmxlZCBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgc3R5bGU9XCJkaXNwbGF5OmJsb2NrXCI+VGlkYWsgU2V0dWp1PC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtNlwiPlxuICAgICAgICAgICAgICA8QnV0dG9uICBuYW1lPVwiZHNldHVqdVwiIGJsb2NrIGRpc2FibGVkIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBzdHlsZT1cImRpc3BsYXk6YmxvY2tcIj5TZXR1anU8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8TmF2YmFyICBjbGFzcz1cIm5hdmJhciBuYXZiYXItZXhwYW5kLXhzIGZpeGVkLWJvdHRvbSAgIG1iLTUgcGItNVwiPiAgXG4gICAgICAgICAgICA8dWwgY2xhc3M9XCJuYXZiYXItbmF2ICBtbC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPGRpdiAgY2xhc3MgPVwiY29sLTEyICBmaXhlZCBtYi01IHBiLTVcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGFyayBidG4tc21cIiBzdHlsZT1cImJvcmRlci1yYWRpdXM6MTAwJTtcIj48ZGl2IGlkPVwiem9vbWluXCIgc3R5bGU9XCJmb250LXNpemU6OHB4OyB3aWR0aDogOHB4OyBtYXJnaW4tYm90dG9tOjFweDtcIiAgb246Y2xpY2sgPSB7em9vbWlufT48Wm9vbWluLz48L2Rpdj4gPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b24gY2xhc3M9XCJidG4gYnRuLWRhcmsgYnRuLXNtXCIgc3R5bGU9XCJib3JkZXItcmFkaXVzOjEwMCU7XCI+PGRpdiBpZD1cInpvb21vdXRcIiBzdHlsZT1cImZvbnQtc2l6ZTo4cHg7IHdpZHRoOiA4cHg7IG1hcmdpbi1ib3R0b206MXB4O1wiICBvbjpjbGljayA9IHt6b29tb3V0fT48Wm9vbW91dC8+PC9kaXY+PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+ICAgICAgICAgXG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvTmF2YmFyPiAgXG4gICAgICAgIDwvTmF2YmFyPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9tYWluPlxuIl0sInNvdXJjZVJvb3QiOiIifQ==