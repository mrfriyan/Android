#!/bin/bash
set -e

# node --max-old-space-size=1536
node --unhandled-rejections=strict

npm start
echo "service starting"