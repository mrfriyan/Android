#! /bin/bash

# Wait for MySQL
# until nc -z -v -w30 db 5432
# do
#   echo "Waiting for Postgres..."
#   sleep 1
# done

# echo "Postgres is up and running"

# Run Setup
# bin/setup

# start unoconv
unoconv --listener

sleep 2

# build n run
# pm2 start ./docker/start.sh
npm run start