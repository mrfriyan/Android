const redis = require('redis');
const {RateLimiterRedis, RLWrapperBlackAndWhite} = require('rate-limiter-flexible');
const config = require('./server-config.js')

const redisClient = redis.createClient({
  host: config.redis_host,
  port: config.redis_port,
  enable_offline_queue: false,
});

const limiter = new RateLimiterRedis({
  redis: redisClient,
  keyPrefix: 'middleware',
  points: 2, // 10 requests
  duration: 2, // per 1 second by IP
});

// const limiterWrapped = new RLWrapperBlackAndWhite({
//       limiter,
//       whiteList: ['127.0.0.1', '::1', '[::1]:3000', 'localhost:3000'],
//       blackList: ['13.35.67.49', '13.35.68.50'],
//       isWhite: (ip) => {
//         return /^36.+$/.test(ip);
//       },
//       isBlack: (ip) => {
//         return /^47.+$/.test(ip);
//       },
//       runActionAnyway: false,
//     });

const rateLimiterMiddleware = (req, res, next) => {
  //console.log(req.ip)
    // //console.log(req);
  limiter.consume(req.body.transactionId)
    .then(() => {
      next();
    })
    .catch(() => {
      res.status(429).send('Too Many Requests ss');
    });
};



module.exports = rateLimiterMiddleware;