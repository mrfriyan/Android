const axios = require('axios');
const fs = require('fs');
const path = require('path');
var FormData = require('form-data');


const generatePDFUsingUnoConvServer = async (filePath, outputPath) => {
    const file = fs.createReadStream(filePath);

    // const fileInfo = path.parse(filePath);
    // console.log("path  "+filePath)

    // const destination = outputPath;

    // const headers = {
    //   'Content-Type': 'multipart/form-data',
    //   'Content-Disposition': `attachment; filename="${fileInfo.base}"`
    // };
    // console.log("end headers");

    // var body = new FormData();
    // body.append('file', file);
    // body.append('convert-to', 'pdf'); 
    // // body.append('output',outputPath);

    // console.log("end formdata");

    // // const unoconvUrl = 'https://pf-unoconv-server-uat-pruforce-uat.lb1-pruidlife-uat-az1-to2vcj.pru.intranet.asia'
    // const unoconvUrl = 'http://127.0.0.1:2004'

    // // axios.post(unoconvUrl+'/request', body, {
    // //   headers: {
    // //     "Content-Type": "multipart/form-data",
    // //   }
    // // });

    // /**
    //  * Postman yang sukses conver dmna mas ?
    //  * ke unoconv
    //  */

    //  return {
    //    file: fileInfo,
    //    destination
    //  }


    
    const form = new FormData();
    form.append('file', file);
    form.append('convert-to', 'pdf');

        console.log("path file "+filePath);

    
    return new Promise((resolve, reject) => {
      const config = {
        method: 'post',
        url: 'http://127.0.0.1:2004/request',
        headers: {
          'Content-Type': 'multipart/form-data',
          'Cache-Control': 'no-cache',
          "Content-Disposition": outputPath
        },
        responseType: 'stream',
        data: form
      };
      
      axios(config)
        .then(function (response) {
          // fs.writeFileSync(outputPath, response)
          response.data.pipe(fs.createWriteStream(outputPath));
          resolve({message: 'convert success'})
          // resolve(response)
        })
        .catch(function (error) {
          reject({message: 'unable convert fil!',error: error})
        });
    })

}

let client;

module.exports = {
  generatePDFUsingUnoConvServer: generatePDFUsingUnoConvServer
}