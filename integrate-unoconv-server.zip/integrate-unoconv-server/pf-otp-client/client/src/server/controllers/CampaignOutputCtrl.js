const config = require('../config/server-config.js');
const PizZip = require('pizzip');
const Docxtemplater = require('docxtemplater');
// const ImageModule = require('open-docxtemplater-image-module');
const InspectModule = require("docxtemplater/js/inspect-module");
const Unoconv = require('./Unoconv');
const fs = require('fs');
const path = require('path');
const Utils = require('./Utils');
const pdf2base64 = require('pdf-to-base64');
const moment = require('moment');
const _ = require('lodash');
const logOpts = {
    errorEventName: 'error',
    logDirectory: './log', // NOTE: folder must exist and be writable...
    fileNamePattern: 'roll-<DATE>.log',
    dateFormat: 'DD.MM.YYYY'
};
const log = require('simple-node-logger').createRollingFileLogger(logOpts);

const generatePDFFreePA = async function (params) {
    const inspectModule = new InspectModule();
    const content = fs.readFileSync(path.join(__dirname, '/public/template/sertifikat3.docx'), 'binary');
    const zip = new PizZip(content);
    const doc = new Docxtemplater();

    let fileName = params.fileName;
    let password = params.noSertifikat.substring(params.noSertifikat.length - 4) + params.dob;

    let mapObj = {
        no_polis: params.noPolis,
        no_sertifikat: params.noSertifikat,
        nama_peserta: params.namaPeserta,
        tanggal_awal: params.tanggalAwal,
        tanggal_akhir: params.tanggalAkhir,
        today: params.today
    }

    doc.loadZip(zip);
    doc.attachModule(inspectModule);

    doc.setData(mapObj);

    return new Promise((resolve, reject) => {
        log.info("start render to docx");
        try {
            doc.render();
            const buf = doc.getZip().generate({ type: 'nodebuffer' });
            fs.writeFileSync(path.join(__dirname, '/public/output/' + fileName + '.docx'), buf);
            Utils.convertDocxToPdf(fileName, password).then(function (resp) {
                console.log("success ", resp);
                resolve(resp);
            }).catch((err) => {
                console.log("error", err)
                reject(err);
            })
        }

        catch (error) {
            // //console.log(error);
            log.error("error converting to docx ");
            let e = {
                message: error.message,
                name: error.name,
                stack: error.stack,
                properties: error.properties,
            }
            console.log(e);
            reject(error);
        }
    })
}

const generatePDF = async function (dataAfter, opt, type, agent, isOTP) {
    console.log("masuk generate pdf");
    console.log("start generate pdf ----- ", opt, " ", type, " ", isOTP);
    log.info("start generate pdf ----- ", opt, " ", type, " ", isOTP);
    let stringOpt = "0" + opt;
    const inspectModule = new InspectModule();
    let template = "eup-convent";
    let isSharia = false;

    let simpleSharia = false;
    let currentSelectedEU = "";

    //data dummy cica simple
    let mapCica =
    {
        policyNumber: 79939909,
        agentCode: 1307,
        additional01: 50186413,
        additional02: 50186413,
        additional03: "BAPAK",
        additional04: "KHORNAYLIUS TOMMY",
        additional05: "KHORNAYLIUS TOMMY",
        additional06: "U1B",
        additional07: 500000000,
        additional08: 0,
        additional09: 0,
        additional10: 0,
        additional11: 0,
        additional12: 0,
        additional13: 0,
        additional14: 0,
        additional15: 0,
        additional16: 0,
        additional17: 0,
        additional18: 0,
        additional19: 0,
        additional20: "C1XR",
        additional21: 300000000,
        additional22: 70,
        additional23: 19200000,
        additional24: 18200004,
        additional25: 83333,
        additional26: 19200000,
        additional27: 12,
        additional28: "U1H",
        additional29: 500000000,
        additional30: 0,
        additional31: 0,
        additional32: 0,
        additional33: 0,
        additional34: 0,
        additional35: 0,
        additional36: 0,
        additional37: 0,
        additional38: 0,
        additional39: "NO",
        additional40: 0,
        additional41: 0,
        additional42: 0,
        additional43: "NO",
        additional44: "C1XR",
        additional45: 1300000000,
        additional46: 70,
        additional47: "YES",
        additional48: 73929900,
        additional49: 72929904,
        additional50: 83333,
        additional51: 73929900,
        additional52: "U1H",
        additional53: 500000000,
        additional54: "C1XR",
        additional55: 0,
        additional56: 0,
        additional57: 0,
        additional58: 0,
        additional59: 0,
        additional60: 0,
        additional61: 0,
        additional62: 0,
        additional63: "NO",
        additional64: 0,
        additional65: 0,
        additional66: 0,
        additional67: "NO",
        additional68: "C1XR",
        additional69: 600000000,
        additional70: 70,
        additional71: "YES",
        additional72: 38983800,
        additional73: 37983804,
        additional74: 83333,
        additional75: 38983800,
        additional76: "group2"
    }

    if (dataAfter.campaignInfo.campaignCode == "CCA-001") {
        mapCica = await getDataCampaign(dataAfter.policyNumber, dataAfter.agentNumber, dataAfter.campaignInfo.campaignCode).then((objCampaign) => {
            //// console.log(objCampaign);
            Object.keys(objCampaign).map(function (e) {
                if (objCampaign[e] == null) {
                    objCampaign[e] = "0";
                }
            })
            return objCampaign.data;
        }).catch((err) => {
            //// console.log(err);
            //// console.log("fail connect to campaign detail");
            return error;
        });
    }

    //pengecekan code basic sharia pada EUP/EU     
    dataAfter.products.map(function (obj) {
        if (["U11R", "U1H", "U1S", "U11", "U1HR", "U1SR"].includes(obj.riderCode)) {
            isSharia = true;
        }

    })

    //pengecekan code basic sharia pada cica flexible/simple
    if (["U1H", "U1S", "U11"].includes(mapCica.additional06)) {
        simpleSharia = true;
    }

    //pengechekan template EUP
    if (dataAfter.campaignInfo.campaignCode == "PLS-001") {
        if (isSharia) {
            template = "eup-sharia";
        } else {
            template = "eup-convent";
        }
    }

    //pengechekan template EU
    else if (dataAfter.campaignInfo.campaignCode == "PLS-002") {
        if (isSharia) {
            template = "eu-sharia";
        } else {
            template = "eu-convent";
        }
    }

    //pengechekan template cica simple
    else if (dataAfter.campaignInfo.campaignCode == "CCA-001") {
        mapCica.additional76 = mapCica.additional76.replace(/\s/g, "").toLowerCase();
        if (simpleSharia) {
            if (mapCica.additional76 == "group2" && stringOpt == "02") {
                template = "cica-simple-sharia-non-increase";
            } else {
                template = "cica-simple-sharia-increase";
            }
        } else if (!simpleSharia) {
            if (mapCica.additional76 == "group2" && stringOpt == "02") {
                template = "cica-simple-convent-non-increase";
            } else {
                template = "cica-simple-convent-increase";
            }
        }
    }

    //pengechekan template cica flexible
    else if (dataAfter.campaignInfo.campaignCode == "CCA-002") {
        if (isSharia) {
            template = "cica-flexible-sharia";
        } else {
            template = "cica-flexible-convent";
        }
    }

    //add template for package v2
    if (dataAfter.campaignInfo.campaignCode == "EEP-001") {
        if (isSharia) {
            template = "eup-sharia-v2";
        } else {
            template = "eup-convent-v2";
        }
    }

    //add template for package repricing
    if (dataAfter.campaignInfo.campaignCode == "ECX-001") {
        if (isSharia) {
            template = "form-penyesuaian-konstribusi";
            
        } else {
            template = "form-premium-adjustment-repricing";
        }
    }

     //add template for flexible v2
    if (dataAfter.campaignInfo.campaignCode == "EEF-001") {
        if (isSharia) {
            template = "eu-sharia-v2";
        } else {
            template = "eu-convent-v2";
        }
    }

    //pengechekan non otp
    if (!isOTP) {
        template = template + "-non-otp";
    }

    console.log("CampaignCode " + dataAfter.campaignInfo.campaignCode);
    console.log("Get template doc : " + template);
    const content = fs.readFileSync(path.join(__dirname, '/public/template/' + template + ".docx"), 'binary');
    console.log("Success get template Doc : " + template);

    const zip = new PizZip(content);
    const doc = new Docxtemplater();

    console.log("masuk");
    //Below the options that will be passed to ImageModule instance
    var opts = {}
    opts.centered = false; //Set to true to always center images
    opts.fileType = "docx"; //Or pptx

    //Pass your image loader
    opts.getImage = function (tagValue, tagName) {
        console.log(tagValue, tagName);
        //tagValue is 'examples/image.png'
        //tagName is 'image'
        return fs.readFileSync(tagValue);
    }

    //Pass the function that return image size
    opts.getSize = function (img, tagValue, tagName) {
        //img is the image returned by opts.getImage()
        //tagValue is 'examples/image.png'
        //tagName is 'image'
        //tip: you can use node module 'image-size' here
        return [212, 64];
    }

    doc.loadZip(zip);
    doc.attachModule(inspectModule);

    // let lifeName = ""

    // //sort EUP by life number
    dataAfter.lifeAssured.map(function (e) {
        if (e.lifeNumber == "01") {
            lifeName = e.lifeName.toUpperCase();
        }
    })

    // mapping EU berdasarkan get data campaign
    let dummyEU = {};
    // if (["PLS-002", "EEP-001", "ECX-001"].includes(dataAfter.campaignInfo.campaignCode)) {
    //     console.log("Get Data Campaign EU  ----- ", opt, " ", type, " ", agent, " ", isOTP);
    //     dummyEU = await getDataCampaign(dataAfter.policyNumber, dataAfter.agentNumber, dataAfter.campaignInfo.campaignCode).then((objCampaign) => {
    //         //// console.log(objCampaign);
    //         return objCampaign.data;
    //     }).catch((err) => {
    //         //// console.log(err);
    //         //// console.log("fail connect to campaign detail");
    //         return error;
    //     });

    //     //// mapping Cica Simple berdasarkan get data campaign
    // }



    // dummy map plan PPH pada EUP
    let mapPlanPPh = [
        {
            "Plan": "Bronze A",
            "Area": "Indonesia",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "500"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "1,000"
                }
            ],
            "companionCompensation": "600",
            "hospitalizationCompensation": "500",
            "annualLimit": "2,000,000",
            "planLimitBooster": "8,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "4,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Bronze B",
            "Area": "Indonesia",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "1,000"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "3,000"
                }
            ],
            "companionCompensation": "650",
            "hospitalizationCompensation": "1,000",
            "annualLimit": "3,000,000",
            "planLimitBooster": "12,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "5,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Silver A",
            "Area": "Asia kecuali Singapura, Jepang, dan Hongkong",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "500"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "1,000"
                }
            ],
            "companionCompensation": "600",
            "hospitalizationCompensation": "500",
            "annualLimit": "2,000,000",
            "planLimitBooster": "8,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "4,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Silver B",
            "Area": "Asia kecuali Singapura, Jepang, dan Hongkong",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "1,000"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "3,000"
                }
            ],
            "companionCompensation": "650",
            "hospitalizationCompensation": "1,000",
            "annualLimit": "3,000,000",
            "planLimitBooster": "12,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "5,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Gold A",
            "Area": "Asia",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "1,000"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "3,000"
                }
            ],
            "companionCompensation": "800",
            "hospitalizationCompensation": "1,000",
            "annualLimit": "4,000,000",
            "planLimitBooster": "26,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "9,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Gold B",
            "Area": "Asia",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "1,500"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "3,000"
                }
            ],
            "companionCompensation": "850",
            "hospitalizationCompensation": "1,000",
            "annualLimit": "5,000,000",
            "planLimitBooster": "30,000,000",
            "funeralCompensation": "15,000,000",
            "HIVCompensation": "15,000",
            "primeSaver": "10,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Platinum",
            "Area": "Seluruh Dunia kecuali Amerika Serikat",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "1,500"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "10,000"
                }
            ],
            "companionCompensation": "1,000",
            "hospitalizationCompensation": "1,500",
            "annualLimit": "10,000,000",
            "planLimitBooster": "40,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "15,000",
            "marhamah": "15,000"
        },
        {
            "Plan": "Diamond",
            "Area": "Seluruh Dunia",
            "Bed": [
                {
                    "option": "Opsi 1",
                    "maxPrice": "1,500"
                },
                {
                    "option": "Opsi 2",
                    "maxPrice": "10,000"
                }
            ],
            "companionCompensation": "1,250",
            "hospitalizationCompensation": "1,500",
            "annualLimit": "15,000,000",
            "planLimitBooster": "50,000,000",
            "funeralCompensation": "15,000",
            "HIVCompensation": "15,000",
            "primeSaver": "20,000",
            "marhamah": "15,000"
        }
    ];

    // list product Cica untuk cica flexible
    let productDescList = {};

    //Basic Product
    productDescList.U1B = "PRULink Assurance Account";
    productDescList.U1H = "PRULink Syariah Assurance Account ";
    productDescList.U1Z = "PRULink Assurance Account";
    productDescList.U1S = "PRULink Syariah Assurance Account";
    productDescList.U10 = "PRULink Generasi Baru";
    productDescList.U11 = "PRULink Syariah Generasi Baru";

    var productLinkTerm = ["T1JR", "T1KR"];
    var productPADD = ["P1DR", "P1RR", "P1IR", "P1TR"];

    //Link Term
    productDescList.T1JR = "PRULink Term";
    productDescList.T1KR = "PRULink Term Syariah";

    //PADD
    productDescList.P1DR = "PRUpersonal Accident Death and Disablement";
    productDescList.P1RR = "PRUpersonal Accident Death and Disablement Plus";
    productDescList.P1IR = "PRUpersonal Accident Death and Disablement Syariah";
    productDescList.P1TR = "PRUpersonal Accident Death and Disablement Plus Syariah";

    //CI
    productDescList.C1LR = "PRUCrisis Cover Benefit 34";
    productDescList.C1WR = "PRUCrisis Cover Benefit Plus 61";
    productDescList.C1XR = "PRUEarly Stage Crisis Cover";
    productDescList.C106 = "PRUEarly Stage Crisis Cover Plus";
    productDescList.C1QR = "PRUCrisis Cover Benefit Syariah 34";
    productDescList.C11R = "PRUCrisis Cover Benefit Plus Syariah 61";
    productDescList.C1YR = "PRUEarly Stage Crisis Cover Syariah";
    productDescList.C108 = "PRUEarly Stage Crisis Cover Plus Syariah";
    productDescList.C1LR = "PRUCrisis Cover Benefit 34";

    let planConvent = {};
    //list rider critical protection convent
    planConvent.C14R = "PRUTotal Critical Protection";
    planConvent.C141 = "PRUTotal Critical Protection";
    planConvent.C143 = "PRUTotal Critical Protection";

    let planSharia = {};
    //list rider critical protection convent
    planSharia.C15R = "PRUTotal Critical Protection Syariah";
    planSharia.C151 = "PRUTotal Critical Protection Syariah";
    planSharia.C153 = "PRUTotal Critical Protection Syariah";

    let total = 0;
    let biaya_asuransi = 0;
    let fundAllocationSaver = 0;

    let riderData = [];
    let codeBasic = [];
    let basicCode = [];

    let padd = [];
    let linkterm = [];
    let CCB61 = [];
    let planCCB61 = [];
    let CCB34 = [];
    let planCCB34 = [];
    let ESCC = [];
    let planESCC = [];
    let HS = [];
    let PPH = [];
    let PPHPLUS = [];
    let SAVER = [];

    let onlycodeBasic = [];
    let manfaatAsuransiTemp = [];
    let fundAllocationData = [];
    let totalCharge = 0;
    let codeBasicTmp = [];
    let allCodeBasicTitle = [];
    let Critical = [];
    let pphPlusTitle = [];
    let basicCodeTitle = [];

    let linkTermTitle = '';
    let linkTermDescription = '';
    let paddTitle = '';
    let paddDescription = '';

    let plan = 0;
    let chosen = 0;
    let currentPlan = "";
    let offerMonthlyCoi = "";

    // mapping table EUP dan CIca Flexible
    console.log("Start mapping from product  ----- ", opt, " ", type, " ", agent, " ", isOTP);
    // // console.log(dataAfter.products);
    dataAfter.products.map(function (e, i) {

        console.log("--- start set current_health and current_plan ---");
        if (e.riderCode == dummyEU.additional27) {
            if (["H1GR", "H1G1", "H1QR", "H1TR", "H1MR", "H1UR", "H1JR", "H1J1", "H1RR", "H1NR",
                "H1X1", "H1X3", "H1X5", "H1Y1", "H1Y3", "H1Y5",
                "H1Z1", "H1Z3", "H1Z5", "H1Z7",
                "H1H1", "H1H3", "H1H5", "H1H7"].includes(e.riderCode)) {
                if (e.riderCode == "H1TR") {
                    currentSelectedEU = 'hospital & surgical cover plus';
                }
                if (e.riderCode == "H1GR") {
                    currentSelectedEU = 'hospital & surgical';
                }
                if (e.riderCode == "H1G1") {
                    currentSelectedEU = 'hospital & surgical 75';
                }
                if (e.riderCode == "H1QR") {
                    currentSelectedEU = 'hospital & surgical cover';
                }
                if (e.riderCode == "H1MR") {
                    currentSelectedEU = 'hospital & surgical plus';
                }
                if (e.riderCode == "H1UR") {
                    currentSelectedEU = 'hospital & surgical plus syariah';
                }
                if (e.riderCode == "H1JR") {
                    currentSelectedEU = 'hospital & surgical syariah';
                }
                if (e.riderCode == "H1J1") {
                    currentSelectedEU = 'hospital & surgical syariah 75';
                }
                if (e.riderCode == "H1RR") {
                    currentSelectedEU = 'hospital & surgical cover syariah';
                }
                if (e.riderCode == "H1NR") {
                    currentSelectedEU = 'hospital & surgical plus syariah';
                }
                if (["H1X1", "H1X3", "H1X5"].includes(e.riderCode)) {
                    currentSelectedEU = 'prime healthcare';
                }
                if (["H1Y1", "H1Y3", "H1Y5"].includes(e.riderCode)) {
                    currentSelectedEU = 'prime healthcare syariah';
                }
                if (["H1Z1", "H1Z3"].includes(e.riderCode)) {
                    currentSelectedEU = 'prime healthcare plus';
                }
                if (["H1Z5", "H1Z7"].includes(e.riderCode)) {
                    currentSelectedEU = 'prime healthcare plus syariah';
                }
                if (["H1H1", "H1H3"].includes(e.riderCode)) {
                    currentSelectedEU = 'prime healthcare plus pro';
                }
                if (["H1H5", "H1H7"].includes(e.riderCode)) {
                    currentSelectedEU = 'prime healthcare plus pro syariah';
                }

                if (["H1Z1", "H1Z5", "H1Y1", "H1Y5"].includes(e.riderCode)) {
                    if (dummyEU.additional27 == "Plan A") {
                        currentPlan = "Bronze A";
                    } else if (dummyEU.additional27 == "Plan B") {
                        currentPlan = "Bronze B";
                    } else if (dummyEU.additional27 == "Plan C") {
                        currentPlan = "Silver A";
                    } else if (dummyEU.additional27 == "Plan D") {
                        currentPlan = "Silver B";
                    } else if (dummyEU.additional27 == "Plan E") {
                        currentPlan = "Gold A";
                    } else if (dummyEU.additional27 == "Plan F") {
                        currentPlan = "Gold B";
                    } else if (dummyEU.additional27 == "Plan G") {
                        currentPlan = "Platinum";
                    } else if (dummyEU.additional27 == "Plan H") {
                        currentPlan = "Diamond";
                    }
                }
                if (["H1Z3", "H1Z7", "H1Y3", "H1Y7"].includes(e.riderCode)) {
                    if (["Plan A1", "Plan A2"].includes(dummyEU.additional27)) {
                        currentPlan = "Cermat 1";
                    } else if (["Plan B1", "Plan B2"].includes(dummyEU.additional27)) {
                        currentPlan = "Cermat 2";
                    } else if (["Plan C1", "Plan C2"].includes(dummyEU.additional27)) {
                        currentPlan = "Cermat 3";
                    }
                }
            } else {
                currentSelectedEU = e.riderDescription;
            }
        }
        console.log("--- done set current_health and current_plan ---");

        //pengecekan product cica flexible untuk mapping code basicnya saja
        console.log("e.riderCode line 699 = "+e.riderCode);
        if (_.includes(Object.keys(productDescList), e.riderCode.substring(0, 3))) {
            onlycodeBasic.push(e.riderCode.substring(0, 3));
        }

        if (_.includes(Object.keys(planSharia), e.riderCode)) {
            codeBasic.push("PRUTotal Critical Protection Syariah");
        } else if (_.includes(Object.keys(planConvent), e.riderCode)) {
            codeBasic.push("PRUTotal Critical Protection");
        }


        //pengecekan deskripsi rider jika includes saver atau tidak include saver
        if (e.riderDescription && !e.riderDescription.includes("saver")) {
            //  //// console.log(e,i);
            let obj = {};

            obj.tmpriderCode = "";
            obj.tmpriderDescription = "";

            // console.log("masuk");

            //coverageType == mainrre
            if (e.calcListActive && e.newAdd) {
                // console.log("masuk sini");
                if (e.plan) {
                    plan = e.plan.charCodeAt(0) - 65;
                    if (plan < 0 || plan >= mapPlanPPh.length) {
                        plan = 0;
                    }
                }
                obj.col1 = e.riderCode + ' PRU' + e.riderDescription;
                obj.col2 = '-';
                obj.col3 = '-';
                obj.col4 = e.term;
                obj.col5 = 'Rp. ' + convertCurrency(e.sumAssured);
                obj.tmpriderCode = e.riderCode;
                obj.tmpriderDescription = e.riderDescription;

                // console.log(dataAfter.chargeRiderME.chargeRider);
                let arrCharge = Object.keys(dataAfter.chargeRiderME.chargeRider);
                // console.log("ini arrCharge", arrCharge);
                for (let index = 0; index < arrCharge.length; index++) {
                    const element = arrCharge[index];
                    // console.log("element", element);
console.log("e.riderCode line 744 = "+e.riderCode);
                    if (element.includes(e.riderCode.substring(0, 4))) {
                        if (e.riderCode.includes("U1")) {
                            obj.col6 = 'Rp. ' + convertCurrency((parseInt(dataAfter.chargeRiderME.chargeRider[element]) / 12))
                            // totalCharge += parseInt(Math.ceil(dataAfter.chargeRiderME.chargeRider[element]) / 12 );
                            break;
                        } else {
                            obj.col6 = 'Rp. ' + convertCurrency(Math.round(dataAfter.chargeRiderME.chargeRider[element]));
                            // totalCharge += parseInt(Math.ceil(dataAfter.chargeRiderME.chargeRider[element]));
                            break;
                        }
                    } else {
                        obj.col6 = 0;
                    }
                }
                chosen = _.findIndex(e.fixedAmountList, function (o) { return parseInt(o.value) == parseInt(e.sumAssured) });
                if (chosen < 0) {
                    chosen = 0;
                }
            } else if (e.calcListActive && e.productHistories && e.productHistories[0]) {
                // console.log("masuk else if 2");
                console.log("e.riderCode line 765 = "+e.riderCode);
                if (e.riderCode.substring(0, 1) == "W" || e.riderCode.substring(0, 1) == "S") {
                    e.productHistories[e.productHistories.length - 1].sumAssured = parseInt(Math.ceil(e.productHistories[e.productHistories.length - 1].annualWaiveSA / 100) * 100);
                }

                // start campaign pph+pro
                // add lifeNumber suffix for wop
                console.log("e.riderCode line 772 = "+e.riderCode);
                var isWOPRider = ["W", "S"].includes(e.riderCode.substring(0, 1))
                var multiLifeSuffix = "";

                if (isWOPRider && e.multiLife) {
                    if (e.lifeNumber == "02") {
                        multiLifeSuffix = "1";
                    } else if (e.lifeNumber == "03") {
                        multiLifeSuffix = "2";
                    }
                    multiLifeSuffix = " - " + multiLifeSuffix;
                }
                // end campaign pph+pro

                if (!e.riderDescription.includes('PRU')) {
                    obj.col1 = e.riderCode + ' PRU' + e.riderDescription + multiLifeSuffix; //campaign pph+pro
                } else {
                    obj.col1 = e.riderCode + ' ' + e.riderDescription + multiLifeSuffix; //campaign pph+pro
                }
                // obj.col2 = e.productHistories[0].term;
                obj.col2 = e.productHistories[e.productHistories.length - 1].term;
                obj.col3 = 'Rp. ' + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                obj.col4 = e.term;
                obj.col5 = 'Rp. ' + convertCurrency(e.sumAssured);
                obj.tmpriderCode = e.riderCode;
                obj.tmpriderDescription = e.riderDescription;

                let arrCharge = Object.keys(dataAfter.chargeRiderME.chargeRider);
                for (let index = 0; index < arrCharge.length; index++) {
                    const element = arrCharge[index];
console.log("e.riderCode line 802 = "+e.riderCode);
console.log("e.mainCodeParent line 802 = "+e.mainCodeParent);
                    if (element.includes(e.riderCode.substring(0, 4)) || (isWOPRider && element.includes(e.mainCodeParent.substring(0, 4)))) {
                        if (e.riderCode.includes("U1")) {
                            obj.col6 = 'Rp. ' + convertCurrency((parseInt(dataAfter.chargeRiderME.chargeRider[element]) / 12))
                            // totalCharge += parseInt(Math.ceil(dataAfter.chargeRiderME.chargeRider[element]) / 12 );
                            break;
                        } else {
                            obj.col6 = 'Rp. ' + convertCurrency(Math.round(dataAfter.chargeRiderME.chargeRider[element]));
                            // totalCharge += parseInt(Math.ceil(dataAfter.chargeRiderME.chargeRider[element]));
                            break;
                        }
                    } else {
                        obj.col6 = 0;
                    }
                }
                total += parseInt(e.productHistories[e.productHistories.length - 1].sumAssured);
            } else if (!e.calcListActive && e.productHistories && e.productHistories[0]) {
                // console.log("masuk else if 3");
console.log("e.riderCode line 821 = "+e.riderCode);
                if (e.riderCode.substring(0, 1) == "W" || e.riderCode.substring(0, 1) == "S") {
                    e.productHistories[e.productHistories.length - 1].sumAssured = parseInt(Math.ceil(e.productHistories[e.productHistories.length - 1].annualWaiveSA / 100) * 100);
                }
                obj.col1 = e.riderCode + ' PRU' + e.riderDescription;
                obj.col2 = e.productHistories[e.productHistories.length - 1].term;
                obj.col3 = 'Rp. ' + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                obj.col4 = '-';
                obj.col5 = '-';
                obj.col6 = 0;
                obj.tmpriderCode = e.riderCode;
                obj.tmpriderDescription = e.riderDescription;

                total += parseInt(e.productHistories[e.productHistories.length - 1].sumAssured);
            }

            saldo_percentage = "fundPrice";
            saldo_name = "fundName";

            obj.rider = e.rider ? e.rider : "99";
            obj.lifeNumber = e.lifeNumber ? e.lifeNumber : "99";

            riderData.push(obj);
            console.log('INI col3 guyss :', obj.col3, obj.col1);
            // ---START campaign pph+pro add saver-------
            // try add saver
            if (dataAfter.campaignInfo.campaignCode == "EEF-001") {
                // if (["H1H1","H1H3","H1H5","H1H7"].includes(e.riderCode)) {
            if (["H1H1","H1H3","H1H5","H1H7"].includes(e.riderCode)) {
                // for current Hospital rider saver
                    if (e.deductAmountAdv == "" || e.deductAmountAdv == "0" || isNaN(e.deductAmountAdv)) {
                        let objx = {};
                        // SAVER[0] = objx;
                        objx.col1 = "PRUPrimesaver**";
                        objx.col2 = "-";
                        objx.col3 = "-";
                        objx.col4 = "-";
                        objx.col5 = "Tidak Dipilih";
                        objx.col6 = "-";
                        riderData.push(objx);
                    } else {
                        let objx = {};
                        // SAVER[0] = objx;
                        objx.col1 = "PRUPrimesaver**" + convertCurrency(e.deductAmount);
                        objx.col2 = "-";
                        objx.col3 = "-";
                        objx.col4 = "-";
                        objx.col5 = "Rp. " + convertCurrency(e.deductAmount);
                        objx.col6 = "-";
                        riderData.push(objx);
                    }
console.log("e.riderCode line 872 = "+e.riderCode);
                } else if (e.riderCode.substring(0,1) == "H" && !e.calcListActive) {
                    // for existing Hospital rider saver
                    if (e.deductAmountAdv == "" || e.deductAmountAdv == "0" || isNaN(e.deductAmountAdv)) {
                        let objx = {};
                        // SAVER[0] = objx;
                        objx.col1 = "PRUPrimesaver**";
                        objx.col2 = "-";
                        objx.col3 = "Tidak Dipilih";
                        objx.col4 = "-";
                        objx.col5 = "-";
                        objx.col6 = "-";
                        riderData.push(objx);
                    } else {
                        let objx = {};
                        // SAVER[0] = objx;
                        objx.col1 = "PRUPrimesaver**" + convertCurrency(e.deductAmount);
                        objx.col2 = "-";
                        objx.col3 = "Rp. " + convertCurrency(e.deductAmount);
                        objx.col4 = "-";
                        objx.col5 = "-";
                        objx.col6 = "-";
                        riderData.push(objx);
                    }
                }
            }
            console.log('riderData after saver=== :', riderData);
            // ---END campaign pph+pro add saver-------
            if (dataAfter.campaignInfo.campaignCode == "CCA-002") {
                var a = 0;
                var b = 0;
                if (![obj.col3,obj.col5].includes(undefined)) {
                    a = obj.col3.replace(/[^0-9]/g, '').length > 0 ? parseInt(obj.col3.replace(/[^0-9]/g, '')) : 0;
                    b = obj.col5.replace(/[^0-9]/g, '').length > 0 ? parseInt(obj.col5.replace(/[^0-9]/g, '')) : 0;
                }
               

                //mapping product description
                if (isSharia) {
                    if (["T1JR", "T1KR"].includes(obj.tmpriderCode)) {
                        linkTermTitle = "PRULink Term Syariah";
                        linkTermDescription = "Perlindungan atas risiko meninggal dunia sebelum berakhirnya masa Asuransi Tambahan PRULink Term Syariah. Santunan Asuransi yang dibayarkan akan mengikuti ketentuan Asuransi Tambahan PRULink Term Syariah sebagaimana tercantum dalam ketentuan Polis.";
                    }

                    if (["P1DR", "P1IR"].includes(obj.tmpriderCode)) {
                        paddTitle = "PRUAccident Death and Disablement Syariah";
                        paddDescription = "Perlindungan terhadap risiko meninggal dunia dan Cacat Tetap akibat kecelakaan. Santunan Asuransi yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement Syariah sebagaimana tercantum dalam ketentuan Polis.";
                    } else if (["P1RR", "P1TR"].includes(obj.tmpriderCode)) {
                        paddTitle = "PRUAccident Death and Disablement Plus Syariah";
                        paddDescription = "Perlindungan terhadap risiko meninggal dunia, menderita Cacat Tetap, Luka Bakar, Patah Tulang Komplit atau menjalani rawat jalan darurat akibat kecelakaan. Santunan Asuransi yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement Plus Syariah sebagaimana tercantum pada ketentuan Polis.";
                    }
                } else {
                    if (["T1JR", "T1KR"].includes(obj.tmpriderCode)) {
                        linkTermTitle = "PRULink Term";
                        linkTermDescription = "Perlindungan atas risiko meninggal dunia sebelum berakhirnya masa Asuransi Tambahan PRULink Term. Uang Pertanggungan yang dibayarkan akan mengikuti ketentuan Asuransi Tambahan PRULink Term sebagaimana tercantum dalam ketentuan Polis.";
                    }

                    if (["P1DR", "P1IR"].includes(obj.tmpriderCode)) {
                        paddTitle = "PRUAccident Death and Disablement";
                        paddDescription = "Perlindungan terhadap risiko meninggal dunia dan Cacat Tetap akibat kecelakaan. Uang Pertanggungan yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement sebagaimana tercantum dalam ketentuan Polis";
                    } else if (["P1RR", "P1TR"].includes(obj.tmpriderCode)) {
                        paddTitle = "PRUAccident Death and Disablement Plus";
                        paddDescription = "Perlindungan terhadap risiko meninggal dunia, menderita Cacat Tetap, Luka Bakar, Patah Tulang Komplit atau menjalani rawat jalan darurat akibat kecelakaan. Uang Pertanggungan yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement Plus sebagaimana tercantum pada ketentuan Polis.";
                    }
                }
                //end mapping product description

                //basic code
                if (["U1B", "U1H", "U1Z", "U1S", "U10", "U11"].includes(obj.tmpriderCode.substring(0, 3))) {
                    basicCode[0] = obj;
                    if (b > a) {
                        basicCodeTitle.push("Manfaat Asuransi Dasar " + obj.tmpriderDescription + " dan ");
                    }
                    _.remove(riderData, function (n) { return n == obj; });
                }
                //link term
                if (["T1JR", "T1KR"].includes(obj.tmpriderCode)) {
                    linkterm[0] = obj;
                    if (b > a) {
                        allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                    }
                    _.remove(riderData, function (n) {
                        return n == obj;
                        // console.log(n);    
                    });
                }

                //PADD
                if (["P1DR", "P1RR", "P1IR", "P1TR"].includes(obj.tmpriderCode)) {
                    padd[0] = obj;
                    if (b > a) {
                        allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                    }
                    _.remove(riderData, function (n) { return n == obj; });
                }
                // //CCB61
                // if (["C1WR", "C11R"].includes(obj.tmpriderCode)) {
                //     CCB61[0] = obj;
                //     if (b > a) {
                //         allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                //     }
                //     _.remove(riderData, function (n) { return n == obj; });
                // }
                // // plan CCB61
                // if (["C14R", "C15R"].includes(obj.tmpriderCode)) {
                //     planCCB61[0] = obj;
                //     if (b > a) {
                //         Critical.push("PRU" + obj.tmpriderDescription);
                //     }
                //     _.remove(riderData, function (n) { return n == obj; });
                // }


                // // CCB34
                // if (["C1LR", "C1QR"].includes(obj.tmpriderCode)) {
                //     CCB34[0] = obj;
                //     if (b > a) {
                //         allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                //     }
                //     _.remove(riderData, function (n) { return n == obj; });
                // }
                // //plan CCB34
                // if (["C141", "C151"].includes(obj.tmpriderCode)) {
                //     planCCB34[0] = obj;
                //     if (b > a) {
                //         Critical.push("PRU" + obj.tmpriderDescription);
                //     }
                //     _.remove(riderData, function (n) { return n == obj; });
                // }

                // // ESCC
                // if (["TIYR", "C108", "C1XR", "C106"].includes(obj.tmpriderCode)) {
                //     ESCC[0] = obj;
                //     if (b > a) {
                //         allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                //     }
                //     _.remove(riderData, function (n) { return n == obj; });
                // }

                // //plan ESCC
                // if (["C153", "C143"].includes(obj.tmpriderCode)) {
                //     planESCC[0] = obj;
                //     if (b > a) {
                //         Critical.push("PRU" + obj.tmpriderDescription);
                //     }
                //     _.remove(riderData, function (n) { return n == obj; });
                // }

                //HS
                if (["H1GR", "H1G1", "H1QR", "H1TR", "H1UR", "H1JR", "H1J1", "H1RR"].includes(obj.tmpriderCode)) {
                    HS[0] = obj;
                    if (b > a) {
                        allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                    }
                    _.remove(riderData, function (n) { return n == obj; });
                }
                //pph
                if (["H1X1", "H1X3", "H1X5", "H1Y1", "H1Y3", "H1Y5"].includes(obj.tmpriderCode)) {
                    PPH[0] = obj;
                    if (b > a) {
                        allCodeBasicTitle.push("PRU" + obj.tmpriderDescription);
                    }
                    _.remove(riderData, function (n) { return n == obj; });
                }
                //pphplus
                if (["H1Z1", "H1Z5"].includes(obj.tmpriderCode)) {
                    PPHPLUS[0] = obj;
                    // if(b>a){
                    //     pphPlusTitle.push("PRU" + obj.tmpriderDescription);
                    // }
                    if (e.planAdv.name == undefined) {
                        obj.col5 = " Rp. " + convertCurrency(e.sumAssured);
                    } else if (e.planAdv.name != undefined) {
                        obj.col5 = e.planAdv.name + " Rp. " + convertCurrency(e.sumAssured);
                    }
                    //saver
                    if (e.deductAmountAdv == "Tidak dipilih") {
                        let objx = {};
                        SAVER[0] = objx;
                        objx.col1s = "PRUPrimesaver**";
                        objx.col2s = "-";
                        objx.col3s = "-";
                        objx.col4s = "-";
                        objx.col5s = "Tidak Dipilih";
                        objx.col6s = "-";
                        _.remove(riderData, function (n) { return n == objx; });
                    } else {
                        let objx = {};
                        SAVER[0] = objx;
                        objx.col1s = "PRUPrimesaver**";
                        objx.col2s = "-";
                        objx.col3s = "-";
                        objx.col4s = "-";
                        objx.col5s = "Rp. " + convertCurrency(e.deductAmount);
                        objx.col6s = "-";
                        _.remove(riderData, function (n) { return n == objx; });
                    }

                    _.remove(riderData, function (n) { return n == obj; });

                    //wording planAdv existing
                    if ([e.original.planAdv.value].includes("A")) {
                        obj.col3 = "Bronze A - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("B")) {
                        obj.col3 = "Bronze B - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("C")) {
                        obj.col3 = "Silver A - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("D")) {
                        obj.col3 = "Silver B - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("E")) {
                        obj.col3 = "Gold A - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("F")) {
                        obj.col3 = "Gold B - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("G")) {
                        obj.col3 = "Platinum - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("H")) {
                        obj.col3 = "Diamond - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    }

                    //wording planAdv updated
                    if ([e.planAdv.value].includes("A")) {
                        obj.col5 = "Bronze A - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("B")) {
                        obj.col5 = "Bronze B - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("C")) {
                        obj.col5 = "Silver A - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("D")) {
                        obj.col5 = "Silver B - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("E")) {
                        obj.col5 = "Gold A - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("F")) {
                        obj.col5 = "Gold B - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("G")) {
                        obj.col5 = "Platinum - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("H")) {
                        obj.col5 = "Diamond - Rp. " + convertCurrency(e.sumAssured);
                    }

                }

                 //pphpluspro
                 // add saver for pph+pro
                 if (["H1H1","H1H3","H1H5","H1H7"].includes(obj.tmpriderCode)) {
                    PPHPLUS[0] = obj;
                    if (e.planAdv.name == undefined) {
                        obj.col5 = " Rp. " + convertCurrency(e.sumAssured);
                    } else if (e.planAdv.name != undefined) {
                        obj.col5 = e.planAdv.name + " Rp. " + convertCurrency(e.sumAssured);
                    }
                    //saver
                    if (e.deductAmountAdv == "Tidak dipilih") {
                        let objx = {};
                        SAVER[0] = objx;
                        objx.col1s = "PRUPrimesaver**";
                        objx.col2s = "-";
                        objx.col3s = "-";
                        objx.col4s = "-";
                        objx.col5s = "Tidak Dipilih";
                        objx.col6s = "-";
                        _.remove(riderData, function (n) { return n == objx; });
                    } else {
                        let objx = {};
                        SAVER[0] = objx;
                        objx.col1s = "PRUPrimesaver**";
                        objx.col2s = "-";
                        objx.col3s = "-";
                        objx.col4s = "-";
                        objx.col5s = "Rp. " + convertCurrency(e.deductAmount);
                        objx.col6s = "-";
                        _.remove(riderData, function (n) { return n == objx; });
                    }

                    _.remove(riderData, function (n) { return n == obj; });

                    //wording planAdv existing
                    if ([e.original.planAdv.value].includes("A")) {
                        obj.col3 = "Bronze A - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("B")) {
                        obj.col3 = "Bronze B - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("C")) {
                        obj.col3 = "Silver A - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("D")) {
                        obj.col3 = "Silver B - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("E")) {
                        obj.col3 = "Gold A - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("F")) {
                        obj.col3 = "Gold B - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("G")) {
                        obj.col3 = "Platinum - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    } else if ([e.original.planAdv.value].includes("H")) {
                        obj.col3 = "Diamond - Rp. " + convertCurrency(e.productHistories[e.productHistories.length - 1].sumAssured);
                    }

                    //wording planAdv updated
                    if ([e.planAdv.value].includes("A")) {
                        obj.col5 = "Bronze A - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("B")) {
                        obj.col5 = "Bronze B - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("C")) {
                        obj.col5 = "Silver A - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("D")) {
                        obj.col5 = "Silver B - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("E")) {
                        obj.col5 = "Gold A - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("F")) {
                        obj.col5 = "Gold B - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("G")) {
                        obj.col5 = "Platinum - Rp. " + convertCurrency(e.sumAssured);
                    } else if ([e.planAdv.value].includes("H")) {
                        obj.col5 = "Diamond - Rp. " + convertCurrency(e.sumAssured);
                    }

                }

                riderData = _.uniq(riderData);

                riderData.map(function (each) {
                    if (each.tmpriderCode.substring(0, 2) == "W1" || each.tmpriderCode.substring(0, 2) == "W3") {
                        let arrCharge = Object.keys(dataAfter.chargeRiderME.chargeRider);
                        arrCharge.map(function (obj) {
                            if (obj.includes("W1") || obj.includes("W3")) {
                                each.col6 = 'Rp. ' + convertCurrency(dataAfter.chargeRiderME.chargeRider[obj]);
                            }
                        }, function (err) {
                            // console.log(err);
                        })
                    }
                    if (a > b) {
                        codeBasic.push("PRU" + each.tmpriderDescription)
                    }
                })
                codeBasic = _.uniq(codeBasic);
            }
        }

        console.log("--- start set offer_monthly_coi ---");
        if (e.riderCode.includes("H1H")) {
            let arrCharge = Object.keys(dataAfter.chargeRiderME.chargeRider);
                for (let index = 0; index < arrCharge.length; index++) {
                    const element = arrCharge[index];
console.log("e.riderCode line 1212 = "+e.riderCode);
                    if (element.includes(e.riderCode.substring(0, 4))) {
                        offerMonthlyCoi = Math.round(dataAfter.chargeRiderME.chargeRider[element]);
                    }
                }
        }
        console.log("--- done set offer_monthly_coi ---");
    });

    Critical = Critical.map(function (obj) {
        if (obj.includes("plan")) {
console.log("obj line 1223 = "+obj);
            obj = obj.substring(0, obj.length - 7);
        }

        return obj;

    })

    allCodeBasicTitle = _.uniq(allCodeBasicTitle);
    Critical = _.uniq(Critical);
    pphPlusTitle = _.uniq(pphPlusTitle);
    // start campaign pph+pro filter rider
    if (dataAfter.campaignInfo.campaignCode == "EEF-001") {
        // show existing hospital plan
console.log("obj.tmpriderCode line 1237 = "+obj.tmpriderCode);
        riderData = _.filter(riderData, function (obj) { return obj.col1 != undefined, ((obj.col4 && obj.col5 != "-")  || (obj.col4 && obj.col5 == "-" && obj.tmpriderCode != null && obj.tmpriderCode.substring(0, 1) == "H") || (obj.col4 && obj.col5 == "-" && obj.tmpriderCode == null))});
    } else {
        riderData = _.filter(riderData, function (obj) { return obj.col1 != undefined, obj.col4 && obj.col5 != "-" });
    }
    // end campaign pph+pro filter rider

    console.log("allCodeBasicTitle=====", allCodeBasicTitle)
    console.log("pphPlusTitle=====", pphPlusTitle)
    console.log("riderData=====", riderData)

    // let prodCicaAll = _.filter(codeBasic, function(obj){ return obj.substring(0,2) != "U1"});

    //filter maapping product basic cica saja
    let onlyBasic = _.filter(onlycodeBasic, function (obj) { return obj.substring(0, 2) == "U1" });



    var arrFundAllocationKeySaver = Object.keys(dataAfter.fundAllocation.fundAllocationSaver);
    var arrNameFund = _.remove(arrFundAllocationKeySaver, function (n) {
        return n.includes("Name");
    })

    arrNameFund.map(function (obj) {
        //// console.log(obj.slice(-1));
        var idx = obj.slice(-1);
        var objx = { colFund1: "", colFund2: "" };
        var found = false;

        if (dataAfter.fundAllocation.fundAllocationSaver.fundShow) {
            if (dataAfter.fundAllocation.fundAllocationSaver[obj]) {
                //// console.log("ketemu");
                objx.colFund2 = dataAfter.fundAllocation.fundAllocationSaver["fundPrice" + idx] + "% " + dataAfter.fundAllocation.fundAllocationSaver["fundName" + idx];
                found = true;
            }
        }


        if (dataAfter.fundAllocation.fundAllocationBasic[obj]) {
            //// console.log("ketemu");
            objx.colFund1 = dataAfter.fundAllocation.fundAllocationBasic["fundPrice" + idx] + "% " + dataAfter.fundAllocation.fundAllocationBasic["fundName" + idx];
            found = true;
        }

        if (found) {
            fundAllocationData.push(objx);
        }

    });

    //mapping data EUP 
    total_currency = 'Rp. ' + convertCurrency(total);
    biaya_asuransi = 'Rp. ' + convertCurrency(dataAfter.total_coi);
    let option = 0;
    let today = moment().format("DD-MMM-YYYY");
    let time = "23:59";
    let expire = today + ' ' + time;

    // console.log("ini rider data ", riderData);
    riderData.map(function (e) {

    })

    //pembulatan saver dan total premium pada EU
    // var str = dummyEU.additional06;
    // var rtotprem = str.replace(",", ".");
    // var totprem = parseFloat(rtotprem);

    // var str2 = dummyEU.additional05;
    // var rsaver = str2.replace(",", ".");
    // var csaver = parseFloat(rsaver);

    var mappingSetData = {
        offer_date: today,
        expired_date: expire,
        client_ow_salut: capitalize_Words(dataAfter.clientRoleOW.clientSalut),
        client_ow_client_name: dataAfter.clientRoleOW.clientName.toUpperCase(),
        client_ow_address: dataAfter.clientRoleOW.clientAddress1.toUpperCase() + " " + dataAfter.clientRoleOW.clientAddress2.toUpperCase(),
        client_ow_address3: dataAfter.clientRoleOW.clientAddress3.toUpperCase(),
        client_ow_address4: dataAfter.clientRoleOW.clientAddress4.toUpperCase(),
        client_ow_address5: dataAfter.clientRoleOW.clientAddress5.toUpperCase(),
        agent_name: agent.clientName,
        agent_code: dataAfter.agentNumber,
        agent_kpm_code: agent.agentOfficeCode,
        policy_number: dataAfter.policyNumber,
        life_assured_main: lifeName,
        product_list: riderData,
        // mapping  sorting  product cica 
        codebasic: basicCode,
        padd: padd,
        linkterm: linkterm,
        ccb61: CCB61,
        planccb61: planCCB61,
        ccb34: CCB34,
        planccb34: planCCB34,
        escc: ESCC,
        planescc: planESCC,
        hs: HS,
        pph: PPH,
        pphplus: PPHPLUS,
        saver: SAVER,

        only_basic: basicCodeTitle,
        only_basic2: productDescList[onlyBasic],
        list_product: dataAfter.products.riderCode + ' PRU' + dataAfter.products.riderDescription,
        total_premi: 'Rp. ' + convertCurrency(total),
        total_premi_berkala_after: 'Rp. ' + convertCurrency(dataAfter.premiBerkala),
        billing_freq: dataAfter.billingFrequency === "12" ? "Bulanan" :
            (dataAfter.billingFrequency == "04" ? "3 Bulanan" :
                (dataAfter.billingFrequency == "02" ? "Semesteran" :
                    (dataAfter.billingFrequency == "01" ? "Tahunan" : "undefined"))),
        saldo_percentage: dataAfter.fundAllocation.fundAllocationSaver.fundPrice1 + '%',
        saldo_name: dataAfter.fundAllocation.fundAllocationSaver.fundName1,
        saldo_unit: 'Rp. ' + convertCurrency(dataAfter.fundHolding.totalUnitAmount),
        premi_berkala_before: 'Rp. ' + convertCurrency(parseInt(dataAfter.premiumSummary.before.premiumBulanan)),
        premi_berkala_after: 'Rp. ' + convertCurrency(parseInt(dataAfter.premiumSummary.after.premiumBulanan)),
        topup_berkala_before: 'Rp. ' + convertCurrency(Math.round(parseInt(dataAfter.premiumSummary.before.pruSaverPremiumTahunan) / parseInt(dataAfter.billingFrequency))),
        topup_berkala_after: 'Rp. ' + convertCurrency(Math.round(parseInt(dataAfter.premiumSummary.after.pruSaverPremiumTahunan) / parseInt(dataAfter.billingFrequency))),
        total_premi_berkala_before: 'Rp. ' + convertCurrency((parseInt(dataAfter.premiumSummary.before.premiumTahunan) / parseInt(dataAfter.billingFrequency)) + (parseInt(dataAfter.premiumSummary.before.pruSaverPremiumTahunan) / parseInt(dataAfter.billingFrequency))),
        total_premi_berkala_after: 'Rp. ' + convertCurrency((parseInt(dataAfter.premiumSummary.after.premiumTahunan) / parseInt(dataAfter.billingFrequency)) + (parseInt(dataAfter.premiumSummary.after.pruSaverPremiumTahunan) / parseInt(dataAfter.billingFrequency))),
        fund_allocation: fundAllocationData,

        //mapping data EU
        pru_prefix: 'PRU',
        current_health_rider: currentSelectedEU == "" ? dummyEU.additional27 : currentSelectedEU,
        current_health: 'Rp. ' + convertCurrency(dummyEU.additional01),
        current_plan: currentPlan == "" ? dummyEU.additional24 : currentPlan,
        offer_plan: stringOpt == "01" ? dummyEU.additional07 : stringOpt == "02" ? dummyEU.additional16 : dummyEU.additional28,
        current_term: dummyEU.additional03,
        offer_term: stringOpt == "01" ? dummyEU.additional10 : stringOpt == "02" ? dummyEU.additional19 : dummyEU.additional31,
        current_monthly_coi: 'Rp. ' + convertCurrency(dummyEU.additional14),
        // offer_monthly_coi: 'Rp. ' + convertCurrency(stringOpt == "01" ? dummyEU.additional15 : stringOpt == "02" ? dummyEU.additional23 : dummyEU.additional35),
        offer_monthly_coi: offerMonthlyCoi == "" ? 'Rp. ' + convertCurrency(dataAfter.total_coi) : 'Rp. ' + convertCurrency(offerMonthlyCoi),
        current_basprem: 'Rp. ' + convertCurrency(dummyEU.additional04),
        offer_basprem: 'Rp. ' + convertCurrency(stringOpt == "01" ? dummyEU.additional11 : stringOpt == "02" ? dummyEU.additional20 : dummyEU.additional32),
        // current_saver : 'Rp. '+ convertCurrency(Math.round(csaver)),
        current_saver: 'Rp. ' + convertCurrency(dummyEU.additional05),
        offera_fix: 'Rp. ' + convertCurrency(stringOpt == "01" ? dummyEU.additional08 : stringOpt == "02" ? dummyEU.additional17 : dummyEU.additional29),
        // current_totprem : 'Rp. '+ convertCurrency(Math.round(totprem)),
        current_totprem: 'Rp. ' + convertCurrency(dummyEU.additional06),
        offer_totprem: 'Rp. ' + convertCurrency(stringOpt == "01" ? dummyEU.additional13 : stringOpt == "02" ? dummyEU.additional22 : dummyEU.additional34),
        offera_opsi: stringOpt == "01" ? dummyEU.additional25 : stringOpt == "02" ? dummyEU.additional26 : dummyEU.additional36,
        offer_saver: 'Rp. ' + convertCurrency(stringOpt == "01" ? dummyEU.additional12 : stringOpt == "02" ? dummyEU.additional21 : dummyEU.additional33),
        current_health_ded: 'Rp. ' + convertCurrency(dummyEU.additional02),
        offera_plan_dedamt: 'Rp. ' + convertCurrency(stringOpt == "01" ? dummyEU.additional09 : stringOpt == "02" ? dummyEU.additional18 : dummyEU.additional30),

        //mapping PPH pada EUP
        plan_name: mapPlanPPh[plan].Plan,
        coverage_area: mapPlanPPh[plan].Area,
        option_chosen: mapPlanPPh[plan].Bed[chosen].option,
        max_room_price: mapPlanPPh[plan].Bed[chosen].maxPrice,
        companion_compensation: mapPlanPPh[plan].companionCompensation,
        hospitalization_compensation: mapPlanPPh[plan].hospitalizationCompensation,
        annual_compensation_limit: mapPlanPPh[plan].annualLimit,
        plan_limit_booster: mapPlanPPh[plan].planLimitBooster,
        prime_saver: mapPlanPPh[plan].primeSaver,
        total: total_currency,
        biaya_asuransi: biaya_asuransi,
    };

    if (dataAfter.campaignInfo.campaignCode == "ECX-001") {
        mappingSetData.current_basprem = 'Rp. ' + convertCurrency(dummyEU.additional11);
        mappingSetData.current_saver = 'Rp. ' + convertCurrency(dummyEU.additional12);
        mappingSetData.total_premi = 'Rp. ' + convertCurrency(dummyEU.additional13);
    }


    let rincianManfaatList = [];
    let rincianManfaatList2 = [];
    let planCondition = false;
    let asuransi_tambahan = [];

    //linkterm
    var tmpTermCode = stringOpt == "01" ? mapCica.additional30 : mapCica.additional54;

    //mapping description cica
    if (['T1JR', 'T1KR'].includes(stringOpt == "01" ? mapCica.additional30 : mapCica.additional54)) {
        if (simpleSharia) {
            linkTermTitle = productDescList[stringOpt == "01" ? mapCica.additional30 : mapCica.additional54];
            linkTermDescription = 'Perlindungan atas risiko meninggal dunia sebelum berakhirnya masa Asuransi Tambahan PRULink Term Syariah. Santunan Asuransi yang dibayarkan akan mengikuti ketentuan Asuransi Tambahan PRULink Term Syariah sebagaimana tercantum dalam ketentuan Polis.';
        } else {
            linkTermTitle = productDescList[stringOpt == "01" ? mapCica.additional30 : mapCica.additional54];
            linkTermDescription = 'Perlindungan atas risiko meninggal dunia sebelum berakhirnya masa Asuransi Tambahan PRULink Term. Uang Pertanggungan yang dibayarkan akan mengikuti ketentuan Asuransi Tambahan PRULink Term sebagaimana tercantum dalam ketentuan Polis.';
        }
    }

    if (['P1DR', 'P1IR'].includes(stringOpt == "01" ? mapCica.additional33 : mapCica.additional57)) {
        if (simpleSharia) {
            paddTitle = productDescList[stringOpt == "01" ? mapCica.additional33 : mapCica.additional57];
            paddDescription = 'Perlindungan terhadap risiko meninggal dunia dan Cacat Tetap akibat kecelakaan. Santunan Asuransi yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement Syariah sebagaimana tercantum dalam ketentuan Polis.';
        } else {
            paddTitle = productDescList[stringOpt == "01" ? mapCica.additional33 : mapCica.additional57]
            paddDescription = 'Perlindungan terhadap risiko meninggal dunia dan Cacat Tetap akibat kecelakaan. Uang Pertanggungan yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement sebagaimana tercantum dalam ketentuan Polis';
        }
    } else if (['P1RR', 'P1TR'].includes(stringOpt == "01" ? mapCica.additional33 : mapCica.additional57)) {
        if (simpleSharia) {
            paddTitle = productDescList[stringOpt == "01" ? mapCica.additional33 : mapCica.additional57];
            paddDescription = 'Perlindungan terhadap risiko meninggal dunia, menderita Cacat Tetap, Luka Bakar, Patah Tulang Komplit atau menjalani rawat jalan darurat akibat kecelakaan. Santunan Asuransi yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement Plus Syariah sebagaimana tercantum pada ketentuan Polis.';
        } else {
            paddTitle = productDescList[stringOpt == "01" ? mapCica.additional33 : mapCica.additional57];
            paddDescription = 'Perlindungan terhadap risiko meninggal dunia, menderita Cacat Tetap, Luka Bakar, Patah Tulang Komplit atau menjalani rawat jalan darurat akibat kecelakaan. Uang Pertanggungan yang dibayarkan akan mengikuti ketentuan Tabel Manfaat Asuransi Tambahan PRUAccident Death and Disablement Plus sebagaimana tercantum pada ketentuan Polis.';
        }
    }

    // console.log(_.includes(productLinkTerm, tmpTermCode));
    if (_.includes(productLinkTerm, tmpTermCode)) {
        var a = mapCica.additional08 === undefined ? "-" : 'Rp. ' + convertCurrency(mapCica.additional09);
        var b = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional31) : 'Rp. ' + convertCurrency(mapCica.additional55);

        var x = a.replace(/[^0-9]/g, '').length > 0 ? parseInt(a.replace(/[^0-9]/g, '')) : 0;
        var z = b.replace(/[^0-9]/g, '').length > 0 ? parseInt(b.replace(/[^0-9]/g, '')) : 0;

        if (z > x) {
            // console.log("masuk situ");
            // if (mapCica.additional76 != "group2" && stringOpt != "02") {
            asuransi_tambahan.push(stringOpt == "01" ? productDescList[mapCica.additional30] : productDescList[mapCica.additional54]);
            // }

            // console.log(asuransi_tambahan);
        }



        if (!simpleSharia) {
            rincianManfaatList.push(
                {
                    col1: "Uang Pertanggungan " + productDescList[stringOpt == "01" ? mapCica.additional30 : mapCica.additional54],
                    col2: mapCica.additional08 === undefined ? "-" : 'Rp. ' + convertCurrency(mapCica.additional09),
                    col3: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional31) : 'Rp. ' + convertCurrency(mapCica.additional55),
                    offer_link_term: stringOpt == "01" ? productDescList[mapCica.additional30] : productDescList[mapCica.additional54]
                },
                {
                    col1: "Masa Pertanggungan*",
                    col2: "Sampai dengan usia " + mapCica.additional10 + " tahun",
                    col3: stringOpt == "01" ? "Sampai dengan usia " + mapCica.additional32 + " tahun" : "Sampai dengan usia " + mapCica.additional56 + " tahun",

                }
            )
        } else {
            rincianManfaatList.push(
                {
                    col1: "Santunan Asuransi " + productDescList[stringOpt == "01" ? mapCica.additional30 : mapCica.additional54],
                    col2: mapCica.additional08 === undefined ? "-" : 'Rp. ' + convertCurrency(mapCica.additional09),
                    col3: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional31) : 'Rp. ' + convertCurrency(mapCica.additional55),
                    offer_link_term: stringOpt == "01" ? productDescList[mapCica.additional30] : productDescList[mapCica.additional54]
                },
                {
                    col1: "Masa Pertanggungan* ",
                    col2: "Sampai dengan usia " + mapCica.additional10 + " tahun",
                    col3: stringOpt == "01" ? "Sampai dengan usia " + mapCica.additional32 + " tahun" : "Sampai dengan usia " + mapCica.additional56 + " tahun",

                }
            )
        }

        rincianManfaatList.map(function (e) {
            if (e.col1.includes('Masa Pertanggungan*')) {
                if (e.col3 == "Sampai dengan usia  tahun") {
                    e.col3 = '-';
                };
                if (e.col2 == "Sampai dengan usia  tahun") {
                    e.col2 = '-';
                };
            }

            if (e.col1.includes('Uang Pertanggungan') || e.col1.includes('Santunan Asuransi')) {
                if (e.col3 == "Rp. 0") {
                    e.col3 = '-';
                };
                if (e.col2 == "Rp. 0") {
                    e.col2 = '-';
                };
            }
        })
    }


    //padd
    var tmpPaddCode = stringOpt == "01" ? mapCica.additional33 : mapCica.additional57;
    
    // console.log(_.includes(productPADD, tmpPaddCode));
    if (_.includes(productPADD, tmpPaddCode)) {
        var a = mapCica.additional11 === undefined ? "-" : 'Rp. ' + convertCurrency(mapCica.additional12);
        var b = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional34) : 'Rp. ' + convertCurrency(mapCica.additional58);

        var x = a.replace(/[^0-9]/g, '').length > 0 ? parseInt(a.replace(/[^0-9]/g, '')) : 0;
        var z = b.replace(/[^0-9]/g, '').length > 0 ? parseInt(b.replace(/[^0-9]/g, '')) : 0;

        if (z > x) {
            // console.log("masuk sini");
            // if (mapCica.additional76 != "group2" && stringOpt != "02") {
            asuransi_tambahan.push(stringOpt == "01" ? productDescList[mapCica.additional33] : productDescList[mapCica.additional57]);
            // }
            // console.log(asuransi_tambahan);
        }
        if (!simpleSharia) {
            rincianManfaatList2.push(
                {
                    col1: "Uang Pertanggungan " + productDescList[stringOpt == "01" ? mapCica.additional33 : mapCica.additional57],
                    col2: mapCica.additional11 === undefined ? "-" : 'Rp. ' + convertCurrency(mapCica.additional12),
                    col3: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional34) : 'Rp. ' + convertCurrency(mapCica.additional58),
                    offer_padd: stringOpt == "01" ? productDescList[mapCica.additional33] : productDescList[mapCica.additional57]
                },
                {
                    col1: "Masa Pertanggungan* ",
                    col2: 'Sampai dengan usia ' + mapCica.additional13 + ' tahun',
                    col3: stringOpt == "01" ? 'Sampai dengan usia ' + mapCica.additional35 + ' tahun' : 'Sampai dengan usia ' + mapCica.additional59 + ' tahun'
                }
            )
        }

        else if (simpleSharia) {
            rincianManfaatList2.push(
                {
                    col1: "Santunan Asuransi " + productDescList[stringOpt == "01" ? mapCica.additional33 : mapCica.additional57],
                    col2: mapCica.additional11 === undefined ? "-" : 'Rp. ' + convertCurrency(mapCica.additional12),
                    col3: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional34) : 'Rp. ' + convertCurrency(mapCica.additional58),
                    offer_padd: stringOpt == "01" ? productDescList[mapCica.additional33] : productDescList[mapCica.additional57]
                },
                {
                    col1: "Masa Pertanggungan* ",
                    col2: 'Sampai dengan usia ' + mapCica.additional13 + ' tahun',
                    col3: stringOpt == "01" ? 'Sampai dengan usia ' + mapCica.additional35 + ' tahun' : 'Sampai dengan usia ' + mapCica.additional59 + ' tahun'
                }
            )
        }
        rincianManfaatList2.map(function (e) {
            if (e.col1.includes('Masa Pertanggungan*')) {
                if (e.col3 == "Sampai dengan usia  tahun") {
                    e.col3 = '-';
                };
                if (e.col2 == "Sampai dengan usia  tahun") {
                    e.col2 = '-';
                };
            }

            if (e.col1.includes('Uang Pertanggungan') || e.col1.includes('Santunan Asuransi')) {
                if (e.col3 == "Rp. 0") {
                    e.col3 = '-';
                };
                if (e.col2 == "Rp. 0") {
                    e.col2 = '-';
                };
            }
        })
    }
    let title_organ = "PRUTotal Critical Protection ";
    if (simpleSharia) {
        title_organ = "PRUTotal Critical Protection Syariah";
    }
    let productName = [
        //Produk PRUCrisis Cover Benefit Plus 61
        {
            col1a: 'Nama Produk',
            col2a: productDescList[mapCica.additional17],
            col3a: stringOpt == "01" ? productDescList[mapCica.additional40] : productDescList[mapCica.additional64],
            none: '-'
        }, {
            col1a: 'Uang Pertanggungan',
            col2a: 'Rp. ' + convertCurrency(mapCica.additional18),
            col3a: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional41) : 'Rp. ' + convertCurrency(mapCica.additional65)
        }, {
            col1a: 'Masa Pertanggungan*',
            col2a: 'Sampai dengan Usia ' + mapCica.additional19 + ' tahun',
            col3a: stringOpt == "01" ? 'Sampai dengan Usia ' + mapCica.additional42 + ' tahun' : 'Sampai dengan Usia ' + mapCica.additional66 + ' tahun'
        }, {
            col1a: 'Tambahan ' + title_organ,
            col2a: '-',
            col3a: stringOpt == "01" ? mapCica.additional43 : mapCica.additional67,
            plan: 'Plan 1'
        },

        //Produk PRUCrisis Cover Benefit 34
        {
            col1a: 'Nama Produk',
            col2a: productDescList[mapCica.additional14],
            col3a: stringOpt == "01" ? productDescList[mapCica.additional36] : productDescList[mapCica.additional60],
            none: '-'
        }, {
            col1a: 'Uang Pertanggungan',
            col2a: 'Rp. ' + convertCurrency(mapCica.additional15),
            col3a: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional37) : 'Rp. ' + convertCurrency(mapCica.additional61)
        }, {
            col1a: 'Masa Pertanggungan*',
            col2a: 'Sampai dengan Usia ' + mapCica.additional16 + ' tahun',
            col3a: stringOpt == "01" ? 'Sampai dengan Usia ' + mapCica.additional38 + ' tahun' : 'Sampai dengan Usia ' + mapCica.additional62 + ' tahun'
        }, {
            col1a: 'Tambahan ' + title_organ,
            col2a: '-',
            col3a: stringOpt == "01" ? mapCica.additional39 : mapCica.additional63,
            plan: 'Plan 1'
        },

        // Product PRUEarly Stage Crisis Cover Plus
        {
            col1a: 'Nama Produk',
            col2a: productDescList[mapCica.additional20],
            // col3a: stringOpt == "01" ? productDescList[mapCica.additional30] : productDescList[mapCica.additional54],
            col3a: stringOpt == "01" ? productDescList[mapCica.additional44] : productDescList[mapCica.additional68],
            none: '-'
        }, {
            col1a: 'Uang Pertanggungan',
            col2a: 'Rp. ' + convertCurrency(mapCica.additional21),
            col3a: stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional45) : 'Rp. ' + convertCurrency(mapCica.additional69)
        }, {
            col1a: 'Masa Pertanggungan*',
            col2a: 'Sampai dengan Usia ' + mapCica.additional22 + ' tahun',
            col3a: stringOpt == "01" ? 'Sampai dengan Usia ' + mapCica.additional46 + ' tahun' : 'Sampai dengan Usia ' + mapCica.additional70 + ' tahun'
        }, {
            col1a: 'Tambahan ' + title_organ,
            col2a: '-',
            col3a: stringOpt == "01" ? mapCica.additional47 : mapCica.additional71,
            plan: 'Plan 2'
        }

    ];


    // console.log("====",productName);

    // filter product CI cica simple
    var arrProducts = [];
    productName.map(function (e, i) {
        if (e.col1a == "Nama Produk") {
            if (e.col3a === undefined) {

            } else {
                // console.log("ambil yang ini ", e);
                var x = productName[i + 1].col2a.replace(/[^0-9]/g, '').length > 0 ? parseInt(productName[i + 1].col2a.replace(/[^0-9]/g, '')) : 0;
                var z = productName[i + 1].col3a.replace(/[^0-9]/g, '').length > 0 ? parseInt(productName[i + 1].col3a.replace(/[^0-9]/g, '')) : 0;

                console.log("==== uang ", productName[i + 1].col2a, productName[i + 1].col3a);
                if (z > x) {
                    asuransi_tambahan.push(e.col3a);
                }

                arrProducts.push(productName[i]);
                arrProducts.push(productName[i + 1]);
                arrProducts.push(productName[i + 2]);
                arrProducts.push(productName[i + 3]);
            }
        }
    });

    console.log("asruansi tambahan : ", asuransi_tambahan);



    arrProducts.map(function (e, i) {
        if (simpleSharia) {
            if (e.col1a.includes('Uang Pertanggungan')) {
                e.col1a = "Santunan Asuransi";
            };
            if (e.col2a == "Rp. 0" || e.col2a == "Sampai dengan Usia  tahun" || e.col2a == undefined) {
                e.col2a = "-";
            }
        }
        if (e.col1a.includes('Nama Produk')) {
            if (e.col3a == undefined) {
                e.col3a = '-';
            };
            if (e.col2a == undefined) {
                e.col2a = '-';
            };
        }

        if (e.col1a.includes("Uang")) {
            if (e.col2a == "Rp. 0") {
                e.col2a = "-"
                arrProducts[i + 1].col2a = "-";
            }
        }

        // kondisi jika ada plan pada product CI Cica Simple
        if (e.col1a.includes('Tambahan ')) {
            if (e.col3a) {
                var a = e.col3a.toUpperCase();
                e.col3a = a == 'YES' ? e.plan : '-';
            }
        }

        if (e.plan) {
            var a = e.plan.toUpperCase();
            if (a == 'PLAN 1' || a == 'PLAN 2') {
                planCondition = true;
            }
        }

    })

    // if (planCondition) {
    //     if (simpleSharia) {
    //         asuransi_tambahan.push("PRUTotal Critical Protection Syariah");
    //     } else {
    //         asuransi_tambahan.push("PRUTotal Critical Protection");
    //     }
    // }

    // console.log( "asruansi tambahan2 : ", asuransi_tambahan);

    let asuransiTambahan = asuransi_tambahan;


    console.log("asruansi tambahan3 : ", asuransiTambahan);


    if (mapCica.additional76 != "group2" && stringOpt != "02") {
        rincianManfaatList.forEach(e => {
            if (e.col2 > e.col3 && !e.col1.includes("Uang") && !e.col1.includes("Santunan")) {
                asuransiTambahan.push(e.col1);
            }

        })

        rincianManfaatList2.forEach(e => {

            if (e.col2 > e.col3 && !e.col1.includes("Uang") && !e.col1.includes("Santunan")) {
                asuransiTambahan.push(e.col1);

            }
        })
    }

    asuransiTambahan = _.uniq(asuransiTambahan);
    let campaignCodeTemp = [
        'EEP-001',
        'EEF-001', 
        'ECX-001', 
        
        'PLS-001',
        'PLS-002',
        'CCA-001',
        'CCA-002'
    ]

    //fungsi capitalize huruf
    function capitalize_Words(str) {
        return str.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substring(1).toLowerCase(); });
    }

    console.log("ini mapping" + dataAfter.campaignInfo.campaignCode);

    //mapping data cica simple


    if (_.includes(campaignCodeTemp, dataAfter.campaignInfo.campaignCode)) {

        // mapping for package repricing data
        mappingSetData.BILL_FREQ = mapCica. additional27;
        mappingSetData.CURRENT_BASIC_PREMI = 'Rp. '+ convertCurrency(mapCica.additional24);
        mappingSetData.CURRENT_SAVER = 'Rp. '+ convertCurrency(mapCica.additional25);
        mappingSetData.CURRENT_TOTAL_PREMI = 'Rp. '+ convertCurrency(mapCica. additional26);
        //
        if ([dataAfter.campaignInfo.isRecalculated].includes("Y")) {
            mappingSetData.CURRENT_BASIC_PREMI = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedCurrentBasic);
            mappingSetData.CURRENT_SAVER = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedCurrentSaver);
            mappingSetData.CURRENT_TOTAL_PREMI = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedCurrentTotal);

            mappingSetData.OFFER_A__BASIC_PREMI = stringOpt == "01" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferABasicPremi) : 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferBBasicPremi);
            mappingSetData.OFFER_A__SAVER = stringOpt == "01" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferASaver) : 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferBSaver);
            mappingSetData.OFFER_A__TOTAL_PREMI = stringOpt == "01" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferATotal) : 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferBTotal);
            mappingSetData.BILL_FREQ = dataAfter.billingFrequency == "12" ? "Bulanan" :
                (dataAfter.billingFrequency == "04" ? "Triwulan" :
                    (dataAfter.billingFrequency == "02" ? "Semesteran" :
                        (dataAfter.billingFrequency == "01" ? "Tahunan" : "undefined")));

            //            mappingSetData.current_basprem = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedCurrentBasic);
            //            mappingSetData.current_basprem = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferABasicPremi);
                        mappingSetData.current_basprem = 'Rp. ' + convertCurrency(dataAfter.premiBerkala);
            //            mappingSetData.current_saver = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedCurrentSaver);
            //            mappingSetData.current_saver = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferASaver);
                        mappingSetData.current_saver = 'Rp. ' + convertCurrency(dataAfter.pruSaver);
                        mappingSetData.current_totprem = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedCurrentTotal);
                        mappingSetData.total_premi = 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferATotal);

            mappingSetData.offer_basprem = stringOpt == "01" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferABasicPremi) : stringOpt == "02" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferBBasicPremi) : 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferCBasicPremi);
            mappingSetData.offer_saver = stringOpt == "01" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferASaver) : stringOpt == "02" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferBSaver) : 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferCSaver);
            mappingSetData.offer_totprem = stringOpt == "01" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferATotal) : stringOpt == "02" ? 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferBTotal) : 'Rp. ' + convertCurrency(dataAfter.campaignInfo.recalculatedOfferCTotal);

        } else if (dataAfter.campaignInfo.isRecalculated == "N") {
            mappingSetData.CURRENT_BASIC_PREMI = 'Rp. ' + convertCurrency(mapCica.additional24);
            mappingSetData.CURRENT_SAVER = 'Rp. ' + convertCurrency(mapCica.additional25);
            mappingSetData.CURRENT_TOTAL_PREMI = 'Rp. ' + convertCurrency(mapCica.additional26);
            
            //20 June 2021 issue basic_premi beda 1 angka sama di sqs dari PF
            var billFreqNumber = mapCica.additional27 ===  "Bulanan" ? "12" : (mapCica.additional27 ==  "Triwulan" ?  "04" : (mapCica.additional27 == "Semesteran" ? "02" : (mapCica.additional27 == "Tahunan" ? "01" : "undefined")));
            var offerAPremTahunan = Math.round(parseInt(mapCica.additional49) * parseInt(billFreqNumber) / 1000) * 1000;
            var offerABasePremCica = Math.round(offerAPremTahunan / parseInt(billFreqNumber));

            var offerBPremTahunan = Math.round(parseInt(mapCica.additional73) * parseInt(billFreqNumber) / 1000) * 1000;
            var offerBBasePremCica = Math.round(offerBPremTahunan / parseInt(billFreqNumber));
            
            var offerTotalPremi = stringOpt == "01" ? (parseInt(offerABasePremCica) + parseInt(mapCica.additional50)) : (parseInt(offerBBasePremCica) + parseInt(mapCica.additional74));
            
            mappingSetData.OFFER_A__BASIC_PREMI = stringOpt == "01" ? 'Rp. ' + convertCurrency(offerABasePremCica) : 'Rp. ' + convertCurrency(offerBBasePremCica);
            mappingSetData.OFFER_A__SAVER = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional50) : 'Rp. ' + convertCurrency(mapCica.additional74);
            mappingSetData.OFFER_A__TOTAL_PREMI = stringOpt == "01" ? 'Rp. ' + convertCurrency(offerTotalPremi) : 'Rp. ' + convertCurrency(offerTotalPremi);
            mappingSetData.BILL_FREQ = mapCica.additional27;
            //jira 6216
            if (dataAfter.campaignInfo.campaignCode == 'CCA-001') {
                mappingSetData.OFFER_A__BASIC_PREMI = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional49) : 'Rp. ' + convertCurrency(mapCica.additional73);
                mappingSetData.OFFER_A__TOTAL_PREMI = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional51) : 'Rp. ' + convertCurrency(mapCica.additional75); 
            }
            //end jira 6216
        }

        mappingSetData.SALUTATION = capitalize_Words(mapCica.additional03);
        mappingSetData.POLICY_NO = mapCica.policyNumber;
        mappingSetData.POLICY_HOLDER_NAME = capitalize_Words(mapCica.additional04);
        mappingSetData.LIFE_ASSURED_NAME = mapCica.additional05;
        mappingSetData.CURRENT_BASIC_CODE = productDescList[mapCica.additional06];
        mappingSetData.CURRENT_RIDER_CODE_LINK_TERM = productDescList[mapCica.additional08];
        mappingSetData.CURRENT_RIDER_CODE_CCB61 = productDescList[mapCica.additional17];
        mappingSetData.CURRENT_RIDER_CODE_ESC_OR_ESSCC_P = productDescList[mapCica.additional20];
        mappingSetData.CURRENT_RIDER_CODE_PADD_OR_PADD_P = productDescList[mapCica.additional11];
        mappingSetData.CURRENT_BASIC_SA = 'Rp. ' + convertCurrency(mapCica.additional07);
        mappingSetData.OFFER_A__BASIC_SA = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional29) : 'Rp. ' + convertCurrency(mapCica.additional53);
        mappingSetData.CURRENT_RIDER_SA_LINK_TERM = 'Rp. ' + convertCurrency(mapCica.additional09);
        mappingSetData.OFFER_A__RIDER_SA_LINK_TERM = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional31) : 'Rp. ' + convertCurrency(mapCica.additional55);
        mappingSetData.CURRENT_RIDER_SA_PADD_OR_PADD_P = 'Rp. ' + convertCurrency(mapCica.additional12);
        mappingSetData.OFFER_A__RIDER_SA_PADD_OR_PADD_P = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional34) : 'Rp. ' + convertCurrency(mapCica.additional58);
        // mappingSetData.CURRENT_RIDER_CODE_CCB61 = productDescList[mapCica.additional17];
        mappingSetData.OFFER_A__RIDER_CODE_CCB61 = stringOpt == "01" ? mapCica.additional40 : mapCica.additional64;
        mappingSetData.CURRENT_RIDER_SA_CCB61 = 'Rp. ' + convertCurrency(mapCica.additional18);
        mappingSetData.OFFER_A__RIDER_SA_CCB61 = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional41) : 'Rp. ' + convertCurrency(mapCica.additional65);
        mappingSetData.CURRENT_RIDER_TERM_CCB61 = mapCica.additional19;
        mappingSetData.OFFER_A__RIDER_TERM_CCB61 = stringOpt == "01" ? mapCica.additional42 : mapCica.additional66;
        mappingSetData.OFFER_A__CICA_CCB61_PLAN_1 = stringOpt == "01" ? mapCica.additional43 : mapCica.additional67;
        mappingSetData.CURRENT_RIDER_CODE_CCB34 = productDescList[mapCica.additional14];
        mappingSetData.OFFER_A__RIDER_CODE_CCB34 = stringOpt == "01" ? mapCica.additional36 : mapCica.additional60;
        mappingSetData.CURRENT_RIDER_SA_CCB34 = 'Rp. ' + convertCurrency(mapCica.additional15);
        mappingSetData.OFFER_A__RIDER_SA_CCB34 = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional37) : 'Rp. ' + convertCurrency(mapCica.additional61);
        mappingSetData.CURRENT_RIDER_TERM_CCB34 = mapCica.additional16;
        mappingSetData.OFFER_A__RIDER_TERM_CCB34 = stringOpt == "01" ? mapCica.additional38 : mapCica.additional62;
        mappingSetData.OFFER_A__CICA_CCB34_PLAN_1 = stringOpt == "01" ? mapCica.additional39 : mapCica.additional63;
        // mappingSetData.CURRENT_RIDER_CODE_ESCC_OR_ESCC_P = productDescList[mapCica.additional20];
        mappingSetData.OFFER_A__RIDER_CODE_ESCC_OR_ESCC_P = stringOpt == "01" ? productDescList[mapCica.additional44] : productDescList[mapCica.additional68];
        mappingSetData.CURRENT_RIDER_SA_ESCC_OR_ESCC_P = 'Rp. ' + convertCurrency(mapCica.additional21);
        mappingSetData.OFFER_A__RIDER_SA_ESCC_OR_ESCC_P = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional45) : 'Rp. ' + convertCurrency(mapCica.additional69);
        mappingSetData.CURRENT_RIDER_TERM_ESCC_OR_ESCC_P = mapCica.additional22;
        mappingSetData.OFFER_A__RIDER_TERM_ESCC_OR_ESCC_P = stringOpt == "01" ? mapCica.additional46 : mapCica.additional70;
        mappingSetData.OFFER_A__CICA_ESCC_OR_ESCC_P_PLAN_2 = stringOpt == "01" ? mapCica.additional47 : mapCica.additional71;
        mappingSetData.CURRENT_TOTAL_BIAYA_ASURANSI = 'Rp. ' + convertCurrency(mapCica.additional23);
        mappingSetData.OFFER_A__TOTAL_BIAYA_ASURANSI = stringOpt == "01" ? 'Rp. ' + convertCurrency(mapCica.additional48) : 'Rp. ' + convertCurrency(mapCica.additional72);
        // mappingSetData.CURRENT_BASIC_PREMI = 'Rp. '+ convertCurrency(mapCica.additional24);
        // mappingSetData.OFFER_A__BASIC_PREMI = stringOpt == "01" ? 'Rp. '+ convertCurrency(Math.round(parseInt(a) * parseInt(b) / 1000) * 1000mapCica.additional49) : 'Rp. '+ convertCurrency(mapCica.additional73) ;
        // mappingSetData.CURRENT_SAVER = 'Rp. '+ convertCurrency(mapCica.additional25);
        // mappingSetData.OFFER_A__SAVER = stringOpt == "01" ? 'Rp. '+ convertCurrency(mapCica.additional50) : 'Rp. '+ convertCurrency(mapCica.additional74);
        //mappingSetData.BILL_FREQ = mapCica. additional27;
        // mappingSetData.CURRENT_TOTAL_PREMI = 'Rp. '+ convertCurrency(mapCica. additional26);
        // mappingSetData.OFFER_A__TOTAL_PREMI = stringOpt == "01" ? 'Rp. '+ convertCurrency(mapCica.additional51) : 'Rp. '+ convertCurrency(mapCica.additional75);
        mappingSetData.rincian_manfaat_list = rincianManfaatList;
        mappingSetData.rincian_manfaat_list2 = rincianManfaatList2;

        //deskripsi product
        mappingSetData.linkterm_title = linkTermTitle;
        mappingSetData.padd_title = paddTitle;
        mappingSetData.linkterm_description = linkTermDescription;
        mappingSetData.padd_description = paddDescription;
        

        mappingSetData.product_name = arrProducts;
        mappingSetData.asuransi_tambahan = asuransiTambahan;
        mappingSetData.product_cica = "Manfaat Asuransi Tambahan " + allCodeBasicTitle;
        mappingSetData.product_cica2 = allCodeBasicTitle;
        mappingSetData.pphplustitle = pphPlusTitle;
        mappingSetData.critical = " , " + Critical;
        mappingSetData.total_p_berkala_before = 'Rp. ' + convertCurrency(parseInt(dataAfter.premiumSummary.before.totalPremiumBulanan));
        mappingSetData.total_p_berkala_after = 'Rp. ' + convertCurrency(parseInt(dataAfter.policyTemporary[parseInt(stringOpt) - 1].totalPremiumBulanan));
        // mappingSetData.CURRENT_BASIC_TERM = "Sampai dengan usia " + dataAfter.products.filter(x=>x.rider == 0)[0].term + " tahun" ; 
        mappingSetData.CURRENT_BASIC_TERM = "Sampai dengan usia 99 tahun";
        if (dataAfter.statusOtp != undefined && dataAfter.statusOtp == "Y") {
            mappingSetData.agreement_otp = 'Persetujuan atas pengajuan ini dilakukan dengan konfirmasi one-time password (OTP).';
            mappingSetData.agreement_approval_otp = '"Saya dengan ini menyetujui perubahan Polis sesuai dengan manfaat produk Asuransi Tambahan yang tertera pada penawaran ini, dan akan diproses tanpa melalui permintaan pemeriksaan kesehatan jika status Polis tetap aktif serta sesuai dengan syarat dan ketentuan."';
            mappingSetData.agreement_approval_otp_1 = '"Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui ketentuan mengenai Kondisi Yang Telah Ada Sebelumnya (Pre-Existing Conditions/PEC) pada polis ini."';
            mappingSetData.agreement_approval_otp_2 = '"Saya menyatakan bahwa saat ini saya dalam kesehatan yang baik, tidak pernah menderita atau dirawat di rumah sakit karena COVID-19, dan tidak sedang dalam isolasi diri sendiri atau tidak melakukan kontak dengan penderita COVID-19."';
        } else {
            mappingSetData.agreement_otp = "";
            mappingSetData.agreement_approval_otp = '"Saya dengan ini menyetujui perubahan Polis sesuai dengan manfaat produk Asuransi Tambahan yang tertera pada penawaran ini, dan akan diproses tanpa melalui permintaan pemeriksaan kesehatan jika status Polis tetap aktif serta sesuai dengan syarat dan ketentuan."';
            mappingSetData.agreement_approval_otp_1 = '"Saya menyatakan bahwa saya telah membaca, memahami, dan menyetujui ketentuan mengenai Kondisi Yang Telah Ada Sebelumnya (Pre-Existing Conditions/PEC) pada polis ini."';
            mappingSetData.agreement_approval_otp_2 = '"Saya menyatakan bahwa saat ini saya dalam kesehatan yang baik, tidak pernah menderita atau dirawat di rumah sakit karena COVID-19, dan tidak sedang dalam isolasi diri sendiri atau tidak melakukan kontak dengan penderita COVID-19."';
        }
        mappingSetData.BASIC_CODE_TITLE = " Manfaat Asuransi Dasar " + productDescList[mapCica.additional06] + " dan ";

        // var basic_code_value = stringOpt == "01" ? parseInt(mapCica.additional29) : parseInt(mapCica.additional53);
        // if (basic_code_value > parseInt(mapCica.additional07)) {
        //     mappingSetData.BASIC_CODE_TITLE = " Manfaat Asuransi Dasar " + productDescList[mapCica.additional06] + " dan ";
        // } else {
        //     mappingSetData.BASIC_CODE_TITLE = "";
        // }


    }
    doc.setData(mappingSetData);
    //  //// console.log ("ini cica :" + mappingSetData.product_cica2);

    console.log("mapping data for template docx done  ----- ");
    doc.render();
    const buf = doc.getZip().generate({ type: 'nodebuffer' });

    const filePathDocx =path.join(__dirname, '/public/output/' + dataAfter.policyNumber + stringOpt + dataAfter.campaignInfo.campaignCode + '.docx')
    fs.writeFileSync(filePathDocx, buf);

    const fileName = dataAfter.policyNumber + stringOpt + dataAfter.campaignInfo.campaignCode;
    
    const filePathPdf = filePathDocx.replace(".docx",".pdf")
    // return {
    //     docx: filePathDocx,
    //     pdf: filePathPdf
    // }
    // return new Promise((resolve,reject) => {
    //     return resolve({message: 'done generate docx', data: fileName})
    // })

    // // call generate pdf
    const isSuccessGenPdf = await Unoconv.generatePDFUsingUnoConvServer(
        filePathDocx, filePathPdf
    );

    return {
        data: isSuccessGenPdf,
        docx: filePathDocx,
        pdf: filePathPdf
    }

    // console.debug(isSuccessGenPdf)

    //kondisi untuk render dari dokumen docx ke PDF
    // return new Promise((resolve, reject) => {
    //     log.info("start render to docx");
    //     console.log("start render to docx");
    //     try {
    //         doc.render();
    //         const buf = doc.getZip().generate({ type: 'nodebuffer' });
    //         fs.writeFileSync(path.join(__dirname, '/public/output/' + dataAfter.policyNumber + stringOpt + dataAfter.campaignInfo.campaignCode + '.docx'), buf);
    //         Utils.docxConverter(dataAfter.policyNumber + stringOpt + dataAfter.campaignInfo.campaignCode).then(function (resp) {
    //             console.log("success ", resp);
    //             resolve(resp);
    //         }).catch((err) => {
    //             console.log("error", err)
    //             reject(err);
    //         })
    //     }

    //     catch (error) {
    //         // //console.log(error);
    //         log.error("error converting to docx ");
    //         let e = {
    //             message: error.message,
    //             name: error.name,
    //             stack: error.stack,
    //             properties: error.properties,
    //         }
    //         console.log(e);
    //         reject(error);
    //     }
    // })
    return {
        message: "Should not error"
      }
}

//fungsi convert currency 
const convertCurrency = function (data) {
    //// console.log(data);
    var x = parseInt(data);
    if (isNaN(x)) {
        x = 0;
    }
    try {
        var reverse = x.toString().split('').reverse().join(''),
            ribuan = reverse.match(/\d{1,3}/g);
        ribuan = ribuan.join('.').split('').reverse().join('');
        return ribuan;
    } catch (err) {
        return x;
    }
}

//fungsi kirim notifikasi 
const pushNotif = function (transactionId, agentCode, policyNumber, eventId, reqId, reason) {
    log.info("start send notif to ", agentCode, eventId, reqId);
    let objBody = [{
        userid: agentCode,
        eventid: eventId,
        token: "",
        subtituteParam: {
            campaignDetailId: transactionId,
            policyNumber: policyNumber,
            reason: reason,
            reqId: reqId,
            npa: {
                policyNumber: policyNumber,
                transactionId: transactionId,
                status: "OK",
                reason: reason
            }
        }
    }]
    console.log("ini objek notifikasi", objBody);

    //  //// console.log(dataAlter);
    const request = require("request");
    var options = {
        method: 'POST',
        url: config.service_url + '/pushNotif/sendMessage',
        headers:
            { 'Content-Type': 'application/json' },
        body: objBody,
        json: true
    };

    //  //// console.log("masuk kirim notif");

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            log.info("push notif send ", agentCode, eventId, reqId);
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

//fungsi create OTP
const createOTP = function (dataAlter) {
    //  //// console.log(dataAlter);
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/otpService/createOTP',
        headers:
            { 'Content-Type': 'application/json' },
        body: dataAlter,
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            // console.log(response);
            // console.log(body);
            if (body.responseCode == "00") {
                resolve(body)
            } else {
                console.log("masuk error");
                reject("fail to create otp");
            }
        });
    })
}

// fungsi mengambil OTP berdasarkan id transaksi
const getOTPByTransactionId = function (transactionId) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/otpService/getOTP',
        headers:
            { 'Content-Type': 'application/json' },
        body: { transactionId: transactionId },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

const getDataOTPByTransactionId = function (transactionId) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/otpService/getOTP',
        headers:
            { 'Content-Type': 'application/json' },
        body: { transactionId: transactionId },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

//kondisi update status OTP
const updateStatusOTP = function (transactionId, status) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/otpService/updateStatus',
        headers:
            { 'Content-Type': 'application/json' },
        body: { transactionId: transactionId, statusCode: status },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

//fungsi mengambil semua OTP
const getAllOTP = function (policyNumber) {
    console.log("masuk getAllOTP, request to " + config.service_url + "/otpService/getAll");
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/otpService/getAll',
        headers:
            { 'Content-Type': 'application/json' },
        body: { policyNumber: policyNumber },
        json: true
    };

    console.log(options.body);
    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            console.log(response.body);
            if (error) {
                reject("error");
            }
            resolve(body);
        });
    })
}

//fungsi mengambil data campaign dari json data after
const getDataCampaign = function (policyNumber, agentCode, campaignCode) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/resource/campaign/getDataClientDetail',
        headers:
            { 'Content-Type': 'application/json' },
        body: {
            additionalType: "major",
            policyNumber: policyNumber,
            agentCode: agentCode,
            campaignCode: campaignCode
        },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

//replace OTP
const replaceOTP = function (policyNumber, option, campaignCode) {
    console.log("masuk replaceOTP");
    return new Promise((resolve, reject) => {
        getAllOTP(policyNumber).then((resBody) => {
            if (resBody.OTP.length > 0) {
                resBody.OTP.forEach(function (obj) {
                    console.log('CEK LOG ' + obj.campaignCode);
                    console.info('CEK LOG ' + obj.campaignCode);
                    if (obj.option == option && obj.status == "ACTIVE" && obj.campaignCode == '') {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    } else if (obj.option == option && obj.status == "SUBMITTED" && obj.campaignCode == '') {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    } else if (obj.option == option && obj.status == "REJECT" && obj.campaignCode == '') {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    } else if ((obj.option == option && obj.status == "ACTIVE" && obj.campaignCode == campaignCode)) {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    } else if ((obj.option == option && obj.status == "" && obj.campaignCode == campaignCode)) {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    }
                    else if (obj.option == option && obj.status == "SUBMITTED" && obj.campaignCode == campaignCode) {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    } else if (obj.option == option && obj.status == "REJECT" && obj.campaignCode == campaignCode) {
                        updateStatusOTP(obj.transactionId, "06").then((resp) => {
                            //// console.log("success delete");
                        }).catch((error) => {
                            reject(error);
                        })
                    }
                });
                resolve("success");
            } else {
                resolve("success");
            }
        }).catch((err) => {
            reject(err);
        });
    });
}

// authorization 
const authorise = async function (password, transactionId) {
    let obj = {
        isLoggedIn: false,
        exists: false
    };

    let result = await getOTPByTransactionId(transactionId).then((resBody) => {
        //  //// console.log(resBody.OTP);
        if (password == resBody.OTP.otp) {

            let campaignCode = resBody.OTP.campaignCode;
            if (campaignCode == "") {
                console.log("INI BUAT OTP GIO");
                console.log("ini akan membuat content");
                let parsingJson = JSON.parse(resBody.OTP.data);
                let content = parsingJson.main.policyAfter.additionalData.documentHTMLOutput;
                // console.log(content);
                let codeAgen = resBody.OTP.agentNumber;
                console.log(codeAgen);
                let noPolis = resBody.OTP.policyNumber;
                console.log(noPolis);
                return Utils.convertBase64(content, codeAgen, noPolis).then((response) => {
                    // console.log(response.status);
                    // console.log(response.data);
                    // console.log(response.status);
                    let obj = {
                        isLoggedIn: true,
                        exists: true,
                        base64: response.data,
                        policyNumber: resBody.OTP.policyNumber,
                        transactionId: transactionId,
                        campaignCode: campaignCode
                    };

                    return obj;
                }).catch((error) => {
                    console.log("ada error dari service convertBae64");
                    console.log(error);
                    obj.isLoggedIn = false;
                    obj.exists = false;
                    return obj;
                });
            } else {
                //  //// console.log(resBody.OTP);
                return pdf2base64(path.join(__dirname, '/public/output/' + resBody.OTP.policyNumber + resBody.OTP.option + resBody.OTP.campaignCode + '.pdf')).then((response) => {
                    obj.isLoggedIn = true;
                    obj.exists = true;
                    obj.base64 = response;
                    obj.policyNumber = resBody.OTP.policyNumber;
                    obj.transactionId = transactionId;
                    obj.campaignCode = campaignCode;
                    return obj;
                }).catch((error) => {
                    obj.isLoggedIn = false;
                    obj.exists = false;
                    return obj;
                });
            }

        } else {
            obj.isLoggedIn = false;
            obj.exists = false;
            return obj;
        }
    }).catch((error) => {
        obj.isLoggedIn = false;
        obj.exists = false;
        return obj;
    });
    await result;
    //  //// console.log(obj);
    //  //// console.log(result);
    log.info("authorise result isLoggedIn ", obj.isLoggedIn);
    return result;
}

const submit = function (transactionId) {
    let obj = {};
    return new Promise((resolve, reject) => {
        console.log("masuk", transactionId);
        getDataOTPByTransactionId(transactionId).then(function (response) {
            // console.log(response);
            let respJson = JSON.parse(response.OTP.data);
            // console.log(respJson);
            // console.log(JSON.parse(response.OTP.data));
            if (response.responseCode == "00") {
                pdf2base64(path.join(__dirname, '/public/output/' + response.OTP.policyNumber + response.OTP.option + response.OTP.campaignCode + '.pdf')).then((base64) => {
                    // console.log(base64);
                    // obj.main.policyAfter.base64OTP = base64;
                    obj.dataAfter = respJson.main.policyAfter;
                    obj.dataBefore = respJson.main.policyBefore;
                    obj.campaignData = respJson.campaignData;
                    obj.dataAfter.filebase64OTP = "data:image/pdf;base64," + base64;

                    //set remaining data

                    // prubooster flag update
                    // --- set new flag to new key ('alt_pruboosterFlag')
                    obj.dataAfter.alt_pruboosterFlag = obj.dataAfter.pruboosterFlag;
                    // --- set previous (before) value to 'pruboosterFlag'
                    obj.dataAfter.pruboosterFlag = obj.dataBefore.pruboosterFlag;
                    // --- update flag value if counter increased
                    if (obj.dataAfter.pruboosterFlag == 'Y' && obj.dataAfter.counter > obj.dataBefore.counter) {
                        obj.dataAfter.alt_pruboosterFlag = 'YY';
                        obj.dataAfter.alterDocumentID.pruBoosterDoc = '14220701';
                    }

                    // occupation
                    // -- life assureds // policy AFTER
                    for (var gg = 0; gg < obj.dataAfter.lifeAssured.length; gg++) {
                        // job name id/en
                        obj.dataAfter.lifeAssured[gg].lifeOccupationNameInd = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'jobNameInd');
                        obj.dataAfter.lifeAssured[gg].lifeOccupationNameEng = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'jobNameEng');
                        // job description id/en
                        obj.dataAfter.lifeAssured[gg].lifeOccupationDescInd = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'descriptionInd');
                        obj.dataAfter.lifeAssured[gg].lifeOccupationDescEng = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'descriptionEng');
                    }

                    // -- life assureds // policy BEFORE
                    for (var ty = 0; ty < obj.dataBefore.lifeAssured.length; ty++) {
                        // job name id/en
                        obj.dataBefore.lifeAssured[ty].lifeOccupationNameInd = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'jobNameInd');
                        obj.dataBefore.lifeAssured[ty].lifeOccupationNameEng = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'jobNameEng');
                        // job description id/en
                        obj.dataBefore.lifeAssured[ty].lifeOccupationDescInd = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'descriptionInd');
                        obj.dataBefore.lifeAssured[ty].lifeOccupationDescEng = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'descriptionEng');
                        if (obj.dataBefore.lifeAssured[ty].lifeOccupationClass == '') {
                            obj.dataBefore.lifeAssured[ty].lifeOccupationClass = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'clazz');
                        }
                    }
                    // --- payor
                    obj.dataAfter.clientRolePY.clientOccupationNameInd = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'jobNameInd');
                    obj.dataAfter.clientRolePY.clientOccupationNameEng = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'jobNameEng');
                    obj.dataAfter.clientRolePY.clientOccupationDescInd = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'descriptionInd');
                    obj.dataAfter.clientRolePY.clientOccupationDescEng = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'descriptionEng');

                    // -- life assureds // policy AFTER
                    for (var wp = 0; wp < obj.dataAfter.lifeAssured.length; wp++) {
                        obj.dataAfter.lifeAssured[wp].lifePositionInd = Utils.positionAll(obj.dataAfter.lifeAssured[wp].lifePosition, 'descriptionInd');
                        obj.dataAfter.lifeAssured[wp].lifePositionEng = Utils.positionAll(obj.dataAfter.lifeAssured[wp].lifePosition, 'descriptionEng');
                    }

                    // -- life assureds // policy BEFORE
                    for (var wp = 0; wp < obj.dataBefore.lifeAssured.length; wp++) {
                        obj.dataBefore.lifeAssured[wp].lifePositionInd = Utils.positionAll(obj.dataBefore.lifeAssured[wp].lifePosition, 'descriptionInd');
                        obj.dataBefore.lifeAssured[wp].lifePositionEng = Utils.positionAll(obj.dataBefore.lifeAssured[wp].lifePosition, 'descriptionEng');
                    }

                    // data biaya-biaya polis
                    if (obj.dataAfter.policyTemporary[0]._prevSessionData.calcLastPremiData.length > 0) {
                        if (
                            obj.dataAfter.policyTemporary &&
                            obj.dataAfter.policyTemporary.length
                        ) {
                            var selIdx;
                            for (var item = 0; item < obj.dataAfter.policyTemporary.length; item++) {
                                if (obj.dataAfter.policyTemporary[item].selected == true) {
                                    selIdx = item;
                                    break;
                                }
                            }
                            if (obj.dataAfter._prevSessionData.calcLastPremiData.length == 1) {
                                selIdx = 0;
                            }
                            obj.dataAfter.premi_berkala = parseInt(Math.ceil(obj.dataAfter._prevSessionData.calcLastPremiData[selIdx].premiTahunan));
                            obj.dataAfter.prusaver_amount = obj.dataAfter._prevSessionData.calcLastPremiData[selIdx].pruSaver;
                            obj.dataAfter.total_premi = obj.dataAfter._prevSessionData.calcLastPremiData[selIdx].premiBerkala;
                        }
                        else {
                            var premi_berkala = parseInt(Math.ceil(obj.dataBefore.yPremium));
                            var total_premi = parseInt(obj.dataBefore.premium) * parseInt(obj.dataBefore.billingFrequency);
                            var prusaver_amount = total_premi - premi_berkala;
                            obj.dataAfter.premi_berkala = premi_berkala;
                            obj.dataAfter.prusaver_amount = prusaver_amount;
                            obj.dataAfter.total_premi = total_premi;
                        }
                    }

                    //set data submit
                    obj.dataAfter = Utils.modifyPolicyAfter(obj.dataAfter);

                    obj.dataAfter.Campaign = 'Y';
                    obj.dataAfter.Campaign_Condition = 'Y';
                    obj.dataAfter.alterDocumentID.campaign = true;
                    obj.dataAfter.alterDocumentID.mainDoc2 = [{
                        id: "14240106",
                        version: "0.7",
                        main_document: "SIO",
                        sub_document: "Campaign"
                    }];

                    //let groupFlag = respJson.campaignData.campaignInfo.campaignCICAGroup.replace(/\D/g, '');
                    let groupFlag;
                    let optionFlag = parseInt(response.OTP.option);
                    let campaignType = respJson.campaignData.campaignType;

                    if (["CCA-001", "CCA-002"].includes(obj.dataAfter.campaignInfo.campaignCode)) {
                        groupFlag = respJson.campaignData.campaignInfo.campaignCICAGroup.replace(/\D/g, '');
                    }

                    if (obj.dataAfter.campaignInfo.campaignCode == "PLS-002" && obj.campaignData.campaignDetail.additional28 != null) {
                        obj.dataAfter.flag = [{
                            name: "campaign_type",
                            value: "ECB"
                        }, {
                            name: "option_flag",
                            value: optionFlag
                        }, {
                            name: "otp_flag",
                            value: 'Y'
                        }, {
                            name: "group_flag",
                            value: parseInt(groupFlag)
                        }]
                    } else if (obj.dataAfter.campaignInfo.campaignCode == "PLS-002" && obj.campaignData.campaignDetail.additional28 == null) {
                        obj.dataAfter.flag = [{
                            name: "campaign_type",
                            value: "ECE"
                        }, {
                            name: "option_flag",
                            value: optionFlag
                        }, {
                            name: "otp_flag",
                            value: 'Y'
                        }, {
                            name: "group_flag",
                            value: parseInt(groupFlag)
                        }]
                    } else {
                        obj.dataAfter.flag = [{
                            name: "campaign_type",
                            value: campaignType
                        }, {
                            name: "option_flag",
                            value: optionFlag
                        }, {
                            name: "otp_flag",
                            value: 'Y'
                        }, {
                            name: "group_flag",
                            value: parseInt(groupFlag)
                        }]
                    }


                    obj.dataAfter.products = _.filter(obj.dataAfter.products, function (o) { return o.calcListActive; });
                    // console.log(obj.dataAfter.products);

                    let policyType = obj.dataAfter.alterPolicyType;
                    if (policyType.prubooster == false) {
                        obj.dataAfter.pruboosterFlag = obj.dataBefore.pruboosterFlag;
                        obj.dataAfter.counter = obj.dataBefore.counter;
                    }
                    if (policyType.pekerjaan == false) {
                        // Reset Perubahan data after dengan data before
                    }
                    if (policyType.manfaat == false) {
                        // Reset Perubahan data after dengan data before
                    }
                    if (policyType.statusMerokok == false) {
                        // Reset Perubahan data after dengan data before
                    }

                    let _currentDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
                    let _policyBefore = obj.dataBefore;
                    let _policyAfter = obj.dataAfter;
                    // Define State where is
                    // SAVE TO SQL LITE
                    delete _policyBefore.$$hashKey;
                    delete _policyAfter.alterState;

                    let _JSONBefore = JSON.stringify(_policyBefore);
                    let _JSONAfter = JSON.stringify(_policyAfter);
                    // New Method
                    let newLifeAssured = obj.dataBefore.lifeAssured;
                    let ownerDOB = newLifeAssured.find(function (item) { return item.lifeNumber == '01'; }).lifeDob || '';
                    let policyNumber = obj.dataAfter.policyNumber;

                    let paramsSubmit = {
                        policyNumber: policyNumber,
                        dataBefore: _JSONBefore,
                        dataAfter: _JSONAfter,
                        createdDevice: _currentDateTime,
                        ownerDOB: ownerDOB
                    };

                    // obj.base64OTP = base64;
                    // return res.status(200).send(obj);
                    submitCampaign(paramsSubmit).then(function (resp) {
                        resolve(resp);
                    }).catch(function (err) {
                        reject(err)
                    })
                }).catch((error) => {
                    console.log(error);
                    obj = {
                        message: "file not found"
                    };
                    // console.log(base64);
                    reject(obj);
                })
            } else {
                // log.error("response code != 00 dari service ");
                // return res.status(500).send(obj);
                reject(obj);
            }

        }).catch((err) => {
            console.log(err)
            // log.error("get phone number from getDataOTPByTransactionId ");
            // return res.status(404).send(obj);
            reject(err);
        })
    })
}

const submitAlter = function (transactionId) {
    let obj = {};
    return new Promise((resolve, reject) => {
        console.log("masuk", transactionId);
        getDataOTPByTransactionId(transactionId).then(function (response) {
            // console.log(response);
            let respJson = JSON.parse(response.OTP.data);
            console.log(respJson);
            if (response.responseCode == "00") {
                obj.main = respJson.main;
                obj.dataAfter = respJson.main.policyAfter;
                obj.dataBefore = respJson.main.policyBefore;
                obj.campaignData = respJson.campaignData;
                // obj.dataAfter.alt_pruboosterFlag = obj.dataAfter.pruboosterFlag;
                // obj.dataAfter.pruboosterFlag = obj.dataBefore.pruboosterFlag;

                if (obj.dataAfter.pruboosterChanged && !obj.main.ispruboosterYN && !obj.main.ispruboosterYY) {
                    if (obj.dataAfter.pruboosterFlag == 'Y') {
                        obj.dataAfter.alt_pruboosterFlag = 'N';
                    } else if (obj.dataAfter.pruboosterFlag == 'N') {
                        obj.dataAfter.alt_pruboosterFlag = 'Y';
                    }
                } else if (!obj.dataAfter.pruboosterChanged && !obj.main.ispruboosterYN && !obj.main.ispruboosterYY) {
                    obj.dataAfter.alt_pruboosterFlag = obj.dataAfter.pruboosterFlag;
                } else if (obj.dataAfter.alterPolicyType.prubooster && obj.main.ispruboosterYN) {
                    obj.dataAfter.alt_pruboosterFlag = 'YN';
                    obj.dataAfter.alterDocumentID.pruBoosterDoc = '14220701';
                } else if (!obj.dataAfter.alterPolicyType.prubooster && obj.main.ispruboosterYN) {
                    obj.dataAfter.alt_pruboosterFlag = 'N';
                    obj.dataAfter.alterDocumentID.pruBoosterDoc = '14220701';
                } else if (obj.dataAfter.alterPolicyType.prubooster && obj.main.ispruboosterYY) {
                    obj.dataAfter.alt_pruboosterFlag = 'YY';
                    obj.dataAfter.alterDocumentID.pruBoosterDoc = '14220701';
                } else if (!obj.dataAfter.alterPolicyType.prubooster && obj.main.ispruboosterYY) {
                    obj.dataAfter.alt_pruboosterFlag = 'Y';
                    obj.dataAfter.alterDocumentID.pruBoosterDoc = '14220701';
                }
                
                obj.dataAfter.hnwiData = {};
                obj.dataAfter.hnwiData.flagging = 'N';
                obj.dataAfter.hnwiData.freeAdminFee = 'N';

                for (var gg = 0; gg < obj.dataAfter.lifeAssured.length; gg++) {
                    // job name id/en
                    obj.dataAfter.lifeAssured[gg].lifeOccupationNameInd = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'jobNameInd');
                    obj.dataAfter.lifeAssured[gg].lifeOccupationNameEng = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'jobNameEng');
                    // job description id/en
                    obj.dataAfter.lifeAssured[gg].lifeOccupationDescInd = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'descriptionInd');
                    obj.dataAfter.lifeAssured[gg].lifeOccupationDescEng = Utils.jobsAll(obj.dataAfter.lifeAssured[gg].lifeOccupationCode, 'descriptionEng');
                }

                // -- life assureds // policy BEFORE
                for (var ty = 0; ty < obj.dataBefore.lifeAssured.length; ty++) {
                    // job name id/en
                    obj.dataBefore.lifeAssured[ty].lifeOccupationNameInd = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'jobNameInd');
                    obj.dataBefore.lifeAssured[ty].lifeOccupationNameEng = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'jobNameEng');
                    // job description id/en
                    obj.dataBefore.lifeAssured[ty].lifeOccupationDescInd = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'descriptionInd');
                    obj.dataBefore.lifeAssured[ty].lifeOccupationDescEng = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'descriptionEng');
                    if (obj.dataBefore.lifeAssured[ty].lifeOccupationClass == '') {
                        obj.dataBefore.lifeAssured[ty].lifeOccupationClass = Utils.jobsAll(obj.dataBefore.lifeAssured[ty].lifeOccupationCode, 'clazz');
                    }
                }
                // --- payor
                obj.dataAfter.clientRolePY.clientOccupationNameInd = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'jobNameInd');
                obj.dataAfter.clientRolePY.clientOccupationNameEng = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'jobNameEng');
                obj.dataAfter.clientRolePY.clientOccupationDescInd = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'descriptionInd');
                obj.dataAfter.clientRolePY.clientOccupationDescEng = Utils.jobsAll(obj.dataAfter.clientRolePY.clientOccupationCode, 'descriptionEng');

                // -- life assureds // policy AFTER
                for (var wp = 0; wp < obj.dataAfter.lifeAssured.length; wp++) {
                    obj.dataAfter.lifeAssured[wp].lifePositionInd = Utils.positionAll(obj.dataAfter.lifeAssured[wp].lifePosition, 'descriptionInd');
                    obj.dataAfter.lifeAssured[wp].lifePositionEng = Utils.positionAll(obj.dataAfter.lifeAssured[wp].lifePosition, 'descriptionEng');
                }

                // -- life assureds // policy BEFORE
                for (var wp = 0; wp < obj.dataBefore.lifeAssured.length; wp++) {
                    obj.dataBefore.lifeAssured[wp].lifePositionInd = Utils.positionAll(obj.dataBefore.lifeAssured[wp].lifePosition, 'descriptionInd');
                    obj.dataBefore.lifeAssured[wp].lifePositionEng = Utils.positionAll(obj.dataBefore.lifeAssured[wp].lifePosition, 'descriptionEng');
                }

                // data biaya-biaya polis
                if (obj.dataAfter.policyTemporary[0]._prevSessionData.calcLastPremiData.length > 0) {
                    if (
                        obj.dataAfter.policyTemporary &&
                        obj.dataAfter.policyTemporary.length
                    ) {
                        var selIdx;
                        for (var item = 0; item < obj.dataAfter.policyTemporary.length; item++) {
                            if (obj.dataAfter.policyTemporary[item].selected == true) {
                                selIdx = item;
                                break;
                            }
                        }
                        if (obj.dataAfter._prevSessionData.calcLastPremiData.length == 1) {
                            selIdx = 0;
                        }
                        obj.dataAfter.premi_berkala = parseInt(Math.ceil(obj.dataAfter._prevSessionData.calcLastPremiData[selIdx].premiTahunan));
                        obj.dataAfter.prusaver_amount = obj.dataAfter._prevSessionData.calcLastPremiData[selIdx].pruSaver;
                        obj.dataAfter.total_premi = obj.dataAfter._prevSessionData.calcLastPremiData[selIdx].premiBerkala;
                    }
                    else {
                        var premi_berkala = parseInt(Math.ceil(obj.dataBefore.yPremium));
                        var total_premi = parseInt(obj.dataBefore.premium) * parseInt(obj.dataBefore.billingFrequency);
                        var prusaver_amount = total_premi - premi_berkala;
                        obj.dataAfter.premi_berkala = premi_berkala;
                        obj.dataAfter.prusaver_amount = prusaver_amount;
                        obj.dataAfter.total_premi = total_premi;
                    }
                }

                //set data submit
                obj.dataAfter = Utils.modifyPolicyAfter(obj.dataAfter);


                //let groupFlag = respJson.campaignData.campaignInfo.campaignCICAGroup.replace(/\D/g, '');
                let groupFlag;
                let optionFlag = parseInt(response.OTP.option);
                let campaignType = respJson.campaignData.campaignType;


                obj.dataAfter.flag = [{
                    name: "campaign_type",
                    value: campaignType
                }, {
                    name: "option_flag",
                    value: optionFlag
                }, {
                    name: "otp_flag",
                    value: 'Y'
                }, {
                    name: "group_flag",
                    value: parseInt(groupFlag)
                }]

                obj.dataAfter.products = _.filter(obj.dataAfter.products, function (o) { return o.calcListActive; });


                let policyType = obj.dataAfter.alterPolicyType;
                if (policyType.prubooster == false) {
                    obj.dataAfter.pruboosterFlag = obj.dataBefore.pruboosterFlag;
                    obj.dataAfter.counter = obj.dataBefore.counter;
                }

                obj.dataAfter.alterDocumentID.mainDoc2 = [{
                    id: "14220101",
                    version: "0.7",
                    main_document: "FRMD",
                    sub_document: "Formulir Pengajuan Perubahan Polis Major Untuk Produk PRUlink"
                }];

                let _currentDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
                let _policyBefore = obj.dataBefore;
                let _policyAfter = obj.dataAfter;
                delete _policyBefore.$$hashKey;
                delete _policyAfter.alterState;

                let _JSONBefore = JSON.stringify(_policyBefore);
                let _JSONAfter = JSON.stringify(_policyAfter);
                // New Method
                let newLifeAssured = obj.dataBefore.lifeAssured;
                let ownerDOB = newLifeAssured.find(function (item) { return item.lifeNumber == '01'; }).lifeDob || '';
                let policyNumber = obj.dataAfter.policyNumber;

                let paramsSubmit = {
                    policyNumber: policyNumber,
                    dataBefore: _JSONBefore,
                    dataAfter: _JSONAfter,
                    createdDevice: _currentDateTime,
                    ownerDOB: ownerDOB
                };

                submitCampaign(paramsSubmit).then(function (resp) {
                    resolve(resp);
                }).catch(function (err) {
                    reject(err)
                })

            } else {
                // log.error("response code != 00 dari service ");
                // return res.status(500).send(obj);
                reject(obj);
            }

        }).catch((err) => {
            console.log(err)
            // log.error("get phone number from getDataOTPByTransactionId ");
            // return res.status(404).send(obj);
            reject(err);
        })
    })
}

const submitCampaign = function (paramsSubmit) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.mfUrl + '/pruforce/api/adapters/HTTPAdapterDSG/dsg/submit',
        headers:
            { 'Content-Type': 'application/json' },
        body: paramsSubmit,
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
};

const setDocID2 = function (params) {

    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/common/masterdata/documentphs',
        headers:
            { 'Content-Type': 'application/json' },
        body: params,
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            //  //// console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

let client;

module.exports = {
    setClient: function (inClient) { client = inClient; },
    generatePDF: generatePDF,
    createOTP: createOTP,
    getOTPByTransactionId: getOTPByTransactionId,
    updateStatusOTP: updateStatusOTP,
    getAllOTP: getAllOTP,
    authorise: authorise,
    pushNotif: pushNotif,
    getDataOTPByTransactionId: getDataOTPByTransactionId,
    replaceOTP: replaceOTP,
    getDataCampaign: getDataCampaign,
    generatePDFFreePA: generatePDFFreePA,
    submitCampaign: submitCampaign,
    submit: submit,
    submitAlter: submitAlter
}