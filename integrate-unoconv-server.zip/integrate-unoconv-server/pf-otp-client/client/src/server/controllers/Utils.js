const config = require('../config/server-config.js');
const fs = require('fs');
const path = require('path');
const btoa = require('btoa');
const request = require("request");
const unoconv = require("unoconv-promise");
const qpdf = require('node-qpdf');
const exec = require('child_process').exec;
const Unoconv = require('./Unoconv');
const FormData = require('form-data');
const axios = require('axios');



const bufferToBase64 = (buf) => {
    var binstr = Array.prototype.map.call(buf, function(ch) {
        return String.fromCharCode(ch);
    }).join('');
    return btoa(binstr);
};

const readJSONFile = function(filename, callback) {
    fs.readFile(filename, function(err, data) {
        if (err) {
            callback(err);
            return;
        }
        try {
            callback(null, JSON.parse(data));
        } catch (exception) {
            callback(exception);
        }
    });
}


const sendSMS = function(transactionId, phoneNumber, message) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.service_url + '/otpService/apiSMS', // 'http://10.170.53.177/cxf/util/smsdb',
        headers: { 'Content-Type': 'application/json' },
        body: {
            transactionId: transactionId,
            transactionTime: "",
            signatureString: "",
            processCode: "smsmitracom",
            channelId: config.channelIdSMS,
            phoneNo: phoneNumber,
            message: message
        },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
            // //console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

const convertBase64 = function(content, codeagent, nopolicy) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.base64_url,
        headers: { 'Content-Type': 'application/json' },
        body: {
            content: content,
            codeagent: codeagent,
            nopolicy: nopolicy
        },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
            // console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    })
}

function getRandomVal() {
    const char = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; //Random Generate Every Time From This Given Char
    const length = config.random_code_url_length;
    let randomvalue = "";

    for (let i = 0; i < length; i++) {
        var arrayRandom = new Uint8Array(1);
        // var randomVal = window.crypto.getRandomValues(arrayRandom);
        const value = Math.floor(Math.random() * char.length);
        // var value = Math.floor(randomVal * char.length);
        randomvalue += char.substring(value, value + 1);
    }

    return new Promise(resolve => {
        client.hget(randomvalue, "uid", function(err, res) {
            if (!res) {
                resolve(randomvalue);
            } else {
                resolve(getRandomVal());
            }
        })
    })
}

function getRandomOtpCode() {
    const char = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ'; //Random Generate Every Time From This Given Char
    const length = config.random_code_otp_length;
    let randomvalue = "";

    for (let i = 0; i < length; i++) {
        var arrayRandom = new Uint8Array(1);
        // var randomVal = window.crypto.getRandomValues(arrayRandom);
        const value = Math.floor(Math.random() * char.length);
        // var value = Math.floor(randomVal * char.length);
        randomvalue += char.substring(value, value + 1);
    }

    return randomvalue;
}

const createShortUrl = async function(uniqId) {
    var uId = await getRandomVal();
    //console.log("promise ", uId);
    return new Promise((resolve, reject) => {
        client.hmset(uId, ["uid", uId, "uniqueId", uniqId + uId, "status", true, "createDate", Date.now()], function(err, res) {
            var todayEnd = new Date().setHours(23, 59, 59, 999);
            client.expireat(uId, parseInt(todayEnd / 1000));
            if (err) {
                reject(err);
            } else {
                client.hmget(uId, ["uid", "uniqueId", "status", "createDate"], function(err, reply) {
                    if (err) {
                        reject(err);
                    } else {
                        //console.log("get ", reply);
                        resolve(reply);
                    }
                })

            }
        });
    })
}

const convertDocxToPdf = function(fileName, password) {
    const request = require("request");

    var options = {
        method: 'POST',
        url: config.converterUrl,
        headers: { 'Content-Type': 'application/json' },
        body: {
            fileName: fileName,
            password: password
        },
        json: true
    };

    return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
            // //console.log(response);
            if (error) reject(error);
            resolve(body);
        });
    });
}

const docxConverter = function(fileName) {

    console.log("masuk docxConverter")

    Unoconv.generatePDFUsingUnoConvServer(path.join(__dirname, '/public/output/' + fileName + '.docx'), path.join(__dirname, '/public/output/' + fileName + '.pdf'));
    // .then(response => {
    //     console.log("response data "+response);
    // })
    // .catch(error => {
    //     console.log("er   "+error);
    // });


    // return new Promise((resolve, reject) => {
    //     unoconv.convert(path.join(__dirname, '/public/output/' + fileName + '.docx')).then(fileBuffer => {
    //         fs.writeFileSync(path.join(__dirname, '/public/output/' + fileName + '.pdf'), fileBuffer);
    //         resolve({ code: 200, message: 'success convert docx to pdf', fileName: fileName + '.pdf' });
    //     }).catch(e => {
    //         reject(e);
    //     });
    // });
}

const modifyPolicyAfter = function(_data) {
    _data.spajSignDataTemp = {
        "aggreement1": true,
        "aggreement2": true,
        "agent": {
            "sign": true,
            "save": true,
            "date": "24/09/2019 16:36:35",
            "location": "Jakarta",
            "signature": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/MAAADYCAYAAACnf7PLAAAgAElEQVR4Xu3dCbh153g38PQzFVVjDEnEWzM1hxhqeCVR1Cwi4aukGkMTYhZqSF5Bi0gQpTU0yWcMQU1FaeI1lUSDGqsV3qIxxzzz6f/mHN2Wvc97ztnTGn77uu7rPXvtvZ7nuX/PcsW911rP+p1dvAgQIECAAAECBAgQIECAAIFOCfxOp0ZrsAQIECBAgAABAgQIECBAgMAuinkHAQECBAgQIECAAAECBAgQ6JiAYr5jE2a4BAgQIECAAAECBAgQIEBAMe8YIECAAAECBAgQIECAAAECHRNQzHdswgyXAAECBAgQIECAAAECBAgo5h0DBAgQIECAAAECBAgQIECgYwKK+Y5NmOESIECAAAECBAgQIECAAAHFvGOAAAECBAgQIECAAAECBAh0TEAx37EJM1wCBAgQIECAAAECBAgQIKCYdwwQIECAAAECBAgQIECAAIGOCSjmOzZhhkuAAAECBAgQIECAAAECBBTzjgECBAgQIECAAAECBAgQINAxAcV8xybMcAkQIEBgpwJb842vJb668u8fruzxiZ3u6QsECBAgQIAAgY4IKOY7MlGGSYAAAQITBa6aTw5K7JW4VmLLhG/uWNn+wvx7RmI7UwIECBAgQIBAVwUU812dOeMmQIDAcAXqTPv+iSsl9khsTfyfDXL8/3z/B4m3J/4pcdZKbLAZXydAgAABAgQILEdAMb8cd70SIECAwPoFLpev3iZxg8SBiUtvonjfWW9V3NfryYntK7GzfXxOgAABAgQIEFiagGJ+afQ6JkCAAIE1BOrM+36JByS+nbjoHAr4Sd1XYf/ixCsV9Y5RAgQIECBAoK0Civm2zoxxESBAYJgCN03aT0lsnbJ4r8vmL5ioRfBWF8D7fv7esgHWKuoflfiwon4Dar5KgAABAgQILERAMb8QZp0QIECAwDoEHprvHL/JIv672e9ViU8lPrJG8V3F/M0T9aPBHyeuuI5x/XO+U4vmnbqO7/oKAQIECBAgQGAhAor5hTDrhAABAgTWENiaz+6YeHhiIwvZvTbff8tK4b5jpP3V+9/XQl/t59r50i0Td0/UOCa9vpkPTkgck1hP+yacAAECBAgQIDBXAcX8XHk1ToAAAQLrEHhmvrNWIf+5fH7xRJ1xr7Pv/5HYvtLuL/JvxTSv1cJ+axo5OHHIGo09KZ8p6KfRti8BAgQIECAwEwHF/EwYNUKAAAECmxR4d/b7o0TzjHwV7m9aKdpXC/fVLuZ5ZrzGcb3EoYnDJ+RU99E/KzHPcWyS024ECBAgQIDAUAQU80OZaXkSIECgXQK7ZjhHJw4bU8gflG2r96cvq2C+RMZw/8TTxrB9MdvqDP2JCvp2HVRGQ4AAAQIEhiSgmB/SbMuVAAEC7RG4X4bygjGFfD3nfVtLiuSLZBy3S5wyZpwnZdtLEtvbQ2okBAgQIECAwJAEFPNDmm25EiBAoB0Cdbb70WMK5Hdl2z4tKeRHpepHh3reffNVK9zXjw91pt6LAAECBAgQILBQAcX8Qrl1RoAAgcELHBWBuh99z4bE+/O+VpX/WQuF6j76uqR+3MJ4r8/2/RPLuh2ghVyGRIAAAQIECCxCQDG/CGV9ECBAgEAJ1ErxT0xcucFRj5irx77VYnhtfe2xMvZxZ+hfvpKbgr6ts2dcBAgQIECghwKK+R5OqpQIECDQQoEq5OvS+ms1xrYj72+fqMfNtb0Y3pox1j30jxnje89sW120r4X8hkSAAAECBAj0TUAx37cZlQ8BAgTaJ1BF8OMT+40ZWl2i/rr2DXniiK6YT45P3GXMN66TbR/rUC6GSoAAAQIECHRYQDHf4ckzdAIECHRAoFaE/8tEnc1uPkv+71aK/HM7kMfoECuPTyau1hh3XVnwB4nPdywfwyVAgAABAgQ6KKCY7+CkGTIBAgQ6JFBn3l89ppCvZ8m/I9G1Qn6V/kb5oxa/260xF/X8+WMSbb9loEOHkKESIECAAAEC4wQU844LAgQIEJiXQBXy9Vi3SzY6qAXvHpT4yrw6XlC729LPQxIXH+nvrPy9t2J+QTOgGwIECBAgMGABxfyAJ1/qBAgQmLPAKWn/wEYfn837RyTe1IOCty63rxwPaORYxfwH52yreQIECBAgQGDgAor5gR8A0idAgMCcBPZKu2cmmvfJPznbtvWgkF9lOzx/PK9h+MC8f3GPcpzTIaJZAgQIECBAYBoBxfw0evYlQIAAgUkCH8gHN258WJfX1yPc+nQ/ef0wcXQjz+15v2/P8nSkEyBAgAABAi0TUMy3bEIMhwABAj0QeGZyeHhi9Kz81/L+/ok39CC/0RS25s1pjVz/Ku+fqJjv2UxLhwABAgQItExAMd+yCTEcAgQIdFzgfBn/vyfqeeyjryPz5rgeFriPSk7HNnKtdQGu0sNcO35oGj4BAgQIEOiXgGK+X/MpGwIECCxb4OAM4KTE6Fn5HXlfK9t/aNmDm0P/29Jm8zL7n2TbhRI/n0N/miRAgAABAgQI/FJAMe9AIECAAIFZCnwsjV2r0eCheX9yok/3yq+mWAv6PWEM4Hl6mu8sjxVtESBAgAABAlMIKOanwLMrAQIECPyGwLa8a56lfmu23bHHhe3Tk1vdQtB8XSAb6gy9FwECBAgQIEBgLgKK+bmwapQAAQKDE/j9ZPzRxBUamR+U96/qsUYt9Hf8mPwulW3f6HHeUiNAgAABAgSWLKCYX/IE6J4AAQI9EXhw8nhOYvRe+bpH/uaJH/Ykx3FpbMvG5tUI9b1LJs7tcd5SI0CAAAECBJYsoJhf8gTongABAj0ReGHyqEfPjb5qpfdnJfp4r/xqng/JH/UjRvNVq9l/pidzKw0CBAgQIECghQKK+RZOiiERIECgYwK3yXjflmiuYH/nbKsF8fr8ekySe5pivs9TLDcCBAgQINBOAcV8O+fFqAgQINAlgRMz2Ps2Blz3yp+a6PNZ+Uq5VrKvFe2brxtlw792aRKNlQABAgQIEOiWgGK+W/NltAQIEGibwJYM6OzE6Fn57+X9HyY+37bBzmE8k87MK+bngK1JAgQIECBA4H8FFPOOBgIECBCYRuCA7HxKo5h/Y97fLdH3s/LldkziiWMAb5BtH54G1r4ECBAgQIAAgbUEFPOODwIECBCYRuC07LxPo4Hb5f0/TdNoh/Z9dsb60DHjvWa2fapDeRgqAQIECBAg0DEBxXzHJsxwCRAg0DKBusT+iiNj+s/8ffXEEM7KV9qvSew/Zk62ZNt/tWyuDIcAAQIECBDokYBivkeTKRUCBAgsWKAK1ub98kdm23EDKuY/kFxvPMb94tn2rQXPh+4IECBAgACBAQko5gc02VIlQIDAHAR+njZHF7/bN+9Pn0M/bW2ymf/qOM8zoB802jo3xkWAAAECBHotoJjv9fRKjgABAnMVOCqtP6nRg2L+VyCK+bkeehonQIAAAQIEFPOOAQIECBDYrMDh2fF5Izt/KX/vkRjK/fKVujPzmz167EeAAAECBAhMJaCYn4rPzgQIEBi0wNZkX6vZr15m/5H8vZdi/pfHhDPzg/6fhuQJECBAgMD8BRTz8zfWAwECBPoq0DwzvyOJXkkxr5jv6wEvLwIECBAg0CYBxXybZsNYCBAg0C2BbRnu0SNDroXvbqOY3+VlMThkYA7dOnKNlgABAgQI9EBAMd+DSZQCAQIEliTQLObPyjj2HlARW7cX/DQxupp/TcUtE+9Z0pzolgABAgQIEBiIgGJ+IBMtTQIECMxB4JFp85kj7T43fz9sQMX8ZZLrOWOKec+Yn8PBpkkCBAgQIEDgNwUU844IAgQIENiswCnZ8cCRnU/N3wcNqJi/WXKtM/DNM/MWv9vsEWU/AgQIECBAYN0Civl1U/kiAQIECDQE3p73dY/86mtoZ+brvvgTFfP+d0GAAAECBAgsQ0Axvwx1fRIgQKAfAmcnjSuOpHJk/j4uMZTnzD8+uT6lMZX/lPd/MiCDfhzJsiBAgAABAh0UUMx3cNIMmQABAi0ReEfGsd/IWOoS+1e1ZGyLGMYz0smjGx3VbQevXkTn+iBAgAABAgSGLaCYH/b8y54AAQLTCLw7O99ipIF983c9nm4or2cn0Yc2kr1a3v/HUADkSYAAAQIECCxPQDG/PHs9EyBAoOsCP08Co4u/Da2Yr5X8a0X/1deX88fuiaHcZtD149f4CRAgQIBApwUU852ePoMnQIDAUgWa98xfKaP57FJHtNjOT0t3+zS6tJL9YudAbwQIECBAYLACivnBTr3ECRAgMLXAaDF/VlrbOzGks9LNR/M9Kvk/a2AGUx9EGiBAgAABAgQ2J6CY35ybvQgQIEBgl11Gz0x/MyDXSHxlIDBbk2flP3qbwZPzfptifiBHgDQJECBAgMCSBRTzS54A3RMgQKDDAs3L7C87oGJ+S3Kt/EeL+Srw39Xh+TR0AgQIECBAoEMCivkOTZahEiBAoGUC/5Dx3HVkTEO6Z/6Q5H1SYvS/o9fK+0+0bI4MhwABAgQIEOipgGK+pxMrLQIECCxAoHnP+H3T58kL6LcNXZyYQVS+q68hrhnQhnkwBgIECBAgMFgBxfxgp17iBAgQmFrggLRQBf3qpeY3z9/vm7rVbjTQXMn+VRn2vRNDWgCwGzNllAQIECBAoKcCivmeTqy0CBAgsACBw9PH80b6OSJ/P38ABe1eyfHMkR8xisDidws44HRBgAABAgQI/K+AYt7RQIAAAQKbFdg1O355pKg9Ln8fOYBi/m+T41800A7L+xcOIPfNHiv2I0CAAAECBGYsoJifMajmCBAgMCCBPZPr50aK+Srsdx9AQfvzkZxXp/t8+eNnA5p7qRIgQIAAAQJLFlDML3kCdE+AAIGOC/xbxn+dlRy+nX8vmahit6+vcZfYH5tkHzuAHzH6OqfyIkCAAAECnRRQzHdy2gyaAAECrRH4ZEZyjZHRXDN/f6o1o5v9QF6dJmvhv9HXn+bNy2fflRYJECBAgAABApMFFPOODgIECBCYRuCL2bkurV999XlF+wsnyfcnrj2S79fy99UT506DaF8CBAgQIECAwEYFFPMbFfN9AgQIEBgVOClv/mxkwwvyd61y38dHtN0meb0tsfoovkq7ivnL9jRfRzoBAgQIECDQYgHFfIsnx9AIECDQAYFHZYx1z/jq64z8cbOeFre1Wv8jGnPikXQdOEgNkQABAgQI9FFAMd/HWZUTAQIEFidQ94v/v8To2erz9LSYH7eK/d7J9YOL49YTAQIECBAgQOBXAop5RwIBAgQITCOwJTuf3Sjmz5v3fVvR/uDkdHLjv5u16F1t7+MtBdMcE/YlQIAAAQIEFiCgmF8Asi4IECDQY4FxxXw9f/4LPcr5qsmlVugfvfqg0tuaeFeP8pQKAQIECBAg0CEBxXyHJstQCRAg0FKB5uXnf5FxvijRlzPWT0suj2nYvyXv79SjHFt6aBkWAQIECBAgMElAMe/YIECAAIFpBZrF/JvS4F17UujWVQbvSdS/o69D86ZW8v/FtHj2J0CAAAECBAhsRkAxvxk1+xAgQIDAqMC4heH6sgjeQUm07o0fvcS+Fry7SU9+rHAkEyBAgAABAh0VUMx3dOIMmwABAi0S6HMxf1qc92lYexxdiw4+QyFAgAABAkMVUMwPdeblTYAAgdkJvDZN3b3R3IXz/gez62IpLe2aXr+caC58d/ls++JSRqRTAgQIECBAgMCKgGLeoUCAAAEC0wrcIw28qlH03jDvz5q24SXvf5v0/7ZGXrV6fZ2p78vifksm1j0BAgQIECCwWQHF/Gbl7EeAAAECqwKXyx91pnr0DPbL8v6Qjhe9R2X8T2pM8z/kff14oZh3/BMgQIAAAQJLFVDML5Vf5wQIEOiFwHmTxY8bxXwl1vVF8F6RHO7VmKEj8/44xXwvjltJECBAgACBTgso5js9fQZPgACB1gj0bRG8S0f2S2N+oLhstn2lNeoGQoAAAQIECAxWQDE/2KmXOAECBGYq0Ldi/oDonKKYn+kxojECBAgQIEBghgKK+RliaooAAQIDFnh/cq9nr4++aqG4d3bUpAr5Axtjt/hdRyfTsAkQIECAQB8FFPN9nFU5ESBAYPECt0+Xb06MLoJXK9zfO9HFxeLOzLhv1GD0fPnFH1ez6HFLGqnYnrhS4uxZNKoNAgQIECCwbAHF/LJnQP8ECBDoh8BFksa3GsV8ZdbFRfD2yLj/a0wu18i2f+/HdPUii2uuzFPNVz1NYfXHlzoWr5+oxQvPn9jSyLbWPPhhon6cqYUb37py7PYCRRIECBAgMBwBxfxw5lqmBAgQmLdAX+6bPzhQJydG/xtZi+FV0djFqwzmPe/Ttn+hNFA/lFRcN3H/RBXkG3nVsVc/HK2+Rq8QWaudms9/S7w08fbEJzbSqe8SIECAAIFlCijml6mvbwIECPRL4DtjirDLZNtXO5bmuOfLd/mWgTbwXzuD2DVx30StpVBPBRj3Wm8RPo+cPplGj03U7SJfn0cH2iRAgAABArMUUMzPUlNbBAgQGLbAM5L+oxsEJ+T9wxNdOqP9soz3/zbycL/8zo/t3fKVwxN1lvwGiT8Zs8uii/VamPFyiS07H/6vv1HH8EmJb2xgH18lQIAAAQILF1DML5xchwQIEOitQBVNde/yaMF2bt7XGdkuFfOVw+6NWToo7+vsvNcuu2wNQt2v/rXETRMXS/xx4nyJSy8J6JXpt64AqatDjkncMfHRxI6V8dSYv5t4XOJ6iS07GWddQXDyknLRLQECBAgQWJeAYn5dTL5EgAABAusU6Pp981X0nZZonkHeN9tOX6dB3752p5VCuB7V94CV5MqnfqBZ1Jn2WpDwvYm6p/2sRBXqk27fWOuHo9Xx7pX975HYO1Fz3nx9MBvqUYtd+hGqb8edfAgQIEBgJwKKeYcIAQIECMxSYFwxvyUdVDHWhdcVM8j/TDSL1Otk28e6kMCUY6zC9tuJIxJ1dcJ+I+3Ns3A/Jf3UVRxvSnwu8YXEjybkMqsCezWf7ennFo2+6geDKvRn1deU02J3AgQIECDw2wKKeUcFAQIECMxSoC5Hf3litPDbP+9fN8tO5tzWO9P+1kYffS3m75c86/FstYL8lRO1YGG9pincq736UadWqf9e4hWJKoprxfgq0D+10ue4aVxG8fziDOTQxmDqx4QtK+Oe8+GmeQIECBAgsDkBxfzm3OxFgAABAuMF9szmOrM6WgxWgVb3Uy+jUNvMPJ2ZnVafWb66f18us6/7xe+duFqi1jioy83rtZnivc5e133oddXFuxPbE1tW/h3n3tb5r0K+CvrR11vypm4vaOuYN3Nc24cAAQIEeiagmO/ZhEqHAAECLRDo+n3zdc98PT5t9FWPLavHq3WtuKsrCmpl+fsktq4ktNHCvR7TVmfY6z71eib79sSOlVg1+kX+qOji68QMuha8G319KW/26OB8d9HfmAkQIEBgkwKK+U3C2Y0AAQIEJgrUQmV/1Pi07r8+pyNmWzPO5iJ4VcRWUdzmYr7GXWfKr5+4fWJ11fb6b/1G/ntfawN8JLE9UVda1Fnr0blrs8FmDrFxV2J4FOFmJO1DgAABAgsV2Mh/3Bc6MJ0RIECAQGcF6jFlb02MngE+JO9f0qGM6kz0hRvjvW3ev33BOZw3/dWq6vV4v6snfrpSYF8y/9Zz3X+WqCsG6lXfqddGzrzXpfKfTpydeH2iHjO3faWdOtNe/z+hb8V7cwrHXYnxwnzpsAHkvuDDWXcECBAgMEsBxfwsNbVFgAABAiVwiUQ9g3y0qKwV4qsY7Uph+LyM9fDGdNal9o9K1CPRLpL4QOIPE59NfHODU1+r5l9+xei6+fdBidq21msjRfqkdt6VD2ou6jLyWjm+ivnVV1fmZoPUa359az4d9yjC7dle6yQM0WSWvtoiQIAAgTkKKObniKtpAgQIDFhg3H3zdZa5tnfhdUAGWY9LaxbQo8XdrJ6zPosifZLpjnwweq97FamrL4Xqr65m+PKYee7Lgodd+N+aMRIgQIDAJgUU85uEsxsBAgQIrCnwjHz66JFv1CXbV0rUSvddeY17RF3bxr76g0I99q0WuatLw2+ZeFaiLp3/1siAFe+/PXtbs2ncmXnFfNuOdOMhQIAAgd8SUMw7KAgQIEBgHgJ1H3ctotbl583X2Gvhu2vNA2jKNmuF+acn/iVRZ5Z3NNpTuK8PuAyPHPPV+uGpbp/wIkCAAAECrRVQzLd2agyMAAECnRdoXmq/PRl17T7kuo/9qEQt4LfM14PTed2j/2FF+0ynYdztINXBeRJ+EJkptcYIECBAYNYCivlZi2qPAAECBFYFnpo/HjfCUYut7d3BIqnO0Ndj3u6ceECiHv921TlOc50R/uvEJxJnjPSjuJwtei1eWOsJNNcsOD7b6hYR3rP11hoBAgQIzFhAMT9jUM0RIECAwK8FqvB9QcOjy2c8R4u+OySvWp2/Vu4/NPG+xK0TF13H/FeRWCvjvz/x94k6216PmGu+FJPrwJziK7WuwMPG7H+zlbmZomm7EiBAgACB+Qso5udvrAcCBAgMWeDMJH+jEYBaoK2e4a1QHfJRsfzc67GA9WPK7o2h1JUQVcw7Ppc/R0ZAgAABAjsRUMw7RAgQIEBgngJvSON1efrq69j88VjF0jzJtb0OgYfmO3U5ffMS+7qapK6WUMyvA9FXCBAgQGC5Aor55frrnQABAn0X2JoERx/99bW8r5XC675zLwLLEGgek6tjeG3+uKdCfhlTok8CBAgQ2IyAYn4zavYhQIAAgY0I1OPTbjqyQxVMp26kAd8lMEOBU9LWgWPaOyjbXjXDfjRFgAABAgTmKqCYnyuvxgkQIEAgAtsSR49IVCFfhZNLmR0eixa4cjr8dKJ5ef1Ls+3PHJOLng79ESBAgMA0Aor5afTsS4AAAQLrEdiSL53dKKDqefOnr2dn3yEwQ4G65WOfMe39QbbtmGE/miJAgAABAnMXUMzPnVgHBAgQIBCBExJHjEi8I3/fLuHsvMNjEQK/n06OWTkGm2fl98/21zsWFzEN+iBAgACBWQoo5mepqS0CBAgQmCSwWz74UOIyI1+4Zf5+DzICCxB4YPr4uzH91LbHJ85dwBh0QYAAAQIEZiqgmJ8pp8YIECBAYA2Bbfls9N75s/J+74Sz8w6beQrcPo2/OdE8I//ebKurQ74/z861TYAAAQIE5iWgmJ+XrHYJECBAoClQxVTds7x15AP3zjtO5ilQl9d/I3HeRiffzvtdEz+dZ+faJkCAAAEC8xRQzM9TV9sECBAg0BR4UDb8TWPjpVYKLloEZi3wr2lwrzGN/nm2nTTrzrRHgAABAgQWKaCYX6S2vggQIECgzs6/MXGHEYoP5u/bJr6Jh8AMBZ6ftg4b095zs+1hCbd3zBBbUwQIECCweAHF/OLN9UiAAIGhC9wgAHW5/cVGIO6Vv08ZOoz8ZyZwSFo6MdG8T7462D1xzsx60hABAgQIEFiSgGJ+SfC6JUCAwMAFjk/+Dx8xqLOkN0x8eOAu0p9e4Mpp4tMTCvnrZvtHp+9CCwQIECBAYPkCivnlz4ERECBAYIgCN0rSH2gUXG/N+zsmXP48xCNiNjmfP83U6vTNBe+q9VrV/u2Or9lAa4UAAQIEli+gmF/+HBgBAQIEhirQPDtfDndLvH6oIPKeWqBWpx9XyNc6DXVs+aFoamINECBAgEBbBBTzbZkJ4yBAgMDwBOqy+jMSo/c1V7G1Z+K/h8ch4ykF/iP7X2VMGz/PtgsmPIZuSmC7EyBAgEC7BBTz7ZoPoyFAgMDQBJ6dhB/aSLrud75O4idDw5DvpgTq0voq5K8wYe8LZ/sPNtWynQgQIECAQIsFFPMtnhxDI0CAwAAErpEcP55orjq+b7adPoD8pTidQB03ZybGPUu+Wq7F8M6ergt7EyBAgACBdgoo5ts5L0ZFgACBIQnUc78f3Ei4LrevM6o/GhKEXDckcKF8+6zE1SfsVffI173y7pPfEKsvEyBAgEBXBBTzXZkp4yRAgEB/BS6Q1Ooy6ObZ+fdm260UY/2d+CkyO8/KDz3jFrurZp+SONqxM4WwXQkQIECg9QKK+dZPkQESIEBgEALPSJaPHpOpy+0HMf0bTnLSqvXV0OMST1fIb9jUDgQIECDQMQHFfMcmzHAJECDQU4E6K18FWvPsfF0i/bsrn/U0dWltQOD38t1vJiadkX9CPvtrhfwGRH2VAAECBDoroJjv7NQZOAECBHoncMdk9IYxBf1ns60eOebe595N+YYSuna+/aE1CvkH5LO/d5xsyNSXCRAgQKDDAor5Dk+eoRMgQKBnAnW29cdjivlKc5/EO3uWr3TWL3DXfPW1E46NauUuiTcr5NcP6psECBAg0H0BxXz351AGBAgQ6JPA8Unm4WMSqrPy9Tzxn/cpWbmsS+Av8q3nrVHIXzOffVohvy5LXyJAgACBHgko5ns0mVIhQIBADwRqlfKfTCjc3pbtd1C09WCW15/CW/LV265RyNc99N9ff3O+SYAAAQIE+iOgmO/PXMqEAAECfRG4XRL5xwkF3C2z/T19SVQeawq8O5/eYsI3Xp7tB/thxxFEgAABAkMWUMwPefblToAAgfYK1OX0zZXta7R1uf1FE99r79CNbEqBenpBXYVxqwnt1Pb3KuSnVLY7AQIECHReQDHf+SmUAAECBHopcMVk9Z8TCvpvZfslFXO9nPcbJKszEpMePbdnPvtCLzOXFAECBAgQ2KCAYn6DYL5OgAABAgsTeEd62m9Cb1a3X9g0LKyjW6enf57wA85Lsv3QxM8WNhodESBAgACBlgso5ls+QYZHgACBAQvU6vU/nFDc1eX2l058Y8A+fUr9Qknm24lxZ+Trvvl/SdScexEgQIAAAQIrAop5hwIBAgQItFmgnh/+ujUK+vMp8to8fesaWy1qeNqYQr6K+/rBpp5u4EWAAAECBAg0BOOgXukAAA3dSURBVBTzDgkCBAgQaLvApMXwatyPTDxbQd/2KZw4vrvlk6clrtr4xlPzflvCZfWdnVoDJ0CAAIF5Cyjm5y2sfQIECBCYVuAKaeCziXGr21fbuyfOmbYT+y9U4ILp7bDEcWN63TXbvr7Q0eiMAAECBAh0UEAx38FJM2QCBAgMUOD5K8XfuNTrXmqX23froHhxhnvfxg809ez4FyTe061UjJYAAQIECCxHQDG/HHe9EiBAgMDGBOqs/E8bxd9oC6/JmwMTFknbmOuiv32RdHhSoi6vH73S4o15/6eJ7y56QPojQIAAAQJdFVDMd3XmjJsAAQLDE6jL6T+/RkF/w3x21vBYOpPxnTPS1yaaK9b/VbY90Q8xnZlHAyVAgACBlggo5lsyEYZBgAABAusSOCHfOmLCN+usfD3OrhbM82qXwN0znFPH/BBz02z714SF7to1X0ZDgAABAh0QUMx3YJIMkQABAgR+LbCzy+2fk28+IuFy+3YcNLXQ3VGJI8cU8vfMtjpTb67aMVdGQYAAAQIdE1DMd2zCDJcAAQIEdrlZDGqRtEmr27vcvh0HSV1OXwvd3WfMXN06296tkG/HRBkFAQIECHRTQDHfzXkzagIECAxd4MkBeMIEhDrTe6nEN4eOtMT8r5a+P55o3h9fc3L1xFeXODZdEyBAgACBXggo5nsxjZIgQIDA4ATqrPwXErtNyLxWRb9YwiXciz80rp8uzxxTyNcTB+6VcH/84udEjwQIECDQQwHFfA8nVUoECBAYiMCuyfPLiUmX2z8+nz1NQb/Qo6EuqT95zJw8Ndvq3nk/rix0OnRGgAABAn0WUMz3eXblRoAAgf4L1L3X/7xGQb9XPvtQ/xlakeFfZhRPGTMX9di5evycQr4V02QQBAgQINAXAcV8X2ZSHgQIEBiuwHOT+oMnpF9n7uv59ArJ+R0fF0jT/5a4yphC/kYrP6bwn5+/lgkQIEBgoAKK+YFOvLQJECDQI4HzJJefjCkkV1Osx6Idp6Cfy4xfI61+NNFc6K46u95KkT+XjjVKgAABAgSGLqCYH/oRIH8CBAj0Q+A6SePDaxT0N8lnZ/Qj1dZkUU8TeNIY81rg7gqJc1ozUgMhQIAAAQI9FFDM93BSpUSAAIGBChyWvJ8/Ife6zPuiie8N1GaWaddZ+DckbjemkK/tByZ+PMsOtUWAAAECBAj8toBi3lFBgAABAn0RqMvtP5m46oSE6nFpf5TwaLTNz3gV8j9MjLus/tBsPznh/vjN+9qTAAECBAisW0Axv24qXyRAgACBDgjs7HF19ZzzUzqQRxuHWGfcXzahkK/74z+mkG/jtBkTAQIECPRVQDHf15mVFwECBIYrcOOk/i+Jcc+f/+9sr4L+PcPl2XDm9f8VyuumY0w/mG37JNy+sGFWOxAgQIAAgekEFPPT+dmbAAECBNop8KwM62EThlarr18/4XLwnc/d1fOVOuM+7rL6+2f7iRx3jugbBAgQIEBgHgKK+XmoapMAAQIEli1QZ+U/lLjuhIFUIX+bxOnLHmiL+79DxvbGxLgrHC6T7V9XyLd49gyNAAECBHovoJjv/RRLkAABAoMVqPvnX5e4+RoFfa2A/2JF6W8I7ZZ3/5iox/01C/lHZdtzEhYRHOz/rCROgAABAm0RUMy3ZSaMgwABAgTmIXC1NPrkxAFrNP7mfHYXBf0vheq++Hcnxl1Wf+Vs/xyneRym2iRAgAABAhsXUMxv3MweBAgQINAtgTtluPX8+T3WGPbH81ldkj/k++gflPxPSDTPxteZ+Doj72x8t457oyVAgACBngso5ns+wdIjQIAAgV8K7Jd4QGKtM/R/nc+fMMCCvq5eqNsRarG70UJ+R97vm6h/h/wjh/8JESBAgACBVgoo5ls5LQZFgAABAnMQqDP099lJQf/OlcJ/CMVr/X+AIxK18n/zbPxjV7b/ZA7zoEkCBAgQIEBgBgKK+RkgaoIAAQIEOiNQRetzE4evMeJ6dvpNEn0u6C+V/P5m5YeN0UL+M9l2cOKMnuffmQPWQAkQIECAwCQBxbxjgwABAgSGJlDF6/6J4xOT7qN/YT6rle77WNBvSV51BUL9O/o6NG9ek/jO0A4I+RIgQIAAgS4KKOa7OGvGTIAAAQKzEKii/qeJcc9Rr/aflDimRwV9PRv+0YmHreS8+v8BavX6WuDurB7lOovjQxsECBAgQKDVAor5Vk+PwREgQIDAnAWqwD1nQkH/pWyvBfPeN+cxLKL5u6eTVybOP9LZ+/P33yZerohfxBTogwABAgQIzFZAMT9bT60RIECAQPcETsyQ7zth2Kdm+yMSX+xeWr8c8YVXivg75N/RKxDenvcHJb6tkO/ozBo2AQIECAxeQDE/+EMAAAECBAYvUEXuexM3nSDxjmy/XQeL3vtlzC9oFPE/zvsq7Oue+T6uBzD4gxkAAQIECAxHQDE/nLmWKQECBAhMFqhnrX+yUfiOfvtleXNIRwrgvTLOWtzv5o183pX3tfDfNxwIBAgQIECAQPcFFPPdn0MZECBAgMBsBK6dZj6yRkHf9gXxLpux1xn3q47Joa4s2J6oM/NeBAgQIECAQA8EFPM9mEQpECBAgMDMBO6Sll63RkH/nHxW99C36RL1C2Y8j0/85Zhx1z3/RyS+MjMhDREgQIAAAQKtEFDMt2IaDIIAAQIEWiRwSsZy4BrjuW0+qwXklv2qe/0fnHjWmCL+Z9l2x0Td79+mHx6WbaZ/AgQIECDQGwHFfG+mUiIECBAgMCOBKpKrWN93QntVHD8vUc9rX0ahfN70e3TicWOK+BrytsRTE1XQexEgQIAAAQI9FVDM93RipUWAAAECUwlUQX9aYusarTx3wQX9BdJfnYV/4IQivh6fV7cJ1H3/y/iRYSpwOxMgQIAAAQIbE1DMb8zLtwkQIEBgOAKXSapVsB+wRsr3zGdvS3x3zix3Svt1L3+dlR/3qjHW54r4OU+E5gkQIECAQFsEFPNtmQnjIECAAIE2CtQZ+scm6rL1ca8qno9N1CXvsy6k67/RhydOWOm4xtJ8PSYbalE+q9S38egxJgIECBAgMEcBxfwccTVNgAABAr0Q2DNZPDtxtzWy+Zt89tAZFvS3SFunJyadiX9APjsx8YsZ9tmLyZIEAQIECBAYioBifigzLU8CBAgQmEagzoqfnLjPhEbOzfabJT49TSfZt54RX4vvXT4x7kz8wdn+8pU+Zn0lwJRDtzsBAgQIECCwSAHF/CK19UWAAAECXRbYI4N/SuKQCUlUcb1bYjPPdL909quz+/tPKOLrUv5tiR8lFPFdPoqMnQABAgQIzEhAMT8jSM0QIECAwCAE6mx5XU5//IRsX5jth22g4K7L6J+WePiEIv7p2f6ElfYU8YM4xCRJgAABAgTWJ6CYX5+TbxEgQIAAgVWBKuhflPjzCSTPz/Yj1lHQ3zbfeUXiEmPaqefY11UAX11HO2aGAAECBAgQGKCAYn6Aky5lAgQIEJhaoAr6ZybqjHrz9bVsqLP3r1yjlzPy2Q0Tzfviv59t1018ThE/9RxpgAABAgQI9FpAMd/r6ZUcAQIECMxRoArxUxLjnkNfj4qr574/JPH1kTEclb/vl6gF7pqve2TDmxMeMzfHSdM0AQIECBDoi4Bivi8zKQ8CBAgQWIZAFfJV0I9beb7Gc2qi7nu/Q+JWia1jvvsP2VZF/zkJ98UvYxb1SYAAAQIEOiigmO/gpBkyAQIECLRKoAr6ExKXnTCqKtC/k7hY4/PX5H0V8vXvT1qVkcEQIECAAAECrRdQzLd+igyQAAECBDogsC1jPHqd43xpvndW4rkJZ+LXieZrBAgQIECAwG8KKOYdEQQIECBAYHqBusz+fYmb7KSpHfn80MR2hfz06FogQIAAAQJDFlDMD3n25U6AAAECsxS4aBo7NzHp/vnVvuqxdfX4OmflZ6mvLQIECBAgMDABxfzAJly6BAgQIDAXgd9Lq9sSj1xn6/fM92pxPC8CBAgQIECAwKYEFPObYrMTAQIECBD4tcBV8teTE7UQ3s7Oyq/uVGfld0t8hSMBAgQIECBAYDMCivnNqNmHAAECBAj8SuB6iQ8mztsA+W7eX2QnSPvm89NBEiBAgAABAgQ2I6CY34yafQgQIECAwK/ue39gonk2/jPZdvvEixJb14DaM599ASQBAgQIECBAYDMCivnNqNmHAAECBIYusGsAdiQu1IB4bd4/JfGRlSL/xPx7yBis2vdKCYvgDf1Ikj8BAgQIENikgGJ+k3B2I0CAAIFBC/xusv/+SsG+ClHPjz8mUWfmV1911v6oRPMZ9BbAG/ThI3kCBAgQIDC9gGJ+ekMtECBAgMAwBeqs+31XUq/75m+W+NkYiirod088LnGdxBsTxyaclR/mcSNrAgQIECAwEwHF/EwYNUKAAAECAxSoIv1iibr3/aPrKM5H761XyA/wgJEyAQIECBCYpYBifpaa2iJAgAABAgQIECBAgAABAgsQUMwvAFkXBAgQIECAAAECBAgQIEBglgKK+VlqaosAAQIECBAgQIAAAQIECCxAQDG/AGRdECBAgAABAgQIECBAgACBWQoo5mepqS0CBAgQIECAAAECBAgQILAAAcX8ApB1QYAAAQIECBAgQIAAAQIEZimgmJ+lprYIECBAgAABAgQIECBAgMACBBTzC0DWBQECBAgQIECAAAECBAgQmKWAYn6WmtoiQIAAAQIECBAgQIAAAQILEPgf0cnCFZz/XyQAAAAASUVORK5CYII="
        },
        "pemegang_polis": {
            "sign": true,
            "save": true,
            "date": "24/09/2019 16:36:23",
            "location": "Jakarta",
            "signature": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/MAAADYCAYAAACnf7PLAAAgAElEQVR4Xu3dCbh1dV0v8NJLOSY4pnlvb4VDEmnihGK9Ko6EgYWJRuKEQwKKJmYIr6aJmjlLKiqakjmEJk6B+WJ01Zs4pKIB1dt1HjK1FJWr3u/vaZ/aLvc+Z+1z9j57rbU/63l+z3v2Omv4/z//dZTvXtOP/oiJAAECBAgQIECAAAECBAgQ6JXAj/aqtRpLgAABAgQIECBAgAABAgQI/Igw7yAgQIAAAQIECBAgQIAAAQI9ExDmezZgmkuAAAECBAgQIECAAAECBIR5xwABAgQIECBAgAABAgQIEOiZgDDfswHTXAIECBAgQIAAAQIECBAgIMw7BggQIECAAAECBAgQIECAQM8EhPmeDZjmEiBAgAABAgQIECBAgAABYd4xQIAAAQIECBAgQIAAAQIEeiYgzPdswDSXAAECBAgQIECAAAECBAgI844BAgQIECBAgAABAgQIECDQMwFhvmcDprkECBAgQIAAAQIECBAgQECYdwwQIECAAAECBAgQIECAAIGeCQjzPRswzSVAgAABAgQIECBAgAABAsK8Y4AAAQIECBAgQIAAAQIECPRMQJjv2YBpLgECBAgQIECAAAECBAgQEOYdAwQIECBAgAABAgQIECBAoGcCwnzPBkxzCRAgQIAAAQIECBAgQICAMO8YIECAAAECBAgQIECAAAECPRMQ5ns2YJpLgAABAgQIECBAgAABAgSEeccAAQIECBAgQIAAAQIECBDomYAw37MB01wCBAgQIECAAAECBAgQICDMOwYIECBAgAABAgQIECBAgEDPBIT5ng2Y5hIgQIAAAQIECBAgQIAAAWHeMUCAAAECBAgQIECAAAECBHomIMz3bMA0lwABAgQIECBAgAABAgQICPOOAQIECBAgQIAAAQIECBAg0DMBYb5nA6a5BAgQIECAAAECBAgQIEBAmHcMECBAgAABAgQIECBAgACBngkI8z0bMM0lQIAAAQIECBAgQIAAAQLCvGOAAAECBAgQIECAAAECBAj0TECY79mAaS4BAgQIECBAgAABAgQIEBDmHQMECBAgQIAAAQIECBAgQKBnAsJ8zwZMcwkQIECAAAECBAgQIECAgDDvGCBAgAABAgQIECBAgAABAj0TEOZ7NmCaS4AAgY4L7Ez7bpg6IvW3qd2pz6Qu7ni7NY8AAQIECBAg0CsBYb5Xw6WxBAgQ6KzAcWnZsakdqf8x1sr/N/r5wvz73dSTR8H+453tiYYRIECAAAECBHogIMz3YJA0kQABAh0WuGvaVlVBfjzET2vyeLg/a7TQafn3Cx3uo6YRIECAAAECBDonIMx3bkg0iAABAr0RODQtfWVqny22uAL+S1JvStWl+d/c4vasToAAAQIECBAYvIAwP/gh1kECBAgsRODXstU3pNqcjW/bgAr1H0qdnnpZqi7LNxEgQIAAAQIECEwQEOYdFgQIECAwq0A93O7MOQf5ZhsuyIyTUu+YtXGWJ0CAAAECBAisgoAwvwqjrI8ECBCYn8AB2dT71gnyr8nvnpmqB9z9bOp7qRNT109dK1Xrt53qTP05qXum1u61b7uu5QgQIECAAAECgxYQ5gc9vDpHgACBuQs8N1usJ9dPmg7PzLMnBO/xS/Fvm9//aqrO7u9o2boK8vUlwa7UnpbrWIwAAQIECBAgMGgBYX7Qw6tzBAgQmKvAL2RrdU978z758zLvqNRnU23uc19bf78sX18A3C+1b4uWfmUU6uvy+6+3WN4iBAgQIECAAIHBCgjzgx1aHSNAgMDcBR6ULdbD6canPflwSKreI7+ZaS3YH5mVT061CfUfyHJ1dcB7N7ND6xAgQIAAAQIEhiAgzA9hFPWBAAEC2yNQ98HfpLGr38nneq3cPO5pr2D/m6na5oEbdKn2d37qznPa9/YI2gsBAgQIECBAYE4CwvycIG2GAAECAxfYmf7Vw+ial9j/eOZ9Z859r33UpfR3aRHq6+z8sal6+r2JAAECBAgQILAyAsL8ygy1jhIgQGBLApMefPf8bPGE1DzOyjcbt/alQZ2pPy111XVaX/uvs/neTb+lIbYyAQIECBAg0CcBYb5Po6WtBAgQWJ7AX2bXhzZ2/yv5/J5taNI1so+1M/XNy/zHd/+kfHjKgr5c2IZu2gUBAgQIECBAoL2AMN/eypIECBBYVYFfTsfflRq/xL5eQVdPol/EWflJzrXvg1L1zvlHrzMQ9Qq7o7exXat6TOg3AQIECBAgsGQBYX7JA2D3BAgQ6IHAn6eN926086n5vGsJoblCfZ19P3Edt8+Pljkj/36jB76aSIAAAQIECBCYWUCYn5nMCgQIEFgpgb3T239K7dPo9f75/LElSVSgPzhV9+yv9yq7umrgFqmPLKmddkuAAAECBAgQWJiAML8wWhsmQIDAIATumF68MzV+if3787kued+uS+ynQR6RXzwjtWMd6WrjJ1O3T311ECOiEwQIECBAgACBCAjzDgMCBAgQWE+gLqd/QmOB+vzMDoT5atZhqeNTOzcYxgr1p6eOS11myAkQIECAAAECfRcQ5vs+gtpPgACBxQq8Ips/urGLe+XzWYvd7UxbX3sv/Skt1qpQX/fb1yX6Qn0LMIsQIECAAAEC3RQQ5rs5LlpFgACBrghU4B2/xL7atVdq2ZfYT/KpV9OdPAPcIVn2bTMsb1ECBAgQIECAQGcEhPnODIWGECBAoHMCD0yLXtZo1cvz+aEdDfP1pcNNU2embthCc+0LiRtl2XrIn4kAAQIECBAg0BsBYb43Q6WhBAgQ2HaBXdlj89L1O2feudvektl2WKG+Htz31lTzqoJJW1q7n/7Y/LKLVxzM1ntLEyBAgAABAishIMyvxDDrJAECBDYl8KqsdVRjzZ/O5/+7qa1t/0pXzC7rafePbLnrCvLPSf1+6jst17EYAQIECBAgQGApAsL8UtjtlAABAr0QuDitHH+P+558vkGqT2ev68z8jtQnUm3O0tfAVP9ulfpQL0ZJIwkQIECAAIGVFBDmV3LYdZoAAQKtBJoPv9udteoy+z6F+bWO/nh+eEyqXrXXZlrr442z8D+2WcEyBAgQIECAAIHtFBDmt1PbvggQINAfgToDf2Fq/Gz26/P5vj0N8yVfffmx1HNTD245FBXqL0jVk+//teU6FiPQF4EdaWjdUvLwVH1pdVCqrmK5Terjo07syb9Vu/vSKe0kQIDAqggI86sy0vpJgACB2QTqP/LrMvvxMP+QfK73zn93tk11bunq05VTb079SsvWVag/LvXSVB+vTGjZTYsNWGBn+lZve7h1qgL87VL1d17TRregrH2p9e+j/13YnX9fN2ArXSNAgEAvBIT5XgyTRhIgQGDbBeqhcc9v7HUoYX6tWxVgrpSqM+4bhZm1dSrUVAj6P9s+InZIYDaBnaPFj8+/100dMMNxvtGe6u/gktSho383Wt7vCRAgQGABAsL8AlBtkgABAgMQODh9eHvjP/6vl8+fG0Dfml2oIH+P1Btbhp0KMu9MHZZyln6AB0RPu7Qz7b40VZfM17MeKrzX1PaLqs10+5VZqW5Z8XewGT3rECBAYIsCwvwWAa1OgACBgQpUMDinEQTqPvo6GzfUqULPNVOfahmAKsDcPXXuUEH0q9MCO9K6m6d+L/X91C+NWrvZ8P6trH+FVH1hV2fy20yfyULVDmG+jZZlCBAgMGcBYX7OoDZHgACBgQhMesf8zdK3jwykf+t1o8LQzlTzyoRJ61SI2ZO6ReprK2Cji8sRqMC8f6ruea+gfcxYM2YN7/VAx0+m6tg9P1W3mdR2X526XOorqWunLhr9HRzR2N+4QF0FcPpoW8uRsVcCBAissIAwv8KDr+sECBBYR6DCwovHfr8nP/ftHfPzGOA7ZCN/lWoTmOoZA7+fqoeEmQhsVeDAbOCuoyDd9kz5tH3W2faXpP4m9a5NNqxCfd1+s/ZFwuPz87NSzspvEtRqBAgQ2KqAML9VQesTIEBgmAJ1iX39h/vatDs/9PUd81sdoXqd3VGpOgO50fSNLHBs6oxUXfpsItBG4PJZ6G6pn03VGfj6W7t+qs2XSM3t78mMv039VOq01AdTNa+mrQbvZnu2ur02NpYhQIAAgSkCwrxDgwABAgQmCdQltnUmfm16T3640xzCQF+16/LjqqunHpE6ZYOOvDu/f0LqfX3tsHYvXGCf7KFejbgrtd9obxuF9z1Zbu/Uh1P1N1pXgdSD7v4k9fOpF6XqMvm1Sdhe+DDaAQECBJYnIMwvz96eCRAg0FWBOhNdZ5jHg8XZ+Xx4Sjj4T5e9Uo9L7VpnEMuqzpBW8D+vq4OtXdsmUF8G3Sp1x9QTx/6+pgX4Omaulnphqu5r/2hqz5TW1rFW2/H3uW3DaUcECBBYvoAwv/wx0AICBAh0TWDfNOgTY2Gj2ldnmG8vLPzAUFV4unLqYaNwVj9PmipgXZa6Tsr99F072hfXngrvdeb91FQ9dX5tWu/s+4VZqM6yfzn13tSnU3W7xncX10xbJkCAAIG+CgjzfR057SZAgMDiBOpBV2emxkNHnRWsQOLM32T3q2R2nUH97Q2Gpc7Ul289kMw0PIG65/0mqXp45PVm6N4Lsuwfp/55hnUsSoAAAQIrLiDMr/gBoPsECBCYIPC8zKuHuI1Pb8yH+6SE+emHTH358Qups1I71jmy1l5nd88sU1dAmPorUA+uq7PvT0u1Pfteva1L6N+Uqr+rtS92/G319zjQcgIECCxFQJhfCrudEiBAoNMCzSfZV2Pr0t8K+ALHxkNXzxy4TapeAbbeJdVlWdZHpryjfmPXriyxIw2pV7LVlzFr00YPrqvlPpOqAP/s1L+MVvT31JVR1Q4CBAj0UECY7+GgaTIBAgQWLFD3dzfDSZ15PDklfLTHL8NbpOrd3huF+rqN4R6pz7ffvCW3SaDGroL7K1JXGu2zTXivResMfF3p8s7Ut0fr+hvapoGzGwIECAxdQJgf+gjrHwECBGYXmBTm6xL7P599U9aIQD35/jmpeqXdelOFvL9M/WZK4FvuoVNPkT8p9aixZrQN8PW8idNT9SVOTcZyuWNp7wQIEBisgDA/2KHVMQIECGxaYFKYv3O2du6mt2jFCoL1NPsKiPX0+/WmCn91JcSTBcFtPXDqv4melPq90V7bhvda/K9SD0h9cbSuAL+tQ2dnBAgQWE0BYX41x12vCRAgsJ7ApDBfT+j2sLatHzdrAbHuld/ZItSfkGVeklq7RHvrLbCFcYGfyYffStUtJDXNEuAfnOVfn/qmAO+gIkCAAIFlCAjzy1C3TwIECHRbYFKY3ydN/mq3m92r1lVovHrqLalbbdDyOst7VOp1qe/1qpfdbGw9oPD3U08YNW+WAP/rWaduhajJ+9+7Ob5aRYAAgZUREOZXZqh1lAABAq0ELpel6ixwM+DsnXmeuN6KcKaFZnlIXm24npJ/wUx7sHAJ1JUlZ6R+acTRNsDXAwmPTtWbCWpy+bzjiQABAgQ6IyDMd2YoNIQAAQKdEKizxV9INcNOnc2sM/amxQiU90Gpuvx+oyffn59lDkmtXd69mBb1f6v1DvgnpuosfE1tA3zdTlKX3v/9aD0Bvv/Hgh4QIEBgkALC/CCHVacIECCwaYH/lTX/cULwqSeyCzWbZm29YgXO/VIf2CB81ljU2eJ66NrnWm99+AvW7SD3Sj0kdcAMAb6+IHl86v0C/PAPEj0kQIDAUASE+aGMpH4QIEBgPgI/n83UGcnmWUxhfj6+bbdS3ndNndUi1N87y7wttaoPyasz8LdLvTz10zME+HoH/ENT9eVVTb6sant0Wo4AAQIEOiEgzHdiGDSCAAECnRH4xbSk7skW5rsxJDUOdUn9G9YJqWsh9C5ZpgLqKjwkr77suHvqmFR96VFTm8von5fl/iR18WgdAb4bx7lWECBAgMAmBIT5TaBZhQABAgMWEOa7ObhXTrPqDHydfZ42VTB9RuqPUv/WzW5sqVV1Bv6XUw9M3We0pTYB/tQs+yoBfkv2ViZAgACBDgoI8x0cFE0iQIDAEgVcZr9E/A12Xf+fXYH2canfSV1vyvKXZH7dM767u12ZuWX1QLrjUvU0+o0C/DeyzCdTD099aLQnZ+BnJrcCAQIECHRdQJjv+ghpHwECBLZX4MbZ3UcnBCb3zG/vOKy3t7Uwe0IWOjFVbyBoThVeK8hW8N/dnabP3JJ6KN0jUtedcEw2N3Z2Zpw8On7rdwL8zNxWIECAAIE+CQjzfRotbSVAgMDiBXZkF3U/sXvmF2+91T2sjdH9sqE6E18PgWtOFWjrIXovSu3e6g63cf3Ds6/np+rqg2n/rVK3EtQyb0p9LPX9lAC/jYNkVwQIECCwXAFhfrn+9k6AAIGuCdTTwOsybWG+ayOzfntqvE5KVbDfd8Kia6H+vh0OvHU//GGpI1I/OeEYrG79Q6peH/es1IWjfgrw/TpWtZYAAQIE5iQgzM8J0mYIECAwEIG9048vCfO9HM21L2AendbX/eXXnxLqK/RXIN7dkV7+RNrxZ6l6Gn/zS6QvZN4nUq9OvTd1kQDfkVHTDAIECBBYuoAwv/Qh0AACBAh0SuAaac3nhflOjcmsjalAXMH44FQF+0lTvX7wSam3zLrxOS5/q2yrriSoe+LHQ/zXR+16d/6t++D/NVWX0H93jvu2KQIECBAg0HsBYb73Q6gDBAgQmKtAvQLtq41wVTu4Qurbc92TjS1a4GrZQb1q8NmpAybsrC5Pr8vVX5D69KIb09j+mflcl9OPh/i6WqDmvz5VV4cI8Ns8KHZHgAABAv0SEOb7NV5aS4AAgUULXCk7+FojZNU+hflFyy9u+2v3058yZRcV6ute+vek6rL2RU07s+F6pd7NUuP39Z+Xz69IvWa0Y/fAL2oEbJcAAQIEBiUgzA9qOHWGAAECWxao95h/K9W8d/mKo/lb3oENLEWgxrPOzp+aqlDdnNYC9PH5xUtS8wzUtb+jU3VJ/dpxVWfe/yp1Rmp3qi6hrzPxJgIECBAgQKClgDDfEspiBAgQWBGBehhZ3aPcDPPXyrwvr4jBkLtZ43pQ6pwJY7zW7w/mh7rUvc6Wb/ZM/f5Z9w6punf/rmP7qtfk1T3xdS98vVJunl8aDHnc9I0AAQIECPyQgDDvoCBAgACBpkCFrauOzbw0P1fIF7yGc6z8VLry0tTd1+lSjfdjUy9P/XvLrt9oFN7/MP/W8xfqXfD7pN6Rqofu1X3xb3cstdS0GAECBAgQWEdAmHd4ECBAgEBT4HOZUe/5Xps+mx/q/fPC/LCOlTpLf4/Ub6XqYXTTphr3I1NvWGeZW+R3J6bqPfHjV3VUcK8z/btG6zqGhnUM6Q0BAgQILFFAmF8ivl0TIECgowIVvMYflrY7n++cEsQ6OmBbbFaF70emTk7VWfRJU419vQv+aal673tN9bT8upT+halrp8ZDfN0P/xep+gKgHqjo2NniIFmdAAECBAg0BYR5xwQBAgQINAWemxnHjc3cnZ+F+WEfJxXE62qMx6fqifPTpgrlH0u9NvWU0ULjIb6eTF/r/8Pod0L8sI8bvSNAgACBJQoI80vEt2sCBAh0VKAejnZwo20V5s/taHs1a34CFczvlHpy6lYzbLZeK3dC6ispAX4GOIsSIECAAIHNCgjzm5WzHgECBIYrcEy69uJG926Qz5cMt8t61hCoUF9n2J/TQqYuqT9EiG8hZRECBAgQIDBHAWF+jpg2RYAAgYEI3D79+OvU+OXT18vnejCeaTUE6qn0J6Xq4Xhtpjob/6hUvaP+sjYrWIYAAQIECBDYmoAwvzU/axMgQGCIAjvSqYtT42G+nlL+5iF2Vp9+QKCeav+q0diPj38t9B+pq2zgVaG+vgx6H1cCBAgQIEBgsQLC/GJ9bZ0AAQJ9FajX0V13rPF1yXWddXU/dF9HdHq768F3T0399miRZoj/08w/NXVR6jqpPanmMuNbXztGbp2Z9Vo6EwECBAgQILAAAWF+Aag2SYAAgQEI1KXS44Ftdz57ov0ABnasC/vl57NSPzMlnNeVGHXp/KdT41/i1HFx/9TpG3DUOl8fbb/+NREgQIAAAQJzFBDm54hpUwQIEBiQwK70Zfxd86/M5wc3Qt2AursyXfmJ9PTI1AtGPW6eYf9e5j80VeP9/XXG+3L5XVVtp5Zfb6pQ/8epP0jVpfomAgQIECBAYA4CwvwcEG2CAAECAxTYlT6Nh/m6xL4utXeZfT8He59R8L53/p10ifznM/9uqY+nKsR/t2U3a1tXTL0otdHD8urYOTb1spSH5LUEthgBAgQIEJgmIMw7NggQIEBgksAjMvOFY7/Yk5/r9XTCfL+Ol19Lc1+RumpqUog/P/OPSjUvpZ+1l7Xta4y2s9799LXdOoYOTp03604sT4AAAQIECPy3gDDvaCBAgACBSQI7M/OcsQD48vxcl1ML890/Xur/2++XqhBf06RwXU+tf9Po9/Mc09rXbVPvmrLfNb3a5xtS9aXRv3WfVAsJECBAgED3BIT57o2JFhEgQKALAjvSiObr6eqBaRd2oXHaMFGg7od/Quoxqfr/98tPWKpeMfjW1DwD/KTGVKi/Weq9qY2efF9P0q9y6b0DmwABAgQIzCAgzM+AZVECBAiskMAV0tevpX5s1Oe6j7rujf72Chn0pas3SkNfmjpwSnCuh9RVyL90G0J806yOn7oX/40bhPrv5Pf3StUXDSYCBAgQIECghYAw3wLJIgQIEFhBgeulz//SCGB3z+d3rKBFV7t87TRsV+ohU4Ly4zK/gnyd8V70mfiNjOrs/DGp8ecwNNepNn4gdZ/RsbfRNv2eAAECBAistIAwv9LDr/MECBCYKnD1/OYLjZD4yHx+cQeC4aoP276jUHzHCSG+nkJfX7q8e4S07BA/PlYV6PdK3SlV77efdvl9tfl1qXqXfZfav+rHnf4TIECAQMcEhPmODYjmECBAoCMCdXn0NxqBq+5r3iVgLW2E6kz8aam6HL05fSkzbpXas7TWzb7jE7PKqeusVk/Yr1B/8uhYnH0P1iBAgAABAgMWEOYHPLi6RoAAgS0ITArzf5/tHZBytnQLsJtY9aCs84zULVPNs9lvybzjU5/q4bisnan/87T9V1PT/pukjrenpZ7cwz5uYritQoAAAQIE2gkI8+2cLEWAAIFVFKh7rZvhsS6TFuYXfzSU801TZ6Z+ZsI4vCjznpj6+gDGo46xfVLPT/3mOrR13P166u0pT75f/DFoDwQIECDQcQFhvuMDpHkECBBYooAwvxz8Cu9/kpp0T/wDMv+1owA/tC9VKtRfK/XmVF2FMGla6/Pv5pf1cL+hGSzniLNXAgQIEOilgDDfy2HTaAIECGyLgDC/Lcz/tZO75KcHpurs8/gVEV/M53oyfV2OXmNSD7kb8lR93z91Xuqq63S0gvw9UucMGUPfCBAgQIDANAFh3rFBgAABAtMEhPntOTZunt1UkP+DRoivvddr2uod7RXgv789zenMXirUPz11wgaBvn796NRLUvW+ehMBAgQIEFgJAWF+JYZZJwkQILApgUlh/srZ0jc3tTUrNQUOyYw6E3/P1PiZ+DrjfFyq7pf/99T3VphuzaXup3/YBg7ldrPUx1fYS9cJECBAYIUEhPkVGmxdJUCAwIwCk8L8DbONi2fcjsV/UODgfDx2FOLHf/O1fKh7wV+duhTaDwnslznPSZXfRlNd7fChjRbyewIECBAg0GcBYb7Po6ftBAgQWKzApDD/G9llXfZtml3gJlnlsalfSI0/4K1e+VdnnT+WqhDvoW7TbetM/c+l/nfq6usMQRm+J3VYqq5uMBEgQIAAgcEJCPODG1IdIkCAwNwEJoX5eqd5vRZN4GzPvCOLnph6cKrCaN37Xv//+5HUfVN1pYNXrbX3rCXLsb4U+bvRz9PWruO03gxQ99Q7ZmcztjQBAgQIdFxAmO/4AGkeAQIEligwKcz/Wdrz24JRq1HZO0udknpUY+l6N/ytUxelVvl++FaILRb66SxzyQahvjZzYOp9LbZnEQIECBAg0AsBYb4Xw6SRBAgQWIrApDBfDxerh4w5yzl9SOq5ArtSR0wImIdm3vtTX1rKiA53p3Wm/u6pv1gn1NcxW19G1fMK6vkEJgIECBAg0GsBYb7Xw6fxBAgQWKjApDBf9x/XvcrC/A/T1zvR6xaEep3c+NPpa8mTU/XqtC8sdMRsvNwfmXr2OhR17NaVER/ERYAAAQIE+iwgzPd59LSdAAECixX4bDZ/3Qm72EuY/wGV+nKj3hF/zIQQ/6rM+8PUPzJb7ME6tvUK9FdL/WXqtlP2WoH+rFS9AvDz29YyOyJAgAABAnMUEObniGlTBAgQGJjAu9OfnRP6JMz/J8qNU3Um/vap5pn4ujf7Aam6l9tVDMv5w6gxuVHqzal6Av6k6YuZeYvUp5bTRHslQIAAAQKbFxDmN29nTQIECAxdoC4Lf8iETq56mL9mTN6W+qUJIf68zKvXz31YiO/Mn0eF+julzp4wXtXItbP09WYBX7x0Ztg0hAABAgQ2EhDmNxLyewIECKyuwOPS9acL8/8lcJVRILzdlFBYT/mvB6wJhN38m7lGmvXA1DOmNK/Grc7S1ysDTQQIECBAoPMCwnznh0gDCRAgsDSBQ7LnN00Irqt2Zv7aMTgjVU9LnzRViD8z9d2ljZQdzyJweBa+d+o3Jhzbdf98fSFTX2T5UmYWVcsSIECAwLYLCPPbTm6HBAgQ6I3A/mlpPfG7eT/4qoT5K6Xvz0vdf4JBDeL9Uq8T+npzPI83tI7pk1J3S9WT7ZvT2zOjzuDv7mXvNJoAAQIEVkJAmF+JYdZJAgQIbEqgXrX2lQlB9oqZ961NbbE/K52Ypj5lQt+rBx9PHZz6csrZ2/6MabOla19SnZ5f1Bc2zanG9qmj48A493ectZwAAQKDFRDmBzu0OkaAAIEtC1TYuXRCoHClhtkAAA/NSURBVK0HwP3rlrfezQ0ckWbV6+SuMKF51ee6p/rTQnw3B2+TrarjvC69f2HqWhO28crMq8vu68n3JgIECBAg0BkBYb4zQ6EhBAgQ6KTAZWlV8zL7AzKvLr8f0nSbdKZexVd9bfa3+nnn1O6UM7RDGvUf7EuN+/mpSZfd15sd6mn4bxlu9/WMAAECBPomIMz3bcS0lwABAtsrMCnM14Px6tVsQ5j2HvXlllNC/NGZ/xohfghD3aoPFeifm6orNJpn6V+feRXqz221JQsRIECAAIEFCwjzCwa2eQIECPRcYFKYPyp9enXP+1XNf2bqUVNC/Esz/zGpb6Y8pX4Agz1DF9Yejlf30e9orFe3WNTxv3uG7VmUAAECBAgsRECYXwirjRIgQGAwAp9LT36y0Zsn5/MfpPp6yXk9vK4ul550X/xHM/+Oqa/2uH+DOfiW2JEK9HVrxR+lbtJoRx33h6bescT22TUBAgQIEPgRYd5BQIAAAQLrCXwkv/zFxgLPyeff7WHYvVza/NZUhflJ98UfNvp9X7+kcCTPX+Cm2eSLU8376OsYuW+qLr03ESBAgACBpQgI80tht1MCBAj0RuCUtHRXo7X1tPcH9SjM75W2PjZVVxRMCvHHjwLbt3szKhq6nQJ1zJyV+tXGTivQ199H/T3U5fcmAgQIECCwrQLC/LZy2xkBAgR6J1BPef+bRgg+M5/rfuI+nMGuh/W9aUqIf3Pm3yf1rd6NigYvQ+CY7LTO0jen52fGCT35e1iGm30SIECAwIIEhPkFwdosAQIEBiJQT/T+bCMM1xO9f6cH4aXOmB45Jcjvl/kX9aAPAzmMBtGNy6cX90rVl1nNKzx2Z96jU/+QunQQvdUJAgQIEOi8gDDf+SHSQAIECCxVYGf2fk4jvFRwqYeDdfXM/EGjNk96wF2dWa0n2Dsbv9TDqtc7r/voPzAh0NffQ73W7vEd/tvoNbzGEyBAgMAPCgjzjggCBAgQ2Ejg3VmgQv3a9PL88NAOBpabp03vTNW745tnTuup/PunvtbBdm/k7/fdE6jj64JU8+GQ1dL3pW7vOOveoGkRAQIEhiYgzA9tRPWHAAEC8xdoPtH+7Ozi8A6FlXrAXV32X++Nn/SAu7o0utp82fxpbHGFBepYq4cq/t4EgzpL/9TUUzr0d7LCQ6XrBAgQGKaAMD/McdUrAgQIzFOgGea/lI1fryMhpR7Q97bUPhM6XO8Ir6eNf3OeGLZFYEygAv3DU8+bolKh/jWpF6b+jhwBAgQIEJingDA/T03bIkCAwDAF6p75ejf7+FRnw5d5z3w9mO/YVJ0VbZ6NrwffPSb11SW3cZhHg141Ber4u0HqXanrTuGpv5WXpR7pmHQAESBAgMC8BIT5eUnaDgECBIYr0LUw/7BQnzaF+46ZX/f4mwgsQ2DS38paO+qhiz+bquc3mAgQIECAwJYFhPktE9oAAQIEBi8w6f3at0yv64ne2znVpf1PS9031Twbf1Lm1fu+v76dDbIvAg2BOi4PTD199O/4r4V5hwsBAgQIzFVAmJ8rp40RIEBgkAI70quLGwG6Liu+ZJt6e83s596peu1XM8S/NvPqIWP1fu9lXva/TRR20xOBeoZD3ZryjFT9/dRUl9nXVSWO054MomYSIECg6wLCfNdHSPsIECCwfIEKI80w/4DMO2PBTbt6tn9Yqp4KXoF+PMjXpcoPSdWr6ISjBQ+EzW9a4H9mzTulPpb6sGN1045WJECAAIEJAsK8w4IAAQIE2ghUmN93bMFX5ucHLyicXCXbvUeqngI+6VVzf5r59Z77S9s03DIECBAgQIAAgSEKCPNDHFV9IkCAwPwFzsgm77/gMH/9bP/oVL1OrqbxIP/9fH5v6pDUf6ScjZ//GNsiAQIECBAg0CMBYb5Hg6WpBAgQWKLArrGQvdaMed43f2Q2Wq+Um3Qmvvb3u6nnCPFLPALsmgABAgQIEOiUgDDfqeHQGAIECHRW4K5p2dmNsF1P7X7fFlv8qKz/zNE2pgX52ne9bu6yLe7L6gQIECBAgACBwQgI84MZSh0hQIDAQgVumK1/vBHmX5DPj07Nesl7hfbjUvX6rmkBvjpzXuo+qc8vtGc2ToAAAQIECBDooYAw38NB02QCBAgsQeA62eenJ4TvvWYI87Xsk1OP3SDEV/cemTo99e0l9NUuCRAgQIAAAQKdFxDmOz9EGkiAAIHOCNRl7s0z6f8r8z7VooW/kWVenfrxFsvW5fsfmOFLghabtAgBAgQIECBAYFgCwvywxlNvCBAgsEiBSWH+EdnhS9cJ3r+W37129CXAepfUV7svSB2aqnfImwgQIECAAAECBNYREOYdHgQIECDQVmBSmK91J11qf93M/6eWIb62UU+yr3fHf6ttYyxHgAABAgQIEFhlAWF+lUdf3wkQIDCbwCVZ/OcmrDIe5uvnv07dZhTk2+zhplnowtSsD9Jrs23LECBAgAABAgQGKSDMD3JYdYoAAQILETgxWz11wpYPyLwPpvZNfTR1hZZ7/3KWq3vuL225vMUIECBAgAABAgRGAsK8Q4EAAQIE2grcOguen2re+/7OzNsndfMJv5u27XqlXb3aztn4tvqWI0CAAAECBAiMCQjzDgcCBAgQaCtQ/5/xnRkC+6Tt1ln4ulT/S4J8W3bLESBAgAABAgR+WECYd1QQIECAwCwC0x6C12Yb9e74FwvxbagsQ4AAAQIECBBYX0CYd4QQIECAwCwCmw3zdV/93wvys1BblgABAgQIECAwXUCYd3QQIECAwCwCp2fhB82yQpa9Ysor52ZEszgBAgQIECBAYD0BYd7xQYAAAQJtBR6cBU9LNR+AN239Q/OLd6Q85K6tsOUIECBAgAABAi0FhPmWUBYjQIDACgtcLX2vp9jfeIYgv3eW/doKm+k6AQIECBAgQGChAsL8QnltnAABAr0XuHp68JlU23fHPzXLPiXlsvreD70OECBAgAABAl0WEOa7PDraRoAAgeUK3Da7f9cMQb5a6/745Y6ZvRMgQIAAAQIrIiDMr8hA6yYBAgRmFHhilj851fb++LXN75MfvjrjvixOgAABAgQIECAwo4AwPyOYxQkQIDBwgbov/q2pHanLbaKvR2WdV29iPasQIECAAAECBAjMICDMz4BlUQIECAxcoMJ7vQt+vy308+Kse5OUJ9hvAdGqBAgQIECAAIGNBIT5jYT8ngABAqsj8KJ09eEtuvuJLHNk6gOpSZfh7yXMt1C0CAECBAgQIEBgCwLC/BbwrEqAAIEBCexMX86ZEs7Hu/n4fHjWKKxfNmX5G2X+RQOy0RUCBAgQIECAQOcEhPnODYkGESBAYNsFDs8eX9ciyN9jFPjXLqH/Qj5fe0Jrj8+8OsvvUvttH0o7JECAAAECBFZFQJhflZHWTwIECEwWODCz39MiyE96Sv09s94bJ6z7yczbX5h3yBEgQIAAAQIEFicgzC/O1pYJECDQB4G6tP7gKQ39UuY/L/WS1BcnLHP5zPvWhDD/lcy7jjDfh+HXRgIECBAgQKCvAsJ8X0dOuwkQILB1gRdmE8dMCOO15fumzk392wah/K/z+ztMaMqdR+tvvZW2QIAAAQIECBAg8EMCwryDggABAqspUJfN19n25tPoP5x5j0j93QYhfk3t2fnhURMIX5V5D2q5jdUcAb0mQIAAAQIECGxBQJjfAp5VCRAg0GOBS9P2KzTaf14+3y1Vl863na6fBf855RV1bcUsR4AAAQIECBCYg4AwPwdEmyBAgEDPBOry+jr7Pj6dlQ91af0sQb7W35ma9kq7J+V3T0l5qn3PDhDNJUCAAAECBLovIMx3f4y0kAABAvMUOCkbOyU1fia9HnT30FQF+lmna2aFzzW2t7aNC/LDbYT5WUktT4AAAQIECBDYWECY39jIEgQIEBiKwK3TkfMnBO+nZt6uLYTuekf9EVOQPAhvKEePfhAgQIAAAQKdEhDmOzUcGkOAAIGFClycre/b2MPL87nOym/lUvh6Iv6Lp7T8NZl/9Ba3v1AUGydAgAABAgQI9FFAmO/jqGkzAQIEZheoM/K3a6xWD7yrd8xvJcjXJmsbb09Neghe/X6vOexj9h5bgwABAgQIECAwYAFhfsCDq2sECBAYCZyQf5/eCNsX5vMBqVkfeDcJ9Scy829SvzhF/JmZ/wSB3vFIgAABAgQIEJifgDA/P0tbIkCAQFcFTk3DThxr3Gn5+dGpb8+xwbXNh03ZXr27/pbC/By1bYoAAQIECBBYeQFhfuUPAQAECKyAwHXSx7rMvu6X35Oqh9JdMud+78z2pr2irnZVT7V//5z3aXMECBAgQIAAgZUVEOZXduh1nACBFROo+9krcO9ObfUe+Wl078kvbj/lly/I/LoaYFH7XrHh1F0CBAgQIEBg1QWE+VU/AvSfAAEC8xM4LJt6fWrSg/DqyoA7CPPzw7YlAgQIECBAYLUFhPnVHn+9J0CAwDwF6nL+T08J8xdl/n7C/Dy5bYsAAQIECBBYZQFhfpVHX98JECAwf4Fd2eQpEzZ7QebVffMus5+/uS0SIECAAAECKyggzK/goOsyAQIEFihQl9ifmTpiwj7qwXvnLnDfNk2AAAECBAgQWBkBYX5lhlpHCRAgsG0CO0aB/sDGHo/P5xelnJ3ftqGwIwIECBAgQGCoAsL8UEdWvwgQILBcgbtk929NjT8M78J8vqkwv9yBsXcCBAgQIEBgGALC/DDGUS8IECDQRYEz0qj7Nxq2lzDfxaHSJgIECBAgQKBvAsJ830ZMewkQINAfgbunqa9MXWusyWfn58MF+v4MopYSIECAAAEC3RQQ5rs5LlpFgACBoQjsSkfGn26/J59vIMwPZXj1gwABAgQIEFiWgDC/LHn7JUCAwGoIVHCve+XH751/Vj4/XqBfjQNALwkQIECAAIHFCAjzi3G1VQIECBD4b4Fd+XH87Pwf5/OJwrxDhAABAgQIECCweQFhfvN21iRAgACBdgLXzGLvTe2b2pM6KPWZdqtaigABAgQIECBAYJKAMO+4IECAAIHtEKjL7Hemdqe8Z347xO2DAAECBAgQGLSAMD/o4dU5AgQIECBAgAABAgQIEBiigDA/xFHVJwIECBAgQIAAAQIECBAYtIAwP+jh1TkCBAgQIECAAAECBAgQGKKAMD/EUdUnAgQIECBAgAABAgQIEBi0gDA/6OHVOQIECBAgQIAAAQIECBAYooAwP8RR1ScCBAgQIECAAAECBAgQGLSAMD/o4dU5AgQIECBAgAABAgQIEBiigDA/xFHVJwIECBAgQIAAAQIECBAYtIAwP+jh1TkCBAgQIECAAAECBAgQGKKAMD/EUdUnAgQIECBAgAABAgQIEBi0gDA/6OHVOQIECBAgQIAAAQIECBAYosD/B80hHySbt6YKAAAAAElFTkSuQmCC"
        },
        "tertanggung_utama": {
            "sign": false,
            "save": false,
            "location": "",
            "date": "",
            "signature": ""
        },
        "tambahan_satu": {
            "sign": false,
            "save": false,
            "location": "",
            "date": "",
            "signature": ""
        },
        "tambahan_dua": {
            "sign": false,
            "save": false,
            "location": "",
            "date": "",
            "signature": ""
        },
        "payor": {
            "sign": false,
            "save": false,
            "location": "",
            "date": "",
            "signature": ""
        }
    }
    return _data;
}

const occupationList = [{
        "nameEng": "Beekeeper",
        "code": "BEEK",
        "gender": "All",
        "nameInd": "Peternak lebah",
        "minAge": "0",
        "descriptionInd": "Seseorang yang merawat lebah-lebah madu",
        "descriptionEng": "A person who keeps honey bees",
        "clazz": "3",
        "$$hashKey": "object:4408"
    },
    {
        "nameEng": "Sheep shearer",
        "code": "SHSH",
        "gender": "All",
        "nameInd": "Pencukur bulu domba",
        "minAge": "0",
        "descriptionInd": "seorang pekerja yang menggunakan pisau atau mesin cukur untuk mencabut wol dari domba",
        "descriptionEng": "a worker who uses-blade or machine shears to remove wool from domestic sheep",
        "clazz": "3",
        "$$hashKey": "object:4116"
    },
    {
        "nameEng": "Shepherd",
        "code": "SHEP",
        "gender": "All",
        "nameInd": "Gembala",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggembalakan, memberi makan, atau melindungi kawanan domba",
        "descriptionEng": "a person who herds, feeds, or guards herds of sheep.",
        "clazz": "3",
        "$$hashKey": "object:3513"
    },
    {
        "nameEng": "Inseminator",
        "code": "INSE",
        "gender": "All",
        "nameInd": "Pelaku inseminasi ternak",
        "minAge": "0",
        "descriptionInd": "seorang teknisi yang sudah menyiapkan air mani untuk dimasukkan ke alat kelamin binatang pada masa pembiakan",
        "descriptionEng": "a technician who introduces prepared semen into the genital tract of breeding animals",
        "clazz": "2",
        "$$hashKey": "object:3913"
    },
    {
        "nameEng": "Milker Dairy Farmer",
        "code": "DAIR",
        "gender": "All",
        "nameInd": "Pemerah susu",
        "minAge": "0",
        "descriptionInd": "Seseorang yang terlibat dalam bidang pertanian atau peternakan untuk memproduksi susu jangka panjang, biasanya susu dapat berasal dari sapi perah atau dari kambing,domba,maupun unta; untuk kemudian dikirim atau diolah lebih lanjut di pabrik susu hingga akhirnya dijual secara eceran.",
        "descriptionEng": "Dairy farmer is person engaged in agricultural, or an animal husbandry, enterprise, for long-term production of milk, usually from dairy cows but also from goats, sheep and camels, which may be either processed on-site or transported to a dairy factory for processing and eventual retail sale.",
        "clazz": "2",
        "$$hashKey": "object:4054"
    },
    {
        "nameEng": "Poultry worker / Hatchery worker / Poultry worker (food and drink production)",
        "code": "POUL",
        "gender": "All",
        "nameInd": "Pekerja unggas / Pekerja penetasan / Pekerja unggas (produksi makanan dan minuman)",
        "minAge": "0",
        "descriptionInd": "pekerja yang memastikan keselamatan dan keefisiensian operasi dari peternakan unggas",
        "descriptionEng": "a worker who ensures the safety and efficiency of poultry farm operations",
        "clazz": "2",
        "$$hashKey": "object:3910"
    },
    {
        "nameEng": "Stock worker",
        "code": "STOC",
        "gender": "All",
        "nameInd": "Buruh stok",
        "minAge": "0",
        "descriptionInd": "seseorang yang memindahkan produk dari gudang ke toko",
        "descriptionEng": "someone who moves products from the warehouse to store shelves",
        "clazz": "3",
        "$$hashKey": "object:3462"
    },
    {
        "nameEng": "Crofter",
        "code": "CROF",
        "gender": "All",
        "nameInd": "Tukang kebun di area tertutup",
        "minAge": "0",
        "descriptionInd": "seseorang yang memiliki lahan kecil",
        "descriptionEng": "a person who farms a croft.",
        "clazz": "3",
        "$$hashKey": "object:4678"
    },
    {
        "nameEng": "Orchard worker",
        "code": "ORCH",
        "gender": "All",
        "nameInd": "Pekerja kebun",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di pertanian",
        "descriptionEng": "a person who works in farms",
        "clazz": "3",
        "$$hashKey": "object:3869"
    },
    {
        "nameEng": "Agricultural engineer",
        "code": "AGEN",
        "gender": "All",
        "nameInd": "Insinyur pertanian",
        "minAge": "0",
        "descriptionInd": "seorang insinyur yang menggabungkan teknologi dengan pertanian",
        "descriptionEng": "an engineer who integrates technology with farming",
        "clazz": "3",
        "$$hashKey": "object:3552"
    },
    {
        "nameEng": "Agricultural machinery engineer",
        "code": "AGME",
        "gender": "All",
        "nameInd": "Insinyur mesin pertanian",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat mesin untuk kebutuhan pertanian",
        "descriptionEng": "a person who builds machine for farming",
        "clazz": "3",
        "$$hashKey": "object:3544"
    },
    {
        "nameEng": "Agricultural worker / farm hand",
        "code": "AGWF",
        "gender": "All",
        "nameInd": "Pekerja pertanian / Pekerja kebun",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di bidang pertanian",
        "descriptionEng": "a person who works in agriculture",
        "clazz": "3",
        "$$hashKey": "object:3896"
    },
    {
        "nameEng": "Farm worker",
        "code": "FAWO",
        "gender": "All",
        "nameInd": "Peternak",
        "minAge": "0",
        "descriptionInd": "Keluarga yang menjalankan kegiatan industri agrikultural berskala besar. Tergantung pada lokasi dan jenis dari perkebunan, pekerjaan dapat musiman atau permanen.",
        "descriptionEng": "A farmworker is a person working in the agricultural production industry. This work occurs on farms of all sizes, from small, family-run businesses to large industrial agriculture operations. Depending on the location and type of farm, the work may be seasonal or permanent.",
        "clazz": "3",
        "$$hashKey": "object:4405"
    },
    {
        "nameEng": "Plantation Worker",
        "code": "PLTW",
        "gender": "All",
        "nameInd": "Pekerja Perkebunan",
        "minAge": "0",
        "descriptionInd": "pekerjaannya berupa menanam dan memtik katun atau lainnya",
        "descriptionEng": "Their jobs were to plant and pick cotton/others.",
        "clazz": "3",
        "$$hashKey": "object:3895"
    },
    {
        "nameEng": "Agricultural foreman",
        "code": "AGFO",
        "gender": "All",
        "nameInd": "Mandor pertanian",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi bidang pertanian",
        "descriptionEng": "someone who supervises in agricultural",
        "clazz": "3",
        "$$hashKey": "object:3720"
    },
    {
        "nameEng": "Farm Manager",
        "code": "FAMA",
        "gender": "All",
        "nameInd": "Pengelola Peternakan",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab atas kondisi keuangan dan fisik dari perkebunan dan memiliki keahlian yang tinggi dalam semua segi usaha perkebunan.",
        "descriptionEng": "People who has responsible for the financial and physical performance of the farm and highly skilled in all aspects of the farm business.",
        "clazz": "2",
        "$$hashKey": "object:4178"
    },
    {
        "nameEng": "Agricultural labourer",
        "code": "AGLA",
        "gender": "All",
        "nameInd": "Buruh tani",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja tanpa keahlian",
        "descriptionEng": "a person doing unskilled manual work",
        "clazz": "3",
        "$$hashKey": "object:3463"
    },
    {
        "nameEng": "Agricultural scientist",
        "code": "AGRI",
        "gender": "All",
        "nameInd": "Peneliti pertanian",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempelajari tumbuhan komersial, binatang, dan teknik kultivasi untuk memperkuat produktivitas lahan dan industri pertanian",
        "descriptionEng": "Studies commercial plants, animals and cultivation techniques to enhance the productivity of farms and agricultural industries.",
        "clazz": "2",
        "$$hashKey": "object:4132"
    },
    {
        "nameEng": "Tractor driver",
        "code": "TRDR",
        "gender": "All",
        "nameInd": "Pengemudi traktor",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudi traktor",
        "descriptionEng": "someone who drives tractor",
        "clazz": "3",
        "$$hashKey": "object:4220"
    },
    {
        "nameEng": "Agricultural miller",
        "code": "AGMI",
        "gender": "All",
        "nameInd": "Penggilingan pertanian",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggiling lahan pertanian",
        "descriptionEng": "someone who mills farm",
        "clazz": "3",
        "$$hashKey": "object:4232"
    },
    {
        "nameEng": "Veterinarian / veterinary assistant",
        "code": "VETE",
        "gender": "All",
        "nameInd": "Dokter hewan / Asisten dokter hewan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempraktekkan obat hewan",
        "descriptionEng": "A person who practices veterinary medicine.",
        "clazz": "2",
        "$$hashKey": "object:3489"
    },
    {
        "nameEng": "Veterinary surgeon",
        "code": "VTSU",
        "gender": "All",
        "nameInd": "Dokter bedah hewan",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan pembedahan pada binatang",
        "descriptionEng": "a person who performs surgery on animals",
        "clazz": "2",
        "$$hashKey": "object:3487"
    },
    {
        "nameEng": "Westelyman",
        "code": "WSTE",
        "gender": "All",
        "nameInd": "Westelyman",
        "minAge": "0",
        "descriptionInd": "Westelyman",
        "descriptionEng": "Westelyman",
        "clazz": "2",
        "$$hashKey": "object:4720"
    },
    {
        "nameEng": "Zookeeper",
        "code": "ZOOK",
        "gender": "All",
        "nameInd": "Penjaga kebun binatang",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga dan memelihara kebersihan dan kesehatan binatang di kebun binatang",
        "descriptionEng": "A person who guards and maintain the hygiene and health of the animal in the zoo.",
        "clazz": "3",
        "$$hashKey": "object:4306"
    },
    {
        "nameEng": "Zoo curator",
        "code": "ZOOC",
        "gender": "All",
        "nameInd": "Kurator kebun binatang",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan perawatan binatang secara langsung",
        "descriptionEng": "a person who sometimes performs direct animal care activities",
        "clazz": "3",
        "$$hashKey": "object:3657"
    },
    {
        "nameEng": "Animal conservation officer",
        "code": "ANCS",
        "gender": "All",
        "nameInd": "Petugas konservasi hewan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu untuk mengkonservasi hewan",
        "descriptionEng": "a person who helps to conserve animal",
        "clazz": "3",
        "$$hashKey": "object:4440"
    },
    {
        "nameEng": "Head zookeeper",
        "code": "ZOOH",
        "gender": "All",
        "nameInd": "Kepala petugas kebun binatang",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur binatang yang disimpan dalam penangkaran untuk konservasi atau ditampilkan di depan umum",
        "descriptionEng": "a person who manages zoo animals that are kept in captivity for conservation or to be displayed to the public.",
        "clazz": "2",
        "$$hashKey": "object:3613"
    },
    {
        "nameEng": "Canine beautician",
        "code": "CANB",
        "gender": "All",
        "nameInd": "Ahli kecantikan anjing",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat anjing",
        "descriptionEng": "a person grooms dog",
        "clazz": "2",
        "$$hashKey": "object:3350"
    },
    {
        "nameEng": "Dog breeder / Kennel owner",
        "code": "DOGB",
        "gender": "All",
        "nameInd": "Peternak anjing / Pemilik kandang",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan perkawinan pada anjing yang terpilih dengan niatan untuk menjaga atau memproduksi kualitas atau karakteristik tertentu",
        "descriptionEng": "a person who practices mating selected dogs with the intent to maintain or produce specific qualities and characteristics",
        "clazz": "2",
        "$$hashKey": "object:4406"
    },
    {
        "nameEng": "Animal nursing auxiliary",
        "code": "ANNS",
        "gender": "All",
        "nameInd": "Pelengkap perawatan hewan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga kebutuhan kelengkapan hewan",
        "descriptionEng": "a person who keeps stock on the auxiliary",
        "clazz": "2",
        "$$hashKey": "object:3942"
    },
    {
        "nameEng": "Silversmith (arts and crafts)",
        "code": "SILV",
        "gender": "All",
        "nameInd": "Pandai perak (seni dan kerajinan tangan)",
        "minAge": "0",
        "descriptionInd": "seorang pengrajin yang membuat benda terbuat dari perak",
        "descriptionEng": "a craftsman who crafts objects from silver.",
        "clazz": "3",
        "$$hashKey": "object:3829"
    },
    {
        "nameEng": "Horse breeder",
        "code": "HRSB",
        "gender": "All",
        "nameInd": "Peternak kuda",
        "minAge": "0",
        "descriptionInd": "seseorang  yang terlibat dalam reproduksi kuda, lebih tepatnya proses turun tangannya manusia dari binatang yang sedang pembiakan",
        "descriptionEng": "a person who involves in the reproduction of horses, and particularly the human-directed process of selective breeding of animals,",
        "clazz": "2",
        "$$hashKey": "object:4407"
    },
    {
        "nameEng": "Animal controller / Kennel assistant",
        "code": "ANCT",
        "gender": "All",
        "nameInd": "Pengontrol hewan / Asisten kandang",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengontrol binatang",
        "descriptionEng": "a person who controls animals",
        "clazz": "3",
        "$$hashKey": "object:4247"
    },
    {
        "nameEng": "Groom",
        "code": "GROM",
        "gender": "All",
        "nameInd": "Perawat kuda",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat kuda",
        "descriptionEng": "someone who takes care of horses",
        "clazz": "3",
        "$$hashKey": "object:4391"
    },
    {
        "nameEng": "Stablehand",
        "code": "STHN",
        "gender": "All",
        "nameInd": "Pengurus istal",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di istal",
        "descriptionEng": "someone who works on stable",
        "clazz": "3",
        "$$hashKey": "object:4275"
    },
    {
        "nameEng": "Auctioneer",
        "code": "AUCT",
        "gender": "All",
        "nameInd": "Tukang lelang",
        "minAge": "0",
        "descriptionInd": "seseorang yang melaksanakan penjualan dengan cara lelang",
        "descriptionEng": "a person who conducts sales by auction",
        "clazz": "1",
        "$$hashKey": "object:4684"
    },
    {
        "nameEng": "Curator / Museum curator / Art gallery curator / Commercial art gallery manager",
        "code": "CURT",
        "gender": "All",
        "nameInd": "Kepala museum / Kepala museum / Kepala galeri seni / Manajer galeri seni komersial",
        "minAge": "0",
        "descriptionInd": "pegawai kurator",
        "descriptionEng": "Curator/ Curator employees",
        "clazz": "2",
        "$$hashKey": "object:3605"
    },
    {
        "nameEng": "Ceramicist",
        "code": "CRMS",
        "gender": "All",
        "nameInd": "Ahli keramik",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat keramik",
        "descriptionEng": "A person who makes ceramics",
        "clazz": "2",
        "$$hashKey": "object:3352"
    },
    {
        "nameEng": "Museum attendant / Historic building guide / Art gallery attendant / Art gallery guide",
        "code": "MUSG",
        "gender": "All",
        "nameInd": "Penjaga museum / Pemandu bangunan bersejarah / Penjaga galeri seni / Pemandu galeri seni",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga galeri di sebuah museum untuk alasan keamanan, membantu pengunjung museum, dan terkadang membantu kurator dalam memindahkan atau mengganti tatanan galeri",
        "descriptionEng": "someone who looks after a gallery in a museum for security reasons, to help museum visitors, and sometimes to help curators in moving objects or changing the gallery displays",
        "clazz": "2",
        "$$hashKey": "object:4312"
    },
    {
        "nameEng": "Photographic finisher / photographic mounter",
        "code": "PHOF",
        "gender": "All",
        "nameInd": "Finisher fotografi / Penajam fotografi",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyelesaikan fotografi",
        "descriptionEng": "someone who finishes photographic",
        "clazz": "2",
        "$$hashKey": "object:3510"
    },
    {
        "nameEng": "Wicker worker",
        "code": "WIWO",
        "gender": "All",
        "nameInd": "Pembuat anyaman",
        "minAge": "0",
        "descriptionInd": "seseorang yang menganyam",
        "descriptionEng": "someone who wicker",
        "clazz": "2",
        "$$hashKey": "object:4005"
    },
    {
        "nameEng": "Draughtsman",
        "code": "DRAU",
        "gender": "All",
        "nameInd": "Perancang",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat sebuah gambaran  (teknikal atau sebaliknya)",
        "descriptionEng": "Draughtsman is a person who makes a drawing (technical or otherwise).",
        "clazz": "2",
        "$$hashKey": "object:4382"
    },
    {
        "nameEng": "Graphic designer",
        "code": "GRPD",
        "gender": "All",
        "nameInd": "Perancang grafis",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja dari desain yang sudah disetujui, perancang grafis membuat solusi inovatif untuk mengkomunikasikan suatu masalah yang menggabungkan tulisan dan elemen visual",
        "descriptionEng": "a person whose working from agreed design briefs, graphic designers produce innovative solutions to communication problems that combine both written and visual elements.",
        "clazz": "1",
        "$$hashKey": "object:4387"
    },
    {
        "nameEng": "Draftperson",
        "code": "DRAF",
        "gender": "All",
        "nameInd": "Perancang Gambar",
        "minAge": "0",
        "descriptionInd": "Pembuat rancangan adalah orang yang bekerja membuat suatu gambar rancangan (teknik atau lainnya).",
        "descriptionEng": "Draftsperson is a person who makes a drawing (technical or otherwise).",
        "clazz": "2",
        "$$hashKey": "object:4386"
    },
    {
        "nameEng": "F A graphic artist",
        "code": "FAGA",
        "gender": "All",
        "nameInd": "Grafis Desainer",
        "minAge": "0",
        "descriptionInd": "Seniman Grafis adalah seorang profesional dalam desain grafis dan industri seni grafis yang mengemas gambar, typography atau gambar gerak untuk menciptakan suatu desain. Seniman grafis menciptakan suatu grafis khususnya untuk dipublikasikan  di media cetak atau elektronik seperti brosur dan iklan.",
        "descriptionEng": "F A graphic artist is a professional within the graphic design and graphic arts industry who assembles together images, typography or motion graphics to create a piece of design. F A graphic artist creates the graphics primarily for published, printed or electronic media, such as brochures (sometimes) and advertising.",
        "clazz": "2",
        "$$hashKey": "object:3515"
    },
    {
        "nameEng": "Layout artist",
        "code": "LAYO",
        "gender": "All",
        "nameInd": "Desainer Tata Ruang",
        "minAge": "0",
        "descriptionInd": "Orang yang bertugas membuat desain untuk memenuhi kebutuhan komersial atau promosi khusus, seperti kemasan, display, atau logo. Dapat menggunakan berbagai media untuk mencapai efek artistik atau dekoratif.",
        "descriptionEng": "Design or create graphics to meet specific commercial or promotional needs, such as packaging, displays, or logos. May use a variety of mediums to achieve artistic or decorative effects.",
        "clazz": "2",
        "$$hashKey": "object:3476"
    },
    {
        "nameEng": "Designer",
        "code": "DSGN",
        "gender": "All",
        "nameInd": "Desainer",
        "minAge": "0",
        "descriptionInd": "seseorang yang merencanakan bentuk, tampang, atau pekerjaannya sebelum dibangun",
        "descriptionEng": "a person who plans the form, look, or workings of something before its being made or built",
        "clazz": "1",
        "$$hashKey": "object:3473"
    },
    {
        "nameEng": "Antique dealer / Ancient and Art Dealer",
        "code": "ANCI",
        "gender": "All",
        "nameInd": "Dealer barang antik/seni dan Kuno",
        "minAge": "0",
        "descriptionInd": "Orang yang menghubungkan antara penjual barang antik atau seni dengan pembeli, mencapai kesepakatan di antara mereka dan mendapatkan komisi atas usahanya.",
        "descriptionEng": "A person who communicates between the an article/art seller & buyer thus settles a deal and is paid commission for it.",
        "clazz": "2",
        "$$hashKey": "object:3466"
    },
    {
        "nameEng": "Photographer",
        "code": "PGRA",
        "gender": "All",
        "nameInd": "Fotografer",
        "minAge": "0",
        "descriptionInd": "mengambil foto orang, objek, dan tempat dalam bentuk film atau digital menggunakan kamera",
        "descriptionEng": "Capture images of people, objects and places on film or in digital form using a camera.",
        "clazz": "2",
        "$$hashKey": "object:3511"
    },
    {
        "nameEng": "Photo assistant",
        "code": "PHAS",
        "gender": "All",
        "nameInd": "Asisten Fotographer",
        "minAge": "0",
        "descriptionInd": "Bertugas membantu seorang fotografer baik dalam studio atau di lokasi pemotretan, bukan hanya bertugas dalam membantu pemotretan tapi juga membantu tugas sehari-hari dalam menjalankan studio. Melakukan pengisian dan memproses film, mengatur pencahayaan, membaca meter dan suhu warna serta lampu untuk pemotretan. Kebanyakan adalah pekerja paruh waktu, namun ada juga pekerja tetap terutama yang bekerja untuk fotografer ternama atau studio yang ramai di pasaran.",
        "descriptionEng": "Are assisting a studio or location photographer, not just helping out on shoots but also carrying out the mundane day-to-day running of the studio. would be loading and processing film, setting up lights, doing meter reading, and color temperature readings, shooting lighting. The photo assistant is most often employed on a freelance basis, but in some instances photo assistants are full time employees primarily in major markets and with big name photographers.",
        "clazz": "1",
        "$$hashKey": "object:3425"
    },
    {
        "nameEng": "Photo room technician",
        "code": "PTRM",
        "gender": "All",
        "nameInd": "Teknisi ruang foto",
        "minAge": "0",
        "descriptionInd": "Mengoperasikan proses foto untuk menghasilkan film yang nantinya akan dilakukan pencetakan.",
        "descriptionEng": "Operates a photo-mechanical process camera to produce film intermediates to be used in making offset printing plates.",
        "clazz": "2",
        "$$hashKey": "object:4637"
    },
    {
        "nameEng": "Taxidermist",
        "code": "TAXD",
        "gender": "All",
        "nameInd": "Ahli taksidermi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempersiapkan kulit dari binatang yang sudah mati dan mengisinya dengan bahan khusus agar membuatnya terlihat seakan-akan hidup",
        "descriptionEng": "a person who prepares the skins of dead animals and fill them with a special material to make them look as if they are alive.",
        "clazz": "2",
        "$$hashKey": "object:3377"
    },
    {
        "nameEng": "Candle maker",
        "code": "CAND",
        "gender": "All",
        "nameInd": "Pembuat lilin",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat lilin",
        "descriptionEng": "a person who makes candles",
        "clazz": "3",
        "$$hashKey": "object:4019"
    },
    {
        "nameEng": "Jewellery maker / Jewellery repairer",
        "code": "JEWR",
        "gender": "All",
        "nameInd": "Pembuat permata / Tukang perbaikan permata",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat dan memperbaiki perhiasaan",
        "descriptionEng": "a person who makes and repairs jewellery",
        "clazz": "3",
        "$$hashKey": "object:4031"
    },
    {
        "nameEng": "Antique restorer",
        "code": "ANTQ",
        "gender": "All",
        "nameInd": "Tukang perbaikan barang antik",
        "minAge": "0",
        "descriptionInd": "seseorang yang memulihkan barang antik",
        "descriptionEng": "a person who restores antique stuff",
        "clazz": "3",
        "$$hashKey": "object:4691"
    },
    {
        "nameEng": "Hand decorator",
        "code": "HNDD",
        "gender": "All",
        "nameInd": "Dekorator tangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan dekorasi dengan tangan",
        "descriptionEng": "someone who decorates stuff with the hand",
        "clazz": "3",
        "$$hashKey": "object:3469"
    },
    {
        "nameEng": "Screwman",
        "code": "SCRW",
        "gender": "All",
        "nameInd": "Tukang sekrup",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyekrup",
        "descriptionEng": "someone who screws",
        "clazz": "3",
        "$$hashKey": "object:4700"
    },
    {
        "nameEng": "Wood carver (arts and crafts)",
        "code": "WOOD",
        "gender": "All",
        "nameInd": "Pengukir kayu (seni dan kerajinan tangan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengukir seni kayu",
        "descriptionEng": "a person who carves wood",
        "clazz": "3",
        "$$hashKey": "object:4270"
    },
    {
        "nameEng": "Piano tuner",
        "code": "PINO",
        "gender": "All",
        "nameInd": "Penyetem piano",
        "minAge": "0",
        "descriptionInd": "Untuk menstem / mengatur nada di piano di perusahaan swasta atau publik dengan menggunakan garputala dan palu tunning",
        "descriptionEng": "Is to Tunes pianos in private and public establishments, using tuning fork and tuning hammer.",
        "clazz": "2",
        "$$hashKey": "object:4360"
    },
    {
        "nameEng": "Playwright",
        "code": "PLYW",
        "gender": "All",
        "nameInd": "Dramawan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis naskah drama",
        "descriptionEng": "a person who writes plays",
        "clazz": "2",
        "$$hashKey": "object:3493"
    },
    {
        "nameEng": "Model / artist's model",
        "code": "MODL",
        "gender": "All",
        "nameInd": "Model / Model seniman",
        "minAge": "0",
        "descriptionInd": "\"1) Pakaian model, seperti gaun, mantel, pakaian dalam, pakaian renang, dan pakaian, untuk desainer garmen, PEMBELI, dan pelanggan. 2) Berdiri, berputar, dan berjalan untuk menunjukkan fitur, seperti kualitas garmen, gaya, dan desain, kepada pengamat di acara fashion, pertunjukan pribadi, dan perusahaan ritel. \"",
        "descriptionEng": "1) Models garments, such as dresses, coats, underclothing, swimwear, and suits, for garment designers, BUYERS, and customers. 2) Stands, turns, and walks to demonstrate features, such as garment quality, style, and design, to observers at fashion shows, private showings, and retail establishments.",
        "clazz": "2",
        "$$hashKey": "object:3740"
    },
    {
        "nameEng": "Painting restorer",
        "code": "PNTR",
        "gender": "All",
        "nameInd": "Pemulihan pengecatan",
        "minAge": "0",
        "descriptionInd": "seseorang yang memulihkan pengecatan",
        "descriptionEng": "a person who restorers painting",
        "clazz": "2",
        "$$hashKey": "object:4090"
    },
    {
        "nameEng": "Westleyman",
        "code": "WSTL",
        "gender": "All",
        "nameInd": "Westleyman",
        "minAge": "0",
        "descriptionInd": "Westleyman",
        "descriptionEng": "Westleyman",
        "clazz": "2",
        "$$hashKey": "object:4721"
    },
    {
        "nameEng": "Creative engraver / Engraver / Creative etcher / Etcher",
        "code": "CREG",
        "gender": "All",
        "nameInd": "Pengukir kreatif / Pengukir / Pengikis kreatif / Pengikis",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengukir",
        "descriptionEng": "someone who engraves",
        "clazz": "2",
        "$$hashKey": "object:4271"
    },
    {
        "nameEng": "Poet",
        "code": "POET",
        "gender": "All",
        "nameInd": "Penyair",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis puisi",
        "descriptionEng": "a person who writes poems",
        "clazz": "2",
        "$$hashKey": "object:4354"
    },
    {
        "nameEng": "Sculptor",
        "code": "SCUL",
        "gender": "All",
        "nameInd": "Pemahat",
        "minAge": "0",
        "descriptionInd": "seorang seniman yang memahat patung",
        "descriptionEng": "an artist who makes sculptures",
        "clazz": "2",
        "$$hashKey": "object:3945"
    },
    {
        "nameEng": "Artist / Commercial artist / Freelance painter",
        "code": "ARTS",
        "gender": "All",
        "nameInd": "Seniman / Seniman komersial / Pelukis purnawaktu",
        "minAge": "0",
        "descriptionInd": "Orang yang terlibat dalam satu atau lebih kegiatan yang berkaitan dengan seni.",
        "descriptionEng": "An artist is a person engaged in one or more of any of a broad spectrum of activities related to creating art, practicing the arts, and/or demonstrating an art.",
        "clazz": "3",
        "$$hashKey": "object:4545"
    },
    {
        "nameEng": "Cartoonist",
        "code": "TOON",
        "gender": "All",
        "nameInd": "Kartunis",
        "minAge": "0",
        "descriptionInd": "seorang seniman visual yang ahli di bidang menggambar kartun",
        "descriptionEng": "a visual artist who specializes in drawing cartoons.",
        "clazz": "2",
        "$$hashKey": "object:3594"
    },
    {
        "nameEng": "Batek painter",
        "code": "BTPN",
        "gender": "All",
        "nameInd": "Pembatik",
        "minAge": "0",
        "descriptionInd": "seniman yang membuat seni batik",
        "descriptionEng": "an artist who paints  batek",
        "clazz": "3",
        "$$hashKey": "object:3989"
    },
    {
        "nameEng": "Calligrapher",
        "code": "CGRA",
        "gender": "All",
        "nameInd": "Ahli kaligrafi",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan seni kaligrafi",
        "descriptionEng": "one who practices the art of�calligraphy.",
        "clazz": "2",
        "$$hashKey": "object:3347"
    },
    {
        "nameEng": "Fortune teller",
        "code": "FRTL",
        "gender": "All",
        "nameInd": "Peramal",
        "minAge": "0",
        "descriptionInd": "seseorang yang memprediksi informasi tentang kehidupan pribadi seseorang",
        "descriptionEng": "one who practices on predicting information about a person's life",
        "clazz": "3",
        "$$hashKey": "object:4381"
    },
    {
        "nameEng": "Asbestos assembler / Asbestos stripper / Asbestos lagger",
        "code": "ASBS",
        "gender": "All",
        "nameInd": "Perakit asbes / Pembongkar asbes / Pemasang isolasi asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan pemasangan, perakitan asbestos",
        "descriptionEng": "one who assembles asbestos",
        "clazz": "3",
        "$$hashKey": "object:4375"
    },
    {
        "nameEng": "Asbestos cleaner",
        "code": "ASBC",
        "gender": "All",
        "nameInd": "Pembersih asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang membersihkan asbes",
        "descriptionEng": "one who cleans asbestos",
        "clazz": "3",
        "$$hashKey": "object:3999"
    },
    {
        "nameEng": "Asbestos driller",
        "code": "ASBD",
        "gender": "All",
        "nameInd": "Pengebor asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengebor asbes",
        "descriptionEng": "one who drillls asbestos",
        "clazz": "3",
        "$$hashKey": "object:4170"
    },
    {
        "nameEng": "Asbestos foreman",
        "code": "ASBF",
        "gender": "All",
        "nameInd": "Mandor asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi asbes",
        "descriptionEng": "someone who supervises asbes",
        "clazz": "3",
        "$$hashKey": "object:3713"
    },
    {
        "nameEng": "Asbestos inspector",
        "code": "ASNP",
        "gender": "All",
        "nameInd": "Pengawas asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang memeriksa asbes",
        "descriptionEng": "someone who inspects asbes",
        "clazz": "3",
        "$$hashKey": "object:4153"
    },
    {
        "nameEng": "Asbestos insulator",
        "code": "ASNS",
        "gender": "All",
        "nameInd": "Pemasang isolasi asbes",
        "minAge": "0",
        "descriptionInd": "sesesorang yang memasang isolasi asbes",
        "descriptionEng": "someone who installs asbes insulator",
        "clazz": "3",
        "$$hashKey": "object:3960"
    },
    {
        "nameEng": "Asbestos labourer / asbestos worker",
        "code": "ASBT",
        "gender": "All",
        "nameInd": "Buruh asbes / Pekerja asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk asbes",
        "descriptionEng": "someone who works for asbes",
        "clazz": "3",
        "$$hashKey": "object:3457"
    },
    {
        "nameEng": "Asbestos machine operator",
        "code": "ASMO",
        "gender": "All",
        "nameInd": "Operator mesin asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin asbes",
        "descriptionEng": "someone who operates asbes machine",
        "clazz": "3",
        "$$hashKey": "object:3787"
    },
    {
        "nameEng": "Asbestos packer",
        "code": "ASPK",
        "gender": "All",
        "nameInd": "Pengepak asbes",
        "minAge": "0",
        "descriptionInd": "Membungkus asbestos shingles atau mengocok ke dalam bundel untuk pengiriman: meletakkan asbestos shingles atau menggoyangkan dalam jig dengan ujung kecil yang terjalin untuk membentuk bundel. Menghasilkan herpes zoster atau menggoyangkanuntuk memastikan jumlah yang ditentukan.",
        "descriptionEng": "Packs asbestos shingles or shakes into bundles for shipment: Lays asbestos shingles or shakes in jig with small ends interwoven to form bundle. Counts shingles or shakes to ensure specified quantities.",
        "clazz": "3",
        "$$hashKey": "object:4222"
    },
    {
        "nameEng": "Asbestos process worker",
        "code": "ASPW",
        "gender": "All",
        "nameInd": "Pekerja proses asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang memproses asbes",
        "descriptionEng": "someone who processes asbes",
        "clazz": "3",
        "$$hashKey": "object:3899"
    },
    {
        "nameEng": "Asbestos tester",
        "code": "ASTE",
        "gender": "All",
        "nameInd": "Penguji asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji asbes",
        "descriptionEng": "someone who tests asbes",
        "clazz": "3",
        "$$hashKey": "object:4260"
    },
    {
        "nameEng": "Asbestos works manager",
        "code": "ASWM",
        "gender": "All",
        "nameInd": "Manajer pekerjaan asbes",
        "minAge": "0",
        "descriptionInd": "seseorang yang memegang kendali asbes",
        "descriptionEng": "someone who is in charge in asbes",
        "clazz": "2",
        "$$hashKey": "object:3689"
    },
    {
        "nameEng": "Administrative manager / Administrative assistant / Administrator / Office administrator / Director Office manager / Personal assistant / Personnel manager / Press officer / Public relations officer",
        "code": "ADMO",
        "gender": "All",
        "nameInd": "Manajer administratif / Asisten administrasi / Administrator / Administrator kantor / Direktur / Manajer kantor / Asisten pribadi / Manajer personalia / Staf pres / Staf hubungan masyarakat",
        "minAge": "0",
        "descriptionInd": "mereka yang terlibat dalam melaksanakan pekerjaan dan tanggung jawab",
        "descriptionEng": "people involved in carrying out�duties�and responsibilities",
        "clazz": "1",
        "$$hashKey": "object:3669"
    },
    {
        "nameEng": "Human resources manager / HR manager",
        "code": "HROF",
        "gender": "All",
        "nameInd": "Manajer bagian personalia / Manajer HR",
        "minAge": "0",
        "descriptionInd": "Yaitu orang yang bertugas mengelola sumber daya manusia  di suatu organisasi.",
        "descriptionEng": "Human resource officer is person who works in the management of an organization's workforce, or human resources.",
        "clazz": "1",
        "$$hashKey": "object:3671"
    },
    {
        "nameEng": "Manager (Admin)",
        "code": "MGR",
        "gender": "All",
        "nameInd": "Manajer (Admin)",
        "minAge": "0",
        "descriptionInd": "Mengatur dan memfasilitasi fungsi efisien dari kantor melalui berbagai tugas administratif, keuangan dan manajerial.",
        "descriptionEng": "Manage and Facilitating the efficient functioning of an office via a range of administrative, clecial, financial and managerial tasks.",
        "clazz": "1",
        "$$hashKey": "object:3667"
    },
    {
        "nameEng": "Stenographer",
        "code": "STNO",
        "gender": "All",
        "nameInd": "Stenografer",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam mencatat berdasarkan dikte dengan cepat",
        "descriptionEng": "a person who specializes in taking dictation in shorthand.",
        "clazz": "1",
        "$$hashKey": "object:4591"
    },
    {
        "nameEng": "Advertising executive/Advertising officer",
        "code": "ADEX",
        "gender": "All",
        "nameInd": "Staf Perusahaan Periklanan",
        "minAge": "0",
        "descriptionInd": "Orang yang membantu manajer komunikasi dalam mencapai tujuan dan strategi komunikasi perusahaan.",
        "descriptionEng": "To support the Communications Manager in achieving the company's communication strategy and objectives.",
        "clazz": "2",
        "$$hashKey": "object:4578"
    },
    {
        "nameEng": "Recruitment consultant",
        "code": "RECC",
        "gender": "All",
        "nameInd": "Konsultan perekrutan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bertanggung jawab untuk menarik kandidat untuk pekerjaan dan mencocokkan mereka ke posisi sementara atau tetap dengan perusahaan klien tersebut",
        "descriptionEng": "are responsible for attracting candidates for jobs and matching them to temporary or permanent positions with client companies.�",
        "clazz": "1",
        "$$hashKey": "object:3642"
    },
    {
        "nameEng": "Public Relations Executive",
        "code": "PREX",
        "gender": "All",
        "nameInd": "Eksekutif hubungan masyarakat",
        "minAge": "0",
        "descriptionInd": "Petugas Relasi publik menggunakan berbagai media untuk membangun dan mempertahankan hubungan yang baik antara organisasi yang mempekerjakan dan kliennya melalui kampanye publisitas dan aktivitas relasi publik lainnya. Mengelola penyebaran informasi dan komunikasi. Tipikal dari Kegiatannya seperti:merencanakan, mengembangkan dan menerapkan strategi relasi publik, penghubung dengan kolega dengan juru bicara , penghubung  dan menjawab pertanyaan dari media, individu dan organisasi lainnya, seringkali melalui telepon dan email, selain itu juga meneliti, menulis dan mendistribusikan siaran press media yang ditargetkan, menyusun dan menganalisis liputan media, menulis dan mengedit majalah di rumah, studi kasus, pidato, artikel dan laporan tahunan, menyiapkan dan mengawasi produksi brosur yang akan dipublikasikan, handout, surat selebaran, video promosi, foto, film dan program multimedia, mengorganisir acara termasuk konferensi pers, pameran, hari terbuka dan kunjungan untuk para pers.",
        "descriptionEng": "Public relations officers use a wide range of media to build and sustain good relationships between the employing organisation and its clients throughplanned publicity campaigns and PR activities.the practice of managing the spread of information and communications. Typical wokr activities: planning, developing  and implementing PR stategies, liaising with colleagues and key spokespeople, liaising with and answering enquiries from media, individuals and other organisation, often via telephone and email, researching, writing and distributing presss releases to targeted media, collating and analysing media coverage, writing and editing in-house magazines, case studies, speeches, articles and annual reports, preparing and supervising the production of publicity brochures, handouts, direct mail leaflet, promotional videos, photographs, films and multimedia programmes, organising events including press conferences, exhibitions, open days and press tours.",
        "clazz": "2",
        "$$hashKey": "object:3503"
    },
    {
        "nameEng": "Secretary  / Secretary - blue collar industries",
        "code": "SECB",
        "gender": "All",
        "nameInd": "Sekretaris (Industri Pabrik)",
        "minAge": "0",
        "descriptionInd": "dinamakan pekerja kerah biru karena mereka cenderung mengenakan pakaian tidak terlalu mahal, kokoh yang tidak terlalu kotor, seperti denim biru atau baju chambray",
        "descriptionEng": "Blue-collar workers are so named because they tended to wear sturdy, inexpensive clothing that didn't show dirt easily, such as blue denim or chambray shirts.",
        "clazz": "2",
        "$$hashKey": "object:4542"
    },
    {
        "nameEng": "Data entry clerk",
        "code": "DECL",
        "gender": "All",
        "nameInd": "Staf Data Entry",
        "minAge": "0",
        "descriptionInd": "Biasa disebut juga sebagai Juru Ketik, yaitu seseorang anggota staf yang dipekerjakan untuk mengetik data kedalam database dengan menggunakan mesin ketik, scanner optik atau perekam data.",
        "descriptionEng": "A data entry clerk, sometimes called a typist, is a member of staff employed to type data into a database using a keyboard, optical scanner, or data recorder.",
        "clazz": "1",
        "$$hashKey": "object:4556"
    },
    {
        "nameEng": "Information system officer",
        "code": "INFO",
        "gender": "All",
        "nameInd": "Staff Informasi Perusahaan",
        "minAge": "0",
        "descriptionInd": "Petugas informasi yang bertugas mengatur pengadaan  dan distribusi informasi untuk suatu organisasi atau klien dalam mendukung kebutuhan dan tujuan mereka, bekerja dengan informasi elektronik, terutama database online, sistem content manajemen dan internet.",
        "descriptionEng": "Information officers manage and develop the procurement, supply and distribution of information for an organisation or client in support of their needs and objectives. They work with electronic information, especially online databases, content management systems and internet resources, as well as traditional library materials.",
        "clazz": "1",
        "$$hashKey": "object:4582"
    },
    {
        "nameEng": "Module administrator (clerical)",
        "code": "MOAD",
        "gender": "All",
        "nameInd": "Petugas Administrasi Modul (Admin)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang tugasnya mengelola, membuat keputusan untuk suatu jadwal atau program studi.",
        "descriptionEng": "A person whose job is to manages and decide schedules or a course of study.",
        "clazz": "1",
        "$$hashKey": "object:4413"
    },
    {
        "nameEng": "Scanner assistant",
        "code": "SCAN",
        "gender": "All",
        "nameInd": "Pemindai Dokumen",
        "minAge": "0",
        "descriptionInd": "Orang yang bertugas dalam hal administrasi untuk proses pemindaian dokumen di perusahaan. Membantu dalam bentuk data fisik maupun konversi data elektronik.",
        "descriptionEng": "Provide scanning and administration assistance throught out the company. Assist with client request for both physical data and electronic data conversion.",
        "clazz": "2",
        "$$hashKey": "object:4071"
    },
    {
        "nameEng": "Supervisor (Admin)",
        "code": "SPVR",
        "gender": "All",
        "nameInd": "Supervisor (Admin)",
        "minAge": "0",
        "descriptionInd": "Orang yang memegang posisi manajemen di kantor, melakukan studi khusus dan berdasarkan studi khusus tersebut mereka membuat dan mengembangkan laporan. Juga memberikan masukan kepada manajemen dalam mengembangkan kebijakan dan prosedur.",
        "descriptionEng": "People that hold office management positions conduct special studies and based on the results of these special studies, they develop reports. Apart from developing reports, they also provide input to management on the development of policies and procedure.",
        "clazz": "1",
        "$$hashKey": "object:4592"
    },
    {
        "nameEng": "Claims adjuster  / Claims assessor  / Insurance assessor  / Loss adjuster / Underwriter",
        "code": "UNDA",
        "gender": "All",
        "nameInd": "Analisis klaim / Penilai klaim / Penilai asuransi / Analisis kerugian / Petugas seleksi risiko",
        "minAge": "0",
        "descriptionInd": "seseorang yang menilai kerugian pada pendafataran seorang pemohon untuk perlindungan atau sebuah kebijakan",
        "descriptionEng": "A person who assesses the risk of enrolling an applicant for coverage or a policy.",
        "clazz": "1",
        "$$hashKey": "object:3401"
    },
    {
        "nameEng": "Claim assistant",
        "code": "CLMA",
        "gender": "All",
        "nameInd": "Asisten Bagian Klaim",
        "minAge": "0",
        "descriptionInd": "asisten klaim adalah seorang profesional administrasi yang membantu klaim adjuster, penilai, pemeriksa atau penyidik.",
        "descriptionEng": "Claims assistant is an administrative professional who supports claims adjusters, appraisers, examiners or investigators.",
        "clazz": "1",
        "$$hashKey": "object:3418"
    },
    {
        "nameEng": "Reinsurance executive",
        "code": "REIN",
        "gender": "All",
        "nameInd": "Staff Reasuransi",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja mengevaluasi resiko calon nasabah. Bertugas memutuskan berapa besar pertanggungan yang didapat oleh nasabah dan berapa besar mereka harus membayar premi, atau apakah resiko tersebut akan diterima dan ditanggung. Pada kasus ini klien adalah perusahaan asuransi.",
        "descriptionEng": "A person who evaluate the risk and exposures of potential clients. They decide how much coverage the client should receive, how much they should pay for it, or whether even to accept the risk and insure them.In this case the client is the insurance company.",
        "clazz": "1",
        "$$hashKey": "object:4589"
    },
    {
        "nameEng": "Insurance employees",
        "code": "INEM",
        "gender": "All",
        "nameInd": "Karyawan industri asuransi",
        "minAge": "0",
        "descriptionInd": "Seorang yang bekerja di industri asuransi",
        "descriptionEng": "Insurance employees",
        "clazz": "1",
        "$$hashKey": "object:3595"
    },
    {
        "nameEng": "Librarian",
        "code": "LIBR",
        "gender": "All",
        "nameInd": "Pustakawan",
        "minAge": "0",
        "descriptionInd": "seorang pustakawan adalah seseorang yang bekerja di perpustakaan yang berhadapan dengan informasi dalam berbagai format , termasuk buku, majalah, koran, rekaman suara, peta, foto, dan bentuk grafis lainnya",
        "descriptionEng": "A librarian is a person who work in a library, may deal with information in many formats, including books, magazines, newspapers, audio recordings, maps, photographs and other graphic materials.",
        "clazz": "1",
        "$$hashKey": "object:4530"
    },
    {
        "nameEng": "Historian",
        "code": "HIST",
        "gender": "All",
        "nameInd": "Sejarawan",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang mempelajari dan menulis tentang peristiwa masa lalu.",
        "descriptionEng": "A historian is a person who studies and writes about the past and is regarded as an authority on it.",
        "clazz": "2",
        "$$hashKey": "object:4541"
    },
    {
        "nameEng": "Archivist",
        "code": "ARVS",
        "gender": "All",
        "nameInd": "Juru arsip",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan pekerjaan arsip dokumen",
        "descriptionEng": "someone whose job is to archiving documents",
        "clazz": "1",
        "$$hashKey": "object:3580"
    },
    {
        "nameEng": "Filing clerk",
        "code": "FILE",
        "gender": "All",
        "nameInd": "Staf Arsip",
        "minAge": "0",
        "descriptionInd": "Pegawai dokumen dalam suatu kantor adalah mereka yang bertanggung jawab dalam memelihara, mengatur segala macam dokumen, data,file dan data manual.",
        "descriptionEng": "A file clerk in any setting of office is responsible for managing all kinds of databases, files, folders and manual records, and create new entries as required.",
        "clazz": "1",
        "$$hashKey": "object:4555"
    },
    {
        "nameEng": "Receptionist (clerical)",
        "code": "RECP",
        "gender": "All",
        "nameInd": "Resepsionis (administrasi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di kantor yang menyapa tamu, menjawab panggilan,  menelepon, dan mencatat pesan",
        "descriptionEng": "a person who works at an office who greets visitors, answers the phones, routes calls and takes messages.",
        "clazz": "1",
        "$$hashKey": "object:4537"
    },
    {
        "nameEng": "Computer clerk",
        "code": "COCL",
        "gender": "All",
        "nameInd": "Petugas Penginputan data",
        "minAge": "0",
        "descriptionInd": "pegawai komputer adalah seseorang yang pekerjaanya di kantor, sering melibatkan input komputer dan kemampuan keyboard",
        "descriptionEng": "Computer clerk is someone whose job is office based work, often involving computer input and keyboard skills.",
        "clazz": "1",
        "$$hashKey": "object:4474"
    },
    {
        "nameEng": "Clerical officer",
        "code": "CLOF",
        "gender": "All",
        "nameInd": "Pegawai Admin/Juru tulis",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di kantor atau bank untuk menyimpan catatan dan rekening dan untuk melakukan tugas-tugas administrasi lainnya rutin.",
        "descriptionEng": "A person employed in an office or bank to keep records and accounts and to undertake other routine administrative duties.",
        "clazz": "1",
        "$$hashKey": "object:3839"
    },
    {
        "nameEng": "Factory clerk",
        "code": "FACT",
        "gender": "All",
        "nameInd": "Pekerja Pabrik",
        "minAge": "0",
        "descriptionInd": "Pegawai pabrik adalah orang yang bekerja di kantor, lebih sering bekerja di depan komputer. Beberapa pekerjaan dengan kriteria ini dapat dilakukan diluar kantor tetapi pada umumnya tidak berbahaya.",
        "descriptionEng": "Factory clerk is someone whose job is office based work, often involving computer input and keyboard skills. Some occupations within this category may be performed outside an office environment but they are generally non-hazardous in nature.",
        "clazz": "3",
        "$$hashKey": "object:3878"
    },
    {
        "nameEng": "Guest relations officer",
        "code": "GROP",
        "gender": "All",
        "nameInd": "Staf Penerima Tamu",
        "minAge": "0",
        "descriptionInd": "Guest Relation Officer adalah orang yang tugasnya menyambut tamu saat mereka tiba.",
        "descriptionEng": "Guest relations officer is person whose job to greet guests as they arrive.",
        "clazz": "1",
        "$$hashKey": "object:4570"
    },
    {
        "nameEng": "Astrologer",
        "code": "ASTO",
        "gender": "All",
        "nameInd": "Ahli astrologi",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggunakan astrologi untuk memberitahu orang orang tentang karakter mereka atau memprediksi masa depan",
        "descriptionEng": "a person who uses astrology to tell others about their character or to predict their future.",
        "clazz": "1",
        "$$hashKey": "object:3330"
    },
    {
        "nameEng": "Bus inspector",
        "code": "BUSI",
        "gender": "All",
        "nameInd": "Pengawas bus",
        "minAge": "0",
        "descriptionInd": "menguji dan mengatur atau memperbaiki mesin, chassis, sistem listrik, dan interior bus",
        "descriptionEng": "Examines and adjusts or repairs engines, chassis, electrical systems, and interior furnishings of buses",
        "clazz": "2",
        "$$hashKey": "object:4154"
    },
    {
        "nameEng": "Weights and measures inspector",
        "code": "WMIN",
        "gender": "All",
        "nameInd": "Pemeriksa bobot dan ukuran",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan inspeksi bobot dan ukuran",
        "descriptionEng": "one who inspects weights and measures",
        "clazz": "1",
        "$$hashKey": "object:4058"
    },
    {
        "nameEng": "Traffic warden",
        "code": "TRWN",
        "gender": "All",
        "nameInd": "Penjaga lalu lintas",
        "minAge": "0",
        "descriptionInd": "seseorang yang pekerjaannya untuk memastikan bahwa mobil tidak ada yang parkir secara ilegal",
        "descriptionEng": "a person whose job is to make sure that cars are not parked illegally.",
        "clazz": "3",
        "$$hashKey": "object:4309"
    },
    {
        "nameEng": "Postal sorter",
        "code": "POSS",
        "gender": "All",
        "nameInd": "Penyortir pos",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyiapkan surat masuk dan keluar untuk didistribuikan",
        "descriptionEng": "someone who prepares incoming and outgoing mail for distribution.�",
        "clazz": "3",
        "$$hashKey": "object:4367"
    },
    {
        "nameEng": "Business analyst / Quality improvement analyst / Quality analyst",
        "code": "BUSA",
        "gender": "All",
        "nameInd": "Analis bisnis / Analis peningkatan kualitas / Analis kualitas",
        "minAge": "0",
        "descriptionInd": "seseorang yang menganalisis peningkatan kualitas dan bisnis",
        "descriptionEng": "someone who analyse business and quality improvement",
        "clazz": "1",
        "$$hashKey": "object:3394"
    },
    {
        "nameEng": "Analyst (clerical)",
        "code": "ANYS",
        "gender": "All",
        "nameInd": "Analis (Klerikal)",
        "minAge": "0",
        "descriptionInd": "Berbeda di tiap industri, umumnya adalah orang yang mengevaluasi laporan keuangan perusahaan atau bertanggung jawab untuk penagihan barang dan jasa, menerima pembayaran dari nasabah dan atau perusahaan asuransi serta menjalankan proses pembayaran ke rekening yang tepat dan penagihan jika diperlukan.",
        "descriptionEng": "Industry dependant. Generally a person who evaluates and interprets public company financial statements OR is responsible for the billing for goods and services, receiving the payments from a client and or insurance company and the processing of the payments to the proper accounts as well as credit and collections if necessary.",
        "clazz": "1",
        "$$hashKey": "object:3392"
    },
    {
        "nameEng": "Credit Analyst",
        "code": "CRAN",
        "gender": "All",
        "nameInd": "Analis Kredit",
        "minAge": "0",
        "descriptionInd": "Analis Kredit adalah seseorang yang menganalisis permohonan kredit atas berbagai aspek yang berhubungan dengan penilaian kelayakan atas suatu pinjaman; analisa mencakup aspek hukum, lingkungan, keuangan, pemasaran, produksi, manajemen, ekonomi dan ketersediaan agunan yang memadai.",
        "descriptionEng": "Credit analyst is the person who analyzes the application for credit from a variety of aspects related to the feasibility assessment which will be financed with the loan; analysis include, among others, legal, environmental, finance, marketing, production, management, economics, and the availability of adequate collateral.",
        "clazz": "1",
        "$$hashKey": "object:3397"
    },
    {
        "nameEng": "System analyst",
        "code": "SYAN",
        "gender": "All",
        "nameInd": "Analis Sistem",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja melakukan riset atas masalah, rencana solusi, rekomendasi perangkat lunak dan sistemnya, setidaknya pada tingkat fungsional dan mengkordinasikan rencana pengembangannya.",
        "descriptionEng": "A systems analyst researches problems, plans solutions, recommends software and systems, at least at the functional level, and coordinates development to meet business or other requirements.",
        "clazz": "1",
        "$$hashKey": "object:3400"
    },
    {
        "nameEng": "Town planner / Statistician",
        "code": "STAT",
        "gender": "All",
        "nameInd": "Perencana kota / Ahli statistik",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengumpulkan, menganalisis, dan menginterpretasi data kuantitatif. Seseorang ahli matematika yang ahli dalam bidang statistik",
        "descriptionEng": "a person who collect, analyse and interpret quantitative data. A mathematician specializing in statistics.",
        "clazz": "1",
        "$$hashKey": "object:4397"
    },
    {
        "nameEng": "Management consultant",
        "code": "MGCS",
        "gender": "All",
        "nameInd": "Konsultan manajemen",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu meningkatkan dan mengembangkan performa bisnis dengan memecahkan masalah dan menemukan cara baru dan lebih baik dalam melakukan sesuatu",
        "descriptionEng": "someone who helps businesses improve their performance and grow by solving problems and finding new and better ways of doing things.",
        "clazz": "1",
        "$$hashKey": "object:3640"
    },
    {
        "nameEng": "Civil servant",
        "code": "CIVS",
        "gender": "All",
        "nameInd": "Pegawai negeri sipil",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di sektor masyarakat, bekerja untuk pemerintahan atau agensi",
        "descriptionEng": "a person employed in the public sector employed for a government department or agency.",
        "clazz": "1",
        "$$hashKey": "object:3845"
    },
    {
        "nameEng": "Civil servant (Indoor)",
        "code": "CSER",
        "gender": "All",
        "nameInd": "Pegawai Negeri Sipil (Dalam Ruangan)",
        "minAge": "0",
        "descriptionInd": "Penugasan yang  diberikan kepada pegawai pemerintah yang memenuhi syarat berdasarkan atas kemampuannya, dan bukan karena patronase politik atau bantuan individu.",
        "descriptionEng": "The designation given to government employment for which a person qualifies on the basis of merit rather than political patronage or personal favor.",
        "clazz": "1",
        "$$hashKey": "object:3847"
    },
    {
        "nameEng": "Civil servant (Outdoor)",
        "code": "CSRO",
        "gender": "All",
        "nameInd": "Pegawai Negeri Sipil (Aktivitas di Luar Ruangan)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja pada sektor publik untuk kepentingan pemerintah.",
        "descriptionEng": "A person in the public Sector employed for a government department or agency.",
        "clazz": "1",
        "$$hashKey": "object:3846"
    },
    {
        "nameEng": "Civil Servant echelon 1",
        "code": "CSEO",
        "gender": "All",
        "nameInd": "Pegawai Negeri Sipil Esseleon 1",
        "minAge": "0",
        "descriptionInd": "Pegawai Negeri Sipil Esseleon 1",
        "descriptionEng": "Civil Servant echelon 1",
        "clazz": "1",
        "$$hashKey": "object:3848"
    },
    {
        "nameEng": "Civil Servant echelon 2",
        "code": "CSET",
        "gender": "All",
        "nameInd": "Pegawai Negeri Sipil Esseleon 2",
        "minAge": "0",
        "descriptionInd": "Pegawai Negeri Sipil Esseleon 2",
        "descriptionEng": "Civil Servant echelon 2",
        "clazz": "1",
        "$$hashKey": "object:3849"
    },
    {
        "nameEng": "Civil Servant echelon 3",
        "code": "CSEH",
        "gender": "All",
        "nameInd": "Pegawai Negeri Sipil Esseleon 3",
        "minAge": "0",
        "descriptionInd": "Pegawai Negeri Sipil Esseleon 3",
        "descriptionEng": "Civil Servant echelon 3",
        "clazz": "1",
        "$$hashKey": "object:3850"
    },
    {
        "nameEng": "Civil Servant echelon 4",
        "code": "CSEF",
        "gender": "All",
        "nameInd": "Pegawai Negeri Sipil Esseleon 4",
        "minAge": "0",
        "descriptionInd": "Pegawai Negeri Sipil Esseleon 4",
        "descriptionEng": "Civil Servant echelon 4",
        "clazz": "1",
        "$$hashKey": "object:3851"
    },
    {
        "nameEng": "Work study engineer",
        "code": "WSEN",
        "gender": "All",
        "nameInd": "Insinyur studi kerja",
        "minAge": "0",
        "descriptionInd": "seseorang yang Mengembangkan prosedur pengukuran kerja dan mengarahkan studi waktu dan gerak untuk mempromosikan penggunaan tenaga dan fasilitas yang efisien dan ekonomis",
        "descriptionEng": "someone who Develops work measurement procedures and directs time-and-motion studies to promote efficient and economical utilization of personnel and facilities",
        "clazz": "1",
        "$$hashKey": "object:3557"
    },
    {
        "nameEng": "Market research interviewer",
        "code": "MRKT",
        "gender": "All",
        "nameInd": "Pewawancara riset pasar",
        "minAge": "0",
        "descriptionInd": "seorang posisi peneliti pemula yang mengizinkan perusahaan untuk pertama kali melihat bagaimana masyarakat melihat produk, jasa, atau merek.",
        "descriptionEng": "are typically entry-level research positions that allow companies to get first-hand looks into how the public views a product, service or brand.�",
        "clazz": "2",
        "$$hashKey": "object:4506"
    },
    {
        "nameEng": "Company director",
        "code": "COMD",
        "gender": "All",
        "nameInd": "Direktur perusahaan",
        "minAge": "0",
        "descriptionInd": "seseorang dari sekelompok manajer yang memimpin atau mengawasi area tertentu dari sebuah perusahaan, program, atau projek.",
        "descriptionEng": "a person from a group of managers who leads or supervises a particular area of a company, program, or project.�",
        "clazz": "1",
        "$$hashKey": "object:3479"
    },
    {
        "nameEng": "Recruitment officer",
        "code": "REOF",
        "gender": "All",
        "nameInd": "Staff Rekrutmen karyawan",
        "minAge": "0",
        "descriptionInd": "Orang yang pekerjaannya bertanggung jawab atas perencanaan tenaga kerja, bertanggung jawab untuk menemukan kandidat yang cocok untuk posisi yang tersedia dan mengidentifikasi saluran perekrutan yang sesuai, desain iklan iklan untuk proses rekrutmen, memastikan semua posisi diisi dengan candidat yang cocok dalam waktu yang ditargetkan. Memastikan semua kebijakan, prosedur perekrutan dan teknik perekrutan dipatuhi dan merekomendasikan perbaikan.",
        "descriptionEng": "Identify roles to be filled within the organization, resposible for manpower planning, responsible for sourcing for suitable candidates for available position and identifying suitable recruitment channels, designs recruitment andvertising, ensure all vacancies are filled with the suitable candidat within the targeted time. Ensure all recruitment policies procedure and techniques are adhered to and recommend improvements.",
        "clazz": "2",
        "$$hashKey": "object:4590"
    },
    {
        "nameEng": "Freight manager (clerical) / Industrial safety officer (clerical) / Clerical manager",
        "code": "FREM",
        "gender": "All",
        "nameInd": "Manajer muatan (administrasi) / Staf keselamatan industri (administrasi) / Manajer juru tulis",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga layanan kantor dengan mengatur operasional dan prosedur kantor",
        "descriptionEng": "one who Maintains office services by organizing office operations and procedures",
        "clazz": "2",
        "$$hashKey": "object:3686"
    },
    {
        "nameEng": "Local government officer (clerical) / Government Office",
        "code": "LGOF",
        "gender": "All",
        "nameInd": "Pejabat Pemerintahan",
        "minAge": "0",
        "descriptionInd": "mereka yang bekerja di pemerintahan",
        "descriptionEng": "Government officer are people who work in government.",
        "clazz": "2",
        "$$hashKey": "object:3857"
    },
    {
        "nameEng": "General manager (clerical)",
        "code": "GMGR",
        "gender": "All",
        "nameInd": "Manajer umum (administrasi)",
        "minAge": "0",
        "descriptionInd": "manajer umum merujuk kepada eksekutif apapun yang memiliki tanggung jawab penuuh untuk mengatur pendapatan dan elemen biaya dari laporan laba rugi perusahaan. Ini biasa disebut tanggung jawab keuntungan dan kerugian. Artinya, manajer umum biasanya meneliti hampir atau semua pemasaran perusahaan dan fungsi penjualan begitu juga dengan operasi binsis sehari-hari. seringkali, manajer umum bertanggung jawab untuk perencanaan efektif, mendelegasi, mengkoordinasi, proses staf, mengelola, dan mengambil keputusan untuk mendapat keuntungan yang diinginkan yang membuat hasil   bagi organisasi",
        "descriptionEng": "General Manager refers to any executive who has overall responsibility for managing both the revenue and cost elements of a company's income statement. This is often referred to as profit & loss (P&L) responsibility. This means that a General Manager usually oversees most or all of the firm's marketing and sales functions as well as the day-to-day operations of the business. Frequently, the General Manager is responsible for effective planning, delegating, coordinating, staffing, organizing, and decision making to attain desirable profit making results for an organization.",
        "clazz": "1",
        "$$hashKey": "object:3710"
    },
    {
        "nameEng": "Factory manager (clerical) / Managers of factories",
        "code": "MGRR",
        "gender": "All",
        "nameInd": "Manajer Pabrik",
        "minAge": "0",
        "descriptionInd": "manajer pabrik merencanakan kelengkapan produksi, aktivitas produksi, jadwal para pekerja, jadawal perawatan mesin, dan menjaga kualitas produk dan budget",
        "descriptionEng": "The factory manager plans production meetings, production activities, worker schedules, machine maintenance schedules and maintains budges and product quality.",
        "clazz": "2",
        "$$hashKey": "object:3687"
    },
    {
        "nameEng": "Customs and excise officer (clerical) / Customs and excise (immigration)",
        "code": "CUST",
        "gender": "All",
        "nameInd": "Pegawai bea dan Cukai",
        "minAge": "0",
        "descriptionInd": "mereka yang bekerja di instansi pemerintahan yang melayani komunitas di are bea dan cukai",
        "descriptionEng": "People who work in government instance who serve the community in the areas of customs and excise.",
        "clazz": "1",
        "$$hashKey": "object:3841"
    },
    {
        "nameEng": "Executive",
        "code": "EXEC",
        "gender": "All",
        "nameInd": "Eksekutif",
        "minAge": "0",
        "descriptionInd": "Pegawai eksekutif adalah orang yang bertanggung jawab atas berjalannya suatu organisasi, dimana perannya bermacam-macam tergantung pada organisasi.",
        "descriptionEng": "An executive officer is generally a person responsible for running an organization, although the exact nature of the role varies depending on the organization.",
        "clazz": "1",
        "$$hashKey": "object:3501"
    },
    {
        "nameEng": "Immigration officer",
        "code": "IMMI",
        "gender": "All",
        "nameInd": "Petugas Imigrasi",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang bertugas untuk  melihat atau memvalidasi identitas orang yang akan bepergian ke luar negeri.",
        "descriptionEng": "Immigration officer is person who jobs is to oversee the arrival and departure of a citizen or person to see or validate the identity of the person who will be traveling out of the country.",
        "clazz": "1",
        "$$hashKey": "object:4425"
    },
    {
        "nameEng": "Market research analyst",
        "code": "MKAN",
        "gender": "All",
        "nameInd": "Analis riset pasar",
        "minAge": "0",
        "descriptionInd": "meneliti kondisi pasar area lokal, regional, atau nasional untuk menentukan potensi penjualan dari produk atau jasa. Mungkin juga untuk mengumpulkan informasi tentang kompetittor, harga, penjualan, dan metode pemasaran dann distribusi",
        "descriptionEng": "Research market conditions in local, regional, or national areas to determine potential sales of a product or service. May gather information on competitors, prices, sales, and methods of marketing and distribution.",
        "clazz": "1",
        "$$hashKey": "object:3399"
    },
    {
        "nameEng": "Office messenger",
        "code": "MESS",
        "gender": "All",
        "nameInd": "Kurir kantor",
        "minAge": "0",
        "descriptionInd": "mengambil dan membawa pesan, dokumen, paket, dan barang lain ke kantor atau departemen dalam sebuah perusahaan atau kepentingan bisnis lainnya, berjalan kaki, sepeda, motor, otomobil, atau angkutan umum",
        "descriptionEng": "Pick up and carry messages, documents, packages, and other items between offices or departments within an establishment or to other business concerns, traveling by foot, bicycle, motorcycle, automobile, or public conveyance.",
        "clazz": "2",
        "$$hashKey": "object:3658"
    },
    {
        "nameEng": "Sociologist",
        "code": "SCIO",
        "gender": "All",
        "nameInd": "Sosiolog",
        "minAge": "0",
        "descriptionInd": "ilmuwan sosial yang mempelajari institusi dan pengembangan masyarakat manusia",
        "descriptionEng": "a social scientist who studies the institutions and development of human society.",
        "clazz": "2",
        "$$hashKey": "object:4548"
    },
    {
        "nameEng": "Stocktaker",
        "code": "STCK",
        "gender": "All",
        "nameInd": "Pencatat inventaris",
        "minAge": "0",
        "descriptionInd": "seseorang yang menghitung barang barang atau kebutuhan milik sebuah perusahaan atau siap untuk dijual di toko tertentu dalam waktu tertentu",
        "descriptionEng": "someone who counts goods or materials owned by a company or available for sale in a store at a particular time",
        "clazz": "2",
        "$$hashKey": "object:4110"
    },
    {
        "nameEng": "Stock controller",
        "code": "STCN",
        "gender": "All",
        "nameInd": "Petugas Stock Barang",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja menjaga ketersediaan dan kelengkapan stok barang di supermarket.",
        "descriptionEng": "A person whose job to maintain the balance of stock in the market.",
        "clazz": "2",
        "$$hashKey": "object:4495"
    },
    {
        "nameEng": "Training and development officer",
        "code": "TRDO",
        "gender": "All",
        "nameInd": "Staf pelatihan dan pengembangan",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab untuk mengidentifikasi pelatihan anggota dan kebutuhan perkembangan, dan untuk perencanaan, pengaturan, dan meneliti lebih jauh pelatihan",
        "descriptionEng": "are responsible for identifying staff training and development needs, and for planning, organising and overseeing appropriate training.",
        "clazz": "1",
        "$$hashKey": "object:4567"
    },
    {
        "nameEng": "Dock crane driver / Dock crane operator / Dock crane slinger",
        "code": "DOCD",
        "gender": "All",
        "nameInd": "Pengemudi derek dermaga / Operator derek dermaga / Slinger derek dermaga",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudi derek",
        "descriptionEng": "someone who drives dock crane",
        "clazz": "3",
        "$$hashKey": "object:4208"
    },
    {
        "nameEng": "Hoist driver / Winch driver",
        "code": "HOID",
        "gender": "All",
        "nameInd": "Pengemudi hoist / Pengemudi mesin derek",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudikan mesin hoist",
        "descriptionEng": "someone who drives hoist",
        "clazz": "3",
        "$$hashKey": "object:4209"
    },
    {
        "nameEng": "Business development officer",
        "code": "BDVO",
        "gender": "All",
        "nameInd": "Staff Pengembangan Bisnis",
        "minAge": "0",
        "descriptionInd": "seseorang yang melaksankan berbagai fungsi manajerial dari sebuah departemen seperti yang diarahkan, menyediakan pelayanan tingkat atas akanhubungan masyarakat dan layanannya, dan memastikan kepatuhan akan perusahaan",
        "descriptionEng": "A person who is performing various managerial functions of the department as directed, providing a superior level of customer relations and service; and ensuring compliance of the company.",
        "clazz": "1",
        "$$hashKey": "object:4586"
    },
    {
        "nameEng": "Typist",
        "code": "TYPT",
        "gender": "All",
        "nameInd": "Juru ketik",
        "minAge": "0",
        "descriptionInd": "seseorang yang melekukan kerjaan mengetik",
        "descriptionEng": "a person who types.",
        "clazz": "1",
        "$$hashKey": "object:3585"
    },
    {
        "nameEng": "Unmanned aerial vehicle operator",
        "code": "AEVO",
        "gender": "All",
        "nameInd": "Operator kendaraan udara tanpa awak",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi dan mengoperasikan UAV (kendaraan udara tanpa awak)",
        "descriptionEng": "a person who supervises or operates the UAV (unmaned aerial Vehicle)",
        "clazz": "2",
        "$$hashKey": "object:3770"
    },
    {
        "nameEng": "Air traffic controller / Air traffic planner / Air traffic control assistant",
        "code": "AITC",
        "gender": "All",
        "nameInd": "Pengontrol lalu lintas udara / Perencana lalu lintas udara / Asisten kontrol lalu lintas udara",
        "minAge": "0",
        "descriptionInd": "anggota yang bertanggung jawab akan keselamatan, dan alur cepat lalu lintas udara di sistem kontrol global lalu lintas udara",
        "descriptionEng": "are personnel responsible for the safe, orderly, and expeditious flow of air traffic in the global air traffic control system.�",
        "clazz": "2",
        "$$hashKey": "object:4250"
    },
    {
        "nameEng": "Airport radar controller / Airport radar operator / Airport radio operator",
        "code": "ARCO",
        "gender": "All",
        "nameInd": "Pengontrol radar bandara / Operator radar bandara / Operator radio bandara",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu mendeteksi dan mendisplay keberadaaan dan posisi pesawat terbang di area terminal",
        "descriptionEng": "someone who helps to detect and display the presence and position of aircraft in the terminal area,�",
        "clazz": "2",
        "$$hashKey": "object:4252"
    },
    {
        "nameEng": "Airport ground movement controller",
        "code": "AGMC",
        "gender": "All",
        "nameInd": "Pengontrol gerakan darat bandara",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab akan \"pergerakan\"di area bandara, begitu juga area yang tidak disentuh oleh airline atau pengguna lain",
        "descriptionEng": "is responsible for the�airport�\"movement\" areas, as well as areas not released to the airlines or other users.",
        "clazz": "2",
        "$$hashKey": "object:4246"
    },
    {
        "nameEng": "Aircraft marshaller",
        "code": "AIMS",
        "gender": "All",
        "nameInd": "Pemberi sinyal pesawat terbang",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberikan sinyal antara anggota darat dan pilot di bandara, pemsawat terbang atau helipad",
        "descriptionEng": "someone who gives visual signalling between ground personnel and pilots on an airport,�aircraft�carrier or helipad.",
        "clazz": "3",
        "$$hashKey": "object:3996"
    },
    {
        "nameEng": "Aircraft refueller",
        "code": "AIRF",
        "gender": "All",
        "nameInd": "Pengisi ulang bahan bakar pesawat terbang",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab untuk memastikan semua pesawat perusahaan dan kendaraan aviasi agar secara rutin terisi oleh bahan bakar",
        "descriptionEng": "responsible for ensuring that all of a company's planes and aviation vehicles are routinely equipped with fuel",
        "clazz": "3",
        "$$hashKey": "object:4243"
    },
    {
        "nameEng": "Airport manager / Baggage manager / Aircraft inspector / Airport superintendent / Airport duty officer / Airport operations officer / Flight operations inspector / Flight dispatcher / Flight planner / Ground hostess / Airport steward / Ground steward",
        "code": "AIRM",
        "gender": "All",
        "nameInd": "Manajer bandara / Manajer bagasi / Inspektur pesawat terbang / Pengawas bandara / Staf tugas bandara / Staf operasi bandara / Inspektur operasi penerbagan / Staf operasi penerbangan / Perencana penerbangan / Staf darat / Pelayan bandara / Petugas darat",
        "minAge": "0",
        "descriptionInd": "seseorang yang melihat pekerjaan operasi sehari-hari",
        "descriptionEng": "oversee the day-to-day operations�",
        "clazz": "1",
        "$$hashKey": "object:3672"
    },
    {
        "nameEng": "Airport maintenance engineer / Aircraft maintenance engineer",
        "code": "AMEG",
        "gender": "All",
        "nameInd": "Insinyur pemeliharaan bandara / Insinyur pemeliharaan pesawat terbang",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga lampu, perputaran, dan pesawat terbang komersial",
        "descriptionEng": "one who maintains light, rotary and large commercial�aircraft",
        "clazz": "2",
        "$$hashKey": "object:3547"
    },
    {
        "nameEng": "Aircraft engine service fitter",
        "code": "AESF",
        "gender": "All",
        "nameInd": "Mekanik servis mesin pesawat terbang",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang mesin pesawat terbang",
        "descriptionEng": "someone who fits the aircraft engine",
        "clazz": "3",
        "$$hashKey": "object:3737"
    },
    {
        "nameEng": "Aircraft service fitter / Aircraft air frame service fitter / Aircraft electronics service fitter / Aircraft instrument mechanic / Aircraft electronics service mechanic",
        "code": "AISF",
        "gender": "All",
        "nameInd": "Petugas pemasang servis pesawat terbang / Petugas pemasang servis frame udara pesawat terbang / Petugas pemasang servis elektronik pesawat terbang / Mekanik instrumen pesawat terbang / Mekanik servis elektronik pesawat terbang",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat segala jenis pesawat terbang",
        "descriptionEng": "someone who maintains aircraft of all types",
        "clazz": "3",
        "$$hashKey": "object:4461"
    },
    {
        "nameEng": "Aircraft Mechanic",
        "code": "AIRC",
        "gender": "All",
        "nameInd": "Mekanik Pesawat Terbang",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk memperbaiki dan memelihara pesawat.",
        "descriptionEng": "A person who is responsible for field and shop repair and maintenance of aircrafts to ensure airworthiness.",
        "clazz": "3",
        "$$hashKey": "object:3735"
    },
    {
        "nameEng": "Airport conveyor operator / Aircraft conveyor operator",
        "code": "AICV",
        "gender": "All",
        "nameInd": "Operator konveyor bandara / Operator konveyor pesawat terbang",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab untuk mengoperasikan conveyor belt yang memindahkan barang dari satu tempat ke tempat lain; memindahkan maaterial dari dan ke gudang stok dan memastikan mereka dikirim",
        "descriptionEng": "Responsible for operating conveyor belt that moves objects from one place to another. Moves material to and from stockpiles and ensure they are safely transported.",
        "clazz": "3",
        "$$hashKey": "object:3781"
    },
    {
        "nameEng": "Airport loader / Aircraft loader",
        "code": "AILO",
        "gender": "All",
        "nameInd": "Pemuat bagasi bandara / Pemuat bagasi pesawat terbang",
        "minAge": "0",
        "descriptionInd": "seseorang yang memuat barang barang ke bandara",
        "descriptionEng": "someone who loads stuff to airport",
        "clazz": "3",
        "$$hashKey": "object:4085"
    },
    {
        "nameEng": "Off site construction manager / Construction materials planner",
        "code": "OFSC",
        "gender": "All",
        "nameInd": "Manajer konstruksi di luar lokasi / Perencana material konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengkoordinasi  dan mengawasi berbagai macam projek, termasuk semua tipe bangunan rumah, komersial, struktur industri jalan, jembatan, dll",
        "descriptionEng": "someone who coordinates and supervise a wide variety of projects, including the building of all types of residential, commercial, and industrial structures, roads, bridges,",
        "clazz": "1",
        "$$hashKey": "object:3682"
    },
    {
        "nameEng": "Material expeditor",
        "code": "MTEX",
        "gender": "All",
        "nameInd": "Pengontrol Material Bahan Bangunan",
        "minAge": "0",
        "descriptionInd": "Melakukan pencatatan seperti catatan persedian bahan, catatan produksi serta melakukan pemeliharaan jumlah dan jenis bahan secara manual atau menggunakan komputer.",
        "descriptionEng": "Records and maintains perpetual inventory of quantity and type of materials and parts received, stocked, and distributed, manually or using computer. Such as material inventory records, production records, manually or using computer.",
        "clazz": "2",
        "$$hashKey": "object:4251"
    },
    {
        "nameEng": "Architect",
        "code": "ARCH",
        "gender": "All",
        "nameInd": "Arsitek",
        "minAge": "0",
        "descriptionInd": "Orang yang terlatih dan memiliki ijin untuk merencanakan, mendesain, dan mengawasi pembangunan gedung-gedung.",
        "descriptionEng": "An architect is a person trained and licensed to plan, design, and oversee the construction of buildings.",
        "clazz": "2",
        "$$hashKey": "object:3417"
    },
    {
        "nameEng": "Dock rigger",
        "code": "DCKR",
        "gender": "All",
        "nameInd": "Juru ikat dermaga",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam mengangkat dan memindahkan objek yang sangat besar dan berat",
        "descriptionEng": "�a person who specializes in the lifting and moving of extremely large or heavy objects,",
        "clazz": "3",
        "$$hashKey": "object:3583"
    },
    {
        "nameEng": "Welder cutter (oil and natural gas production)",
        "code": "WLDR",
        "gender": "All",
        "nameInd": "Pemotong las (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas tukang las gas dan minyak bumi",
        "descriptionEng": "welder in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:4081"
    },
    {
        "nameEng": "Architectural Drafter",
        "code": "ARCD",
        "gender": "All",
        "nameInd": "Konseptor Arsitek",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja dengan arsitek untuk menciptakan gambar rinci dari rumah, bangunan kantor dan struktur lainnya. Gambar tersebut digunakan oleh pekerja konstruksi dan kontraktor untuk memastikan bahwa semua bagian bangunan yang akan dibangun cocok dengan spesifikasi arsitek.",
        "descriptionEng": "Architectural drafters work with architects to create detailed drawings of homes, office buildings, and other structures. Their drawings are used by construction workers and contractors to ensure that all parts the buildings they construct match the architect's specifications.",
        "clazz": "2",
        "$$hashKey": "object:3634"
    },
    {
        "nameEng": "Concrete finisher / Concrete operator / Concrete repairer / Concrete erector",
        "code": "CONO",
        "gender": "All",
        "nameInd": "Penghalus beton / Operator beton / Pereparasi beton / Pemasang beton",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja dengan semen dengan cara menempatkan, menyelesaikan, memperbaiki semen di bidang teknik dan projek konstruksi",
        "descriptionEng": "someone who works with concrete�by placing, finishing,  repairing�concrete�in engineering and�constructionprojects.�",
        "clazz": "3",
        "$$hashKey": "object:4237"
    },
    {
        "nameEng": "Ceiling fixer / Glazier / Thatcher / Plasterer / Pipe working",
        "code": "CONW",
        "gender": "All",
        "nameInd": "Pemasang langit-langit / Tukang kaca / Tukang atap / Tukang plester / Pekerjaan pipa",
        "minAge": "0",
        "descriptionInd": "pekerja konstruksi adalah seseorang yang pekerjaannya adalah bekerja di konstruksi dimana struktur bangunan seprti jembatan atau rumah sedang dibangun",
        "descriptionEng": "A construction worker is someone whose job is to work on a construction site where structures such as bridges or houses are being built.",
        "clazz": "3",
        "$$hashKey": "object:3963"
    },
    {
        "nameEng": "Tiler",
        "code": "TILR",
        "gender": "All",
        "nameInd": "Tukang ubin",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang ubin di konstruksi",
        "descriptionEng": "A person who install tiles in construction.",
        "clazz": "3",
        "$$hashKey": "object:4705"
    },
    {
        "nameEng": "Builder",
        "code": "BUIL",
        "gender": "All",
        "nameInd": "Tukang bangunan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membangun",
        "descriptionEng": "the one who builds",
        "clazz": "3",
        "$$hashKey": "object:4656"
    },
    {
        "nameEng": "Floor tiler",
        "code": "TILE",
        "gender": "All",
        "nameInd": "Pemasang lantai ubin",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang ubin di konstruksi",
        "descriptionEng": "A person who install tiles in construction.",
        "clazz": "3",
        "$$hashKey": "object:3964"
    },
    {
        "nameEng": "Lift erector / Escalator erector",
        "code": "LIFT",
        "gender": "All",
        "nameInd": "Pemasang lift / Pemasang eskalator",
        "minAge": "0",
        "descriptionInd": "seseorang yang membangun lift",
        "descriptionEng": "the one who erects lift",
        "clazz": "3",
        "$$hashKey": "object:3966"
    },
    {
        "nameEng": "Handyman",
        "code": "HAND",
        "gender": "All",
        "nameInd": "Tukang serbabisa",
        "minAge": "0",
        "descriptionInd": "",
        "descriptionEng": "A handyman or handyperson[1] is a person skilled at a wide range of repairs, typically around the home. These tasks include trade skills, repair work, maintenance work, both interior and exterior, and are sometimes described as \"odd jobs\", \"fix-up tasks\", and include light plumbing jobs such as fixing a leaky toilet or light electric jobs such as changing a light fixture.",
        "clazz": "3",
        "$$hashKey": "object:4701"
    },
    {
        "nameEng": "Construction groundworker / Groundworker",
        "code": "CNSG",
        "gender": "All",
        "nameInd": "Pekerja konstruksi darat / Pekerja darat",
        "minAge": "0",
        "descriptionInd": "seseorang yang dipekerjakan untuk mempersiapkan situs pembangunan rumah untuk rumah dengan fondasi dangkal",
        "descriptionEng": "�someone who is employed to prepare a home�constructionsite for the shallow foundation of a new home.",
        "clazz": "3",
        "$$hashKey": "object:3871"
    },
    {
        "nameEng": "Underground worker / Construction underground worker",
        "code": "UGWO",
        "gender": "All",
        "nameInd": "Pekerja bawah tanah / pekerja konstruksi bawah tanah",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di bangunan bawah tanah",
        "descriptionEng": "someone who works in an underground consruction",
        "clazz": "3",
        "$$hashKey": "object:3861"
    },
    {
        "nameEng": "Construction shotfirer",
        "code": "COSH",
        "gender": "All",
        "nameInd": "Peledak konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola segala aspek dari penyimpanan peledak, transportasi, dan penggunaan peledakan metalik bawah tanah dan konstruksi bawah tanah",
        "descriptionEng": "someonne who manages all aspects of explosives storage, transport and use in underground metalliferous blasting and in underground�construction�...",
        "clazz": "3",
        "$$hashKey": "object:3940"
    },
    {
        "nameEng": "Construction caulker",
        "code": "CONC",
        "gender": "All",
        "nameInd": "Pendempul konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendempul konstruksi",
        "descriptionEng": "someone who caulks construction",
        "clazz": "3",
        "$$hashKey": "object:4118"
    },
    {
        "nameEng": "Construction labourer",
        "code": "CONL",
        "gender": "All",
        "nameInd": "Buruh konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang tidak memiliki keterampilan bekerja di konstruksi",
        "descriptionEng": "someone unskilled who works in a construction",
        "clazz": "3",
        "$$hashKey": "object:3459"
    },
    {
        "nameEng": "Crane slinger / Crane assistant",
        "code": "CRNS",
        "gender": "All",
        "nameInd": "Pengguna sling derek / Asisten derek",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggunakan crane slinger untuk bekerja",
        "descriptionEng": "someone who uses crane slinger to work",
        "clazz": "3",
        "$$hashKey": "object:4236"
    },
    {
        "nameEng": "Cement works loader operator",
        "code": "CWLO",
        "gender": "All",
        "nameInd": "Operator pemuat pekerjaan semen",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan muatan semen",
        "descriptionEng": "someone who operates in loading the cement",
        "clazz": "3",
        "$$hashKey": "object:3811"
    },
    {
        "nameEng": "Construction riveter",
        "code": "CONR",
        "gender": "All",
        "nameInd": "Pemasang paku keliling konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang memaku paku keling di konstruksi",
        "descriptionEng": "someone who nails rivet in construction",
        "clazz": "3",
        "$$hashKey": "object:3968"
    },
    {
        "nameEng": "Steeplejack",
        "code": "STEP",
        "gender": "All",
        "nameInd": "Tukang panjat menara",
        "minAge": "0",
        "descriptionInd": "seseorang yang memanjat gedung tinggi seperti cerobong asap dan bangunan demi melakukan perbaikann",
        "descriptionEng": "a person who climbs tall structures such as chimneys and steeples in order to carry out repairs.",
        "clazz": "3",
        "$$hashKey": "object:4687"
    },
    {
        "nameEng": "Building inspector / Construction site agent",
        "code": "BUIN",
        "gender": "All",
        "nameInd": "Pengawas gedung / Agen tempat konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawas gedung",
        "descriptionEng": "a person who inspects building",
        "clazz": "2",
        "$$hashKey": "object:4156"
    },
    {
        "nameEng": "Dock superintendent",
        "code": "DOCK",
        "gender": "All",
        "nameInd": "Pengawas dermaga",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab dalam mengelola perjalanan atau bagian di layanan pusat sementara menrawat departemen dan layanan  ppusat demi keamanan, kualitas,   efisiensi, cost, jasa dan pengiriman, pelatihan dan pengembangan, dan penjaga rumah",
        "descriptionEng": "responsible for managing a shift or section in a service center while maintaining the department/shift and service center standards for safety, quality, efficiency, cost, service and delivery, training and development and housekeeping.",
        "clazz": "2",
        "$$hashKey": "object:4155"
    },
    {
        "nameEng": "Lightkeeper / Weighbridgeman",
        "code": "LGHP",
        "gender": "All",
        "nameInd": "Petugas mercusuar / Petugas timbang jembatan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk merawat dermaga",
        "descriptionEng": "seomeone who works ro maintain the dock",
        "clazz": "2",
        "$$hashKey": "object:4449"
    },
    {
        "nameEng": "Dock master / Port control signalman / Radar observer",
        "code": "DOCM",
        "gender": "All",
        "nameInd": "Penanggung jawab dermaga / Petugas sinyal kontrol pelabuhan / Pengamat radar",
        "minAge": "0",
        "descriptionInd": "seseorang yang bertanggung jawab akan dermaga yang digunakan untuk kargo, logistik, dan memperbaiki atau merawat kapal",
        "descriptionEng": "a person in charge of a dock used for freight, logistics, and repair or maintenance of ships�",
        "clazz": "2",
        "$$hashKey": "object:4097"
    },
    {
        "nameEng": "Cargo handler",
        "code": "CAHD",
        "gender": "All",
        "nameInd": "Petugas kargo",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab akan memuat barang dengan selamat dan mengeluarkan bagasi penumpang dan kargo lainnya dari pesawat terbang",
        "descriptionEng": "responsible for safely loading and unloading passengers' luggage and other�cargofrom an aircraft.",
        "clazz": "2",
        "$$hashKey": "object:4428"
    },
    {
        "nameEng": "Dock foreman",
        "code": "DOCF",
        "gender": "All",
        "nameInd": "Mandor dermaga",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi dan mengkoordinasi kegiatan para pegawai yang berkaitan dengan kegiatan dermaga yang termasuk mengeluarkan dan memuat kapal",
        "descriptionEng": "Supervises and coordinates activities of employees engaged in�dock�activities which include unloading/loading of vessels",
        "clazz": "2",
        "$$hashKey": "object:3714"
    },
    {
        "nameEng": "Lock keeper",
        "code": "LOKK",
        "gender": "All",
        "nameInd": "Penjaga pintu air",
        "minAge": "0",
        "descriptionInd": "menjaga kanal atau  kunci sungai, mengoperasikan dan jika perlu merawat atau mengatur keterawatannya",
        "descriptionEng": "looks after a canal or river lock, operating it and if necessary maintaining it or organizing its maintenance",
        "clazz": "3",
        "$$hashKey": "object:4317"
    },
    {
        "nameEng": "Dock loader operator / Dock fork lift operator",
        "code": "DOLO",
        "gender": "All",
        "nameInd": "Operator alat muat dermaga / Operator fork lift dermaga",
        "minAge": "0",
        "descriptionInd": "seseorang yang memuat dan mengeluarkan kargo",
        "descriptionEng": "loads and unloads freight",
        "clazz": "3",
        "$$hashKey": "object:3756"
    },
    {
        "nameEng": "Stevedore",
        "code": "STVE",
        "gender": "All",
        "nameInd": "Buruh pelabuhan",
        "minAge": "0",
        "descriptionInd": "biasa dipanggil juga dengan buruh pelabuhan, mereka bertanggung jawab untuk memuat dan mengeluarkan kargo dari kapal",
        "descriptionEng": "Also called dockworker, docker, dock labourer, wharfie and longshoreman, they responsible to load or unload cargos from the ships.",
        "clazz": "3",
        "$$hashKey": "object:3460"
    },
    {
        "nameEng": "Goods vehicle loader",
        "code": "GVLO",
        "gender": "All",
        "nameInd": "Pemuat kendaraan barang",
        "minAge": "0",
        "descriptionInd": "kendaraan yang memuat barang barang",
        "descriptionEng": "vehicle that loads goods",
        "clazz": "3",
        "$$hashKey": "object:4087"
    },
    {
        "nameEng": "Motor cycle courier",
        "code": "MOTC",
        "gender": "All",
        "nameInd": "Kurir sepeda motor",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengendarai motor untuk mengangkut barang barang",
        "descriptionEng": "someone who drives a motor cycle to transport goods",
        "clazz": "3",
        "$$hashKey": "object:3659"
    },
    {
        "nameEng": "Plant operator (driving) / Plant operator driver / Driver plant operator",
        "code": "PLNO",
        "gender": "All",
        "nameInd": "Operator pabrik (mengemudi) / Pengemudi operator pabrik / Pengemudi operator pabrik",
        "minAge": "0",
        "descriptionInd": "orang yang mengemudi sebagai operator pabrik",
        "descriptionEng": "person who drives as plant operator",
        "clazz": "3",
        "$$hashKey": "object:3802"
    },
    {
        "nameEng": "PSA whaft (Merchant Marine)",
        "code": "PSAW",
        "gender": "All",
        "nameInd": "Buruh Pelabuhan kapal",
        "minAge": "0",
        "descriptionInd": "Membongkar hasil tangkapan  dari kapal penangkap ikan dan ikan dari dermaga dan diantarkan ke tempat penyimpanan, melakukan kombinasi dari tugas-tugas berikut. Membongkar muatan dari jaring , ember derek atau tangkapan dari palka kapal, dengan menggunakan tangan atau dengan sekop atau garpu bengkok. Memindahkan hasil tangkapan dari cargo net atau derek ember ke platform dock, dan memisahkan sesuai dengan jenis, ukuran, atau kelas. Mendorong keranjang ikan untuk ditaruh ikan di atas meja, atau meletakan tumpukan ikan di lantai dan memberikan es di atasnya  untuk penyimpanan sementara. Memasukan ikan yang tidak dapat digunakan ke gerobak dan membuangnya ke area pembuangan. Dapat membantu awak kapal di sekitar dock. dapat membersihkan ikan [Pembersih ikan, memancing & berburu].",
        "descriptionEng": "Unloads catch from fishing vessels and conveys fish from wharf to fish-dressing or storage area, performing any combination of following tasks. Loads cargo net, crane bucket, or conveyor with catch from hold of boat, by hand or with shovel or pew hooked prong. Dumps catch from cargo net or crane bucket onto dock platform, and sorts catch according to species, size, or grade. Pushes cart of fish to fish-cleaning tables and dumps fish on table, or piles fish on floor and covers them with chipped ice for temporary storage. Shovels fish scrap into cart and pushes cart to disposal area. May assist boat crew in mooring boat at dock.May clean fish [Fish Cleaner; fishing and hunt.]",
        "clazz": "3",
        "$$hashKey": "object:3461"
    },
    {
        "nameEng": "Coach driver / Breakdown recovery driver",
        "code": "CODR",
        "gender": "All",
        "nameInd": "Pengemudi bus / Pengemudi pemulihan kerusakan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengendarai bus dalam atau luar kota",
        "descriptionEng": "Person who drives a bus either intra or inter city.",
        "clazz": "3",
        "$$hashKey": "object:4205"
    },
    {
        "nameEng": "Bus driver",
        "code": "BUSD",
        "gender": "All",
        "nameInd": "Pengemudi bus",
        "minAge": "0",
        "descriptionInd": "",
        "descriptionEng": "",
        "clazz": "3",
        "$$hashKey": "object:4204"
    },
    {
        "nameEng": "Tour driver",
        "code": "TODR",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Kendaraan Tur Wisata",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengendarai kendaraan yang digunakan untuk tur atau bepergian.",
        "descriptionEng": "A person who drive a vehicle which used for a tour and travelling purpose.",
        "clazz": "2",
        "$$hashKey": "object:4196"
    },
    {
        "nameEng": "Construction driver",
        "code": "DRIV",
        "gender": "All",
        "nameInd": "Pengemudi konstruksi",
        "minAge": "0",
        "descriptionInd": "pengemudi konstruksi adalah seseorang yang pekerjaanya adalah mengendarai kendaraan di lokasi konstruksi",
        "descriptionEng": "A construction driver is someone whose job is driving vehicle on a construction site.",
        "clazz": "3",
        "$$hashKey": "object:4214"
    },
    {
        "nameEng": "Coal delivery driver",
        "code": "COAL",
        "gender": "All",
        "nameInd": "Pengemudi pengiriman batu bara",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengendarai kendaraan yang membawa batu bara",
        "descriptionEng": "Person who drives a vehicle that caries coal.",
        "clazz": "3",
        "$$hashKey": "object:4217"
    },
    {
        "nameEng": "Light goods vehicle driver",
        "code": "LIGH",
        "gender": "All",
        "nameInd": "Pengemudi kendaraan barang ringan",
        "minAge": "0",
        "descriptionInd": "pekerjaan seorang pengemudi light truck fokus kepada agar jadwal penjemputan dan pengambilan harian lebih efisien. Dia juga diharapkan untuk membandingkan dokumen pengiriman dengan pengirimannya untuk mengkonfirmasi bobot dan penerima dan memastikan tanda tangan yang diperlukan diperoleh. Jika ada ketidaksesuaian ditemukan dalam dokumen pengiriman atau paket, itu adalah tanggung jawab pengemudi truk ringan untuk menyelesaikannya.",
        "descriptionEng": "The job focus for a light truck driver is to efficiently schedule daily pick-ups and deliveries. She is also expected to compare shipping documents with her freight to confirm weights and addressees and ensure required signatures are obtained. If any discrepancies are discovered in the delivery documents or packages, it is the light truck driver's responsibility to resolve them.",
        "clazz": "3",
        "$$hashKey": "object:4211"
    },
    {
        "nameEng": "Postal Delivery Driver",
        "code": "POSD",
        "gender": "All",
        "nameInd": "Pengemudi pengiriman pos",
        "minAge": "0",
        "descriptionInd": "dibutuhkan untuk mengirim surat, parsel, dan kartu ke perusahaan atau rumah",
        "descriptionEng": "is required to deliver letters, parcels, and cards to businesses and homes.",
        "clazz": "2",
        "$$hashKey": "object:4218"
    },
    {
        "nameEng": "Chauffeur/Private Driver",
        "code": "PRID",
        "gender": "All",
        "nameInd": "Supir pribadi",
        "minAge": "0",
        "descriptionInd": "seseorang yang dipekerjakan untuk mengendarai penumpang motor, dan biasana mereka selalu mengendarai kendaraan mereka sendiri",
        "descriptionEng": "A person employed to drive a passenger motor vehicle, and usually they always drives the personal  vehicle owner.",
        "clazz": "2",
        "$$hashKey": "object:4596"
    },
    {
        "nameEng": "Postman",
        "code": "POST",
        "gender": "All",
        "nameInd": "Pengirim Surat Keliling(Tukang Pos)",
        "minAge": "0",
        "descriptionInd": "Seorang pegawai kantor pos atau jasa pos, yang mengantarkan surat dan bingkisan ke rumah-rumah atau kantor. Mereka juga mengambil surat dari tempat kerja, kantor pos, kotak pos di suatu area. Mereka berjalan untuk mengantarkan surat dengan mengendarai sepeda atau mobil tergantung dari lokasi dan ukuran paket.",
        "descriptionEng": "is an employee of the post office or postal service, who delivers mail and parcel post to residences and businesses. These workers can also collect letters from places of work, post offices and post boxes within a district. They walk to deliver letters and also drive bicycles and cars depending on location and package size.",
        "clazz": "2",
        "$$hashKey": "object:4241"
    },
    {
        "nameEng": "Van driver",
        "code": "VLAS",
        "gender": "All",
        "nameInd": "Pengemudi van",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengendaarai kendaraan van",
        "descriptionEng": "a person who drives van vehicle.",
        "clazz": "2",
        "$$hashKey": "object:4221"
    },
    {
        "nameEng": "Driving examiner / Driving instructor",
        "code": "COAC",
        "gender": "All",
        "nameInd": "Penguji berkendara / Instruktur berkendara",
        "minAge": "0",
        "descriptionInd": "Orang yang mengajarkan cara mengemudi kendaraan bermotor dan berlisensi.",
        "descriptionEng": "Person who instruct a person how to drive a car and licensed.",
        "clazz": "3",
        "$$hashKey": "object:4261"
    },
    {
        "nameEng": "Heavy goods vehicle driver / Lorry  driver / Truck driver",
        "code": "HEAV",
        "gender": "All",
        "nameInd": "Pengemudi kendaraan barang berat / Pengemudi lori / Pengemudi truk",
        "minAge": "0",
        "descriptionInd": "pengemudi kendaraan beban berat (lori atau truk) adalah seseorang yang mengendarai kendaraan beban bera (lori atau truk)",
        "descriptionEng": "Heavy-goods Vehicle (Lorry or Truck) Driver is someone who drives a Heavy-goods Vehicle (Lorry or Truck).",
        "clazz": "3",
        "$$hashKey": "object:4210"
    },
    {
        "nameEng": "Excavator driver",
        "code": "EXCA",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Excavator",
        "minAge": "0",
        "descriptionInd": "Supir ekskavator adalah orang yang mengemudikan alat ekskavator.",
        "descriptionEng": "An excavator driver is someone whose job is driving or operating excavator.",
        "clazz": "3",
        "$$hashKey": "object:4192"
    },
    {
        "nameEng": "Minicab driver / Mobile shop driver",
        "code": "MOSD",
        "gender": "All",
        "nameInd": "Pengemudi minicab / Pengemudi toko keliling",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengendarai kendaraan jajanan berjalan. Kendaraan jajanan berjalan adalah kendaraan komersial yang dapat berubah menjadi booth, seperti van es krim",
        "descriptionEng": "A person who drives mobile shop vehicle. Mobile shop vehicle is a commercial vehicle that can transformed into a formed of shopping stall, such as ice cream van.",
        "clazz": "2",
        "$$hashKey": "object:4215"
    },
    {
        "nameEng": "Taxi driver",
        "code": "TAXI",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Taxi",
        "minAge": "0",
        "descriptionInd": "seseorang yang pekerjaannya adalah mengendarai taksi",
        "descriptionEng": "a person whose job is to drive a taxi.",
        "clazz": "2",
        "$$hashKey": "object:4202"
    },
    {
        "nameEng": "Rickshaw man / Tuk tuk driver / Auto rickshaw driver",
        "code": "RICK",
        "gender": "All",
        "nameInd": "Petugas angkong / Pengemudi tuk tuk / Pengemudi angkong otomatis",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengendarai kendaraan rickshaw",
        "descriptionEng": "a person who drives rickshaw",
        "clazz": "3",
        "$$hashKey": "object:4415"
    },
    {
        "nameEng": "Drayman / Roundsman driver",
        "code": "DRAY",
        "gender": "All",
        "nameInd": "Pengantar kontainer / Pengemudi penjaja keliling",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengantar bir untuk diolah",
        "descriptionEng": "a person who delivers beer for a brewery.",
        "clazz": "3",
        "$$hashKey": "object:4145"
    },
    {
        "nameEng": "Electrical plant attendant",
        "code": "ELPA",
        "gender": "All",
        "nameInd": "Petugas pembangkit listrik",
        "minAge": "0",
        "descriptionInd": "Petugas instalasi listrik",
        "descriptionEng": "someone who fits electricity",
        "clazz": "3",
        "$$hashKey": "object:4464"
    },
    {
        "nameEng": "Dumper shovel driver / Mechanical shovel driver",
        "code": "DUMP",
        "gender": "All",
        "nameInd": "Pengemudi shovel dumper / Pengemudi shovel mekanik",
        "minAge": "0",
        "descriptionInd": "mengemudi truk dilengkapi dengan bodi berbentuk dump yang mengangkut dan membuat material sisa, seperti pasir, kerikil, batu hancur, batu bara, atau material paving aspal: Menarik tuas atau memutar engkol untuk memiringkan bodi dan membuang isinya.",
        "descriptionEng": "Drives truck equipped with dump body to transport and dump loose materials, such as sand, gravel, crushed rock, coal, or bituminous paving materials: Pulls levers or turns crank to tilt body and dump contents.",
        "clazz": "3",
        "$$hashKey": "object:4219"
    },
    {
        "nameEng": "Road patrolman",
        "code": "ROAD",
        "gender": "All",
        "nameInd": "Patroli jalanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi dan memastikan kepatuhan akan keselamatan lalu lintas di jalan dan jalan tol",
        "descriptionEng": "a person who oversees and enforces traffic safety compliance on roads and highways,�",
        "clazz": "3",
        "$$hashKey": "object:3833"
    },
    {
        "nameEng": "Dancing teacher (private) / Drama teacher (private) / Music teacher (private) / Physical education (PE) teacher",
        "code": "TEAC",
        "gender": "All",
        "nameInd": "Guru tari (privat) / Guru drama (privat) / Guru musik (privat) / Guru olahraga",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengajar suatu materi dan pelajaran di sekolah atau universitass",
        "descriptionEng": "A person who teaches material and subject in school or university.",
        "clazz": "1",
        "$$hashKey": "object:3520"
    },
    {
        "nameEng": "Sport Teacher (School)",
        "code": "SPRT",
        "gender": "All",
        "nameInd": "Guru OlahRaga",
        "minAge": "0",
        "descriptionInd": "Guru yang mengajar bidang olahraga.",
        "descriptionEng": "A teacher who teaches sports subject in school.",
        "clazz": "2",
        "$$hashKey": "object:3517"
    },
    {
        "nameEng": "Road safety officer / Schools inspector / Education inspector / Education officer",
        "code": "ROSO",
        "gender": "All",
        "nameInd": "Staf keselamatan jalanan / Inspektur sekolah / Inspektur pendidikan / Staf pendidikan /",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengevaluasi sekolah untuk memastikan standar spesifik sekolah",
        "descriptionEng": "a person who evaluates schools to ensure that specific standards in teaching",
        "clazz": "2",
        "$$hashKey": "object:4564"
    },
    {
        "nameEng": "Nursery assistant",
        "code": "NRSA",
        "gender": "All",
        "nameInd": "Asisten perawat",
        "minAge": "0",
        "descriptionInd": "membantu menjaga anak kecil. Mereka merencanakan dan mengorganisasi aktivitas bermain dan belajar dan menjaga kebutuhan pribadi anak-anak",
        "descriptionEng": "assists in the care of young children. They plan and organise both fun and educational activities and take care of children's personal needs.",
        "clazz": "3",
        "$$hashKey": "object:3434"
    },
    {
        "nameEng": "Vocational training instructor / Vocational Counselor",
        "code": "VOCC",
        "gender": "All",
        "nameInd": "Konselor Pelatihan",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas memberikan pelatihan kepada orang-orang dengan gangguan fungsional, psikologis, perkembangan, kognitif, emosional maupun kondisi kesehatan tertentu untuk kembali menjadi produktif atau pekerja aktif.",
        "descriptionEng": "A person whose job to give counselling to enables persons with functional, psychological, developmental, cognitive and emotional impairments or health conditions to overcome barriers to accessing, maintaining or returning to employment or other useful occupation.",
        "clazz": "1",
        "$$hashKey": "object:3633"
    },
    {
        "nameEng": "Youth leader  / School youth leader / College youth leader / Youth leader (educational institution)",
        "code": "YOTH",
        "gender": "All",
        "nameInd": "Ketua organisasi pemuda  / Ketua organisasi pemuda sekolah / Ketua organisasi pemuda kampus / Ketua organisasi pemuda lembaga pendidikan)",
        "minAge": "0",
        "descriptionInd": "sekelompok pemuda yang memimpin di sekolah atau universitas",
        "descriptionEng": "a group of youth who leads",
        "clazz": "1",
        "$$hashKey": "object:3618"
    },
    {
        "nameEng": "Teaching assistant (full time) / School teaching assistant (full time)",
        "code": "TCHA",
        "gender": "All",
        "nameInd": "Asisten pengajar (purnawaktu) / Asisten pengajar sekolah (purnawaktu)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengajar pelajaran",
        "descriptionEng": "someone who teaches subjects in schools or universities",
        "clazz": "1",
        "$$hashKey": "object:3431"
    },
    {
        "nameEng": "School teacher (full time)",
        "code": "TEAF",
        "gender": "All",
        "nameInd": "Guru sekolah (purnawaktu)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengajarkan materi dan mata pelajaran di sekolah atau universitas.",
        "descriptionEng": "A person who teaches material and subject in school or university.",
        "clazz": "1",
        "$$hashKey": "object:3519"
    },
    {
        "nameEng": "Ambulance controller",
        "code": "AMBC",
        "gender": "All",
        "nameInd": "Pengontrol ambulans",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja dalam lingkup perawatan medis di ambulance",
        "descriptionEng": "someone who works in a medical care in ambulance",
        "clazz": "3",
        "$$hashKey": "object:4245"
    },
    {
        "nameEng": "Fire prevention officer / Fire prevention researcher",
        "code": "FIPO",
        "gender": "All",
        "nameInd": "Petugas pencegahan kebakaran / Peneliti pencegah kebakaran",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memiliki ilmu pengetahuan dan tanggung jawab atas pencegahan bahaya/musibah kebakaran",
        "descriptionEng": "someone who has knowledge dan is responsible for danger or fire prevention",
        "clazz": "2",
        "$$hashKey": "object:4469"
    },
    {
        "nameEng": "Firefighter",
        "code": "FIRE",
        "gender": "All",
        "nameInd": "Pemadam kebakaran",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang terlatih untuk memadamkan kebakaran, untuk memadamkan api yang berbahaya yang mengancam perumahan dan menyelamatkan orang-orang dari situasi berbahaya.",
        "descriptionEng": "Fireman or firefighter are rescuers extensively trained in firefighting, primarily to extinguish hazardous fires that threaten property and  to rescue people from dangerous situations.",
        "clazz": "3",
        "$$hashKey": "object:3944"
    },
    {
        "nameEng": "Fire service senior officer",
        "code": "FSSO",
        "gender": "All",
        "nameInd": "Staf senior layanan pemadam kebakaran",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja dalam bidang keahlian pemadaman kebakaran",
        "descriptionEng": "someone who works in the field of fire service",
        "clazz": "1",
        "$$hashKey": "object:4580"
    },
    {
        "nameEng": "Fire station manager",
        "code": "FSTM",
        "gender": "All",
        "nameInd": "Manajer pos pemadam kebakaran",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja dalam bidang keahlian pemadaman kebakaran",
        "descriptionEng": "someone who works in the field of fire service",
        "clazz": "3",
        "$$hashKey": "object:3699"
    },
    {
        "nameEng": "Lifeboat enrolled crew",
        "code": "LFBO",
        "gender": "All",
        "nameInd": "Kru sekoci penyelamat",
        "minAge": "0",
        "descriptionInd": "Bekerja pada bidang penyelamatan menggunakan sekoci/kapal penyelamat",
        "descriptionEng": "someone who works in the field of rescue by using lifeboat",
        "clazz": "3",
        "$$hashKey": "object:3655"
    },
    {
        "nameEng": "Maritime inspector / Maritime rescue inspector",
        "code": "MNTI",
        "gender": "All",
        "nameInd": "Inspektur maritim / Inspektur penyelamatan maritim",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab dalam pemeriksaan keselamatan kapal",
        "descriptionEng": "someone who is responsible for checking the boat's safety",
        "clazz": "3",
        "$$hashKey": "object:3567"
    },
    {
        "nameEng": "Maritime mechanic",
        "code": "MNTM",
        "gender": "All",
        "nameInd": "Mekanik maritim",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab atas prinsip mekanisasi dari kapal",
        "descriptionEng": "someone who is responsible for mechanical principal of the boat",
        "clazz": "3",
        "$$hashKey": "object:3731"
    },
    {
        "nameEng": "Police support staff / Police force support staff",
        "code": "POLS",
        "gender": "All",
        "nameInd": "Staf pendukung polisi / Staf pendukung pasukan polisi",
        "minAge": "0",
        "descriptionInd": "Seseorang yg memiliki berbagai macam tugas/peran utk mendukung petugas polisi utama",
        "descriptionEng": "someone who has variety of tasks or roles to support the main police officer",
        "clazz": "3",
        "$$hashKey": "object:4569"
    },
    {
        "nameEng": "Electrical meter collector / Electrical meter reader",
        "code": "ELMC",
        "gender": "All",
        "nameInd": "Kolektor meteran listrik / Pembaca meteran listrik",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memiliki tugas mengumpulkan informasi mengenai data pencatatan meteran listrik",
        "descriptionEng": "someone who has duties to collect information regarding electric meter record data",
        "clazz": "2",
        "$$hashKey": "object:3624"
    },
    {
        "nameEng": "Electrical supply inspector",
        "code": "ELSI",
        "gender": "All",
        "nameInd": "Inspektur suplai listrik",
        "minAge": "0",
        "descriptionInd": "Bertugas mengawasi pasokan listrik",
        "descriptionEng": "assigned to supervise electrical supply",
        "clazz": "2",
        "$$hashKey": "object:3568"
    },
    {
        "nameEng": "Bingo attendant",
        "code": "BNGO",
        "gender": "All",
        "nameInd": "Petugas bingo",
        "minAge": "0",
        "descriptionInd": "seseorang yang bertugas di bingo",
        "descriptionEng": "someone who attends bingo",
        "clazz": "3",
        "$$hashKey": "object:4419"
    },
    {
        "nameEng": "Installation electrician / Maintenance electrician / Electrical installation fitter / Electrical meter fixer",
        "code": "ELIF",
        "gender": "All",
        "nameInd": "Teknisi instalasi listrik / Teknisi pemeliharaan listrik / Petugas pemasang instalasi listrik / Pemasang meteran listrik",
        "minAge": "0",
        "descriptionInd": "Bekerja dalam bidang pemasangan aliran listrik",
        "descriptionEng": "someone who works in an installation electrician",
        "clazz": "3",
        "$$hashKey": "object:4605"
    },
    {
        "nameEng": "Electrical machinery tester / Electrical plant tester / Cable tester / Electrical meter tester",
        "code": "ELMA",
        "gender": "All",
        "nameInd": "Penguji mesin listrik / Penguji pembangkit listrik / Penguji kabel / Penguji meteran listrik",
        "minAge": "0",
        "descriptionInd": "Bekerja dalam bidang pemasangan aliran listrik",
        "descriptionEng": "someone who works in an installation electrician",
        "clazz": "3",
        "$$hashKey": "object:4264"
    },
    {
        "nameEng": "Electrical machinery cleaner / Boiler cleaner",
        "code": "EMHC",
        "gender": "All",
        "nameInd": "Pembersih mesin listrik / Pembersih mesin boiler",
        "minAge": "0",
        "descriptionInd": "Petugas pembersihan mesin listrik",
        "descriptionEng": "someone who cleans electrical machinery",
        "clazz": "3",
        "$$hashKey": "object:4004"
    },
    {
        "nameEng": "Cable jointer",
        "code": "CBJT",
        "gender": "All",
        "nameInd": "Pengelas Kabel",
        "minAge": "0",
        "descriptionInd": "Orang yang menyambungkan kabel dan memastikan peralatan elektronik bekerja dengan baik.",
        "descriptionEng": "Person who joins the cable wires & ensures electronic/electrical applicance is working.",
        "clazz": "3",
        "$$hashKey": "object:4173"
    },
    {
        "nameEng": "Electrical linesman",
        "code": "ELIN",
        "gender": "All",
        "nameInd": "Tukang kabel listrik",
        "minAge": "0",
        "descriptionInd": "Petugas di bidang kelistrikan",
        "descriptionEng": "someone who works in electricity",
        "clazz": "3",
        "$$hashKey": "object:4670"
    },
    {
        "nameEng": "Electrical process worker",
        "code": "ELEP",
        "gender": "All",
        "nameInd": "Pekerja proses listrik",
        "minAge": "0",
        "descriptionInd": "Petugas di bidang proses perlistrikan",
        "descriptionEng": "someone who works in electric process",
        "clazz": "3",
        "$$hashKey": "object:3900"
    },
    {
        "nameEng": "Control room operator (gas supply) / Valveman (gas supply)",
        "code": "COPR",
        "gender": "All",
        "nameInd": "Operator ruang kontrol (suplai gas) / Petugas katup (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas di bidang yang berhubungan dengan pasokan gas",
        "descriptionEng": "someone who works in relation to gas supply",
        "clazz": "3",
        "$$hashKey": "object:3821"
    },
    {
        "nameEng": "Home service adviser (gas supply)",
        "code": "HOMS",
        "gender": "All",
        "nameInd": "Penasihat layanan rumah (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Petugas pemberi informasi mengenai pasokan gas",
        "descriptionEng": "someone who informs about gas supply",
        "clazz": "2",
        "$$hashKey": "object:4103"
    },
    {
        "nameEng": "Meter collector (gas supply) / Meter reader (gas supply) / Meter tester (gas supply)",
        "code": "METC",
        "gender": "All",
        "nameInd": "Kolektor meteran (suplai gas) / Pembaca meteran (suplai gas) / Penguji meteran (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas di bidang yang berhubungan dengan pasokan gas",
        "descriptionEng": "someone who works in relation to gas supply",
        "clazz": "2",
        "$$hashKey": "object:3623"
    },
    {
        "nameEng": "Gas inspector",
        "code": "GSIN",
        "gender": "All",
        "nameInd": "Inspektur gas",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab dalam pemeriksaan pasokan gas",
        "descriptionEng": "someone who is responsible for checking gas  supply",
        "clazz": "2",
        "$$hashKey": "object:3565"
    },
    {
        "nameEng": "Conveyor operator (gas supply)",
        "code": "GSCO",
        "gender": "All",
        "nameInd": "Operator konveyor (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas di bidang yang berhubungan dengan pengangkutanpasokan gas",
        "descriptionEng": "someone who transports gas supply",
        "clazz": "3",
        "$$hashKey": "object:3779"
    },
    {
        "nameEng": "Gas appliance mechanic / Gas compressor operator / Exhausterman  / Exhausterman (gas suppy)",
        "code": "GASM",
        "gender": "All",
        "nameInd": "Mekanik peralatan gas / Operator kompresor gas / Tukang pembuangan / Tukang pembuangan  (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas di bidang yang berhubungan dengan perbaikan peralatan gas",
        "descriptionEng": "someone who repairs gas supply",
        "clazz": "3",
        "$$hashKey": "object:3733"
    },
    {
        "nameEng": "Gas fitter / Gas fittings tester / Gas holder attendant / Pipe fitter (gas supply)",
        "code": "GAST",
        "gender": "All",
        "nameInd": "Petugas pemasang gas / Penguji tatakan gas / Penjaga penahan gas / Petugas pemasang pipa (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas di bidang yang berhubungan dengan perbaikan peralatan gas",
        "descriptionEng": "someone who repairs gas supply",
        "clazz": "3",
        "$$hashKey": "object:4457"
    },
    {
        "nameEng": "Gas cylinder tester",
        "code": "GASC",
        "gender": "All",
        "nameInd": "Penguji silinder gas",
        "minAge": "0",
        "descriptionInd": "Pekerja bidang pengujian peralatan gas",
        "descriptionEng": "someone who tests gas equipment",
        "clazz": "3",
        "$$hashKey": "object:4266"
    },
    {
        "nameEng": "Rigger (gas supply)",
        "code": "RIGS",
        "gender": "All",
        "nameInd": "Juru ikat (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang pasokan gas",
        "descriptionEng": "gas supply wroker",
        "clazz": "3",
        "$$hashKey": "object:3582"
    },
    {
        "nameEng": "Tanker filler (gas supply)",
        "code": "TNKF",
        "gender": "All",
        "nameInd": "Pengisi tanker (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang pasokan gas",
        "descriptionEng": "gas supply wroker",
        "clazz": "3",
        "$$hashKey": "object:4242"
    },
    {
        "nameEng": "Pipe layer (gas supply)",
        "code": "PIPL",
        "gender": "All",
        "nameInd": "Pelapis pipa (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang pipa pasokan gas",
        "descriptionEng": "someone who works in gas pipe supply",
        "clazz": "3",
        "$$hashKey": "object:3919"
    },
    {
        "nameEng": "Loader operator (gas supply)",
        "code": "LOAP",
        "gender": "All",
        "nameInd": "Operator pemuat (suplai gas)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang pasokan gas",
        "descriptionEng": "vehicle that loads goods",
        "clazz": "3",
        "$$hashKey": "object:3809"
    },
    {
        "nameEng": "Gas cylinder preparer",
        "code": "GACY",
        "gender": "All",
        "nameInd": "Penyiap silinder gas",
        "minAge": "0",
        "descriptionInd": "Pekerja bidang pengujian peralatan gas",
        "descriptionEng": "someone who tests gas equipment",
        "clazz": "3",
        "$$hashKey": "object:4363"
    },
    {
        "nameEng": "Health physics monitor (nuclear energy)",
        "code": "HPMO",
        "gender": "All",
        "nameInd": "Monitor fisik kesehatan (energi nuklir)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di bidang pemantauan kesehatan fisik",
        "descriptionEng": "someone who works",
        "clazz": "2",
        "$$hashKey": "object:3741"
    },
    {
        "nameEng": "Health physicist (nuclear energy) / Radiation protection adviser",
        "code": "PHSY",
        "gender": "All",
        "nameInd": "Ahli ilmu fisika kesehatan (energi nuklir) / Penasihat perlindungan radiasi",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di bidang pemantauan kesehatan fisik",
        "descriptionEng": "someone who monitors physical health",
        "clazz": "2",
        "$$hashKey": "object:3344"
    },
    {
        "nameEng": "Nuclear decommissioning engineer",
        "code": "NUCD",
        "gender": "All",
        "nameInd": "Insinyur penonaktifan nuklir",
        "minAge": "0",
        "descriptionInd": "Insinyur di bidang nuklir",
        "descriptionEng": "nuclear engineer",
        "clazz": "2",
        "$$hashKey": "object:3550"
    },
    {
        "nameEng": "Scientist (nuclear energy)",
        "code": "SCIE",
        "gender": "All",
        "nameInd": "Peneliti (energi nuklir)",
        "minAge": "0",
        "descriptionInd": "Ilmuwan di bidang nuklir",
        "descriptionEng": "nuclear scientist",
        "clazz": "2",
        "$$hashKey": "object:4125"
    },
    {
        "nameEng": "Fitter (nuclear energy)",
        "code": "FITT",
        "gender": "All",
        "nameInd": "Petugas pemasang (energi nuklir)",
        "minAge": "0",
        "descriptionInd": "Petugas di bidang energi nuklir",
        "descriptionEng": "nuclear energy worker",
        "clazz": "3",
        "$$hashKey": "object:4456"
    },
    {
        "nameEng": "Maintenance technician (nuclear energy) / Nuclear plant attendant / Nuclear plant operator",
        "code": "NUCP",
        "gender": "All",
        "nameInd": "Teknisi pemeliharaan (energi nuklir) / Penjaga pembangkit nuklir / Operator pembangkit nuklir",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas di bidang perawatan energi nuklir",
        "descriptionEng": "someone who works in nuclear energy  maintenance",
        "clazz": "3",
        "$$hashKey": "object:4623"
    },
    {
        "nameEng": "Nuclear Plant Decontamination Technician",
        "code": "NPDT",
        "gender": "All",
        "nameInd": "Teknisi Pabrik Nuklir Dekontaminasi",
        "minAge": "0",
        "descriptionInd": "1) Melakukan penelitian dan menganalisa dan mengevaluasi metode yang diusulkan dan yang sudah ada transportasi, penanganan, dan penyimpanan bahan bakar nuklir untuk menghalangi reaksi nuklir kecelakaan di fasilitas nuklir: Ulasan dan mengevaluasi pemindahan bahan bakar dan rencana penyimpanan yang diterima dari pembangkit nuklir. 2) Melakukan studi laporan karakteristik bahan bakar nuklir untuk menentukan masalah potensial 3) Memperkirakan kekritisan bahan bakar nuklir, mengingat berbagai faktor yang mungkin ada dalam penanganan bahan bakar dan penyimpanan, dengan menggunakan pengetahuan fisika nuklir, kalkulator, dan terminal komputer.4) Menentukan potensi bahaya dan kondisi kecelakaan yang mungkin ada dalam penanganan bahan bakar dan penyimpanan dan merekomendasikan langkah-langkah pencegahan.",
        "descriptionEng": "1) Conducts research and analyzes and evaluates proposed and existing methods of transportation, handling, and storage of nuclear fuel to preclude accidental nuclear reaction at nuclear facilities: Reviews and evaluates fuel transfer and storage plans received from nuclear plants. 2) Studies reports of nuclear fuel characteristics to determine potential or inherent problems. 3) Forecasts nuclear fuel criticality, given various factors which may exist in fuel handling and storage, using knowledge of nuclear physics, calculator, and computer terminal. 4) Determines potential hazards and accident conditions which may exist in fuel handling and storage and recommends preventive measures.",
        "clazz": "3",
        "$$hashKey": "object:4621"
    },
    {
        "nameEng": "Watchstander (oil and natural gas production)",
        "code": "WTCS",
        "gender": "All",
        "nameInd": "Rekan navigasi (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "rekan yang dipercaya untuk mengoperaikan kapal secara berkelanjutan",
        "descriptionEng": "qualified personnel to operate a ship continuously",
        "clazz": "3",
        "$$hashKey": "object:4532"
    },
    {
        "nameEng": "Geologist (oil and natural gas production) GeophysicistSeismologist (oil and natural gas production)",
        "code": "OGST",
        "gender": "All",
        "nameInd": "Ahli geologi (produksi minyak dan gas alam)Ahli geofisikaAhli seismologi (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Geologist adalah seorang ilmuwan yang mempelajari materi padat dan cair serta proses terjadinya bumi.",
        "descriptionEng": "geologist is a scientist who studies solid and liquid material and the making of the earth",
        "clazz": "3",
        "$$hashKey": "object:3338"
    },
    {
        "nameEng": "Inspector (oil and natural gas production)",
        "code": "INOG",
        "gender": "All",
        "nameInd": "Inspektur (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab dalam pemeriksaan produksi minyak dan gas bumi",
        "descriptionEng": "someone who is responsible for checking oil and natural gas production",
        "clazz": "3",
        "$$hashKey": "object:3563"
    },
    {
        "nameEng": "Offshore installation manager (oil and natural gas production)",
        "code": "OFFS",
        "gender": "All",
        "nameInd": "Manajer instalasi lepas pantai (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas di bidang instalasi lepas pantai minyak dan gas bumi",
        "descriptionEng": "someone who installs oil and natural gas offshore",
        "clazz": "3",
        "$$hashKey": "object:3679"
    },
    {
        "nameEng": "Drilling supervisor (oil and natural gas production)",
        "code": "DRLS",
        "gender": "All",
        "nameInd": "Pengawas pengeboran (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas di bidang penngawasan pengeboran pantai minyak dan gas bumi",
        "descriptionEng": "someone who supervises drilling in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:4162"
    },
    {
        "nameEng": "Captain (oil and natural gas production)",
        "code": "CPTA",
        "gender": "All",
        "nameInd": "Kapten (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Kapten di bidang minyak dan gas bumi",
        "descriptionEng": "captain in oill and natural gas production",
        "clazz": "3",
        "$$hashKey": "object:3592"
    },
    {
        "nameEng": "Safety officer (oil and natural gas production)",
        "code": "SAFO",
        "gender": "All",
        "nameInd": "Staf keselamatan (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas yang bertanggung jawab di bidang  kesehatan dan keselamatan para tenaga kerja di bidang produksi minyak dan gas bumi",
        "descriptionEng": "someone who is responsible for the health and safety of oil and natural gas production workers",
        "clazz": "3",
        "$$hashKey": "object:4563"
    },
    {
        "nameEng": "Radio operator (oil and natural gas production) / Radiographer (oil and natural gas production)",
        "code": "RADO",
        "gender": "All",
        "nameInd": "Operator radio (produksi minyak dan gas alam) / Ahli teknologi radiologi (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas operator radio bidang gas dan minyak bumi",
        "descriptionEng": "operator  radio  worker in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:3816"
    },
    {
        "nameEng": "Catering staff (oil and natural gas production)",
        "code": "CTST",
        "gender": "All",
        "nameInd": "Staf katering (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas penyedia makanan dan minuman d",
        "descriptionEng": "someone who keeps food and drink supply",
        "clazz": "3",
        "$$hashKey": "object:4559"
    },
    {
        "nameEng": "Clerical staff (oil and natural gas production) / Clerical staff (energy and utilities/handling goods)",
        "code": "CLTY",
        "gender": "All",
        "nameInd": "Petugas Administrasi (produksi minyak dan gas alam) / Petugas Administrasi (Bidang energi)",
        "minAge": "0",
        "descriptionInd": "Petugas admin di bidang gas dan minyak bumi",
        "descriptionEng": "an admin in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:4412"
    },
    {
        "nameEng": "Foreman (oil and natural gas production) / Site foreman (oil and natural gas production) / Construction superintendent (oil and natural gas production)",
        "code": "OGFR",
        "gender": "All",
        "nameInd": "Mandor (produksi minyak dan gas alam) / Mandor situs (produksi minyak dan gas alam) / Pengawas konstruksi (produksi  minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas yang bekerja sebagai mandor/pengawas lokasi di bidang gas dan minyak bumi",
        "descriptionEng": "someone who works as foreman or supervisor in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:3712"
    },
    {
        "nameEng": "Remote operated vehicle (oil and natural gas production) / ROV operator (oil and natural gas production)",
        "code": "RMOT",
        "gender": "All",
        "nameInd": "Operasi kendaraan jarak jauh (produksi minyak dan gas alam) / Operator ROV (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas operator kendaraan yang dapat dikendalikan dari jauh di bidang gas dan minyak bumi",
        "descriptionEng": "vehicle operator that can be controlled from afar in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:3753"
    },
    {
        "nameEng": "Storekeeper (oil and natural gas production)",
        "code": "OISK",
        "gender": "All",
        "nameInd": "Penjaga gudang (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "penjaga toko (produksi minyak dan gas bumi)",
        "descriptionEng": "storekeeper",
        "clazz": "3",
        "$$hashKey": "object:4301"
    },
    {
        "nameEng": "Valveman (oil and natural gas production)",
        "code": "VLVE",
        "gender": "All",
        "nameInd": "Petugas katup (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas yang bertanggung jawab atas fungsi valve di mesin produksi gas dan minyak bumi",
        "descriptionEng": "someone who is responsible for valve functions in oild and natural gas production",
        "clazz": "3",
        "$$hashKey": "object:4431"
    },
    {
        "nameEng": "Crane operator (oil and natural gas production)",
        "code": "CRNO",
        "gender": "All",
        "nameInd": "Operator derek (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Operator crane (produksi minyak dan gas bumi)",
        "descriptionEng": "crane operator (oil and natural gas production)",
        "clazz": "3",
        "$$hashKey": "object:3765"
    },
    {
        "nameEng": "Control room operator (oil and natural gas production)",
        "code": "CNRO",
        "gender": "All",
        "nameInd": "Operator ruang kontrol (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas operator ruang kontrol utama dalam bidang produksi minyak dan gas bumi",
        "descriptionEng": "main control room operator in oil and natural gas production",
        "clazz": "3",
        "$$hashKey": "object:3820"
    },
    {
        "nameEng": "Engineer (oil and natural gas production) / Mud engineer (oil and natural gas production) / Sub-sea engineer (oil and natural gas production)",
        "code": "EGME",
        "gender": "All",
        "nameInd": "Insinyur (produksi minyak dan gas alam) / Insinyur lumpur (produksi minyak dan gas alam) / Insinyur bawah laut (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Insinyur di bidang produksi gas dan minyak bumi",
        "descriptionEng": "oil and natural gas production engineer",
        "clazz": "3",
        "$$hashKey": "object:3529"
    },
    {
        "nameEng": "Bargemaster (oil and natural gas production)",
        "code": "BRGM",
        "gender": "All",
        "nameInd": "Ahli kapal tongkang (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas yang bertanggung jawab atas semua kelengkapan dokumen maupun peralatan serta semua keperluan yang ada di kapal minyak/tongkang",
        "descriptionEng": "someone who is responsible for all the documents and equipments and needs in bargemaster",
        "clazz": "3",
        "$$hashKey": "object:3348"
    },
    {
        "nameEng": "Assistant tool pusher (oil and natural gas production) / Tool pusher (oil and natural gas production) / gang pusher",
        "code": "ASTP",
        "gender": "All",
        "nameInd": "Asisten pengarah pengeboran (produksi minyak dan gas alam) / Pengawas rig / Pengarah pengeboran (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas yang bertanggung jawab atas alat pendorong di bidang gas dan minyak bumi",
        "descriptionEng": "responsible for the tool pusher in oill and natural gas production",
        "clazz": "3",
        "$$hashKey": "object:3432"
    },
    {
        "nameEng": "Marine installation fitter (oil and natural gas production)",
        "code": "MIFT",
        "gender": "All",
        "nameInd": "Petugas pemasang instalasi laut (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di bidang instalasi kelautan",
        "descriptionEng": "someone who works in marine installation",
        "clazz": "3",
        "$$hashKey": "object:4458"
    },
    {
        "nameEng": "Motorman (oil and natural gas production)",
        "code": "MOTO",
        "gender": "All",
        "nameInd": "Pengemudi (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab di motor mesin gas dan minyak bumi",
        "descriptionEng": "someone who is responsible in oil and natural gas motor machinery",
        "clazz": "3",
        "$$hashKey": "object:4187"
    },
    {
        "nameEng": "Electric logger (oil and natural gas production) / Mud logger (oil and natural gas production) / Mud man (oil and natural gas production) / Well logger (oil and natural gas production)",
        "code": "ELMD",
        "gender": "All",
        "nameInd": "Logger elektrik (produksi minyak dan gas alam) / Penganalisa lumpur (produksi minyak dan gas lam) / Insinyur lumpur (produksi minyak dan gas alam) / Pencatat sumur (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorng yang menggali",
        "descriptionEng": "someone who digs",
        "clazz": "3",
        "$$hashKey": "object:3661"
    },
    {
        "nameEng": "Well tester (oil and natural gas production)",
        "code": "WLTS",
        "gender": "All",
        "nameInd": "Penguji sumur (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji sumur",
        "descriptionEng": "someone who tests well",
        "clazz": "3",
        "$$hashKey": "object:4267"
    },
    {
        "nameEng": "Pipe fitter (oil and natural gas production)",
        "code": "PIPF",
        "gender": "All",
        "nameInd": "Petugas pemasang pipa (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas pipa gas dan minyak bumi",
        "descriptionEng": "pipe fitter in oil and natural gas",
        "clazz": "3",
        "$$hashKey": "object:4460"
    },
    {
        "nameEng": "Wireline operator (oil and natural gas production)",
        "code": "WRLN",
        "gender": "All",
        "nameInd": "Operator kabel (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan kabel",
        "descriptionEng": "someone who operates wireline",
        "clazz": "3",
        "$$hashKey": "object:3769"
    },
    {
        "nameEng": "Painter (oil and natural gas production)",
        "code": "PNTO",
        "gender": "All",
        "nameInd": "Tukang cat (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengecat",
        "descriptionEng": "someone who paints",
        "clazz": "3",
        "$$hashKey": "object:4664"
    },
    {
        "nameEng": "Pumpman (oil and natural gas production)",
        "code": "PUMP",
        "gender": "All",
        "nameInd": "Petugas pompa (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas tukang pompa gas dan minyak bumi",
        "descriptionEng": "someone who pumps",
        "clazz": "3",
        "$$hashKey": "object:4484"
    },
    {
        "nameEng": "Rigger / Rigger (oil and natural gas production) / Rig electrician (oil and natural gas production) / Rig mechanic (oil and natural gas production)",
        "code": "RIGG",
        "gender": "All",
        "nameInd": "Petugas rig / Petugas rig (produksi minyak dan gas alam) / Teknisi listrik rig (produksi minyak dan gas alam) / Mekanik rig (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin rig",
        "descriptionEng": "someone who operates rigger",
        "clazz": "3",
        "$$hashKey": "object:4488"
    },
    {
        "nameEng": "Cathead man",
        "code": "CATH",
        "gender": "All",
        "nameInd": "Petugas cathead",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin  cathead",
        "descriptionEng": "someone who operates cathead",
        "clazz": "3",
        "$$hashKey": "object:4420"
    },
    {
        "nameEng": "Cementer (oil and natural gas production)",
        "code": "CMNT",
        "gender": "All",
        "nameInd": "Penyemen (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseoranng yang melakujkan pekerjaan semen",
        "descriptionEng": "someone who does cement",
        "clazz": "3",
        "$$hashKey": "object:4357"
    },
    {
        "nameEng": "Head roustabout",
        "code": "HDRO",
        "gender": "All",
        "nameInd": "Kepala ladang pengeboran",
        "minAge": "0",
        "descriptionInd": "Kepala pekerja kasar di kapal gas dan minyak bumi",
        "descriptionEng": "someone who leads the roustabout",
        "clazz": "3",
        "$$hashKey": "object:3604"
    },
    {
        "nameEng": "Derrickman",
        "code": "DRMN",
        "gender": "All",
        "nameInd": "Petugas rig pengeboran",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin derrick",
        "descriptionEng": "someone who operates derrick",
        "clazz": "3",
        "$$hashKey": "object:4489"
    },
    {
        "nameEng": "Floorman (oil and natural gas production)",
        "code": "FLOI",
        "gender": "All",
        "nameInd": "Pengoperasi pengeboran (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengebor",
        "descriptionEng": "someone who drills",
        "clazz": "3",
        "$$hashKey": "object:4256"
    },
    {
        "nameEng": "Roughneck / Roustabout",
        "code": "RGHN",
        "gender": "All",
        "nameInd": "Pekerja pengeboran minyak / Pekerja dermaga",
        "minAge": "0",
        "descriptionInd": "Pekerja kasar di kapal gas dan minyak bumi",
        "descriptionEng": "someone who operates roughneck",
        "clazz": "3",
        "$$hashKey": "object:3885"
    },
    {
        "nameEng": "Surveyor (oil and natural gas production)",
        "code": "SVYG",
        "gender": "All",
        "nameInd": "Pengamat (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas yang melakukan survei di bidang gas dan minyak bumi",
        "descriptionEng": "someone who surveys",
        "clazz": "3",
        "$$hashKey": "object:4141"
    },
    {
        "nameEng": "Driller (oil and natural gas production)",
        "code": "DRLO",
        "gender": "All",
        "nameInd": "Pengebor (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas pengeboran minyak dan gas bumi",
        "descriptionEng": "someone who drills",
        "clazz": "3",
        "$$hashKey": "object:4168"
    },
    {
        "nameEng": "Driller-tool dresser (oil and natural gas production) / Second man (oil and natural gas production)",
        "code": "DRTD",
        "gender": "All",
        "nameInd": "Penata alat bor (produksi minyak dan gas alam) / Asisten (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin bor",
        "descriptionEng": "someone who operates driller",
        "clazz": "3",
        "$$hashKey": "object:4105"
    },
    {
        "nameEng": "Field services supervisor (oil and natural gas production)",
        "code": "SVPS",
        "gender": "All",
        "nameInd": "Pengawas layanan lapangan (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas pengawas lapangan di bidang gas dan minyak bumi",
        "descriptionEng": "someone who supervises in the field",
        "clazz": "3",
        "$$hashKey": "object:4158"
    },
    {
        "nameEng": "Field services technician (oil and natural gas production)",
        "code": "SVPT",
        "gender": "All",
        "nameInd": "Teknisi layanan lapangan (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Teknisi lapangan di bidang gas dan minyak bumi",
        "descriptionEng": "someone who does technical stuff in the field",
        "clazz": "3",
        "$$hashKey": "object:4611"
    },
    {
        "nameEng": "Oil refining technical assistant / Oil refining technical controller",
        "code": "OILT",
        "gender": "All",
        "nameInd": "Asisten teknis penyulingan minyak / Pengontrol teknis penyulingan minyak /",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who who controls oil refining",
        "clazz": "3",
        "$$hashKey": "object:3439"
    },
    {
        "nameEng": "Test engineer (oil refining) / Chemical engineer (oil refining)",
        "code": "OILW",
        "gender": "All",
        "nameInd": "Insinyur pengujian (penyulingan minyak) / Insinyur kimia (penyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "orang yang terlatih dan terampil dalam desain, konstruksi, dan penggunaan mesin di penyulingan minyak",
        "descriptionEng": "a person trained and skilled in the design, construction, and use of engines in oil refining",
        "clazz": "3",
        "$$hashKey": "object:3549"
    },
    {
        "nameEng": "Chief operator (oil refining) / Foreman (oil refining) / Superintendant (oil refining) / Supervisor (oil refining)",
        "code": "OILF",
        "gender": "All",
        "nameInd": "Kepala operator (penyulingan minyak) / Mandor (penyulingan minyak) / Pemimpin (penyulingan minyak) / Pengawas (penyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who supervises in oil refining",
        "clazz": "3",
        "$$hashKey": "object:3607"
    },
    {
        "nameEng": "Laboratory technician (oil refining)",
        "code": "OLAT",
        "gender": "All",
        "nameInd": "Teknisi laboratorium (penyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who does technical stuff in oil refining",
        "clazz": "3",
        "$$hashKey": "object:4609"
    },
    {
        "nameEng": "Health safety and environment officer / Health safety and environment officer (oil refining)",
        "code": "OILS",
        "gender": "All",
        "nameInd": "Staf keselamatan kesehatan dan lingkungan / Staf keselamatan kesehatan dan lingkungan (prnyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who makes sure of the health and safety environment",
        "clazz": "3",
        "$$hashKey": "object:4565"
    },
    {
        "nameEng": "Bulk storage operator (oil refining) / Downstream control operator (oil refining) / Jetty operator (oil refining) / Plant operator (oil refining)",
        "code": "OILP",
        "gender": "All",
        "nameInd": "Operator penyimpanan masal (penyulingan minyak) / Operator kontrol hilir (penyulingan minyak) / Operator dermaga (penyulingan minyak) / Operator pabrik (penyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who operates oil refining",
        "clazz": "3",
        "$$hashKey": "object:3813"
    },
    {
        "nameEng": "Fuel technologist / Fuel technologist (oil refining)",
        "code": "OFUL",
        "gender": "All",
        "nameInd": "Ahli teknologi bahan bakar / Ahli teknologi bahan bakar (penyulingan minyak) /",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who specializes in fuel",
        "clazz": "3",
        "$$hashKey": "object:3378"
    },
    {
        "nameEng": "Maintenance technician (oil refining)",
        "code": "OILM",
        "gender": "All",
        "nameInd": "Teknisi pemeliharaan (penyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who does technical mainenance in oil refining",
        "clazz": "3",
        "$$hashKey": "object:4626"
    },
    {
        "nameEng": "Unskilled workers (oil refining)",
        "code": "OILU",
        "gender": "All",
        "nameInd": "Pekerja tidak trampil (penyulingan minyak)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyulingan minyak",
        "descriptionEng": "someone who works in oil refining",
        "clazz": "3",
        "$$hashKey": "object:3908"
    },
    {
        "nameEng": "Contracts manager (energy renewables) / Health safety and environment manager (energy renewables) / Hydro engineer (energy renewables) / Project manager (energy renewables) / Site manager (energy renewables)",
        "code": "HSEM",
        "gender": "All",
        "nameInd": "Manajer kontrak (energi terbarukan) / Manajer keselamatan kesehatan dan lingkungan (energi terbarukan) / Insinyur hidro (energi terbarukan) / Manajer proyek (energi terbarukan) / Manajer situs (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur",
        "descriptionEng": "someone who manages",
        "clazz": "2",
        "$$hashKey": "object:3684"
    },
    {
        "nameEng": "Data analyst (energy renewables) / Software developer (energy renewables)",
        "code": "DTAN",
        "gender": "All",
        "nameInd": "Analis data (energi terbarukan) / Pengembang perangkat lunak (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "seseuatu yang memberikan infromasi perigal teknologi",
        "descriptionEng": "something that gives information regarding technology",
        "clazz": "1",
        "$$hashKey": "object:3395"
    },
    {
        "nameEng": "Renewables consultant (energy renewables) / Solar resource analyst (energy renewables) / Wind resource analyst (energy renewables)",
        "code": "RNWC",
        "gender": "All",
        "nameInd": "Konsultan terbarukan (energi terbarukan) / Analis sumber daya matahari (energi terbarukan) / Analis sumber daya angin (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberi nasihat",
        "descriptionEng": "someone who gives consult",
        "clazz": "1",
        "$$hashKey": "object:3644"
    },
    {
        "nameEng": "Bingo caller",
        "code": "BNGC",
        "gender": "All",
        "nameInd": "Pemanggil nomor bingo",
        "minAge": "0",
        "descriptionInd": "seseorang yang memanggil bingo",
        "descriptionEng": "someone who calls for bingo",
        "clazz": "3",
        "$$hashKey": "object:3955"
    },
    {
        "nameEng": "Offshore geotechnical engineer",
        "code": "OFFG",
        "gender": "All",
        "nameInd": "Insinyur geoteknis lepas pantai",
        "minAge": "0",
        "descriptionInd": "orang yang terlatih dan terampil dalam desain, konstruksi, dan penggunaan mesin di geoteknikal lepas pantai",
        "descriptionEng": "a person trained and skilled in the design, construction, and use of engines in offshore geotechnical",
        "clazz": "3",
        "$$hashKey": "object:3533"
    },
    {
        "nameEng": "Combined heating and power engineer (energy renewables)",
        "code": "CHPE",
        "gender": "All",
        "nameInd": "Insinyur kombinasi pemanas dan daya (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "a person trained and skilled in the design, construction, and use of engines in combined heating and power",
        "clazz": "2",
        "$$hashKey": "object:3535"
    },
    {
        "nameEng": "Biomass technician (energy renewables)",
        "code": "BIOM",
        "gender": "All",
        "nameInd": "Teknisi biomasa (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who knows about biomass",
        "clazz": "2",
        "$$hashKey": "object:4603"
    },
    {
        "nameEng": "Civil engineer (energy renewables)  / Structural engineer (energy renewables)",
        "code": "CVLE",
        "gender": "All",
        "nameInd": "Insinyur sipil (energi terbarukan) / Insinyur struktur (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "seorang disiplin teknik profesional yang berhubungan dengan desain, konstruksi, dan pemeliharaan lingkungan fisik dan alami yang dibangun,",
        "descriptionEng": "a professional engineering discipline that deals with the design, construction, and maintenance of the physical and naturally built environment,",
        "clazz": "2",
        "$$hashKey": "object:3555"
    },
    {
        "nameEng": "Aerodynamacist",
        "code": "ADYM",
        "gender": "All",
        "nameInd": "Ahli aerodinamis",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who specializes in aerodnamics",
        "clazz": "2",
        "$$hashKey": "object:3326"
    },
    {
        "nameEng": "Environmental analyst (energy renewables)",
        "code": "ANEV",
        "gender": "All",
        "nameInd": "Analis lingkungan (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who analyses renewables environmental",
        "clazz": "2",
        "$$hashKey": "object:3398"
    },
    {
        "nameEng": "Wire winder (metals)",
        "code": "WRWD",
        "gender": "All",
        "nameInd": "Penggulung kabel (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggulung kabel",
        "descriptionEng": "somone who winds wire",
        "clazz": "3",
        "$$hashKey": "object:4234"
    },
    {
        "nameEng": "Marine development engineer",
        "code": "DENM",
        "gender": "All",
        "nameInd": "Insinyur pengembangan laut",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "a person trained and skilled in the design, construction, and use of engines in marine development",
        "clazz": "2",
        "$$hashKey": "object:3548"
    },
    {
        "nameEng": "Offshore environmental developer (energy renewables)",
        "code": "OFFD",
        "gender": "All",
        "nameInd": "Pengembang lingkungan lepas pantai (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who develops offshore environmental",
        "clazz": "2",
        "$$hashKey": "object:4183"
    },
    {
        "nameEng": "Electrical engineer (energy renewables)",
        "code": "EGEL",
        "gender": "All",
        "nameInd": "Insinyur listrik (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "a person trained and skilled in the design, construction, and use of engines in renewables electrical",
        "clazz": "3",
        "$$hashKey": "object:3542"
    },
    {
        "nameEng": "Inspector (energy renewables)",
        "code": "ISPC",
        "gender": "All",
        "nameInd": "Inspektur (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who inspects",
        "clazz": "3",
        "$$hashKey": "object:3560"
    },
    {
        "nameEng": "Maintenance engineer (energy renewables)",
        "code": "MNEN",
        "gender": "All",
        "nameInd": "Insinyur pemeliharaan (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "a person trained and skilled in the design, construction, and use of engines in maintaining renewables",
        "clazz": "3",
        "$$hashKey": "object:3546"
    },
    {
        "nameEng": "Bargemaster (energy renewables)",
        "code": "BGMS",
        "gender": "All",
        "nameInd": "Nakhoda tongkang (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who is a supervisor",
        "clazz": "3",
        "$$hashKey": "object:3744"
    },
    {
        "nameEng": "Construction workers (energy renewables)",
        "code": "CSWK",
        "gender": "All",
        "nameInd": "Pekerja konstruksi (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who works in renewables construction",
        "clazz": "3",
        "$$hashKey": "object:3870"
    },
    {
        "nameEng": "Crane operator (energy renewables)",
        "code": "OPCN",
        "gender": "All",
        "nameInd": "Operator derek (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who operates crane",
        "clazz": "3",
        "$$hashKey": "object:3762"
    },
    {
        "nameEng": "Heavy lift supervisor (energy renewables)",
        "code": "HVLS",
        "gender": "All",
        "nameInd": "Pengawas angkat berat (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who supervises heavy lift machine",
        "clazz": "3",
        "$$hashKey": "object:4152"
    },
    {
        "nameEng": "Rigger (energy renewables)",
        "code": "TGGR",
        "gender": "All",
        "nameInd": "Petugas rig (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang energi terbarukan",
        "descriptionEng": "someone who operates rigger",
        "clazz": "3",
        "$$hashKey": "object:4487"
    },
    {
        "nameEng": "Solar panel installer (energy renewables)",
        "code": "SOLP",
        "gender": "All",
        "nameInd": "Pemasang panel surya (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang pemasangan panel surya",
        "descriptionEng": "someone who installsl solar panel",
        "clazz": "3",
        "$$hashKey": "object:3969"
    },
    {
        "nameEng": "Welder (energy renewables)",
        "code": "WELD",
        "gender": "All",
        "nameInd": "Tukang las (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang pengelasan",
        "descriptionEng": "someone who welds",
        "clazz": "3",
        "$$hashKey": "object:4682"
    },
    {
        "nameEng": "Wind turbine technician (energy renewables)",
        "code": "WNTT",
        "gender": "All",
        "nameInd": "Teknisi turbin angin (energi terbarukan)",
        "minAge": "0",
        "descriptionInd": "Pekerja teknisi mesin turbin angin",
        "descriptionEng": "someone who does technical stuff in wind turbine",
        "clazz": "3",
        "$$hashKey": "object:4640"
    },
    {
        "nameEng": "Cleaner Boiler (water supply) / Cleaner machinery (water supply) / Cleaner pipe (water supply)",
        "code": "CLBO",
        "gender": "All",
        "nameInd": "Pembersih ketel (penyediaan air) / Pembersih mesin (penyediaan air) / Pembersih pipa (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyedia jasa perairan",
        "descriptionEng": "someone who cleans water supply",
        "clazz": "3",
        "$$hashKey": "object:4003"
    },
    {
        "nameEng": "Driller (Pipes -  water supply) / Driller (water supply)",
        "code": "DRPP",
        "gender": "All",
        "nameInd": "Pengebor (Pipa - penyediaan air) / Pengebor (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja pengebor sumber air",
        "descriptionEng": "someone who drills water supply",
        "clazz": "3",
        "$$hashKey": "object:4167"
    },
    {
        "nameEng": "Inspector (water supply)",
        "code": "WSIN",
        "gender": "All",
        "nameInd": "Inspektur (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi penyediaan air",
        "descriptionEng": "someone who inspects water supply",
        "clazz": "2",
        "$$hashKey": "object:3562"
    },
    {
        "nameEng": "Meter reader (water supply)",
        "code": "MTRR",
        "gender": "All",
        "nameInd": "Pembaca meteran (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membaca meteran di penyediaan air",
        "descriptionEng": "someone who reads meter in water supply",
        "clazz": "2",
        "$$hashKey": "object:3979"
    },
    {
        "nameEng": "Meter technician (water supply)Tester (water supply)",
        "code": "MTTC",
        "gender": "All",
        "nameInd": "Teknisi meteran (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyedia jasa perairan",
        "descriptionEng": "someone who does technical stuff in water supply",
        "clazz": "3",
        "$$hashKey": "object:4618"
    },
    {
        "nameEng": "Pipe fitter (water suppy) / Pipe jointer (water suppy)",
        "code": "PPFT",
        "gender": "All",
        "nameInd": "Pengepas pipa (penyediaan air) / Penyambung pipa (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyedia jasa perairan",
        "descriptionEng": "someone who works in pipes",
        "clazz": "3",
        "$$hashKey": "object:4227"
    },
    {
        "nameEng": "Pipe layer (water supply)",
        "code": "PPLY",
        "gender": "All",
        "nameInd": "Pemasang lapisan pipa (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang penyedia jasa perairan",
        "descriptionEng": "someone who lays pipes",
        "clazz": "3",
        "$$hashKey": "object:3965"
    },
    {
        "nameEng": "Plant operator (water supply)",
        "code": "PPOP",
        "gender": "All",
        "nameInd": "Operator instalasi (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Petugas yang mengoperasikan pintu air",
        "descriptionEng": "someone who operates water supply",
        "clazz": "3",
        "$$hashKey": "object:3768"
    },
    {
        "nameEng": "Reservoir attendant (water supply)",
        "code": "ATTR",
        "gender": "All",
        "nameInd": "Petugas waduk (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja di waduk pasokan air",
        "descriptionEng": "someone who attends water supply reservoir",
        "clazz": "3",
        "$$hashKey": "object:4504"
    },
    {
        "nameEng": "Well driller (water supply)",
        "code": "WDWS",
        "gender": "All",
        "nameInd": "Pengebor sumur (penyediaan air)",
        "minAge": "0",
        "descriptionInd": "Pekerja pengebor sumber air",
        "descriptionEng": "someone who drills water supply well",
        "clazz": "3",
        "$$hashKey": "object:4171"
    },
    {
        "nameEng": "Admissions attendant (amusements) / Amusements admissions attendant",
        "code": "ADAT",
        "gender": "All",
        "nameInd": "Penjaga pintu masuk (tempat hiburan) / Penjaga pintu masuk tempat hiburan",
        "minAge": "0",
        "descriptionInd": "Petugas penerima pengunjung taman bermain",
        "descriptionEng": "someone who attends the entrance",
        "clazz": "3",
        "$$hashKey": "object:4319"
    },
    {
        "nameEng": "Amusement arcade attendant",
        "code": "AMAR",
        "gender": "All",
        "nameInd": "Penjaga arena permainan",
        "minAge": "0",
        "descriptionInd": "Petugas penjaga lorong taman bermain",
        "descriptionEng": "someone who attends the entrance",
        "clazz": "3",
        "$$hashKey": "object:4293"
    },
    {
        "nameEng": "Jackpot attendent **",
        "code": "JACK",
        "gender": "All",
        "nameInd": "Petugas Mesin Slot",
        "minAge": "0",
        "descriptionInd": "Melakukan pemeliharaan kasino dan/atau perlengkapan, mesin kasino. Mengisi mesin dengan koin apabila diperlukan. Menyiapkan bukti tertulis untuk pembayaran jackpot dan menyerahkannya ke kasir dan/atau pihak manajemen kasino berdasarkan kebijakan operasional kasino.",
        "descriptionEng": "Conducts minor general Casino maintenance and/or service on Casino machines and equipment. Fills machines with coins whenever a fill is required. Prepares written authorization for jackpot payouts and presents to Cashier and/or Casino management based on established Casino Operation policies.",
        "clazz": "2",
        "$$hashKey": "object:4451"
    },
    {
        "nameEng": "Bingo hall fairground manager",
        "code": "BNGH",
        "gender": "All",
        "nameInd": "Manajer aula permainan bingo",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur bingo",
        "descriptionEng": "someone who manages bingo",
        "clazz": "2",
        "$$hashKey": "object:3670"
    },
    {
        "nameEng": "Fairground attendant",
        "code": "FGAT",
        "gender": "All",
        "nameInd": "Penjaga gelanggang pekan raya",
        "minAge": "0",
        "descriptionInd": "seseorang yang menajaga pekan raya",
        "descriptionEng": "someonne who attends fairground",
        "clazz": "3",
        "$$hashKey": "object:4297"
    },
    {
        "nameEng": "Gate keeper (amusements) / Amusements gate keeper",
        "code": "GTKP",
        "gender": "All",
        "nameInd": "Penjaga gerbang masuk (hiburan) / Penjaga gerbang masuk hiburan",
        "minAge": "0",
        "descriptionInd": "Petugas penjaga gerbang taman hiburan",
        "descriptionEng": "someone who keeps the gate",
        "clazz": "3",
        "$$hashKey": "object:4298"
    },
    {
        "nameEng": "Ride operator (amusements) / Amusements ride operator",
        "code": "RDOP",
        "gender": "All",
        "nameInd": "Operator wahana (hiburan) / Operator wahana hiburan",
        "minAge": "0",
        "descriptionInd": "Petugas operator wahana di taman hiburan",
        "descriptionEng": "someone who operates ride",
        "clazz": "3",
        "$$hashKey": "object:3824"
    },
    {
        "nameEng": "Animal keeper (circus)",
        "code": "ANKR",
        "gender": "All",
        "nameInd": "Manajer sirkus / Pemilik sirkus",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja di kebun binatang atau sirkus dan bertanggung jawab untuk menjaga kesehatan dan keselamatan hewan-hewan.",
        "descriptionEng": "someone who keeps animals",
        "clazz": "3",
        "$$hashKey": "object:3704"
    },
    {
        "nameEng": "Circus hand",
        "code": "CIRC",
        "gender": "All",
        "nameInd": "Petugas sirkus",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga sirkus",
        "descriptionEng": "someone who attends circus",
        "clazz": "2",
        "$$hashKey": "object:4493"
    },
    {
        "nameEng": "Clown (circus) / Circus clown",
        "code": "CIMG",
        "gender": "All",
        "nameInd": "Badut (sirkus) / Badut sirkus",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengatur/bertanggung jawab atas pertunjukan sirkus",
        "descriptionEng": "someone who manages or is responsible for circus show",
        "clazz": "2",
        "$$hashKey": "object:3444"
    },
    {
        "nameEng": "Renewables and carbon analyst",
        "code": "CRBA",
        "gender": "All",
        "nameInd": "Analis karbon dan energi terbarukan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menganalisis kabon dan energi terbarukan",
        "descriptionEng": "someone who analyzes renewables and carbon",
        "clazz": "2",
        "$$hashKey": "object:3396"
    },
    {
        "nameEng": "Equestrian artiste (circus) / Juggler (circus) / Tumbler (circus) / Equestrian artiste / Juggler / Tumbler / Circus artiste",
        "code": "JGGL",
        "gender": "All",
        "nameInd": "Menunggang kuda / Pesulap (sirkus) / Ahli akrobat (sirkus) / Penunggang kuda / Pesulap / Ahli akrobat / Pemain sirkus",
        "minAge": "0",
        "descriptionInd": "Pekerja seni di sirkus",
        "descriptionEng": "someone who does circus",
        "clazz": "3",
        "$$hashKey": "object:3739"
    },
    {
        "nameEng": "Tightrope artiste (circus) / Trapeze artiste (circus) / Tightrope artiste / Trapeze artiste / Circus rope artiste",
        "code": "TGHT",
        "gender": "All",
        "nameInd": "Seniman tali tegang (sirkus) / Seniman ayun gantung (sirkus) / Seniman tali tegang  / Seniman ayun gantung  / Seniman tali sirkus",
        "minAge": "0",
        "descriptionInd": "Pekerja seni di sirkus",
        "descriptionEng": "someone who walks on rope",
        "clazz": "3",
        "$$hashKey": "object:4546"
    },
    {
        "nameEng": "Chip / Money changer",
        "code": "CHIP",
        "gender": "All",
        "nameInd": "Chip / Agen penukar uang",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di agen penukar uang",
        "descriptionEng": "someone who works in money changer",
        "clazz": "2",
        "$$hashKey": "object:3465"
    },
    {
        "nameEng": "Club manager  / Nightclub proprietor",
        "code": "CLMG",
        "gender": "All",
        "nameInd": "Manajer kelab / Pemilik kelab malam",
        "minAge": "0",
        "descriptionInd": "Manager sebuah klub",
        "descriptionEng": "someone who manages a club",
        "clazz": "3",
        "$$hashKey": "object:3680"
    },
    {
        "nameEng": "Exotic dancer",
        "code": "EXDC",
        "gender": "All",
        "nameInd": "Penari eksotis",
        "minAge": "0",
        "descriptionInd": "Penari erotis",
        "descriptionEng": "someone who dances exoticly",
        "clazz": "2",
        "$$hashKey": "object:4100"
    },
    {
        "nameEng": "Nightclub hostess",
        "code": "CGHT",
        "gender": "All",
        "nameInd": "Pemandu kelab malam",
        "minAge": "0",
        "descriptionInd": "Wanita penghibur di klub malam",
        "descriptionEng": "someone who greets in nightclub",
        "clazz": "2",
        "$$hashKey": "object:3951"
    },
    {
        "nameEng": "Music composer",
        "code": "MSCC",
        "gender": "All",
        "nameInd": "Komponis musik",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat musik",
        "descriptionEng": "someone who composes music",
        "clazz": "1",
        "$$hashKey": "object:3629"
    },
    {
        "nameEng": "Conductor (music)",
        "code": "COND",
        "gender": "All",
        "nameInd": "Konduktor (musik)",
        "minAge": "0",
        "descriptionInd": "Adalah seni dalam memimpin suatu pertunjukan musik.Tugas utamanya adalah menyeragamkan para pemain musik,mengatur tempo,mendengarkan secara seksama suara dari alat musik.",
        "descriptionEng": "Conducting is the art of directing a musical performance by way of visible gestures. The primary duties of the conductor are to unify performers, set the tempo, execute clear preparations and beats, and to listen critically and shape the sound of the ensemble.",
        "clazz": "2",
        "$$hashKey": "object:3631"
    },
    {
        "nameEng": "Arranger (music)",
        "code": "ARRA",
        "gender": "All",
        "nameInd": "Penyusun (musik)",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk menata musik pada acara tertentu, dapat dipekerjakan oleh perusahaan manajemen acara.",
        "descriptionEng": "A person who is responsible for arranging the music for a particular event, could be employeed with Event Management firms.",
        "clazz": "2",
        "$$hashKey": "object:4368"
    },
    {
        "nameEng": "Karaoke host / Singer",
        "code": "SING",
        "gender": "All",
        "nameInd": "Pemandu karaoke / Penyanyi",
        "minAge": "0",
        "descriptionInd": "Orang yang pekerjaannya menyanyi.",
        "descriptionEng": "someone who sings",
        "clazz": "2",
        "$$hashKey": "object:3950"
    },
    {
        "nameEng": "Musician",
        "code": "MUSI",
        "gender": "All",
        "nameInd": "Musisi",
        "minAge": "0",
        "descriptionInd": "Seorang musisi atau instrumentalis adalah orang yang memainkan alat musik, khususnya(meskipun tidak selalu) sebagai profesi atau mempunyai bakat dibidang musik.",
        "descriptionEng": "someone who plays musical instrument, especially as a job or has talents in music",
        "clazz": "2",
        "$$hashKey": "object:3743"
    },
    {
        "nameEng": "Orchestrator",
        "code": "OCHS",
        "gender": "All",
        "nameInd": "Pemusik orkestra",
        "minAge": "0",
        "descriptionInd": "Seseorang yang merancang/menulis orkestra musik/lagu",
        "descriptionEng": "someone who writes music or song",
        "clazz": "1",
        "$$hashKey": "object:4091"
    },
    {
        "nameEng": "Road crew member (entertainment)  / Road crew member",
        "code": "ROCM",
        "gender": "All",
        "nameInd": "Anggota kru jalanan (hiburan) / Anggota kru jalanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di dunia hiburan",
        "descriptionEng": "someone who helps in  entertainment",
        "clazz": "3",
        "$$hashKey": "object:3408"
    },
    {
        "nameEng": "Song writer",
        "code": "SNGW",
        "gender": "All",
        "nameInd": "Penulis lagu",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja sebagai penulis/pencipta lagu",
        "descriptionEng": "someone who works as a song writer",
        "clazz": "2",
        "$$hashKey": "object:4348"
    },
    {
        "nameEng": "Sound mixer",
        "code": "SNGM",
        "gender": "All",
        "nameInd": "Penyusun suara",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja memadukan/menyusun komposisi suara/lagu",
        "descriptionEng": "someone who works to compound sound or song",
        "clazz": "2",
        "$$hashKey": "object:4369"
    },
    {
        "nameEng": "Vocal coach",
        "code": "VCCH",
        "gender": "All",
        "nameInd": "Pelatih vokal",
        "minAge": "0",
        "descriptionInd": "Seseorang yang melatih/memberikan instruksi mengenai vokal",
        "descriptionEng": "someone who gives instruction on vocal",
        "clazz": "1",
        "$$hashKey": "object:3925"
    },
    {
        "nameEng": "Animator (film and television)",
        "code": "ANIM",
        "gender": "All",
        "nameInd": "Ahli animasi (film dan televisi)",
        "minAge": "0",
        "descriptionInd": "Seniman yang menciptakan beberapa gambar yang memberikan ilusi gerakan yang disebut animasi ketika ditampilkan dalam urutan cepat.",
        "descriptionEng": "someone who creates some images that bring moving illusion which is called animation when it is displayed",
        "clazz": "1",
        "$$hashKey": "object:3328"
    },
    {
        "nameEng": "Announcer (radio television and film) / TV and radio presenter / Television and radio presenter / Presenter  / Commentator (radio television and film) / Interviewer (radio television and film) / Newsreader (radio television and film) / Announcer  / Commentator / Interviewer / Newsreader",
        "code": "INTV",
        "gender": "All",
        "nameInd": "Penyiar (radio, televisi, dan film) / Pembawa acara televisi dan radio / Pembawa acara / Komentator (radio, televisi, dan film) / Pewawancara (radio, televisi, dan film) / Pembaca berita (radio, televisi, dan film) / Penyiar / Komentator / Pewawancara / Pembaca berita",
        "minAge": "0",
        "descriptionInd": "Reporter yaitu orang yang melakukan wawancara untuk tujuan memunculkan pendapat orang yang diwawancara atau untuk memperoleh informasi untuk publikasi.",
        "descriptionEng": "someone who interviews for the purpose of getting an opinion or information for publication",
        "clazz": "2",
        "$$hashKey": "object:4364"
    },
    {
        "nameEng": "Broadcasters & Entertainment TV/Radio",
        "code": "BRCS",
        "gender": "All",
        "nameInd": "Pembawa dan Penyiar Acara Radio/TV",
        "minAge": "0",
        "descriptionInd": "Orang yang menyiarkan isi video/audio untuk pemirsa melalui media komunikasi audio atau visual massa.",
        "descriptionEng": "Person who distributes audio/video content to a dispersed audience via any audio or visual mass communications medium.",
        "clazz": "2",
        "$$hashKey": "object:3990"
    },
    {
        "nameEng": "Broadcast Technician",
        "code": "BRCT",
        "gender": "All",
        "nameInd": "Teknisi Penyiaran Radio/TV",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk menjaga kekuatan dan kejernihan gambar di televisi dan suara di radio, menggunakan peralatan khusus untuk mengatur sinyal siaran.",
        "descriptionEng": "A broadcast technician is responsible for the strength and clarity of the images we see on television and the sounds we hear on radio. He or she uses special equipment to regulate broadcast signals.",
        "clazz": "2",
        "$$hashKey": "object:4631"
    },
    {
        "nameEng": "Disc jockey",
        "code": "DISK",
        "gender": "All",
        "nameInd": "DJ Music (hiburan)",
        "minAge": "0",
        "descriptionInd": "Disk Jockey adalah orang yang pekerjaannya memainkan rekaman musik untuk pengunjung.",
        "descriptionEng": "A disc jockey, also known as DJ, is a person who plays recorded music for an audience.",
        "clazz": "2",
        "$$hashKey": "object:3483"
    },
    {
        "nameEng": "Editor",
        "code": "MOPE",
        "gender": "All",
        "nameInd": "Editor",
        "minAge": "0",
        "descriptionInd": "Adalah seorang editor film yang bekerja di industri film bertugas untuk megedit materi film. Selain itu tugasnya juga mengubah adegan untuk meningkatkan visibilitas, menerapkan efek khusus, memotong bagian-bagian yang tidak dibutuhkan dari suatu rekaman, menata ulang rekaman.",
        "descriptionEng": "Is a film editor who works in the film industry in charge of editing film material. In addition, the task also changes the scene to increase visibility, apply special effects, cut out unnecessary parts of a recording, rearrange the recording.",
        "clazz": "1",
        "$$hashKey": "object:3497"
    },
    {
        "nameEng": "Producer  / Film producer / TV producer",
        "code": "PDCR",
        "gender": "All",
        "nameInd": "Produser / Produser film / Produser TV",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab atas proses produksi suatu pertunjukan",
        "descriptionEng": "Someone who is responsible for the production process of a performance",
        "clazz": "1",
        "$$hashKey": "object:4523"
    },
    {
        "nameEng": "Production manager (radio television and film) / Production manager  / Station manager (radio and TV) / Digital media operator (radio television and film) / Scheduler (radio television and film)",
        "code": "PDMG",
        "gender": "All",
        "nameInd": "Manajer produksi (radio, televisi, dan film) / Manajer produksi / Manajer stasiun (radio dan TV) / Operator media digital (radio, televisi, dan film) / Pembuat jadwal (radio, televisi, dan film)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab atas proses produksi suatu pertunjukan",
        "descriptionEng": "Someone who is responsible for the production process of a performance",
        "clazz": "1",
        "$$hashKey": "object:3700"
    },
    {
        "nameEng": "Researcher (radio television and film) / Researcher",
        "code": "RSRH",
        "gender": "All",
        "nameInd": "Peneliti (radio, televisi, dan film) / Peneliti",
        "minAge": "0",
        "descriptionInd": "Seseorang yang melakukan penelitian",
        "descriptionEng": "Someone who does research",
        "clazz": "1",
        "$$hashKey": "object:4128"
    },
    {
        "nameEng": "Sifter",
        "code": "SFTR",
        "gender": "All",
        "nameInd": "Pengayak",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengayak",
        "descriptionEng": "someone who sifts",
        "clazz": "2",
        "$$hashKey": "object:4165"
    },
    {
        "nameEng": "Rigger (entertainment)  / Radio television and film rigger  / Radio TV and film rigger",
        "code": "RGEN",
        "gender": "All",
        "nameInd": "Petugas teknis (hiburan) / Petugas teknis radio, televisi, dan film / Petugas teknis radi, TV, dan film",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas mendokumentasikan suatu acara",
        "descriptionEng": "Someone who is  in charge of documenting an event",
        "clazz": "3",
        "$$hashKey": "object:4498"
    },
    {
        "nameEng": "Theatre cloakroom attendant",
        "code": "THCO",
        "gender": "All",
        "nameInd": "Petugas ruang penitipan mantel teater",
        "minAge": "0",
        "descriptionInd": "Petugas yang bertanggung jawab atas ruang yang digunakan oleh pemain pertunjukan",
        "descriptionEng": "The clerk who is in charge of the space used by the performers",
        "clazz": "3",
        "$$hashKey": "object:4492"
    },
    {
        "nameEng": "Dresser (theatre) / Wardrobe person (theatre) / Theatre dresser",
        "code": "WORD",
        "gender": "All",
        "nameInd": "Penata kostum (teater) / Penata kostum (teater) / Penata kostum teater",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab untuk mengatur segala sesuatu yang berhubungan dengan pakaian.",
        "descriptionEng": "Someone who is responsible for arranging everything related to clothing.",
        "clazz": "2",
        "$$hashKey": "object:4107"
    },
    {
        "nameEng": "Theatre playwright",
        "code": "THPW",
        "gender": "All",
        "nameInd": "Dramawan teater",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis naskah pertunjukan",
        "descriptionEng": "someone who writes the script of the show",
        "clazz": "1",
        "$$hashKey": "object:3494"
    },
    {
        "nameEng": "Prompter  / Theatre prompter",
        "code": "PMTR",
        "gender": "All",
        "nameInd": "Juru bisik / Juru bisik teater",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu seorang pemain dengan memberikan informasi mengenai  kata-kata dari sebuah pidato yang terlupakan",
        "descriptionEng": "someone who helps a player by providing information about the words of a forgotten speech",
        "clazz": "1",
        "$$hashKey": "object:3581"
    },
    {
        "nameEng": "Scene shifter (theatre) / Theatre scene shifter  / Stage hand  / Stage hand (theatre)",
        "code": "STHD",
        "gender": "All",
        "nameInd": "Pengganti layar adegan (teater) / Pengganti layar adegan teater / Petugas panggung / Petugas panggung (teater)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas dalam hal penggantian adegan/peralatan yang berhubungan pertunjukan panggung",
        "descriptionEng": "Someone who is in charge of changing the scene / equipment related to the stage performance",
        "clazz": "3",
        "$$hashKey": "object:4230"
    },
    {
        "nameEng": "Set up technician",
        "code": "SUTE",
        "gender": "All",
        "nameInd": "Pekerja Setting Panggung",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja mengatur set up panggung termasuk lampu dan dekorasi panggung.",
        "descriptionEng": "A person whose job to manages a set up in a stage such as lighting or decoration.",
        "clazz": "2",
        "$$hashKey": "object:3905"
    },
    {
        "nameEng": "Scenery painter",
        "code": "SCPN",
        "gender": "All",
        "nameInd": "Pelukis pemandangan",
        "minAge": "0",
        "descriptionInd": "sseseorang yang mengecat di teater",
        "descriptionEng": "someone who paints in theatre",
        "clazz": "3",
        "$$hashKey": "object:3943"
    },
    {
        "nameEng": "Stage manager / Theatre stage manager",
        "code": "STMG",
        "gender": "All",
        "nameInd": "Manajer panggung / Manajer panggung teater",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur panggung di teater",
        "descriptionEng": "someone who manages the stage in theatre",
        "clazz": "1",
        "$$hashKey": "object:3688"
    },
    {
        "nameEng": "Theatre technician",
        "code": "THTC",
        "gender": "All",
        "nameInd": "Teknisi teater",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan hal teknis di teter",
        "descriptionEng": "someone who does technical stuff in teater",
        "clazz": "2",
        "$$hashKey": "object:4639"
    },
    {
        "nameEng": "Usher (theatre)  / Stage doorkeeper (theatre) / Theatre usher",
        "code": "USHR",
        "gender": "All",
        "nameInd": "Penjaga pintu (teater) / Penjaga pintu panggung (teater) / Penjaga pintu (teater)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga pintu teater",
        "descriptionEng": "someone who ushers the door",
        "clazz": "2",
        "$$hashKey": "object:4316"
    },
    {
        "nameEng": "Choreographer",
        "code": "CHOR",
        "gender": "All",
        "nameInd": "Koreografer",
        "minAge": "0",
        "descriptionInd": "Seseorang yang menciptakan komposisi tari dan rencana dan mengatur gerakan tari dan pola untuk tarian, terutama untuk balet.",
        "descriptionEng": "A person who creates dance compositions and plans and arranges dance movements and patterns for dances and especially for ballets.",
        "clazz": "2",
        "$$hashKey": "object:3651"
    },
    {
        "nameEng": "Comedian",
        "code": "CMDN",
        "gender": "All",
        "nameInd": "Komedian",
        "minAge": "0",
        "descriptionInd": "seseorang yang menghibur penonton dengan cara membuat mereka tertawa",
        "descriptionEng": "a person who seeks to entertain an audience by making them laugh.",
        "clazz": "2",
        "$$hashKey": "object:3626"
    },
    {
        "nameEng": "Dancer",
        "code": "DNCR",
        "gender": "All",
        "nameInd": "Penari",
        "minAge": "0",
        "descriptionInd": "Seseorang yang melakukan sebuah tarian.",
        "descriptionEng": "A dancer is someone who performs dance.",
        "clazz": "3",
        "$$hashKey": "object:4098"
    },
    {
        "nameEng": "Art director / Casting director  / Musical director  /",
        "code": "ARTD",
        "gender": "All",
        "nameInd": "Penata seni / Penata peran / Penata musik",
        "minAge": "0",
        "descriptionInd": "Orang yang merancang lingkungan fisik di film atau televisi untuk menciptakan suasana yang digambarkan dalam naskah.",
        "descriptionEng": "Persons who designs the physical environment of the film or television set to create the mood called for by the script.",
        "clazz": "2",
        "$$hashKey": "object:4109"
    },
    {
        "nameEng": "Entertainment director / Director (entertainment)",
        "code": "DIR",
        "gender": "All",
        "nameInd": "Sutradara (Dunia Hiburan)",
        "minAge": "0",
        "descriptionInd": "Direktur hiburan adalah orang yang memberikan arahan atas berbagai aktivitas, terlibat dalam pembuatan episode media televisi, film atau musik.",
        "descriptionEng": "Director is a person who directs the activities involved in making television episode, film or music video.",
        "clazz": "2",
        "$$hashKey": "object:4598"
    },
    {
        "nameEng": "Entertainment agent  / Agent (entertainment)",
        "code": "ETAG",
        "gender": "All",
        "nameInd": "Agen hiburan / Agen (hiburan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mencari bakat",
        "descriptionEng": "someone who looks for talent",
        "clazz": "2",
        "$$hashKey": "object:3319"
    },
    {
        "nameEng": "Escapologist",
        "code": "ESCP",
        "gender": "All",
        "nameInd": "Ahli melepaskan diri",
        "minAge": "0",
        "descriptionInd": "seseorang yang melarikan diri",
        "descriptionEng": "someone who escapes",
        "clazz": "3",
        "$$hashKey": "object:3362"
    },
    {
        "nameEng": "Facilities procurement officer (entertainment) / Procurement officer",
        "code": "FCPO",
        "gender": "All",
        "nameInd": "Staf pembelian fasilitas (hiburan) / Staf pembelian",
        "minAge": "0",
        "descriptionInd": "memerlukan negosiasi dan pemberian kontrak pasokan, memastikan kepatuhan hukum, mengawasi staf",
        "descriptionEng": "entails negotiating and awarding supply contracts, ensuring legal compliance, supervising staff",
        "clazz": "2",
        "$$hashKey": "object:4568"
    },
    {
        "nameEng": "Fire eater",
        "code": "FRET",
        "gender": "All",
        "nameInd": "Pemakan api",
        "minAge": "0",
        "descriptionInd": "seseorang yang memakan api",
        "descriptionEng": "someone who eats fire",
        "clazz": "3",
        "$$hashKey": "object:3948"
    },
    {
        "nameEng": "Hypnotist",
        "code": "HYPO",
        "gender": "All",
        "nameInd": "Ahli hipnotis",
        "minAge": "0",
        "descriptionInd": "seseorang yang menghipnotis",
        "descriptionEng": "someone who hypnotizes",
        "clazz": "2",
        "$$hashKey": "object:3343"
    },
    {
        "nameEng": "Illusionist",
        "code": "ILLS",
        "gender": "All",
        "nameInd": "Ahli ilusi",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan ilusi",
        "descriptionEng": "someone who does illusion stuff",
        "clazz": "2",
        "$$hashKey": "object:3346"
    },
    {
        "nameEng": "Impersonator",
        "code": "IMPS",
        "gender": "All",
        "nameInd": "Peniru",
        "minAge": "0",
        "descriptionInd": "seseorang yang meniru",
        "descriptionEng": "someone who impersonates",
        "clazz": "2",
        "$$hashKey": "object:4291"
    },
    {
        "nameEng": "Knife thrower",
        "code": "KNTH",
        "gender": "All",
        "nameInd": "Pelempar pisau",
        "minAge": "0",
        "descriptionInd": "seseorng yang melempar pisau",
        "descriptionEng": "someone who throws knife",
        "clazz": "2",
        "$$hashKey": "object:3941"
    },
    {
        "nameEng": "Stunt person",
        "code": "STNP",
        "gender": "All",
        "nameInd": "Pemeran pengganti",
        "minAge": "0",
        "descriptionInd": "seseoeang yang melakukan hal yang sama seperti seniman utama",
        "descriptionEng": "someone who does thing the same as the main artist",
        "clazz": "3",
        "$$hashKey": "object:4055"
    },
    {
        "nameEng": "Script writer (entertainment)",
        "code": "SCEN",
        "gender": "All",
        "nameInd": "Penulis naskah (hiburan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis skenario",
        "descriptionEng": "someone who writes script",
        "clazz": "1",
        "$$hashKey": "object:4349"
    },
    {
        "nameEng": "Air quality consultant / Pollution inspector",
        "code": "AQCS",
        "gender": "All",
        "nameInd": "Konsultan kualitas udara / Inspektur polusi",
        "minAge": "0",
        "descriptionInd": "seeorang yang mengawasi polusi",
        "descriptionEng": "someone who inspects pollution",
        "clazz": "2",
        "$$hashKey": "object:3639"
    },
    {
        "nameEng": "Hydrologist  / River inspector",
        "code": "HDLG",
        "gender": "All",
        "nameInd": "Ahli hidrologi / Inspektur sungai",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam hidrologi",
        "descriptionEng": "someone who specializes in hydrology",
        "clazz": "2",
        "$$hashKey": "object:3342"
    },
    {
        "nameEng": "Conservation officer",
        "code": "CNOF",
        "gender": "All",
        "nameInd": "Petugas konservasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di konservasi",
        "descriptionEng": "someone who works in conservation",
        "clazz": "2",
        "$$hashKey": "object:4439"
    },
    {
        "nameEng": "Mineralogist",
        "code": "MNLG",
        "gender": "All",
        "nameInd": "Ahli mineral",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam mineral",
        "descriptionEng": "someone who specializes in mineral",
        "clazz": "2",
        "$$hashKey": "object:3366"
    },
    {
        "nameEng": "Volcanologist",
        "code": "VOLC",
        "gender": "All",
        "nameInd": "Vulkanolog",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam gunung merapi",
        "descriptionEng": "someone who specializes in volcano",
        "clazz": "2",
        "$$hashKey": "object:4709"
    },
    {
        "nameEng": "Astronomer",
        "code": "ASTR",
        "gender": "All",
        "nameInd": "Ahli astronomi",
        "minAge": "0",
        "descriptionInd": "Ilmuwan yang mempelajari benda-benda langit seperti bulan, planet, bintang, nebula, dan galaksi.",
        "descriptionEng": "An astronomer is a scientist who studies celestial bodies such as moons, planets, stars, nebulae, and galaxies.",
        "clazz": "1",
        "$$hashKey": "object:3331"
    },
    {
        "nameEng": "Climate adviser",
        "code": "CLMT",
        "gender": "All",
        "nameInd": "Penasihat iklim",
        "minAge": "0",
        "descriptionInd": "sseseorang yang memberi nasihat iklim",
        "descriptionEng": "someone who advises on climate",
        "clazz": "1",
        "$$hashKey": "object:4102"
    },
    {
        "nameEng": "Environmental modeller",
        "code": "ENMO",
        "gender": "All",
        "nameInd": "Pembuat model lingkungan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat model lingkungan",
        "descriptionEng": "someone who makes environmental model",
        "clazz": "1",
        "$$hashKey": "object:4021"
    },
    {
        "nameEng": "Environmental engineer / Environmental scientist / Biologist  / Botanist / Ecologist",
        "code": "BIOL",
        "gender": "All",
        "nameInd": "Insinyur lingkungan / Peneliti lingkungan / Ahli biologi / Ahli botani / Ahli ekologi",
        "minAge": "0",
        "descriptionInd": "Ilmuwan yang mempelajari organisme hidup dan hubungan organisme tersebut dengan lingkungan.",
        "descriptionEng": "A biologist is a scientist who studies living organisms and their relationship to their environment.",
        "clazz": "2",
        "$$hashKey": "object:3540"
    },
    {
        "nameEng": "Geologist in petroleum / Geologist in minerals / Geologist in glacial / Geologist in construction / Geoscientist in enviroment / Enviromental geoscientist  / Environmental geologist",
        "code": "GIST",
        "gender": "All",
        "nameInd": "Ahli geologi di perminyakan / Ahli geologi di mineral / Ahli geologi di sungai es / Ahli geologi di konstruksi / Peneliti geologi di lingkungan / Peneliti geologi di lingkungan / Ahli geologi di lingkungan",
        "minAge": "0",
        "descriptionInd": "Geologist adalah seorang ilmuwan yang mempelajari materi padat dan cair serta proses terjadinya bumi.",
        "descriptionEng": "A geologist is a scientist who studies the solid and liquid matter that constitutes the Earth as well as the processes and history that has shaped it.",
        "clazz": "3",
        "$$hashKey": "object:3339"
    },
    {
        "nameEng": "Meteorologist",
        "code": "MTEO",
        "gender": "All",
        "nameInd": "Ahli meteorologi",
        "minAge": "0",
        "descriptionInd": "Menganalisa dan menafsirkan data meteorologi yang dikumpulkan dari permukaan dan stasiun atas udara, satelit, dan radar. Mempersiapkan laporan dan prakiraan cuaca.",
        "descriptionEng": "Analyzes and interprets meteorological data gathered by surface and upper-air stations, satellites, and radar to prepare reports and forecasts for public and other users: Studies and interprets synoptic reports, maps, photographs, and prognostic charts to predict long and short range weather conditions.",
        "clazz": "2",
        "$$hashKey": "object:3365"
    },
    {
        "nameEng": "Physicist",
        "code": "PHSC",
        "gender": "All",
        "nameInd": "Ahli fisika",
        "minAge": "0",
        "descriptionInd": "Seorang ahli ilmu pengetahuan yang secara khusus mempelajari energi, pergerakan dan benda. Mereka bekerja di laboratorium, kelas, ruang angkasa dan lokasi penelitian, mengatur penelitian fenomena fisika, mengembangkan teori dan observasi sesuai hukum dan melakukan percobaan serta membuat metode-metode untuk diaplikasikan di industri dan di lapangan sesuai hukum dan teori.",
        "descriptionEng": "are highly educated scientists who specialize in the study of energy, motion and matter. They work in scientific laboratories, classrooms, outer space and remote research locations. Conduct research into the phases of physical phenomena, develop theories and laws on the basis of observation and experiments, and devise methods to apply laws and theories to industry and other fields.",
        "clazz": "1",
        "$$hashKey": "object:3335"
    },
    {
        "nameEng": "Seismologist",
        "code": "SSMG",
        "gender": "All",
        "nameInd": "Ahli seismologi",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti seismologi",
        "descriptionEng": "a scientist who does research in seismology.",
        "clazz": "2",
        "$$hashKey": "object:3376"
    },
    {
        "nameEng": "Archaeologist",
        "code": "ACHE",
        "gender": "All",
        "nameInd": "Arkeolog",
        "minAge": "0",
        "descriptionInd": "Orang yang mempelajari aktivitas manusia di masa lalu, terutama melalui penemuan dan analisis data kebudayaan dan lingkungan yang ditinggalkan, mencakup artefak, arsitektur dan tatanan budaya.",
        "descriptionEng": "One who studies of human activity in the past, primarily through the recovery and analysis of the material culture and environmental data that they have left behind, which includes artifacts, architecture, biofacts and cultural landscapes.",
        "clazz": "2",
        "$$hashKey": "object:3416"
    },
    {
        "nameEng": "Cartographer",
        "code": "CRTO",
        "gender": "All",
        "nameInd": "Pembuat peta",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggambar atau memproduksi peta",
        "descriptionEng": "a person who draws or produces maps.",
        "clazz": "1",
        "$$hashKey": "object:4032"
    },
    {
        "nameEng": "Conservation scientist",
        "code": "COSE",
        "gender": "All",
        "nameInd": "Peneliti konservasi",
        "minAge": "0",
        "descriptionInd": "Anggota dari gerakan konservasi atau seorang ilmuwan yang bekerja di bidang biologi konservasi atau seorang praktisi konservasi-restorasi.",
        "descriptionEng": "A member of the conservation movement or A scientist who works in the field of conservation biology or A practitioner of Conservation-restoration.",
        "clazz": "2",
        "$$hashKey": "object:4129"
    },
    {
        "nameEng": "Land drainage worker",
        "code": "LNDR",
        "gender": "All",
        "nameInd": "Pekerja drainase darat",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di drainase darat",
        "descriptionEng": "someone who works in land drainage",
        "clazz": "3",
        "$$hashKey": "object:3863"
    },
    {
        "nameEng": "Sustainability officer",
        "code": "SUSO",
        "gender": "All",
        "nameInd": "Pejabat pelestarian lingkungan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di pelestarian lingkugan",
        "descriptionEng": "someone who works in sustainability",
        "clazz": "1",
        "$$hashKey": "object:3856"
    },
    {
        "nameEng": "Fish boiler",
        "code": "FISB",
        "gender": "All",
        "nameInd": "Boiler ikan",
        "minAge": "0",
        "descriptionInd": "mesin yang mendidihkan ikan",
        "descriptionEng": "a machine that boils fish",
        "clazz": "3",
        "$$hashKey": "object:3451"
    },
    {
        "nameEng": "Fish cooker",
        "code": "FISC",
        "gender": "All",
        "nameInd": "Pemasak ikan",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasak ikan",
        "descriptionEng": "someone who cooks fish",
        "clazz": "3",
        "$$hashKey": "object:3956"
    },
    {
        "nameEng": "Fish freezer operator",
        "code": "FISF",
        "gender": "All",
        "nameInd": "Operator pembeku ikan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pembeku ikan",
        "descriptionEng": "someone who operates the fish freezer",
        "clazz": "3",
        "$$hashKey": "object:3808"
    },
    {
        "nameEng": "Fish grader / Fish sorter",
        "code": "FISD",
        "gender": "All",
        "nameInd": "Pemilih ikan / Penyortir ikan",
        "minAge": "0",
        "descriptionInd": "seseorang yang memilih dan mensortir ikan",
        "descriptionEng": "someone who sorts and grades fish",
        "clazz": "3",
        "$$hashKey": "object:4061"
    },
    {
        "nameEng": "Fish gutter",
        "code": "FISG",
        "gender": "All",
        "nameInd": "Penambak ikan",
        "minAge": "0",
        "descriptionInd": "pekerja yang menambak ikan",
        "descriptionEng": "a worker who guts fishes",
        "clazz": "3",
        "$$hashKey": "object:4095"
    },
    {
        "nameEng": "Fish hatchery worker",
        "code": "FISW",
        "gender": "All",
        "nameInd": "Pekerja penetasan ikan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk penetasan ikan",
        "descriptionEng": "someone who works for fish hatchery",
        "clazz": "3",
        "$$hashKey": "object:3884"
    },
    {
        "nameEng": "Fish preparer",
        "code": "FISP",
        "gender": "All",
        "nameInd": "Penyiap ikan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyiapkan ikan",
        "descriptionEng": "someone  who prepares fish",
        "clazz": "3",
        "$$hashKey": "object:4362"
    },
    {
        "nameEng": "Crab fisherman",
        "code": "CRAB",
        "gender": "All",
        "nameInd": "Nelayan kepiting",
        "minAge": "0",
        "descriptionInd": "seseorang yang memancing kepiting",
        "descriptionEng": "someone who fishes crabs",
        "clazz": "3",
        "$$hashKey": "object:3748"
    },
    {
        "nameEng": "Harpooner",
        "code": "HARP",
        "gender": "All",
        "nameInd": "Tukang tombak ikan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggunakan tombak untuk menombak ikan",
        "descriptionEng": "A person who uses a harpoon",
        "clazz": "3",
        "$$hashKey": "object:4703"
    },
    {
        "nameEng": "Lobster fisherman",
        "code": "LOBS",
        "gender": "All",
        "nameInd": "Nelayan lobster",
        "minAge": "0",
        "descriptionInd": "seseorang yang memancing lobster",
        "descriptionEng": "someone who fishes lobster",
        "clazz": "3",
        "$$hashKey": "object:3749"
    },
    {
        "nameEng": "Oyster fisherman",
        "code": "OYST",
        "gender": "All",
        "nameInd": "Nelayan tiram",
        "minAge": "0",
        "descriptionInd": "seseorang yang memancing tiram",
        "descriptionEng": "someone who fishese oyster",
        "clazz": "3",
        "$$hashKey": "object:3751"
    },
    {
        "nameEng": "Paua fisherman",
        "code": "PAUA",
        "gender": "All",
        "nameInd": "Nelayan paua",
        "minAge": "0",
        "descriptionInd": "seseorang yang memancing paua",
        "descriptionEng": "someone who fishes paua",
        "clazz": "3",
        "$$hashKey": "object:3750"
    },
    {
        "nameEng": "Pot fisherman",
        "code": "POTF",
        "gender": "All",
        "nameInd": "Nelayan dengan keranjang",
        "minAge": "0",
        "descriptionInd": "seseorang dengan keranjang ketika pergi bernelayan",
        "descriptionEng": "someoene with pot when go fishing",
        "clazz": "3",
        "$$hashKey": "object:3747"
    },
    {
        "nameEng": "Fishery officer",
        "code": "FISO",
        "gender": "All",
        "nameInd": "Staf perikanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di perikanan",
        "descriptionEng": "someone who works in fishery",
        "clazz": "1",
        "$$hashKey": "object:4577"
    },
    {
        "nameEng": "Bakery manager / Brewery manager / Catering manager / Food manager",
        "code": "BAKM",
        "gender": "All",
        "nameInd": "Manajer toko roti / Manajer pembuatan minuman / Manajer katering / Manajer makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola makanan",
        "descriptionEng": "someone who manages food",
        "clazz": "1",
        "$$hashKey": "object:3709"
    },
    {
        "nameEng": "Brewer  / Maltster",
        "code": "BRWR",
        "gender": "All",
        "nameInd": "Pembuat bir / Pembuat ragi gandum",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat bir",
        "descriptionEng": "someone who brews",
        "clazz": "2",
        "$$hashKey": "object:4007"
    },
    {
        "nameEng": "Butcher  / Food cutter",
        "code": "BUTC",
        "gender": "All",
        "nameInd": "Tukang daging / Pemotong makanan",
        "minAge": "0",
        "descriptionInd": "Orang yang menyembelih hewan, menjual daging.",
        "descriptionEng": "A butcher is a person who may slaughter animals, dress their flesh, sell their meat or do any combination of these three tasks.",
        "clazz": "3",
        "$$hashKey": "object:4667"
    },
    {
        "nameEng": "Cutter (food) / Meat cutter",
        "code": "MEAT",
        "gender": "All",
        "nameInd": "Pemotong (makanan) / Pemotong daging",
        "minAge": "0",
        "descriptionInd": "Seseorang yang pekerjaannya yaitu pemotongan daging, unggas dan ikan.",
        "descriptionEng": "Retailer use hand tools to perform routine cutting of meat, poultry, and fish.",
        "clazz": "3",
        "$$hashKey": "object:4075"
    },
    {
        "nameEng": "Kitchen hand / Kitchen helper  / Kitchen porter  / Washer (food) / Dish washer",
        "code": "DHWR",
        "gender": "All",
        "nameInd": "Pembantu koki / Pembantu dapur / Staf dapur pemula / Pencuci (makanan) / Pencuci piring",
        "minAge": "0",
        "descriptionInd": "Pencuci piring adalah orang yang pekerjaannya membersihkan piring-piring dan perlengkapan dapur.",
        "descriptionEng": "Dishwasher is someone whose job is to cleaning dishes and eating-utensils.",
        "clazz": "2",
        "$$hashKey": "object:3985"
    },
    {
        "nameEng": "Slaughterer",
        "code": "SLGH",
        "gender": "All",
        "nameInd": "Penjagal",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyembelih",
        "descriptionEng": "someone who slaughters",
        "clazz": "3",
        "$$hashKey": "object:4324"
    },
    {
        "nameEng": "Pantry maid",
        "code": "PYMD",
        "gender": "All",
        "nameInd": "Pembantu Dapur",
        "minAge": "0",
        "descriptionInd": "Membersihkan ruangan dapur dan menjaga agar tetap menarik dan layak.",
        "descriptionEng": "cleanliness of the kitchen rooms, keep the rooms presentable and hospitable.",
        "clazz": "2",
        "$$hashKey": "object:3984"
    },
    {
        "nameEng": "Bottling machine attendant / Bottle washer",
        "code": "BOMA",
        "gender": "All",
        "nameInd": "Petugas mesin botol / Pencuci botol",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di mesin botol",
        "descriptionEng": "someone who works in bottling machine",
        "clazz": "3",
        "$$hashKey": "object:4450"
    },
    {
        "nameEng": "Baker",
        "code": "BAKE",
        "gender": "All",
        "nameInd": "Pembuat kue",
        "minAge": "0",
        "descriptionInd": "Orang yang pekerjaannya membuat roti/kue untuk dijual.",
        "descriptionEng": "A person whose job is to make bread/cakes for sale, or to sell bread/cakes.",
        "clazz": "2",
        "$$hashKey": "object:4015"
    },
    {
        "nameEng": "Boiler (food and drink production)",
        "code": "BOIL",
        "gender": "All",
        "nameInd": "Pendidih (produksi makanan dan minuman)",
        "minAge": "0",
        "descriptionInd": "mesin untuk mendidih",
        "descriptionEng": "a machine that boils",
        "clazz": "3",
        "$$hashKey": "object:4121"
    },
    {
        "nameEng": "Butter maker",
        "code": "BTRM",
        "gender": "All",
        "nameInd": "Pembuat margarin",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat margarin",
        "descriptionEng": "someone who makes butter",
        "clazz": "2",
        "$$hashKey": "object:4020"
    },
    {
        "nameEng": "Canteen assistant",
        "code": "CNAS",
        "gender": "All",
        "nameInd": "Asisten kantin",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di kantin",
        "descriptionEng": "someone who assist in canteen",
        "clazz": "2",
        "$$hashKey": "object:3427"
    },
    {
        "nameEng": "Compounder",
        "code": "CMPO",
        "gender": "All",
        "nameInd": "Pembuat ramuan",
        "minAge": "0",
        "descriptionInd": "seseorang yang meramu",
        "descriptionEng": "someoene who compounds",
        "clazz": "2",
        "$$hashKey": "object:4036"
    },
    {
        "nameEng": "Conveyor operator (food and drink production) / Conveyor operator food and drinks",
        "code": "CNVO",
        "gender": "All",
        "nameInd": "Operator konveyor (produksi makanan dan minuman) / Operator konveyor makanan dan minuman",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan makanan dan minuman",
        "descriptionEng": "someone who operates food and drinks",
        "clazz": "2",
        "$$hashKey": "object:3778"
    },
    {
        "nameEng": "Cooper",
        "code": "COOP",
        "gender": "All",
        "nameInd": "Tukang tong",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat kaleng",
        "descriptionEng": "someone who makes cans",
        "clazz": "3",
        "$$hashKey": "object:4704"
    },
    {
        "nameEng": "Digester operator",
        "code": "DGOP",
        "gender": "All",
        "nameInd": "Operator mesin digester",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengioerasikan mesin digester",
        "descriptionEng": "someone who operates digester machine",
        "clazz": "3",
        "$$hashKey": "object:3789"
    },
    {
        "nameEng": "Distillery worker",
        "code": "DSWO",
        "gender": "All",
        "nameInd": "Pekerja penyulingan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di penyulingan",
        "descriptionEng": "someone who works in distillery",
        "clazz": "3",
        "$$hashKey": "object:3891"
    },
    {
        "nameEng": "Drier meat / Drier fish / Drier poultry / Food drier",
        "code": "DRMT",
        "gender": "All",
        "nameInd": "Pengering daging / Pengering ikan / Pengering unggas / Pengering makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengeringkan makanan",
        "descriptionEng": "someone who dries food",
        "clazz": "2",
        "$$hashKey": "object:4228"
    },
    {
        "nameEng": "Examiner (food and drink production) / Food examiner",
        "code": "EXMF",
        "gender": "All",
        "nameInd": "Pemeriksa (produksi makanan dan minuman) / Pemeriksa makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang memeriksa makanan",
        "descriptionEng": "someone who examines food",
        "clazz": "2",
        "$$hashKey": "object:4057"
    },
    {
        "nameEng": "Flour confectioner",
        "code": "FLCN",
        "gender": "All",
        "nameInd": "Pembuat tepung terigu",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat tepung terigu",
        "descriptionEng": "someone who makes flour",
        "clazz": "2",
        "$$hashKey": "object:4043"
    },
    {
        "nameEng": "Food technologist",
        "code": "FDTH",
        "gender": "All",
        "nameInd": "Ahli teknologi makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam teknologi makanan",
        "descriptionEng": "someone who specializes in food technology",
        "clazz": "1",
        "$$hashKey": "object:3380"
    },
    {
        "nameEng": "Grader sugar production  / Grader / Food grader",
        "code": "GSSG",
        "gender": "All",
        "nameInd": "Penilai produksi gula / Penilai / Penilai makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menilai",
        "descriptionEng": "someone who grades",
        "clazz": "2",
        "$$hashKey": "object:4289"
    },
    {
        "nameEng": "Hand decorator (food and drink production) / Food hand decorator",
        "code": "FDHD",
        "gender": "All",
        "nameInd": "Dekorator tangan (produksi makanan dan minuman) / Dekorator tangan makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menghias makanan dengan tangan",
        "descriptionEng": "someone who decorates food with hand",
        "clazz": "2",
        "$$hashKey": "object:3470"
    },
    {
        "nameEng": "Homogeniser  / Mixer (food and drink production)",
        "code": "HGNS",
        "gender": "All",
        "nameInd": "Alat homogenisasi / Alat pencampur (produksi makanan dan minuman)",
        "minAge": "0",
        "descriptionInd": "peralatan laboratorium atau industri yang digunakan untuk homogenisasi berbagai jenis bahan, seperti jaringan, tanaman, makanan, tanah, dan banyak lainnya.",
        "descriptionEng": "a piece of laboratory or industrial equipment used for the homogenization of various types of material, such as tissue, plant, food, soil, and many others.",
        "clazz": "3",
        "$$hashKey": "object:3391"
    },
    {
        "nameEng": "Kitchen manager",
        "code": "KITM",
        "gender": "All",
        "nameInd": "Manajer dapur",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola dapur",
        "descriptionEng": "someone who manages kitchen",
        "clazz": "2",
        "$$hashKey": "object:3676"
    },
    {
        "nameEng": "Food machine operator / Machine operator (food and drink production)",
        "code": "FMCO",
        "gender": "All",
        "nameInd": "Operator mesin makanan / Operator mesin (produksi makanan dan minuman) /",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin makanan",
        "descriptionEng": "someone who operates food machine",
        "clazz": "3",
        "$$hashKey": "object:3796"
    },
    {
        "nameEng": "Mill worker / Miller",
        "code": "WILW",
        "gender": "All",
        "nameInd": "Pekerja penggilingan / Petugas penggilingan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggiling",
        "descriptionEng": "someone who mills",
        "clazz": "3",
        "$$hashKey": "object:3888"
    },
    {
        "nameEng": "Millman",
        "code": "MILM",
        "gender": "All",
        "nameInd": "Pengoperasi mesing giling",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin giling",
        "descriptionEng": "someone who operates miller",
        "clazz": "3",
        "$$hashKey": "object:4255"
    },
    {
        "nameEng": "Oven feeder",
        "code": "OVNF",
        "gender": "All",
        "nameInd": "Pengumpan oven",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengumpan oven",
        "descriptionEng": "someone who feeds oven",
        "clazz": "3",
        "$$hashKey": "object:4273"
    },
    {
        "nameEng": "Helpdesk support / IT helpdesk support / Service desk support",
        "code": "ITHD",
        "gender": "All",
        "nameInd": "Dukungan bantuan layanan / Dukungan bantuan layanan TI / Dukungan layanan",
        "minAge": "0",
        "descriptionInd": "seeseroang yang memberikan layanan melalui telepon",
        "descriptionEng": "someone who gives a service through telephone",
        "clazz": "1",
        "$$hashKey": "object:3495"
    },
    {
        "nameEng": "Packer (food and drink production) / Food and drink packer",
        "code": "PCKR",
        "gender": "All",
        "nameInd": "Pengemas (produksi makanan dan minuman) / pengemas makanan dan minuman",
        "minAge": "0",
        "descriptionInd": "Mengepak atau mengemas berbagai produk dan material manual dengan menggunakan tangan . Mempersiapkan kotak dengan menempatkan lapisan atau bantalan karton dengan bahan untuk melindungi barang selama pengiriman. Mereka harus menutup kotak atau kontainer menggunakan pita kemasan, paku, lem atau pengencang. Mereka juga memuat / memasukan produk dan bahan setelah dilakukan pengemasan.",
        "descriptionEng": "Pack or package by hand a wide variety of products and materials. prepare the boxes by putting lining or padding cartons with materials to protect items during shipment. Packers must seal the boxes or containers using packing tape, nails, glue or fasteners. They also load products and materials on to skids after they are packed.",
        "clazz": "3",
        "$$hashKey": "object:4180"
    },
    {
        "nameEng": "Pasteuriser",
        "code": "PSTR",
        "gender": "All",
        "nameInd": "Petugas pasteurisasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang memproses terbunuhnya mikroba dalam makanan dan minuman, seperti susu, jus, makanan kaleng, dan lain-lain.",
        "descriptionEng": "someone who process the killing of microbes in food and drink, such as milk, juice, canned food, and others.",
        "clazz": "2",
        "$$hashKey": "object:4454"
    },
    {
        "nameEng": "Pickler",
        "code": "PCKL",
        "gender": "All",
        "nameInd": "Pengawet makanan",
        "minAge": "0",
        "descriptionInd": "Seseorang yang terlibat dalam pengawetan, mengawetkan makanan dengan cuka atau air asin",
        "descriptionEng": "A person who engages in pickling, preserving food with vinegar or brine",
        "clazz": "2",
        "$$hashKey": "object:4164"
    },
    {
        "nameEng": "Preparer (food and drink production) / Food preparer / Food peeler (hand)  / Process worker (food and drink production)  / Food process worker",
        "code": "FDPR",
        "gender": "All",
        "nameInd": "Penyiap (produksi makanan dan minuman) / Penyiap makanan / Pengupas makanan (tangan) / Pekerja proses (produksi makanan dan minuman) / Pekerja proses makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di pemrosesan makanan",
        "descriptionEng": "someone who works in the processing of food",
        "clazz": "2",
        "$$hashKey": "object:4361"
    },
    {
        "nameEng": "Food production workers / Production workers (food and drink production)",
        "code": "FDPW",
        "gender": "All",
        "nameInd": "Pekerja produksi makanan / Pekerja produksi (produksi makanan dan minuman) /",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di produksi makanan",
        "descriptionEng": "someone who works in producing food",
        "clazz": "2",
        "$$hashKey": "object:3898"
    },
    {
        "nameEng": "Quality control (food and drink production) / Food and drink quality control  / Food and drink QC",
        "code": "QTYC",
        "gender": "All",
        "nameInd": "Kontrol kualitas (produksi makanan dan minuman) / kontrol kualitas makanan dan minuman / KK makanan dan minuman",
        "minAge": "0",
        "descriptionInd": "seseorang yang memastikan kualitas makanan dan minuman",
        "descriptionEng": "someone who assures the quality of the food and drink",
        "clazz": "2",
        "$$hashKey": "object:3647"
    },
    {
        "nameEng": "Food roaster / Roaster (food and drink production)",
        "code": "FDRO",
        "gender": "All",
        "nameInd": "Pemanggang makanan / Pemanggang (produksi makanan dan minuman)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memanggang makanan",
        "descriptionEng": "someone who roasts food",
        "clazz": "2",
        "$$hashKey": "object:3954"
    },
    {
        "nameEng": "Smoker (food and drink production) / Food smoker",
        "code": "FDSM",
        "gender": "All",
        "nameInd": "Pengasap (produksi makanan dan minuman) / Pengasap makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengasapi makanan",
        "descriptionEng": "someone who smokes food",
        "clazz": "2",
        "$$hashKey": "object:4148"
    },
    {
        "nameEng": "Steriliser",
        "code": "STRL",
        "gender": "All",
        "nameInd": "Pensteril",
        "minAge": "0",
        "descriptionInd": "seseorang yang mensterilkan",
        "descriptionEng": "someone who sterilizes",
        "clazz": "2",
        "$$hashKey": "object:4343"
    },
    {
        "nameEng": "Sugar beet cutter",
        "code": "SBET",
        "gender": "All",
        "nameInd": "Pemotong gula bit",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong gula bit",
        "descriptionEng": "someone who cuts sugar beet",
        "clazz": "2",
        "$$hashKey": "object:4079"
    },
    {
        "nameEng": "Food tank attendant / Tank attendant (food and drink production) / Food and drink tank attendant /",
        "code": "FTNK",
        "gender": "All",
        "nameInd": "Penjaga bak makanan / Penjaga bak (produksi makanan dan minuman) / Penjaga bak makanan dan minuman",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga bak makanan",
        "descriptionEng": "someone who attends the food tank",
        "clazz": "3",
        "$$hashKey": "object:4294"
    },
    {
        "nameEng": "Taster / Food taster / Food and drink taster",
        "code": "TSTR",
        "gender": "All",
        "nameInd": "Pencicip / Pencicip makanan / Pencicip makanan dan minuman",
        "minAge": "0",
        "descriptionInd": "seeorang yang mencicipi makanan dan minuman",
        "descriptionEng": "someone who tastes food and drink",
        "clazz": "2",
        "$$hashKey": "object:4115"
    },
    {
        "nameEng": "Food weigher / Weigher (food and drink production)",
        "code": "FWGH",
        "gender": "All",
        "nameInd": "Penimbang  makanan / Penimbang (produksi makanan dan minuman)",
        "minAge": "0",
        "descriptionInd": "seesorang yang menimbang makanan",
        "descriptionEng": "someone who weighs food",
        "clazz": "2",
        "$$hashKey": "object:4290"
    },
    {
        "nameEng": "Forest worker",
        "code": "FOWK",
        "gender": "All",
        "nameInd": "Pekerja hutan",
        "minAge": "0",
        "descriptionInd": "seeorang yang bekerja di hutan",
        "descriptionEng": "someone who works in forest",
        "clazz": "3",
        "$$hashKey": "object:3865"
    },
    {
        "nameEng": "Forester / Forest ranger",
        "code": "FOST",
        "gender": "All",
        "nameInd": "Petugas hutan / Penjaga hutan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga hutan",
        "descriptionEng": "someone who forests the forest",
        "clazz": "3",
        "$$hashKey": "object:4424"
    },
    {
        "nameEng": "Forestry officer",
        "code": "FOFC",
        "gender": "All",
        "nameInd": "Staf kehutanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di kehutanan",
        "descriptionEng": "someone who works in forestry",
        "clazz": "2",
        "$$hashKey": "object:4561"
    },
    {
        "nameEng": "Lumberjack",
        "code": "LUMB",
        "gender": "All",
        "nameInd": "Petugas pengangkut kayu",
        "minAge": "0",
        "descriptionInd": "Adalah seorang pekerja di industri kayu yang melakukan proses penebangan, pengangkutan pohon untuk diolah menjadi suatu produk.",
        "descriptionEng": "A lumberjack is a worker in the logging industry who performs the initial harvesting and transport of trees for ultimate processing into forest products.",
        "clazz": "3",
        "$$hashKey": "object:4471"
    },
    {
        "nameEng": "Tree feller",
        "code": "TREF",
        "gender": "All",
        "nameInd": "Penebang pohon",
        "minAge": "0",
        "descriptionInd": "seseorang yang menebang pohon",
        "descriptionEng": "someone who falls the tree",
        "clazz": "3",
        "$$hashKey": "object:4124"
    },
    {
        "nameEng": "Tree surgeon / Woodcutter",
        "code": "TRES",
        "gender": "All",
        "nameInd": "Arboris  / Pemotong kayu",
        "minAge": "0",
        "descriptionInd": "seorang profesional dalam praktek arboriculture, yang merupakan budidaya, manajemen, dan mempelajari pohon individu, semak, tanaman merambat, dan tanaman kayu abadi lainnya di dendrologi dan hortikultura",
        "descriptionEng": "a professional in the practice of arboriculture, which is the cultivation, management, and study of individual trees, shrubs, vines, and other perennial woody plants in dendrology and horticulture",
        "clazz": "3",
        "$$hashKey": "object:3415"
    },
    {
        "nameEng": "Counsellor (healthcare) / Health counsellor / Medical technician",
        "code": "COUN",
        "gender": "All",
        "nameInd": "Penasihat (perawatan kesehatan) / Penasihat kesahatan / Teknisi medis",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberikan nasihat",
        "descriptionEng": "someone who consults",
        "clazz": "1",
        "$$hashKey": "object:4101"
    },
    {
        "nameEng": "Doctor",
        "code": "DOCT",
        "gender": "All",
        "nameInd": "Dokter",
        "minAge": "0",
        "descriptionInd": "Mendiagnosa dan mengobati suatu penyakit/kondisi medis melalui penerapan ketrampilan medis dan pengetahuan yang dimiliki.",
        "descriptionEng": "Diagnose and treat medical conditions, disorders, illnesses and diseases through the application of specialist medical skills and knowledge.",
        "clazz": "1",
        "$$hashKey": "object:3484"
    },
    {
        "nameEng": "Psychologist",
        "code": "PSCO",
        "gender": "All",
        "nameInd": "Psikolog",
        "minAge": "0",
        "descriptionInd": "Psikolog klinis bertugas mengurangi stress dan meningkatkan kesejahteraan psikologis klien dan membantu klien dari semua umur dengan berbagai macam masalah fisik dan mental.",
        "descriptionEng": "Clinical psychologists aim to reduce the distress and improve the psychological well-being of clients, work with clients of all ages on a variety of different mental or physical health problem.",
        "clazz": "1",
        "$$hashKey": "object:4529"
    },
    {
        "nameEng": "Psychiatrist",
        "code": "PSCI",
        "gender": "All",
        "nameInd": "Psikiater",
        "minAge": "0",
        "descriptionInd": "Seorang dokter yang mempunyai spesialisasi di bidang pencegahan , diagnosa dan perawatan penyakit kejiwaan. Psikiatri adalah pemberi pelayanan kesehatan mental yang utama. Mereka menganalisa dan melakukan terapi penyakit kejiwaan dengan kombinasi psikoterapi , psikoanalisis dan perawatan di rumah sakit serta dengan obat-obatan. Mereka juga terlibat diskusi dengan pasien mereka mengenai masalah yang dihadapi.",
        "descriptionEng": "A physician who specializes in the prevention, diagnosis, and treatment of mental illness. Psychiatrists are the primary mental health-care givers. They Assess and treat mental illnesses through a combination of psychotherapy, psychoanalysis, hospitalization and medication. Psychotherapy involves regular discussions with patient about their problems.",
        "clazz": "2",
        "$$hashKey": "object:4528"
    },
    {
        "nameEng": "Clothing assembler",
        "code": "TXCL",
        "gender": "All",
        "nameInd": "Pembuat pakaian",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat pakaian",
        "descriptionEng": "someone who assembles clothing",
        "clazz": "3",
        "$$hashKey": "object:4022"
    },
    {
        "nameEng": "Diagnostic specialist",
        "code": "DGSP",
        "gender": "All",
        "nameInd": "Spesialis Diagnostik",
        "minAge": "0",
        "descriptionInd": "Spesialis Diagnostik adalah seorang ilmuwan yang mempelajari ilmu laboratorium klinik yaitu pelayanan diagnostik klinik menggunakan teknik laboratorium untuk menegakkan diagnosa dan menangani pasien. Di Amerika pelayanan ini di supervisi oleh seorang Patologi klinik. Orang-orang yang bekerja di departemen laboratorium medis ini adalah mereka yang sudah terlatih secara teknis dan bukanlah seorang dokter, tetapi pada umumnya mempunyai gelar sarjana teknologi medis, yang melakukan berbagai tes dan berbagai prosedur yang dibutuhkan untuk pelayanan tertentu.",
        "descriptionEng": "A Diagnostic specialist is a scientist who studies Clinical laboratory sciences which is the clinical diagnostic services that apply laboratory techniques to diagnosis and management of patients. In the United States, these services are supervised by a pathologist. The personnel that work in these medical laboratory departments are technically trained staff who do not hold medical degrees, but who usually hold an undergraduate medical technology degree, who actually perform the tests, assays, and procedures needed for providing the specific services.",
        "clazz": "2",
        "$$hashKey": "object:4549"
    },
    {
        "nameEng": "Dietician",
        "code": "DIET",
        "gender": "All",
        "nameInd": "Ahli Gizi (Ahli Diet)",
        "minAge": "0",
        "descriptionInd": "Ahli Gizi adalah orang yang ahli dalam makanan dan nutrisi. Mereka memberikan nasihat pada orang-orang tentang makanan sehat atau makanan untuk kondisi kesehatan tertentu. Ahli Gizi bekerja pada bidang kesehatan, jasa katering, perusahaan dan pendidikan.",
        "descriptionEng": "Dietitians are experts in food and nutrition (\"dietetics\"). They advise people on what to eat in order to lead a healthy lifestyle or achieve a specific health-related goal. Dietitians work in various capacities in the field of healthcare, foodservice, corporate setting, and educational arenas.",
        "clazz": "1",
        "$$hashKey": "object:3340"
    },
    {
        "nameEng": "House officer",
        "code": "HSEO",
        "gender": "All",
        "nameInd": "Dokter muda / Coass",
        "minAge": "0",
        "descriptionInd": "Petugas kesehatan yang setelah lulus bekerja di suatu instansi kesehatan yang ditunjuk.",
        "descriptionEng": "House officer is a doctor in the first two years after qualification in a hospital, undergoing the postgraduate Foundation Programme.",
        "clazz": "1",
        "$$hashKey": "object:3490"
    },
    {
        "nameEng": "Medical Laboratory Technician",
        "code": "MDLT",
        "gender": "All",
        "nameInd": "Teknisi Laboratorium Medis",
        "minAge": "0",
        "descriptionInd": "Melakukan uji rutin di laboratorium medis untuk menyediakan data yang akan digunakan dalam diagnosis dan pengobatan penyakit, melakukan analisis kimia kuantitatif dan kualitatif dari cairan tubuh seperti darah, urin, dan cairan tulang belakang di bawah pengawasan teknologi medis.",
        "descriptionEng": "Performs routine tests in medical laboratory to provide data for use in diagnosis and treatment of disease: Conducts quantitative and qualitative chemical analyses of body fluids, such as blood, urine, and spinal fluid, under supervision of MEDICAL TECHNOLOGIST.",
        "clazz": "2",
        "$$hashKey": "object:4610"
    },
    {
        "nameEng": "Welfare officer",
        "code": "WLFO",
        "gender": "All",
        "nameInd": "Petugas kesejahteraan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di kesejahteraan",
        "descriptionEng": "someone who works in welfare",
        "clazz": "1",
        "$$hashKey": "object:4438"
    },
    {
        "nameEng": "Medical Records Technician",
        "code": "MDRT",
        "gender": "All",
        "nameInd": "Teknisi Data Medis",
        "minAge": "0",
        "descriptionInd": "Merencanakan, mengembangkan, dan mengelola sistem informasi kesehatan untuk fasilitas pelayanam kesehatan sesuai dengan standar akreditasi dan peraturan lembaga dan persyaratan sistem perawatan kesehatan, mengembangkan dan menerapkan kebijakan dan prosedur untuk mendokumentasikan, menyimpan, mengambil informasi dan mengolah dokumen medis,data asuransi, korespondensi serta tidak bertentangan dengan federal, negara dan undang-undang setempat.",
        "descriptionEng": "Plans, develops, and administers health information system for health care facility consistent with standards of accrediting and regulatory agencies and requirements of health care system: Develops and implements policies and procedures for documenting, storing, and retrieving information, and for processing medical-legal documents, insurance data, and correspondence requests, in conformance with federal, state, and local statutes.",
        "clazz": "1",
        "$$hashKey": "object:4604"
    },
    {
        "nameEng": "Medical Secretary",
        "code": "MEDS",
        "gender": "All",
        "nameInd": "Sekretaris Medis",
        "minAge": "0",
        "descriptionInd": "Melakukan tugas kesekretariatan, memanfaatkan pengetahuan terminologi medis dan rumah sakit, klinik, atau prosedur laboratorium,mengkompilasi dan mencatat laporan,korespondensi menggunakan komputer dalam bekerja.",
        "descriptionEng": "Performs secretarial duties, utilizing knowledge of medical terminology and hospital, clinic, or laboratory procedures,Compiles and records medical charts, reports, and correspondence, using typewriter or word processor.",
        "clazz": "1",
        "$$hashKey": "object:4543"
    },
    {
        "nameEng": "Physician Assistant",
        "code": "PSIA",
        "gender": "All",
        "nameInd": "Asisten Dokter",
        "minAge": "0",
        "descriptionInd": "Bertugas dalam bidang kesehatan di bawah pengawasan dokter umum/ dokter bedah. Terlatih secara formal untuk melakukan diagnostik, terapeutik dan pelayanan kesehatan, seperti yang ditugaskan oleh dokter umum. Pekerja sebagai anggota dari pelayanan kesehatan. Mereka mencatat riwayat penyakit seseorang, memeriksa dan mengobati pasien, meminta dan menginterpretasikan hasil laboratorium serta mendiagnosa pasien. Mereka juga merawat luka minor/kecelakaan minor seperti menjahit, pemasangan gips.",
        "descriptionEng": "Are practice medicine under the supervision of physicians and surgeons, formally trained to provide diagnostic, therapeutic, and preventive health care services, as delegated by a physician. Working as members of the health care team, they take medical histories, examine and treat patients, order and interpret laboratory tests and x rays, and make diagnoses. They also treat minor injuries, by suturing, splinting, and casting.",
        "clazz": "2",
        "$$hashKey": "object:3424"
    },
    {
        "nameEng": "Health inspector",
        "code": "HEAL",
        "gender": "All",
        "nameInd": "Inspektur kesehatan",
        "minAge": "0",
        "descriptionInd": "Inspektur kesehatan bertanggung jawab untuk melaksanakan langkah-langkah untuk melindungi kesehatan masyarakat, termasuk administrasi dan melaksanakan undang-undang yang berkaitan dengan kesehatan lingkungan dan memberikan dukungan untuk meminimalkan bahaya kesehatan dan keselamatan.",
        "descriptionEng": "Health inspector are responsible for carrying out measures for protecting public health, including administering and enforcing legislation related to environmental health and providing support to minimize health and safety hazards.",
        "clazz": "2",
        "$$hashKey": "object:3566"
    },
    {
        "nameEng": "Sanitary inspector",
        "code": "SANI",
        "gender": "All",
        "nameInd": "Ahli Sanitasi",
        "minAge": "0",
        "descriptionInd": "Inspektur Sanitasi berarti adalah ahli sanitasi. Inspektur sanitasi bekerja dalam berbagai kategori yang berbeda contohnya sanitasi desa, perawatan kesehatan, pendidikan kesehatan, pengendalian malaria, penyaringan air, inspektur sanitasi.",
        "descriptionEng": "sanitary inspector means sanitation. sanitary inspector worked different catagories for example, the village sanitation, health care, health education, control malaria, water filtration, sanitary inspector.",
        "clazz": "2",
        "$$hashKey": "object:3375"
    },
    {
        "nameEng": "Radiographer / radiologist",
        "code": "RDIO",
        "gender": "All",
        "nameInd": "Ahli teknologi radiologi / Ahli radiologi",
        "minAge": "0",
        "descriptionInd": "seorang dokter medis yang mengkhususkan diri dalam mendiagnosis dan mengobati penyakit dan cedera melalui penggunaan teknik pencitraan medis",
        "descriptionEng": "a medical doctor who specializes in diagnosing and treating disease and injury through the use of medical imaging techniques�",
        "clazz": "2",
        "$$hashKey": "object:3382"
    },
    {
        "nameEng": "Audiometrician",
        "code": "ADIM",
        "gender": "All",
        "nameInd": "Teknisi audiometri",
        "minAge": "0",
        "descriptionInd": "seorang teknisi yang melakukan audiometri.",
        "descriptionEng": "a technician who carries out audiometry.",
        "clazz": "1",
        "$$hashKey": "object:4602"
    },
    {
        "nameEng": "Audiologist",
        "code": "ADIO",
        "gender": "All",
        "nameInd": "Audiolog",
        "minAge": "0",
        "descriptionInd": "Orang yang terlatih dalam menilai gangguan pendengaran dan dapat memasang alat bantu dengar.",
        "descriptionEng": "An audiologist is a trained professional who measures hearing loss and can fit hearing aids.",
        "clazz": "1",
        "$$hashKey": "object:3443"
    },
    {
        "nameEng": "Nuclear medicine physician",
        "code": "NCMP",
        "gender": "All",
        "nameInd": "Ahli kedokteran nuklir",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempraktekkan obat nuklir",
        "descriptionEng": "a professional who practises nuclear medicine,�",
        "clazz": "1",
        "$$hashKey": "object:3351"
    },
    {
        "nameEng": "IT operator / Operator (information technology)",
        "code": "ITOP",
        "gender": "All",
        "nameInd": "Operator TI / Operator (teknologi informasi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan teknologi informasi",
        "descriptionEng": "someone who operates IT",
        "clazz": "1",
        "$$hashKey": "object:3823"
    },
    {
        "nameEng": "Data warehousing specialist",
        "code": "DTWH",
        "gender": "All",
        "nameInd": "Spesialis gudang data",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam gudang data",
        "descriptionEng": "someone who specializes in data warehousing",
        "clazz": "1",
        "$$hashKey": "object:4551"
    },
    {
        "nameEng": "Radiotherapist",
        "code": "RTHE",
        "gender": "All",
        "nameInd": "Staff Radioterapi",
        "minAge": "0",
        "descriptionInd": "Seorang tenaga medis yang menggunakan zat radioaktif dan sinar-X dalam pengobatan penyakit. Radiotherapists menggunakan peralatan teknis untuk mendeteksi lokasi dan mengobati tumor kanker. Bekerjasama dengan ahli Radiologi Onkologi,  radiotherapists membantu dalam memeriksa pasien kanker dan membantu proses diagnosa serta pengembangan rencana perawatan. Memantau pasien selama proses pengobatan sementara menilai efektivitas pengobatan dan menafsirkan kondisi fisik dan mental pasien.",
        "descriptionEng": "a medical specialist who uses radioactive substances and X-rays in the treatment of disease. Radiotherapists use technical equipment to locate and treat cancerous tumors. Working with radiology oncologists, radiotherapists assist in the examination of cancer patients and help in the diagnoses process and the development of treatment plans. Workers monitor patients during the treatment process while assessing the effectiveness of treatment and interpreting the patient's physical and mental condition.",
        "clazz": "2",
        "$$hashKey": "object:4588"
    },
    {
        "nameEng": "Occupational therapist",
        "code": "OCTH",
        "gender": "All",
        "nameInd": "Terapis okupasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberikan terapi okupasi",
        "descriptionEng": "someone who gives occupational therapy",
        "clazz": "1",
        "$$hashKey": "object:4647"
    },
    {
        "nameEng": "Optician",
        "code": "OPTI",
        "gender": "All",
        "nameInd": "Ahli optik",
        "minAge": "0",
        "descriptionInd": "Adalah sesorang yang bekerja berdasarkan resep yang ditulis oleh dokter mata dan serta memberi saram kepada pasien untuk jenis lensa dan bingkai kacamata, termasuk tentang gaya, berat dan warna.",
        "descriptionEng": "is trained to dispense and fit spectacles and other optical aids, working from the prescriptions written by optometrists and ophthalmologists. advise patients on various types of lenses and spectacle frames, including advice on style, weight and colour.",
        "clazz": "1",
        "$$hashKey": "object:3368"
    },
    {
        "nameEng": "Speech therapist",
        "code": "SPTH",
        "gender": "All",
        "nameInd": "Terapis wicara",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk mencegah, menilai, mendiagnosa, dan mengobati ucapan, bahasa, komunikasi sosial, komunikasi kognitif, dan gangguan menelan pada anak-anak dan orang dewasa.",
        "descriptionEng": "someone who works to prevent, assess, diagnose, and treat speech, language, social communication, cognitive-communication, and swallowing disorders in children and adults.",
        "clazz": "1",
        "$$hashKey": "object:4649"
    },
    {
        "nameEng": "Warden (old people's home)  / Warden (healthcare)  / Warden",
        "code": "WARD",
        "gender": "All",
        "nameInd": "Petugas jaga (panti jompo) / Petugas jaga (perawatan kesehatan) / Petugas jaga",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab untuk menjaga dan mengurus orang yang berusia lanjut pada suatu tempat seperti di rumah orang lanjut usia itu sendiri maupun tempat lainnya dimana orang lanjut usia tersebut berada.",
        "descriptionEng": "an official who is responsible for a particular place or thing, and for making sure that certain laws.",
        "clazz": "2",
        "$$hashKey": "object:4426"
    },
    {
        "nameEng": "Dental nurse / Hygienist / Dental assistant",
        "code": "HYGS",
        "gender": "All",
        "nameInd": "Perawat dokter gigi / Ahli higienis / Asisten dokter gigi",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu dokter gigi",
        "descriptionEng": "someone who assist the dentist",
        "clazz": "1",
        "$$hashKey": "object:4390"
    },
    {
        "nameEng": "Matron",
        "code": "MTRN",
        "gender": "All",
        "nameInd": "Kepala perawat",
        "minAge": "0",
        "descriptionInd": "seorang yang bertanggung jawab atas pengaturan domestik dan medis di rumah sakit atau fasilitas medis",
        "descriptionEng": "a person in charge of domestic and medical arrangements at a hospital or medical facility",
        "clazz": "2",
        "$$hashKey": "object:3611"
    },
    {
        "nameEng": "Hospital porter",
        "code": "HSPP",
        "gender": "All",
        "nameInd": "Buruh angkat rumah sakit",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengangkat barang",
        "descriptionEng": "someone who lifts stuff",
        "clazz": "3",
        "$$hashKey": "object:3456"
    },
    {
        "nameEng": "Hospital storeman",
        "code": "HSPS",
        "gender": "All",
        "nameInd": "Penjaga gudang rumah sakit",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga gudang di rumah sakit",
        "descriptionEng": "someone who keeps storage in hospital",
        "clazz": "3",
        "$$hashKey": "object:4302"
    },
    {
        "nameEng": "Chiropodist",
        "code": "CHRP",
        "gender": "All",
        "nameInd": "Ahli pengobatan kaki",
        "minAge": "0",
        "descriptionInd": "seorang dokter medis yang membaktikan diri untuk studi dan perawatan medis gangguan pada kaki, pergelangan kaki dan ekstremitas bawah",
        "descriptionEng": "a medical doctor devoted to the study and medical treatment of disorders of the foot, ankle and lower extremity",
        "clazz": "1",
        "$$hashKey": "object:3372"
    },
    {
        "nameEng": "Podiatrist",
        "code": "PODI",
        "gender": "All",
        "nameInd": "Podiatrist (Ahli penyakit kaki)",
        "minAge": "0",
        "descriptionInd": "Sebelumnya disebut chiropodist, menyediakan jasa pencegahan, diagnosis dan perawatan dalam banyak hal yang menyangkut kaki, pergelangan dan kaki bagian bawah, fokus pada merawat infeksi, cacat dan trauma pada bagian kaki dan tungkai bagian bawah serta juga merawat kaki dan kuku terkait dengan kondisi penyakit seperti diabetes. Juga memberikan layanan preventif dan masukan dalam peningkatan mobilitas, keleluasaan gerak dan kualitas hidup pasien (tapi bukan melalui operasi).",
        "descriptionEng": "Is also previously known as chiropodists, provide preventative care, diagnosis and treatment of a wide range of problems affecting the feet, ankle and lower legs. Focus on tending infections, ailments, defects and injuries of the foot and lower leg, as well as treating foot and nail conditions related to other major health disorders (e.g. diabetes). They also provide preventative care and advice on improving mobility, independence and the quality of life for their patients (but not through surgical means).",
        "clazz": "2",
        "$$hashKey": "object:4511"
    },
    {
        "nameEng": "Social worker / Social worker (healthcare)",
        "code": "SOCI",
        "gender": "All",
        "nameInd": "Pekerja sosial / Pekerja sosial (perawatan kesehatan)",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja memberikan nasehat yang tepat, dukungan dan jalan keluar kepada orang lain yang mengalami kesulitan pribadi dan membantu mereka mengatasi masalah.",
        "descriptionEng": "a person who provide appropriate advice, support and resources to individuals who are experiencing personal difficulties to help them overcome their problems.",
        "clazz": "2",
        "$$hashKey": "object:3906"
    },
    {
        "nameEng": "Surgeon",
        "code": "SRGN",
        "gender": "All",
        "nameInd": "Dokter bedah",
        "minAge": "0",
        "descriptionInd": "Dokter yang ahli melakukan pembedahan.",
        "descriptionEng": "a medical specialist in surgery.",
        "clazz": "2",
        "$$hashKey": "object:3486"
    },
    {
        "nameEng": "Chiropractor",
        "code": "CHIR",
        "gender": "All",
        "nameInd": "Ahli kiropraktik",
        "minAge": "0",
        "descriptionInd": "Seorang praktisi kesehatan yang memusatkan pada diagnosa, perawatan dan pencegahan gangguan tulang dan otot dan akibat dari gangguan-gangguan tersebut pada kesehatan tubuh secara menyeluruh.",
        "descriptionEng": "A health care profession concerned with the diagnosis, treatment and prevention of disorders of the neuromusculoskeletal system and the effects of these disorders on general health.",
        "clazz": "2",
        "$$hashKey": "object:3356"
    },
    {
        "nameEng": "Osteopath",
        "code": "OSTE",
        "gender": "All",
        "nameInd": "Osteopati",
        "minAge": "0",
        "descriptionInd": "sejenis obat alternatif yang menekankan penyesuaian kembali manual, pelepasan myofascial dan manipulasi fisik lainnya dari jaringan otot dan tulang.",
        "descriptionEng": "a type of alternative medicine that emphasizes manual readjustments, myofascial release and other physical manipulation of muscle tissue and bones.�",
        "clazz": "2",
        "$$hashKey": "object:3826"
    },
    {
        "nameEng": "Physiotherapist",
        "code": "PHYS",
        "gender": "All",
        "nameInd": "Ahli fisioterapi",
        "minAge": "0",
        "descriptionInd": "Bekerja untuk mengidentifikasikan dan meningkatkan fungsi serta pergerakan pasien. Mereka membantu pasien untuk meningkatkan kesehatan dan kehidupan serta membantu proses rehabilitasi dengan meningkatkan fungsi sistem tubuh, secara khusus fungsi persyarafan dan otot, otot dan tulang, fungsi jantung dan sistem persyarafan. Mereka menganjurkan dan mengevaluasi program pengobatan, melakukan terapi scara manual, membimbing olah raga dan pergerakan dan mengaplikasikan peralatan tekhnologi seperti USG.",
        "descriptionEng": "Are Work with patients to identify and improve their movement and function. They help promote their patients' health and wellbeing, and assist the rehabilitation process by developing and restoring body systems, in particular the neuromuscular, musculoskeletal, cardiovascular and respiratory systems. They devise and review treatment programmes, comprising manual therapy, movement, therapeutic exercise and the application of technological equipment, e.g. ultrasound.",
        "clazz": "2",
        "$$hashKey": "object:3337"
    },
    {
        "nameEng": "Jig loader",
        "code": "JIGL",
        "gender": "All",
        "nameInd": "Pemuat jig",
        "minAge": "0",
        "descriptionInd": "seseorang yang memuat jig",
        "descriptionEng": "someone who loads jig",
        "clazz": "3",
        "$$hashKey": "object:4086"
    },
    {
        "nameEng": "Respiratory Therapist",
        "code": "RESP",
        "gender": "All",
        "nameInd": "Terapis Pernafasan",
        "minAge": "0",
        "descriptionInd": "Adalah ahli dan pendidik di bidang kardiologi dan pulmonologi. Terapis pernapasan juga merupakah ahli praktek klinik dalam pengaturan jalan napas, mempertahankan jalan napas pada saat terjadi trauma, perawatan intensif dan mungkin memberikan anastesi dalam operasi.",
        "descriptionEng": "Respiratory therapists are specialists and educators in cardiology and pulmonology. Respiratory therapists are also advanced-practice clinicians in airway management; establishing and maintaining the airway during management of trauma, intensive care, and may administer anaesthesia for surgery or conscious sedation.",
        "clazz": "2",
        "$$hashKey": "object:4648"
    },
    {
        "nameEng": "Dentist / Dental surgeon",
        "code": "DENT",
        "gender": "All",
        "nameInd": "Dokter gigi  / Dokter bedah gigi",
        "minAge": "0",
        "descriptionInd": "Dokter Gigi adalah parktisi kesehatan yang khusus menangani kesehatan gigi dan mulut.",
        "descriptionEng": "Dentists are medical healthcare professionals who focus specifically on the oral and dental hygiene of their patients.",
        "clazz": "3",
        "$$hashKey": "object:3488"
    },
    {
        "nameEng": "Midwife",
        "code": "MDWF",
        "gender": "All",
        "nameInd": "Bidan",
        "minAge": "0",
        "descriptionInd": "Orang yang membantu dalam persalinan bayi, memberikan saran selama masa kehamilan dan memberikan dukungan kepada ibu, bayi dan keluarganya.",
        "descriptionEng": "Midwives deliver babies and provide antenatal and postnatal advice, care and support to women, their babies, their partners and families.",
        "clazz": "3",
        "$$hashKey": "object:3449"
    },
    {
        "nameEng": "Orthodontist",
        "code": "ORTD",
        "gender": "All",
        "nameInd": "Ahli ortodonsia",
        "minAge": "0",
        "descriptionInd": "Spesialisasi kedokteran gigi yang berkaitan dengan studi dan perawatan gigi (ketidakteraturan gigi, kondisi rahang yang tidak proporsional, atau keduanya).",
        "descriptionEng": "Orthodontics is a specialty of dentistry that is concerned with the study and treatment of malocclusions (improper bites), which may be a result of tooth irregularity, disproportionate jaw relationships, or both.",
        "clazz": "3",
        "$$hashKey": "object:3369"
    },
    {
        "nameEng": "Acupuncturist",
        "code": "ACUP",
        "gender": "All",
        "nameInd": "Ahli akupuntur",
        "minAge": "0",
        "descriptionInd": "Orang yang memiliki keahlian dalam praktek akupunktur, dapat diakui oleh lembaga akreditasi.",
        "descriptionEng": "A person who practices acupuncture",
        "clazz": "2",
        "$$hashKey": "object:3327"
    },
    {
        "nameEng": "Aromatherapist",
        "code": "AROM",
        "gender": "All",
        "nameInd": "Ahli aromaterapi",
        "minAge": "0",
        "descriptionInd": "seseorang yang berspesialisasi dalam praktik aromaterapi,",
        "descriptionEng": "someone who specializes in the practice of aromatherapy,",
        "clazz": "2",
        "$$hashKey": "object:3329"
    },
    {
        "nameEng": "Faith healer",
        "code": "FAIT",
        "gender": "All",
        "nameInd": "Paranormal penyembuh",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempraktekkan doa dan gerak-gerik (seperti penumpangan tangan) yang diyakini oleh sebagian orang untuk memperoleh intervensi ilahi dalam penyembuhan spiritual dan fisik,",
        "descriptionEng": "someone who practices prayer and gestures (such as laying on of hands) that are believed by some to elicit divine intervention in spiritual and physical healing,",
        "clazz": "3",
        "$$hashKey": "object:3831"
    },
    {
        "nameEng": "Herbalist",
        "code": "HERB",
        "gender": "All",
        "nameInd": "Ahli herbal",
        "minAge": "0",
        "descriptionInd": "adalah orang yang mempelajari dan menggunakan tanaman sebagai obat.",
        "descriptionEng": "is a person who studies and use of medicinal properties of plants.",
        "clazz": "2",
        "$$hashKey": "object:3341"
    },
    {
        "nameEng": "Hypnotherapist",
        "code": "HYPN",
        "gender": "All",
        "nameInd": "Ahli terapi hipnotis",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatasi berbagai masalah psikologis (Psikoterapi) dengan menerapkan teknik hipnosis.",
        "descriptionEng": "someone who overcomes various psychological problems (Psychotherapy) by applying hypnosis techniques.",
        "clazz": "2",
        "$$hashKey": "object:3384"
    },
    {
        "nameEng": "Reflexologist",
        "code": "RFLX",
        "gender": "All",
        "nameInd": "Ahli refleksologi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempraktekkan pengobatan alternatif yang melibatkan penerapan tekanan ke kaki dan tangan dengan teknik jempol, jari, dan tangan tertentu tanpa menggunakan minyak atau lotion.",
        "descriptionEng": "someone who practices an alternative medicine involving application of pressure to the feet and hands with specific thumb, finger, and hand techniques without the use of oil or lotion.",
        "clazz": "2",
        "$$hashKey": "object:3374"
    },
    {
        "nameEng": "Orthoptist",
        "code": "ORTH",
        "gender": "All",
        "nameInd": "Ortoptis",
        "minAge": "0",
        "descriptionInd": "adalah praktisi perawatan kesehatan yang terlatih dan bersekolah di universitas yang mengkhususkan diri dalam gangguan gerakan mata dan prosedur diagnostik yang berkaitan dengan gangguan mata dan sistem visual.",
        "descriptionEng": "are university-trained, allied health care practitioners who specialize in disorders of eye movements and diagnostic procedures related to disorders of the eye and visual system.",
        "clazz": "2",
        "$$hashKey": "object:3825"
    },
    {
        "nameEng": "Analyst (information technology) / IT business analyst / IT consultant / IT manager / Test analyst /",
        "code": "ITBA",
        "gender": "All",
        "nameInd": "Analis (teknologi informasi) / Analis bisnis TI / Konsultan TI / Manajer TI / Analis uji",
        "minAge": "0",
        "descriptionInd": "seseorang yang menganalisis teknologi informasi",
        "descriptionEng": "someone who analyzes IT",
        "clazz": "1",
        "$$hashKey": "object:3393"
    },
    {
        "nameEng": "Android developer / IT animator / AutoCAD / Flash designer / Gameplayer programmer / Iphone developer / IT developer / Software developer / Video games creater / Website designer /",
        "code": "ITDP",
        "gender": "All",
        "nameInd": "Pengembang android / Ahli animasi TI / AutoCAD / Perancang flash / Pemogram permainan / Pengembang iPhone / Pengembang TI / Pengembang perangkat lunak / Perancang video game / Desainer situs",
        "minAge": "0",
        "descriptionInd": "Pekerjaannya menulis program komputer atau membuat website yang menggabungkan fitur-fitur multimedia seperti tulisan, suara, grafik, fotografi digital, pemodelan 2D/3D, animasi dan video, sesuai dengan spesifikasi seorang desainer. Karena judul dan deskripsi pekerjaan IT belum terstandarisasi, pekerjaan seorang progamer multimedia dapat tumpang tindih dengan tanggung jawab seorang Web developer atau games developer, system developer atau pembuat software.",
        "descriptionEng": "its functionality by writing computer programs or creating websites that draw together multimedia features such as text, sound, graphics, digital photography, 2D/3D modelling, animation and video, according to a designer's specification. Similarly, as IT job titles and descriptions aren�t standardised, the work of a multimedia programmer may overlap with the role of a web developer or games developer, systems developer or software engineer.",
        "clazz": "1",
        "$$hashKey": "object:4181"
    },
    {
        "nameEng": "Web Developer",
        "code": "WEBD",
        "gender": "All",
        "nameInd": "Pembuat Web Site",
        "minAge": "0",
        "descriptionInd": "Seorang programer yang bekerja mengembangkan aplikasi, membuat sebuah situs internet dan atau mendistribusikan aplikasi yang dijalankan melalui suatu network dari web penyedia ke web pencari.",
        "descriptionEng": "A web developer is a programmer who specializes in, or is specifically engaged in, the development of World Wide Web applications, or distributed network applications that are run over HTTP from a web server to a web browser.",
        "clazz": "1",
        "$$hashKey": "object:4047"
    },
    {
        "nameEng": "PHP developer",
        "code": "PDEV",
        "gender": "All",
        "nameInd": "Pengembang PHP",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengembangkan PHP",
        "descriptionEng": "someone who develops PHP",
        "clazz": "1",
        "$$hashKey": "object:4184"
    },
    {
        "nameEng": "Database operator",
        "code": "DTBS",
        "gender": "All",
        "nameInd": "Operator database",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan database",
        "descriptionEng": "someone who operates database",
        "clazz": "1",
        "$$hashKey": "object:3760"
    },
    {
        "nameEng": "EDP operator",
        "code": "EDPO",
        "gender": "All",
        "nameInd": "Operator EDP (Electronic Data Processing)",
        "minAge": "0",
        "descriptionInd": "Operator EDP(Electronic data processing) adalah seseorang yang pekerjaannya memproses data menggunakan cara otomatis untuk mengolah data komersiil. Prosesnya cukup sederhana dan berulang untuk mengolah data dalam jumlah besar dengan informasi yang sejenis. Contohnya, dalam proses inventarisasi, transaksi bank, data pelanggan atau data pemeliharaan barang-barang infrastruktur.",
        "descriptionEng": "EDP operator is someone whose job is to process data using automated methods to process commercial data. Typically, this uses relatively simple, repetitive activities to process large volumes of similar information. For example: stock updates applied to an inventory, banking transactions applied to account and customer master files, booking and ticketing transactions to an airline's reservation system, billing for utility services.",
        "clazz": "1",
        "$$hashKey": "object:3766"
    },
    {
        "nameEng": "Network security technician",
        "code": "NETS",
        "gender": "All",
        "nameInd": "Teknisi keamanan jaringan",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan hal teknis pada keamanan jaringan",
        "descriptionEng": "someone who does technical stuff in network security",
        "clazz": "1",
        "$$hashKey": "object:4606"
    },
    {
        "nameEng": "Furnace operator",
        "code": "FROP",
        "gender": "All",
        "nameInd": "Operator pembakaran",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pembakaran",
        "descriptionEng": "someone who operates furnace",
        "clazz": "3",
        "$$hashKey": "object:3806"
    },
    {
        "nameEng": "Systems administrator",
        "code": "SYSN",
        "gender": "All",
        "nameInd": "Administrator sistem",
        "minAge": "0",
        "descriptionInd": "orang yang bertanggung jawab atas pemeliharaan, konfigurasi, dan pengoperasian sistem komputer yang andal; terutama komputer multi-pengguna, seperti server.",
        "descriptionEng": "a person who is responsible for the upkeep, configuration, and reliable operation of computer systems; especially multi-user computers, such as servers.",
        "clazz": "1",
        "$$hashKey": "object:3316"
    },
    {
        "nameEng": "Video games tester / Tester (information technology) / Player experience associate / Player experience associate (information technology)",
        "code": "VIDT",
        "gender": "All",
        "nameInd": "Penguji video game / Penguji (teknologi informasi) / Staf pengalaman pemain / Staf pengalaman pemain (teknologi informasi) /",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji teknologi informasi",
        "descriptionEng": "someone who tests IT",
        "clazz": "1",
        "$$hashKey": "object:4268"
    },
    {
        "nameEng": "IT programmer / Programmer (information technology)",
        "code": "PROG",
        "gender": "All",
        "nameInd": "Programmer  TI / Pemogram (teknologi informasi)",
        "minAge": "0",
        "descriptionInd": "Pekerjaannya menulis program komputer atau membuat website yang menggabungkan fitur-fitur multimedia seperti tulisan, suara, grafik, fotografi digital, pemodelan 2D/3D, animasi dan video, sesuai dengan spesifikasi seorang desainer. Karena judul dan deskripsi pekerjaan IT belum terstandarisasi, pekerjaan seorang progamer multimedia dapat tumpang tindih dengan tanggung jawab seorang Web developer atau games developer, system developer atau pembuat software.",
        "descriptionEng": "its functionality by writing computer programs or creating websites that draw together multimedia features such as text, sound, graphics, digital photography, 2D/3D modelling, animation and video, according to a designer's specification. Similarly, as IT job titles and descriptions aren�t standardised, the work of a multimedia programmer may overlap with the role of a web developer or games developer, systems developer or software engineer.",
        "clazz": "1",
        "$$hashKey": "object:4525"
    },
    {
        "nameEng": "App developer",
        "code": "APDV",
        "gender": "All",
        "nameInd": "Pengembang aplikasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengembangkan aplikasi",
        "descriptionEng": "someone who develops app",
        "clazz": "1",
        "$$hashKey": "object:4182"
    },
    {
        "nameEng": "Chemical engineer",
        "code": "CHEN",
        "gender": "All",
        "nameInd": "Insinyur kimia",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti metode baru pembuatan bahan kimia, menciptakan proses di mana komponen gas atau cair dipisahkan, mengumpulkan perkiraan biaya produksi dan merancang serta menerapkan prosedur keselamatan bagi karyawan yang bekerja dengan potensi bahaya",
        "descriptionEng": "someone who researches new methods of manufacturing chemicals, creating the process by which gas or liquid components are separated, gathering estimates of the cost of production and designing and implementing safety procedures for employees working with potentially hazardous",
        "clazz": "2",
        "$$hashKey": "object:3534"
    },
    {
        "nameEng": "Core builder (electronic goods)",
        "code": "CORB",
        "gender": "All",
        "nameInd": "Pembangun inti (barang elektronik)",
        "minAge": "0",
        "descriptionInd": "seseorang yanng membangun inti listrik",
        "descriptionEng": "someone who builds electronic core",
        "clazz": "3",
        "$$hashKey": "object:3983"
    },
    {
        "nameEng": "Chemical plumber / Machine operator (chemicals and plastics)  / Process worker (chemicals and plastics)",
        "code": "CHPL",
        "gender": "All",
        "nameInd": "Tukang pipa kimia / Operator mesin (bahan kimia dan plastik) / Pekerja proses (bahan kimia dan plastik)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di dunia kimia",
        "descriptionEng": "someone who works around chemical substances",
        "clazz": "3",
        "$$hashKey": "object:4696"
    },
    {
        "nameEng": "Chemist",
        "code": "CHEM",
        "gender": "All",
        "nameInd": "Ahli kimia",
        "minAge": "0",
        "descriptionInd": "Seorang ahli kima,seorang yang terlibat dalam penelitian atau percobaan kimia.",
        "descriptionEng": "An expert in chemistry; a person engaged in chemical research or experiments.",
        "clazz": "2",
        "$$hashKey": "object:3354"
    },
    {
        "nameEng": "Conveyor operator (chemicals and plastics)",
        "code": "CNVY",
        "gender": "All",
        "nameInd": "Operator konveyor (bahan kimia dan plastik)",
        "minAge": "0",
        "descriptionInd": "Bertanggung jawab untuk mengoperasikan ban berjalan yang memindahkan objek dari satu tempat ke tempat lain. Memindahkan material ke dan dari stockpile dan memastikan mereka diangkut dengan aman.",
        "descriptionEng": "Responsible for operating conveyor belt that moves objects from one place to another. Moves material to and from stockpiles and ensure they are safely transported.",
        "clazz": "3",
        "$$hashKey": "object:3773"
    },
    {
        "nameEng": "Laboratory technician (chemicals and plastics)",
        "code": "LABT",
        "gender": "All",
        "nameInd": "Teknisi laboratori umum (bahan kimia dan plastik)",
        "minAge": "0",
        "descriptionInd": "orang yang dipekerjakan untuk menjaga peralatan teknis atau melakukan pekerjaan praktis di laboratorium.",
        "descriptionEng": "a person employed to look after technical equipment or do practical work in a laboratory.",
        "clazz": "2",
        "$$hashKey": "object:4608"
    },
    {
        "nameEng": "Laboratory operator",
        "code": "LABO",
        "gender": "All",
        "nameInd": "Operator Laboratorium",
        "minAge": "0",
        "descriptionInd": "Yaitu bertugas mengontrol unit peralatan atau sistem yang memproses zat kimia ke dalam produk industri.",
        "descriptionEng": "Controls equipment units or system that processes chemical substances into specified industrial or consumer products.",
        "clazz": "2",
        "$$hashKey": "object:3782"
    },
    {
        "nameEng": "Mini laboratory operator",
        "code": "MINI",
        "gender": "All",
        "nameInd": "Operator Laboratorium",
        "minAge": "0",
        "descriptionInd": "Adalah operator laboratorium yang tugasnya mengembangkan dan mengolah gambar foto dari film atau media digital atau juga mengedit negatif foto dan cetakan foto.",
        "descriptionEng": "Perform work involved in developing and processing photographic images from film or digital media. May perform precision tasks such as editing photographic negatives and prints.",
        "clazz": "1",
        "$$hashKey": "object:3783"
    },
    {
        "nameEng": "Pharmacologist",
        "code": "PHRM",
        "gender": "All",
        "nameInd": "Ahli farmakologi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempelajari ilmu yang berkaitan dengan efek obat-obatan di tubuh.",
        "descriptionEng": "someone who studies  science pertaining to the effects of drugs on the body.",
        "clazz": "2",
        "$$hashKey": "object:3334"
    },
    {
        "nameEng": "Dispenser",
        "code": "DPNR",
        "gender": "All",
        "nameInd": "Distributor Obat",
        "minAge": "0",
        "descriptionInd": "Distributor obat adalah orang yang pekerjaannya menyediakan dan mendistribusikan obat-obatan dan mereka adalah seorang farmakologi atau asisten farmakologi.",
        "descriptionEng": "Dispenser is a person whose job is dispensing of drug and who have authority are pharmacists and assistant pharmacists.",
        "clazz": "2",
        "$$hashKey": "object:3482"
    },
    {
        "nameEng": "Plastics technologist",
        "code": "PLTC",
        "gender": "All",
        "nameInd": "Ahli teknologi plastik",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam teknologi plastik",
        "descriptionEng": "someone who specializes in plastc technology",
        "clazz": "2",
        "$$hashKey": "object:3381"
    },
    {
        "nameEng": "Research technician (chemicals and plastics)",
        "code": "RSTH",
        "gender": "All",
        "nameInd": "Teknisi riset (kimia dan plastik)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di teknisi riset",
        "descriptionEng": "someone who works in technical research",
        "clazz": "2",
        "$$hashKey": "object:4636"
    },
    {
        "nameEng": "Store keeper (chemicals and plastics)",
        "code": "STKP",
        "gender": "All",
        "nameInd": "Penjaga toko (bahan kimia dan plastik)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga toko",
        "descriptionEng": "someone who keeps store",
        "clazz": "2",
        "$$hashKey": "object:4323"
    },
    {
        "nameEng": "Tester (chemicals and plastics)",
        "code": "TSER",
        "gender": "All",
        "nameInd": "Penguji (bahan kimia dan plastik)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji kimia",
        "descriptionEng": "someone who tests",
        "clazz": "3",
        "$$hashKey": "object:4259"
    },
    {
        "nameEng": "Toxicologist",
        "code": "TOXI",
        "gender": "All",
        "nameInd": "Toksikolog",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempelajari keamanan dan efek biologis dari obat-obatan, bahan kimia, agen, dan zat lain pada organisme hidup.",
        "descriptionEng": "someone who studies the safety and biological effects of drugs, chemicals, agents, and other substances on living organisms.",
        "clazz": "2",
        "$$hashKey": "object:4650"
    },
    {
        "nameEng": "Cleaner (diamonds and gems) / Cutter (diamonds and gems) / Jewellery enameller / Jewellery mounter / Lapidary / Polisher (diamonds and gems) / Sawyer (diamonds and gems) / Setter (diamonds and gems) / Diamonds and gems worker",
        "code": "JEWM",
        "gender": "All",
        "nameInd": "Pembersih (berlian dan permata) / Pemotong (berlian dan permata) / Pekerja enamel pada permata / Pemasang permata / Pemotong permata / Pemoles (berlian dan permata) / Pemotong (berlian dan permata) / Penyetel (berlian dan permata) / Pekerja berlian dan permata",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di berlian dan permata",
        "descriptionEng": "someone who works in diamonds and gems",
        "clazz": "3",
        "$$hashKey": "object:3998"
    },
    {
        "nameEng": "Diamond dealer",
        "code": "DIAL",
        "gender": "All",
        "nameInd": "Pedagang berlian",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual berlian",
        "descriptionEng": "someone who sells diamond",
        "clazz": "1",
        "$$hashKey": "object:3835"
    },
    {
        "nameEng": "Jewelry and Gems Trader",
        "code": "JEWE",
        "gender": "All",
        "nameInd": "Pedagang Perhiasan, Batu Permata dan Logam berharga",
        "minAge": "0",
        "descriptionInd": "Orang yang menjual perhiasan dan jam tangan mewah.",
        "descriptionEng": "Displays and sells jewelry and watches: Advises customer on quality, cuts, or value of jewelry and gems and in selecting mountings or settings for gems.",
        "clazz": "2",
        "$$hashKey": "object:3837"
    },
    {
        "nameEng": "Battery repairer",
        "code": "BATR",
        "gender": "All",
        "nameInd": "Tukang reparasi baterai",
        "minAge": "0",
        "descriptionInd": "seseorang yang memperbaiki baterai",
        "descriptionEng": "someone who repairs battery",
        "clazz": "3",
        "$$hashKey": "object:4697"
    },
    {
        "nameEng": "Coil former / Coil winder / Electrical coil worker",
        "code": "COIF",
        "gender": "All",
        "nameInd": "Pembentuk kumparan / Penggulung kumparan / Pekerja kumparan listrik",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di kumparan listrik",
        "descriptionEng": "someone who works in electrical coil",
        "clazz": "3",
        "$$hashKey": "object:3993"
    },
    {
        "nameEng": "Domestic electrician / Electrical contractor / Electrical fitter",
        "code": "DOME",
        "gender": "All",
        "nameInd": "Teknisi listrik rumah tangga / Kontraktor listrik / Petugas pemasang listrik",
        "minAge": "0",
        "descriptionInd": "seseorang yang menginstal dan memelihara sistem kabel, kontrol, dan pencahayaan domestik.",
        "descriptionEng": "someone who installs and maintains domestic wiring, control, and lighting systems.",
        "clazz": "3",
        "$$hashKey": "object:4613"
    },
    {
        "nameEng": "Wireman",
        "code": "WIRE",
        "gender": "All",
        "nameInd": "Pekerja Pemasang Kabel",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memasang dan memelihara jaringan listrik, kabel, dan lain-lain.",
        "descriptionEng": "a person who installs and maintains electric wiring, cables, etc.",
        "clazz": "3",
        "$$hashKey": "object:3881"
    },
    {
        "nameEng": "Electrical component maker",
        "code": "ELCM",
        "gender": "All",
        "nameInd": "Pembuat komponen listrik",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat komponen listrik",
        "descriptionEng": "someone who makes electrical component",
        "clazz": "3",
        "$$hashKey": "object:4014"
    },
    {
        "nameEng": "Assembler (electronics and computer)",
        "code": "ASBL",
        "gender": "All",
        "nameInd": "Perakit (elektronik dan komputer)",
        "minAge": "0",
        "descriptionInd": "seseorang yang merakit elektronik",
        "descriptionEng": "someone who assembles electronic",
        "clazz": "3",
        "$$hashKey": "object:4374"
    },
    {
        "nameEng": "Electronic engineer  / Computer hardware engineer",
        "code": "ELCH",
        "gender": "All",
        "nameInd": "Insiyur elektronik / Insiyur perangkat keras komputer",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara mesin, mesin, atau pekerjaan umum dalam perangkat keras komputer",
        "descriptionEng": "a person who designs, builds, or maintains engines, machines, or public works in computer hardware",
        "clazz": "1",
        "$$hashKey": "object:3559"
    },
    {
        "nameEng": "Computer software engineer",
        "code": "CSEG",
        "gender": "All",
        "nameInd": "Insinyur perangkat lunak komputer",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara mesin, mesin, atau pekerjaan umum dalam perangkat lunak komputer",
        "descriptionEng": "a person who designs, builds, or maintains engines, machines, or public works in computer software",
        "clazz": "1",
        "$$hashKey": "object:3551"
    },
    {
        "nameEng": "Machine operator (electronics and computer)",
        "code": "MOPR",
        "gender": "All",
        "nameInd": "Operator mesin (elektronik dan komputer)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengoperasikan alat pada mesin di dalam industri manufaktur yang memproduksi komputer atau produk elektronik.",
        "descriptionEng": "Who runs machine tools and equipment in the manufacturing industry produces computers or electronic product.",
        "clazz": "3",
        "$$hashKey": "object:3785"
    },
    {
        "nameEng": "Conveyor operator (electronics and computer) / Maintenance technician (electronics and computer) / Maintenance technician electronic",
        "code": "MNTH",
        "gender": "All",
        "nameInd": "Operator konveyor (elektronik dan komputer) / Teknisi perawatan (elektronik dan komputer) / Teknisi perawatan elektronik",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat elektronik",
        "descriptionEng": "someone who looks after electronic",
        "clazz": "3",
        "$$hashKey": "object:3774"
    },
    {
        "nameEng": "Aircon servicing technician",
        "code": "AFST",
        "gender": "All",
        "nameInd": "Teknisi AC",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab memeriksa dan memperbaiki AC/sistem pendingin lainnya atau sistem  pemanas.",
        "descriptionEng": "Person who responsible in conducting maintenance check and repairs for Air-con and other Cooling or Heating system.",
        "clazz": "2",
        "$$hashKey": "object:4600"
    },
    {
        "nameEng": "Blower (glass) / Cleaner (glass) / Cutter (glass) / Laminated glass worker / Machine Operator (glass)",
        "code": "BLWR",
        "gender": "All",
        "nameInd": "Pevakum (kaca) / Pembersih (kaca) / Pemotong (kaca) / Pekerja kaca laminasi / Operator mesin (kaca)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di industri kaca",
        "descriptionEng": "someone who works in glass industry",
        "clazz": "3",
        "$$hashKey": "object:4505"
    },
    {
        "nameEng": "Finisher (glass)",
        "code": "FNSH",
        "gender": "All",
        "nameInd": "Penutup cat (kaca)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menutup kaca",
        "descriptionEng": "someone who finishes a glass",
        "clazz": "3",
        "$$hashKey": "object:4353"
    },
    {
        "nameEng": "Furnaceman",
        "code": "FRNC",
        "gender": "All",
        "nameInd": "Tukang pembakaran",
        "minAge": "0",
        "descriptionInd": "seseorang yang membakar",
        "descriptionEng": "someone who furnaces",
        "clazz": "3",
        "$$hashKey": "object:4689"
    },
    {
        "nameEng": "Glazer / Decorator (glass) / Moulder (glass) / Painter (glass) / Polisher (glass) / Rod maker (glass)",
        "code": "GLZR",
        "gender": "All",
        "nameInd": "Tukang kaca / Dekorator (kaca) / Pencetak (kaca) / Pelukis (kaca) / Pemoles (kaca) / Pembuat batang (kaca)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja memoles kaca",
        "descriptionEng": "someone who glazes",
        "clazz": "3",
        "$$hashKey": "object:4673"
    },
    {
        "nameEng": "Senior glass glazier",
        "code": "SNGL",
        "gender": "All",
        "nameInd": "Tukang Kaca",
        "minAge": "0",
        "descriptionInd": "Adalah Ahli bangunan dalam memilih, memotong, memasang, mengganti kaca artitstik dan bangunan komersial. Tukang Kaca juga memasang frame aluminium etalase dan pintu masuk, pegangan tangan kaca dan baluster, kamar mandi kaca, tirai framing dinding, kaca serta dinding cermin.",
        "descriptionEng": "is a construction tradesperson who selects, cuts, installs, replaces, and removes residential, commercial, and artistic glass. Glaziers also install aluminum storefront frames and entrances, glass handrails and balustrades, shower enclosures, curtain wall framing and glass and mirror walls.",
        "clazz": "3",
        "$$hashKey": "object:4671"
    },
    {
        "nameEng": "Heat tester (glass)",
        "code": "GHEA",
        "gender": "All",
        "nameInd": "Penguji panas (kaca)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji panas",
        "descriptionEng": "someone who tests heat",
        "clazz": "3",
        "$$hashKey": "object:4265"
    },
    {
        "nameEng": "Kiln worker (glass)",
        "code": "GWOK",
        "gender": "All",
        "nameInd": "Pekerja pengering (kaca)",
        "minAge": "0",
        "descriptionInd": "seesorang yang bekerja untuk mengeringkan",
        "descriptionEng": "someone who works to dry",
        "clazz": "3",
        "$$hashKey": "object:3887"
    },
    {
        "nameEng": "Technologist (glass) / Technologist",
        "code": "GTEC",
        "gender": "All",
        "nameInd": "Teknolog (kaca) / Teknolog",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam teknologi",
        "descriptionEng": "someone who specializes in technology",
        "clazz": "2",
        "$$hashKey": "object:4641"
    },
    {
        "nameEng": "Leather assembler / Leather cutter / Leather glove maker / Machine operator (leather) / Pattern cutter (leather) / Maker (leather) / Leather shoe repairer  / Leather shoemaker / Tanner (leather) /",
        "code": "LETH",
        "gender": "All",
        "nameInd": "Perakit kulit / Pemotong kulit / Pembuat sarung tangan kulit / Operator mesin (kulit) / Pemotong pola (kulit) / Pembuat (kulit) / Tukang reparasi sepatu kulit / Pembuat sepatu kulit / Pemroses warna dan bulu (kulit)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di produksi kulit",
        "descriptionEng": "someone who works in leather production",
        "clazz": "3",
        "$$hashKey": "object:4379"
    },
    {
        "nameEng": "Shoe maker/repairer",
        "code": "SHOE",
        "gender": "All",
        "nameInd": "Pembuat Sepatu",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja membuat sepatu serta memperbaiki.",
        "descriptionEng": "A person who makes shoes and repair them.",
        "clazz": "2",
        "$$hashKey": "object:4041"
    },
    {
        "nameEng": "Leather technologist",
        "code": "LETT",
        "gender": "All",
        "nameInd": "Ahli teknologi kulit",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam teknologi kulit",
        "descriptionEng": "someone who specializes in leather technology",
        "clazz": "2",
        "$$hashKey": "object:3379"
    },
    {
        "nameEng": "Saddler",
        "code": "SDDL",
        "gender": "All",
        "nameInd": "Pembuat pelana",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat pelana",
        "descriptionEng": "someone whoo makes paddle",
        "clazz": "3",
        "$$hashKey": "object:4024"
    },
    {
        "nameEng": "Sewing machinist (leather)",
        "code": "SWMC",
        "gender": "All",
        "nameInd": "Operator mesin jahit (kulit)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin jahit",
        "descriptionEng": "someone who operates the sewing machine",
        "clazz": "3",
        "$$hashKey": "object:3794"
    },
    {
        "nameEng": "Computer-controlled machine tool operators",
        "code": "CMPC",
        "gender": "All",
        "nameInd": "Operator alat mesin yang dikontrol komputer",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan alat masin yang dikontrol komputer",
        "descriptionEng": "someone who operates computer controlled machine tool",
        "clazz": "2",
        "$$hashKey": "object:3755"
    },
    {
        "nameEng": "Cutting machine operator (Batteries)",
        "code": "CUTM",
        "gender": "All",
        "nameInd": "Operator mesin pemotong (Baterai)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin pemotong",
        "descriptionEng": "someone who operates cutting machine",
        "clazz": "3",
        "$$hashKey": "object:3798"
    },
    {
        "nameEng": "Knitter",
        "code": "KNIT",
        "gender": "All",
        "nameInd": "Perajut",
        "minAge": "0",
        "descriptionInd": "seseorang yang merajut",
        "descriptionEng": "someone who knits",
        "clazz": "3",
        "$$hashKey": "object:4372"
    },
    {
        "nameEng": "Mechanical engineer",
        "code": "MEEN",
        "gender": "All",
        "nameInd": "Teknisi Mekanik",
        "minAge": "0",
        "descriptionInd": "Melakukan pekerjaan teknik, perencanaan dan perancangan alat, mesin dan peralatan mekanik lainnya. Mengawasi instalasi, pemeliharaan dan perbaikan alat seperti gas, air dan sistem uap.",
        "descriptionEng": "Perform engineering duties in planning and designing tools, engines, machines, and other mechanically functioning equipment. Oversee installation, operation, maintenance, and repair of such equipment as gas, water, and steam systems.",
        "clazz": "3",
        "$$hashKey": "object:4614"
    },
    {
        "nameEng": "Tool and die makers",
        "code": "TODM",
        "gender": "All",
        "nameInd": "Pembuat Peralatan Manufaktur",
        "minAge": "0",
        "descriptionInd": "Insinyur khusus dalam industri manufaktur yang membuat jig, peralatan mesin, cetakan logam, alat pengukur, alat pemotong (seperti penggilingan atau alat pembentuk), maupun alat-alat lainnya yang digunakan dalam proses manufaktur.",
        "descriptionEng": "Tool and die makers are specialized engineers in the manufacturing industry who make jigs, fixtures, dies, molds, machine tools, cutting tools (such as milling cutters and form tools), gauges, and other tools used in manufacturing processes.",
        "clazz": "3",
        "$$hashKey": "object:4027"
    },
    {
        "nameEng": "CNC lathe operator / Cutter (precious metals) / Driller (metals) / Engraver (metals) / Tool maker (metals)",
        "code": "MTOL",
        "gender": "All",
        "nameInd": "Operator bubut CNC / Pemotong (logam berharga) / Pengebor (logam) / Pengukir (logam) / Pembuat alat (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong metal",
        "descriptionEng": "someone who cuts metal",
        "clazz": "3",
        "$$hashKey": "object:3759"
    },
    {
        "nameEng": "Metallisation plant operator / Plant operator (metals) / Miller (metals)",
        "code": "MTOP",
        "gender": "All",
        "nameInd": "Operator pabrik pelapis metal / Operator pabrik (logam) / Tukang giling (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pelapisan logam",
        "descriptionEng": "someone who operates metal plant",
        "clazz": "3",
        "$$hashKey": "object:3803"
    },
    {
        "nameEng": "Mould maker (metals) / Plastic coating operator / Stencil plate maker / Template maker (metals)",
        "code": "MTOM",
        "gender": "All",
        "nameInd": "Pembuat cetakan (logam) / Operator pelapis plastik / Pembuat pelat stensil / Pembuat template (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat cetakan",
        "descriptionEng": "someone who makes template",
        "clazz": "3",
        "$$hashKey": "object:4008"
    },
    {
        "nameEng": "Anodiser (metals)",
        "code": "ANOD",
        "gender": "All",
        "nameInd": "Anodisasi (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi (logam, terutama aluminium) dengan lapisan oksida pelindung dengan proses elektrolitik di mana logam membentuk anoda.",
        "descriptionEng": "someone who coats (a metal, especially aluminum) with a protective oxide layer by an electrolytic process in which the metal forms the anode.",
        "clazz": "3",
        "$$hashKey": "object:3413"
    },
    {
        "nameEng": "Die cutter (metals)Die setter (metals)die sinker (metals)",
        "code": "DIEC",
        "gender": "All",
        "nameInd": "Operator Mesin Potong di Manufaktur logam",
        "minAge": "0",
        "descriptionInd": "Pemotong adalah orang yang pekerjaannya mengoperasikan mesin potong.",
        "descriptionEng": "Die cutter is a someone whose job is to operate die cutting machine.",
        "clazz": "3",
        "$$hashKey": "object:3800"
    },
    {
        "nameEng": "Polisher (metals)",
        "code": "PLSH",
        "gender": "All",
        "nameInd": "Pemoles (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memoles",
        "descriptionEng": "someone who polishes",
        "clazz": "3",
        "$$hashKey": "object:4073"
    },
    {
        "nameEng": "Drawer (bar) / Drawer (plate) / Drawer (rod) / Drawer (tube) / Drawer (wire)",
        "code": "DRWE",
        "gender": "All",
        "nameInd": "Pembuat lemari (bilah) / Pembuat lemari (pelat) / Pembuat lemari (batang) / Pembuat lemari (tabung) / Pembuat lemari (kabel)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat lemari",
        "descriptionEng": "someone who draws drawer",
        "clazz": "3",
        "$$hashKey": "object:4017"
    },
    {
        "nameEng": "Foundry manager",
        "code": "FOUN",
        "gender": "All",
        "nameInd": "Manajer pengecoran logam",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola pengecoran logam",
        "descriptionEng": "someone who manages foundry",
        "clazz": "3",
        "$$hashKey": "object:3692"
    },
    {
        "nameEng": "Metallurgist / Production engineer (metals)",
        "code": "MTAL",
        "gender": "All",
        "nameInd": "Ahli metalurgi / Insinyur produksi (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempelajari cabang ilmu pengetahuan dan teknologi yang berkaitan dengan sifat-sifat logam dan produksi serta pemurniannya.",
        "descriptionEng": "someone who studies the branch of science and technology concerned with the properties of metals and their production and purification.",
        "clazz": "3",
        "$$hashKey": "object:3364"
    },
    {
        "nameEng": "Metal chain maker / Chain maker (metals)",
        "code": "MTAC",
        "gender": "All",
        "nameInd": "Pembuat rantai logam / Pembuat rantai (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat rantai",
        "descriptionEng": "someone who makes chain",
        "clazz": "3",
        "$$hashKey": "object:4039"
    },
    {
        "nameEng": "Furnace control room operator",
        "code": "FNAC",
        "gender": "All",
        "nameInd": "Operator ruang kontrol pembakaran",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan ruang kontrol pembakaran",
        "descriptionEng": "someone who operates furnace control room",
        "clazz": "3",
        "$$hashKey": "object:3822"
    },
    {
        "nameEng": "Inspector (metals) / Rectifier (metals)",
        "code": "INSM",
        "gender": "All",
        "nameInd": "Inspektur (logam) / Penyearah (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi dan memperbaiki",
        "descriptionEng": "someone who inspects and rectifies",
        "clazz": "3",
        "$$hashKey": "object:3561"
    },
    {
        "nameEng": "Technical controller (metals)",
        "code": "TECM",
        "gender": "All",
        "nameInd": "Pengontrol teknis (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengkontrol hal teknis",
        "descriptionEng": "someone who controls technical stuff",
        "clazz": "3",
        "$$hashKey": "object:4253"
    },
    {
        "nameEng": "Test engineer (metals)",
        "code": "TSEN",
        "gender": "All",
        "nameInd": "Teknisi pengujian (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara mesin, mesin, atau pekerjaan umum",
        "descriptionEng": "a person who designs, builds, or maintains engines, machines, or public works",
        "clazz": "3",
        "$$hashKey": "object:4630"
    },
    {
        "nameEng": "Metal plate cutter / Plate cutter (metals)",
        "code": "MTPC",
        "gender": "All",
        "nameInd": "Pemotong pelat logam / Pemotomg pelat (logam)",
        "minAge": "0",
        "descriptionInd": "seseorng yang memotong pelat logam",
        "descriptionEng": "someone who cuts metal plate",
        "clazz": "3",
        "$$hashKey": "object:4083"
    },
    {
        "nameEng": "Roller (metals)",
        "code": "RLLR",
        "gender": "All",
        "nameInd": "Penggulung (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggulung",
        "descriptionEng": "someone who rolls",
        "clazz": "3",
        "$$hashKey": "object:4233"
    },
    {
        "nameEng": "Pipe fitter (metals)",
        "code": "PIPM",
        "gender": "All",
        "nameInd": "Petugas pemasang pipa (logam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang pipa",
        "descriptionEng": "someone who fits pipe",
        "clazz": "3",
        "$$hashKey": "object:4459"
    },
    {
        "nameEng": "Plaster cast process operator",
        "code": "PLSO",
        "gender": "All",
        "nameInd": "Operator proses cetak plester",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan proses cetak plester",
        "descriptionEng": "someone who operates plaster cast process",
        "clazz": "3",
        "$$hashKey": "object:3814"
    },
    {
        "nameEng": "Press tool setter",
        "code": "PRES",
        "gender": "All",
        "nameInd": "Pengatur alat tekan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur alat tekan",
        "descriptionEng": "someone who stes the press tool",
        "clazz": "3",
        "$$hashKey": "object:4149"
    },
    {
        "nameEng": "Goldsmith",
        "code": "GOLD",
        "gender": "All",
        "nameInd": "Pemandai Emas",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang mempunyai keahlian khusus mengelola emas atau logam mulia lainnya.",
        "descriptionEng": "A goldsmith is a metalworker who specializes in working with gold and other precious metals.",
        "clazz": "3",
        "$$hashKey": "object:3949"
    },
    {
        "nameEng": "Sheet metal worker / Metal sheet worker / Sorter (scrap metal)",
        "code": "SHEW",
        "gender": "All",
        "nameInd": "Pekerja logam lembaran / Pekerja lembar logam / Penyortir (logam sisa) /",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di lembar logam",
        "descriptionEng": "someone who works in metal sheet",
        "clazz": "3",
        "$$hashKey": "object:3875"
    },
    {
        "nameEng": "Sheet metal fabricator",
        "code": "SHEE",
        "gender": "All",
        "nameInd": "Pembuat Fabrikasi Logam",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja dalam pembuatan lembaran logam dengan tehnik fabrikasi logam. Fabrikasi logam adalah membuat struktur logam dengan memotong, membengkokkan dan proses perakitan.",
        "descriptionEng": "A person whose job to make metal sheets by a metal fabrication technique. Metal fabrication is the building of metal structures by cutting, bending, and assembling processes.",
        "clazz": "3",
        "$$hashKey": "object:4010"
    },
    {
        "nameEng": "Conveyor operator (metals) / Plant operator (metals)",
        "code": "MTCN",
        "gender": "All",
        "nameInd": "Operator konveyor (logam) / Operator pabrik (logam)",
        "minAge": "0",
        "descriptionInd": "Bertanggung jawab untuk mengoperasikan ban berjalan yang memindahkan objek dari satu tempat ke tempat lain. Memindahkan material ke dan dari stockpile dan memastikan mereka diangkut dengan aman.",
        "descriptionEng": "Responsible for operating conveyor belt that moves objects from one place to another. Moves material to and from stockpiles and ensure they are safely transported.",
        "clazz": "3",
        "$$hashKey": "object:3776"
    },
    {
        "nameEng": "Dip enameller / Painter (metals) / Spray painter (metals)",
        "code": "MTDP",
        "gender": "All",
        "nameInd": "Pencelup enamel / Tukang cat (logam) / Tukang cat semprot (logam) /",
        "minAge": "0",
        "descriptionInd": "seseorang yang mencelup enamel",
        "descriptionEng": "someone who dips enamel",
        "clazz": "3",
        "$$hashKey": "object:4112"
    },
    {
        "nameEng": "Electroplater",
        "code": "ELPL",
        "gender": "All",
        "nameInd": "Pelapis pelat",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi (benda logam) dengan pengendapan elektrolitik dengan kromium, perak, atau logam lain.",
        "descriptionEng": "someone who coats (a metal object) by electrolytic deposition with chromium, silver, or another metal.",
        "clazz": "3",
        "$$hashKey": "object:3917"
    },
    {
        "nameEng": "Farrier",
        "code": "FARR",
        "gender": "All",
        "nameInd": "Tukang besi ladam",
        "minAge": "0",
        "descriptionInd": "seorang pengrajin yang memangkas dan memaku ladam kuda",
        "descriptionEng": "a craftsman who trims and shoes horses' hooves.",
        "clazz": "3",
        "$$hashKey": "object:4661"
    },
    {
        "nameEng": "Furnaceman (batteries)",
        "code": "FURN",
        "gender": "All",
        "nameInd": "Petugas Tungku Pembakaran",
        "minAge": "0",
        "descriptionInd": "Orang yang menyalakan tungku terutama tungku metalurgi.",
        "descriptionEng": "A man who tends a furnace esp. a metallurgical furnace.",
        "clazz": "3",
        "$$hashKey": "object:4502"
    },
    {
        "nameEng": "Crane driver (metals) / Slinger (metals) / Sandblaster",
        "code": "SLGR",
        "gender": "All",
        "nameInd": "Pengemudi derek (logam) / Pengguna sling (logam) / Pelebur /",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudikan derek",
        "descriptionEng": "someone who drives crane",
        "clazz": "3",
        "$$hashKey": "object:4206"
    },
    {
        "nameEng": "Rolling mill assistant",
        "code": "MILL",
        "gender": "All",
        "nameInd": "Asisten gulir penipis logam",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu kilang pelinyak",
        "descriptionEng": "someone who assists in rolling mill",
        "clazz": "3",
        "$$hashKey": "object:3426"
    },
    {
        "nameEng": "Shotblaster / Mixer (furnace)",
        "code": "SHBL",
        "gender": "All",
        "nameInd": "Pelebur / Pencampur (pembakaran)",
        "minAge": "0",
        "descriptionInd": "seseorang yang meleburkan (pembakaran)",
        "descriptionEng": "someone who blasts",
        "clazz": "3",
        "$$hashKey": "object:3938"
    },
    {
        "nameEng": "Annealer / Carboniser / Chromium plater (manufacturing)  / Coremaker / Galvaniser",
        "code": "CRBN",
        "gender": "All",
        "nameInd": "Penguat logam / Karbonisasi / Pelapis krom (pabrik) / Pembuat cetakan / galvanisasi",
        "minAge": "0",
        "descriptionInd": "pekerja terampil yang melapisi besi atau baja dengan seng",
        "descriptionEng": "�a skilled worker who coats iron or steel with zinc",
        "clazz": "3",
        "$$hashKey": "object:4258"
    },
    {
        "nameEng": "Blacksmith / Coppersmith",
        "code": "BLCK",
        "gender": "All",
        "nameInd": "Pandai besi / Pandai tembaga",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat benda dari besi tempa atau baja dengan menempa logam, menggunakan alat untuk memukul, membengkokkan, dan memotong",
        "descriptionEng": "someone who creates objects from wrought iron or steel by forging the metal, using tools to hammer, bend, and cut",
        "clazz": "3",
        "$$hashKey": "object:3827"
    },
    {
        "nameEng": "Caster / Metal caster / Metal caulker",
        "code": "CSTR",
        "gender": "All",
        "nameInd": "Tukang cetak / Tukang cetak logam / Tukang dempul logam",
        "minAge": "0",
        "descriptionInd": "seseorang yang mencetak logam",
        "descriptionEng": "someone who casts metal",
        "clazz": "3",
        "$$hashKey": "object:4665"
    },
    {
        "nameEng": "Grader (scrap metal) / Grinder (metals) / Lathe operator",
        "code": "GRRD",
        "gender": "All",
        "nameInd": "Perata (logam daur ulang) / Penggerinda (logam) / Operator mesin bubut /",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin bubut",
        "descriptionEng": "someone who operates lathe",
        "clazz": "3",
        "$$hashKey": "object:4388"
    },
    {
        "nameEng": "Hoistman / Machine tool operator / Press operator",
        "code": "HOIS",
        "gender": "All",
        "nameInd": "Tukang angkut mesin hoist / Operator alat mesin / Operator mesin tekan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin hoist",
        "descriptionEng": "someone who operates the hoist",
        "clazz": "3",
        "$$hashKey": "object:4653"
    },
    {
        "nameEng": "Plater (metals) / Saw maker / Saw piercer",
        "code": "PLAT",
        "gender": "All",
        "nameInd": "Pelapis (logam) / Pembuat gergaji / Penindik gergaji",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat gergaji",
        "descriptionEng": "someone who makes saw",
        "clazz": "3",
        "$$hashKey": "object:3916"
    },
    {
        "nameEng": "Machine temperer  / Temperer",
        "code": "MTEM",
        "gender": "All",
        "nameInd": "Penempa mesin / Penempa",
        "minAge": "0",
        "descriptionInd": "Mesin di mana kapur, semen, batu, dll, dicampur dengan air",
        "descriptionEng": "A machine in which lime, cement, stone, etc., are mixed with water",
        "clazz": "3",
        "$$hashKey": "object:4134"
    },
    {
        "nameEng": "Riveter",
        "code": "RVTR",
        "gender": "All",
        "nameInd": "Pengeling",
        "minAge": "0",
        "descriptionInd": "seseorang yang tugasnya memaku",
        "descriptionEng": "A person whose job is to rivet.",
        "clazz": "3",
        "$$hashKey": "object:4174"
    },
    {
        "nameEng": "Cleanroom technical associate",
        "code": "TCRO",
        "gender": "All",
        "nameInd": "Petugas teknis kebersihan kamar",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di teknis kebersihan ruangan",
        "descriptionEng": "someone who helps in cleaning room technical",
        "clazz": "2",
        "$$hashKey": "object:4499"
    },
    {
        "nameEng": "Nanomaterials chemist",
        "code": "NANO",
        "gender": "All",
        "nameInd": "Ahli kimia nanomaterial",
        "minAge": "0",
        "descriptionInd": "seseorang yang terlibat dalam penelitian atau eksperimen nanomaterial.",
        "descriptionEng": "a person who is engaged in nanomaterial research or experiments.",
        "clazz": "2",
        "$$hashKey": "object:3355"
    },
    {
        "nameEng": "Research engineer (nanotechnology)",
        "code": "NATC",
        "gender": "All",
        "nameInd": "Insinyur riset (nanoteknologi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara mesin, mesin, atau pekerjaan umum",
        "descriptionEng": "a person who designs, builds, or maintains engines, machines, or public works",
        "clazz": "2",
        "$$hashKey": "object:3553"
    },
    {
        "nameEng": "Scientist (3D Integration) / 3D Integration scientist",
        "code": "SCNT",
        "gender": "All",
        "nameInd": "Peneliti (integrasi 3D) / Peneliti integrasi 3D",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti integrasi 3D",
        "descriptionEng": "someone who does research in 3D integration",
        "clazz": "2",
        "$$hashKey": "object:4126"
    },
    {
        "nameEng": "Staff engineer (nanotechnology)",
        "code": "STFE",
        "gender": "All",
        "nameInd": "Staf perekayasa (teknologi nano)",
        "minAge": "0",
        "descriptionInd": "seseorang yang melaksanakan kegiatan penelitian terapan, pengembangan, perekayasaan dan pengoperasian seperti diinstruksikan dalam Program Manual untuk spesifik bidang tertentu,",
        "descriptionEng": "a person conducting applied research, development, engineering and operation activities as instructed in the Manual Program for specific specific areas,",
        "clazz": "2",
        "$$hashKey": "object:4576"
    },
    {
        "nameEng": "Laser engineer",
        "code": "LASE",
        "gender": "All",
        "nameInd": "Insinyur laser",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara mesin laser",
        "descriptionEng": "a person who designs, builds, or maintains laser engines, machines,",
        "clazz": "3",
        "$$hashKey": "object:3539"
    },
    {
        "nameEng": "Laser field service representative",
        "code": "LASS",
        "gender": "All",
        "nameInd": "Perwakilan layanan lapangan laser",
        "minAge": "0",
        "descriptionInd": "seseoeang yang mewakili di layanan  lapangan laser",
        "descriptionEng": "someone who represents in laser field service",
        "clazz": "3",
        "$$hashKey": "object:4399"
    },
    {
        "nameEng": "Laser finisher",
        "code": "LASF",
        "gender": "All",
        "nameInd": "Pemoles laser",
        "minAge": "0",
        "descriptionInd": "seseorang yang memoles laser",
        "descriptionEng": "someone who finishes laser",
        "clazz": "3",
        "$$hashKey": "object:4074"
    },
    {
        "nameEng": "Laser operator",
        "code": "LASO",
        "gender": "All",
        "nameInd": "Operator laser",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasi laser",
        "descriptionEng": "someone who operates laser",
        "clazz": "3",
        "$$hashKey": "object:3784"
    },
    {
        "nameEng": "Laser programmer",
        "code": "LASP",
        "gender": "All",
        "nameInd": "Pemogram laser",
        "minAge": "0",
        "descriptionInd": "seseorang yang memogram laser",
        "descriptionEng": "someone who programs laser",
        "clazz": "3",
        "$$hashKey": "object:4072"
    },
    {
        "nameEng": "Laser scientist",
        "code": "LASC",
        "gender": "All",
        "nameInd": "Peneliti laser",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti laser",
        "descriptionEng": "someone who does research on laser",
        "clazz": "3",
        "$$hashKey": "object:4130"
    },
    {
        "nameEng": "Field service engineer (biomedical)",
        "code": "SREG",
        "gender": "All",
        "nameInd": "Insinyur servis lapangan (biomedis)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara servis lapangan",
        "descriptionEng": "a person who designs, builds, or maintains field service",
        "clazz": "2",
        "$$hashKey": "object:3554"
    },
    {
        "nameEng": "Manufacturing engineer (biomedical)",
        "code": "BIOD",
        "gender": "All",
        "nameInd": "Insinyur manufaktur (biomedis)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara manifaktur",
        "descriptionEng": "a person who designs, builds, or maintains manifacturing engines",
        "clazz": "2",
        "$$hashKey": "object:3543"
    },
    {
        "nameEng": "Molecular biologist",
        "code": "MOLB",
        "gender": "All",
        "nameInd": "Ahli biologi molekuler",
        "minAge": "0",
        "descriptionInd": "seorang ahli di cabang ilmu tentang organisme hidup molekuler.",
        "descriptionEng": "an expert in the branch of science concerning molecular living organisms.",
        "clazz": "1",
        "$$hashKey": "object:3332"
    },
    {
        "nameEng": "Project leader (biomedical)",
        "code": "MOLP",
        "gender": "All",
        "nameInd": "Kepala proyek (biomedis)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengepalai suatu proyek",
        "descriptionEng": "someone who leads in project",
        "clazz": "2",
        "$$hashKey": "object:3614"
    },
    {
        "nameEng": "Quality engineer (biomedical)",
        "code": "MOLQ",
        "gender": "All",
        "nameInd": "Insinyur kualitas (biomedis)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengecek kualitas",
        "descriptionEng": "someone who checks the quality",
        "clazz": "2",
        "$$hashKey": "object:3538"
    },
    {
        "nameEng": "Research scientist (biomedical)",
        "code": "MOLR",
        "gender": "All",
        "nameInd": "Ahli penelitian (biomedis)",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti",
        "descriptionEng": "someone who does research",
        "clazz": "1",
        "$$hashKey": "object:3371"
    },
    {
        "nameEng": "Calibrator",
        "code": "CALB",
        "gender": "All",
        "nameInd": "Pengkalibrasi",
        "minAge": "0",
        "descriptionInd": "peralatan yang digunakan untuk menyesuaikan keakuratan instrumen, sering dikaitkan dengan aplikasi spesifik: suhu, tekanan, berat.",
        "descriptionEng": "an equipment used to adjust an instrument accuracy, often associated with a specific application: temperature, pressure, weight.",
        "clazz": "2",
        "$$hashKey": "object:4244"
    },
    {
        "nameEng": "Clock maker, repairer, assembler",
        "code": "CLCK",
        "gender": "All",
        "nameInd": "Pembuat, pereparasi, perakit jam",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat jam",
        "descriptionEng": "someone who makes clocks",
        "clazz": "2",
        "$$hashKey": "object:4049"
    },
    {
        "nameEng": "Watch repairer",
        "code": "WTRP",
        "gender": "All",
        "nameInd": "Reparasi Arloji",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memperbaiki jam atau arloji.",
        "descriptionEng": "A person who repair clock and watch.",
        "clazz": "2",
        "$$hashKey": "object:4535"
    },
    {
        "nameEng": "Cloth design / Cloth cutter  / Embroiderer",
        "code": "TEXC",
        "gender": "All",
        "nameInd": "Desain pakaian / Pemotong pakaian / Tukang bordir",
        "minAge": "0",
        "descriptionInd": "seseorang yang membordir pakaian",
        "descriptionEng": "someone who embroids",
        "clazz": "3",
        "$$hashKey": "object:3472"
    },
    {
        "nameEng": "Sprayer",
        "code": "SPRY",
        "gender": "All",
        "nameInd": "Penyemprot",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyemprot",
        "descriptionEng": "someone who sprays",
        "clazz": "3",
        "$$hashKey": "object:4358"
    },
    {
        "nameEng": "Engineer (precision engineering) / Engineering technician (precision engineering)",
        "code": "PRGG",
        "gender": "All",
        "nameInd": "Insinyur (rekayasa presisi) / Teknisi rekayasa (rekayasa presisi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempelajari subdisiplin teknik elektro, rekayasa perangkat lunak, teknik elektronik, teknik mesin, dan teknik optik yang berkaitan dengan perancangan mesin, perlengkapan, dan struktur lain yang memiliki toleransi sangat tinggi, dapat diulang, dan stabil dari waktu ke waktu.",
        "descriptionEng": "someone who studies a subdiscipline of electrical engineering, software engineering, electronics engineering, mechanical engineering, and optical engineering concerned with designing machines, fixtures, and other structures that have exceptionally high tolerances, are repeatable, and are stable over time.",
        "clazz": "3",
        "$$hashKey": "object:3530"
    },
    {
        "nameEng": "Musical instruments asembler / Musical instruments maker / Musical instruments repairer",
        "code": "MSIR",
        "gender": "All",
        "nameInd": "Perakit instrumen musik / Pembuat instrumen musik / Penyervis instrumen musik",
        "minAge": "0",
        "descriptionInd": "Orang yang memiliki keahlian dalam dalam memperbaiki instrumen alat musik yang mengalami kerusakan dengan menggunakan alat-alat sehigga alat tersebut menjadi optimal kembali. Dan mereka juga harus terbiasa dengan berbagai jenis alat musik.",
        "descriptionEng": "Musical instrument repair persons are experts in repairing musical instruments that have either been damaged or are out of tune. They may be required to use many different tools and other tricks of the trade to get the instrument back to its optimal performance. They can perform tasks as small as re-stringing a guitar to large projects like restoring pianos that are family heirlooms. Musical instrument repairers must also have familiarity with many types of instruments in order to be able to repair them.",
        "clazz": "2",
        "$$hashKey": "object:4377"
    },
    {
        "nameEng": "Pattern maker",
        "code": "PTTM",
        "gender": "All",
        "nameInd": "Pembuat pola",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat pola",
        "descriptionEng": "someone who makes pattern",
        "clazz": "2",
        "$$hashKey": "object:4035"
    },
    {
        "nameEng": "Plastic spectacle frame maker / Plastic spectacle frame repairer",
        "code": "PLSP",
        "gender": "All",
        "nameInd": "Pembuat rangka kacamata plastik / Penyervis rangka kacamata plastik",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat rangka kacamata plastik",
        "descriptionEng": "someone who makes plastic spectacle frame",
        "clazz": "3",
        "$$hashKey": "object:4038"
    },
    {
        "nameEng": "Precision instrument maker / Precision instrument fitter / Precision instrument repairer  / Precision instruments (machine Operator)",
        "code": "PLIN",
        "gender": "All",
        "nameInd": "Pembuat instrumen presisi / Pemasang instrumen presisi / Penyervis instrumen presisi  / Instrumen presisi (operator mesin)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat instrumen presis",
        "descriptionEng": "someone who makes precision instrument",
        "clazz": "3",
        "$$hashKey": "object:4012"
    },
    {
        "nameEng": "Sports equipment maker / Sports equipment repairer",
        "code": "SPTE",
        "gender": "All",
        "nameInd": "Pembuat peralatan olahraga / Pereparasi peralatan olahraga",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat peralatan olahraga",
        "descriptionEng": "someone who makes sports equipment",
        "clazz": "3",
        "$$hashKey": "object:4028"
    },
    {
        "nameEng": "Surgical appliance maker",
        "code": "SURG",
        "gender": "All",
        "nameInd": "Pembuat peralatan bedah",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat peralatan bedah",
        "descriptionEng": "someone who makes surgical appliance",
        "clazz": "2",
        "$$hashKey": "object:4026"
    },
    {
        "nameEng": "Block cutter",
        "code": "BLOC",
        "gender": "All",
        "nameInd": "Pemotong bata",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong bara",
        "descriptionEng": "someone who cuts block",
        "clazz": "3",
        "$$hashKey": "object:4077"
    },
    {
        "nameEng": "Cleaner (stone) / cleaner (brickwork)",
        "code": "STCL",
        "gender": "All",
        "nameInd": "Pembersih (batu) / pembersih (tembok)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membersikan batu",
        "descriptionEng": "someone who cleans stone",
        "clazz": "3",
        "$$hashKey": "object:3997"
    },
    {
        "nameEng": "Crushing plant operator (stoneworking) / Crushing plant worker (stoneworking)",
        "code": "STCR",
        "gender": "All",
        "nameInd": "Operator mesin penghancur (bangunan) / Pekerja mesin penghancur (bangunan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin pemotong batu",
        "descriptionEng": "someone who operates stone crushing machine",
        "clazz": "3",
        "$$hashKey": "object:3799"
    },
    {
        "nameEng": "Mason  / Mason bricklayer",
        "code": "MSON",
        "gender": "All",
        "nameInd": "Tukang batu / Tukang pelapis batu bata",
        "minAge": "0",
        "descriptionInd": "seorang pengrajin yang meletakkan batu bata untuk membangun tembok, atau yang meletakkan kombinasi batu, batu bata, blok cinder, atau potongan serupa.",
        "descriptionEng": "a craftsman who lays bricks to construct brickwork, or who lays any combination of stones, bricks, cinder blocks, or similar pieces.",
        "clazz": "3",
        "$$hashKey": "object:4658"
    },
    {
        "nameEng": "Planer (stoneworking)",
        "code": "PLNR",
        "gender": "All",
        "nameInd": "Perencana (pekerjaan batu)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat rencana",
        "descriptionEng": "someone who makes plans",
        "clazz": "3",
        "$$hashKey": "object:4394"
    },
    {
        "nameEng": "Restorer (stone) / Restorer( brickwork)",
        "code": "STRS",
        "gender": "All",
        "nameInd": "Pemulih (batu) / Pemulih (pekerjaan bata)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memulih batu",
        "descriptionEng": "someone who restores",
        "clazz": "3",
        "$$hashKey": "object:4088"
    },
    {
        "nameEng": "Stone breaker",
        "code": "STBR",
        "gender": "All",
        "nameInd": "Pemecah batu",
        "minAge": "0",
        "descriptionInd": "seseorang yang memecaha batu",
        "descriptionEng": "someone who breaks stone",
        "clazz": "3",
        "$$hashKey": "object:4050"
    },
    {
        "nameEng": "Stone carver",
        "code": "STCV",
        "gender": "All",
        "nameInd": "Pemahat batu",
        "minAge": "0",
        "descriptionInd": "seseorang yang memahat batu",
        "descriptionEng": "someone who carves stone",
        "clazz": "3",
        "$$hashKey": "object:3946"
    },
    {
        "nameEng": "Stone sawyer",
        "code": "STSW",
        "gender": "All",
        "nameInd": "Penggergaji batu",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggergaji batu",
        "descriptionEng": "someone who saws stone",
        "clazz": "3",
        "$$hashKey": "object:4231"
    },
    {
        "nameEng": "Stone splitter",
        "code": "STSP",
        "gender": "All",
        "nameInd": "Pembelah batu",
        "minAge": "0",
        "descriptionInd": "seseirang yang membelah batu",
        "descriptionEng": "somene who splits stone",
        "clazz": "3",
        "$$hashKey": "object:3991"
    },
    {
        "nameEng": "Stone turner",
        "code": "STTN",
        "gender": "All",
        "nameInd": "Pandai bubut batu",
        "minAge": "0",
        "descriptionInd": "seseorang yang pandai bubut batu",
        "descriptionEng": "someone who turns stone",
        "clazz": "3",
        "$$hashKey": "object:3828"
    },
    {
        "nameEng": "Stonemason",
        "code": "STMS",
        "gender": "All",
        "nameInd": "Tukang batu",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong, mempersiapkan, dan membangun dengan batu.",
        "descriptionEng": "a person who cuts, prepares, and builds with stone.",
        "clazz": "3",
        "$$hashKey": "object:4657"
    },
    {
        "nameEng": "Street mason",
        "code": "STMO",
        "gender": "All",
        "nameInd": "Buruh jalanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong, mempersiapkan, dan membangun dengan batu di jalan",
        "descriptionEng": "a person who cuts, prepares, and builds with stone in street.",
        "clazz": "3",
        "$$hashKey": "object:3458"
    },
    {
        "nameEng": "Baler",
        "code": "BLER",
        "gender": "All",
        "nameInd": "Penari balet",
        "minAge": "0",
        "descriptionInd": "seseorang yang menari balet",
        "descriptionEng": "someone who dances ballet",
        "clazz": "3",
        "$$hashKey": "object:4099"
    },
    {
        "nameEng": "Tailor / Measurer  / Repairer (textiles)",
        "code": "TAIL",
        "gender": "All",
        "nameInd": "Penjahit / Pengukur / Petugas pembetulan (tekstil)",
        "minAge": "0",
        "descriptionInd": "Orang yang membuat pakaian wanita, seperti gaun, blus, dan gaun malam.",
        "descriptionEng": "A dressmaker is a person who makes custom clothing for women, such as dresses, blouses, and evening gowns.",
        "clazz": "2",
        "$$hashKey": "object:4325"
    },
    {
        "nameEng": "Dressmaker",
        "code": "DRES",
        "gender": "All",
        "nameInd": "Pembuat pakaian (manufaktur)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang pekerjaannya membuat atau mengubah pakaian.",
        "descriptionEng": "A person whose occupation is making or altering outer garments.",
        "clazz": "2",
        "$$hashKey": "object:4023"
    },
    {
        "nameEng": "Fashion designer",
        "code": "DSNR",
        "gender": "All",
        "nameInd": "Perancang busana",
        "minAge": "0",
        "descriptionInd": "Perancang busana adalah orang yang membuat rancangan busana.",
        "descriptionEng": "A designer is a person who design clothes.",
        "clazz": "2",
        "$$hashKey": "object:4384"
    },
    {
        "nameEng": "Fashion consultant",
        "code": "FCON",
        "gender": "All",
        "nameInd": "Konsultan Fashion/Mode",
        "minAge": "0",
        "descriptionInd": "Penasihat busana adalah orang yang pekerjaannya merancang busana yang berfungsi juga sebagai penasihat keindahan. Mereka harus mempertimbangkan siapa yang akan menggunakak busananya dan pada situasi apa busana tsb akan digunakan. Mereka memiliki keleluasaan dalam menggunakan bahan-bahan, warna, pola dan gaya yang akan dipilih.",
        "descriptionEng": "Fashion consultant is people whose job is to design clothes which are functional as well as aesthetically pleasing. They must consider who is likely to wear a garment and the situations in which it will be worn. They have a wide range and combinations of materials to work with and a wide range of colors, patterns and styles to choose from.",
        "clazz": "2",
        "$$hashKey": "object:3636"
    },
    {
        "nameEng": "Mender (textiles)",
        "code": "TEXM",
        "gender": "All",
        "nameInd": "Tukang permak pakaian (tekstil)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempermak pakaian",
        "descriptionEng": "someone who mends",
        "clazz": "2",
        "$$hashKey": "object:4692"
    },
    {
        "nameEng": "Printing (textiles)",
        "code": "TEXP",
        "gender": "All",
        "nameInd": "Percetakan (tekstil)",
        "minAge": "0",
        "descriptionInd": "produksi buku, koran, atau materi cetak lainnya.",
        "descriptionEng": "the production of books, newspapers, or other printed material.",
        "clazz": "2",
        "$$hashKey": "object:4393"
    },
    {
        "nameEng": "Bleacher  / Dyer",
        "code": "TEXD",
        "gender": "All",
        "nameInd": "Pemutih / Tukang celup",
        "minAge": "0",
        "descriptionInd": "seseorang yang mencelup",
        "descriptionEng": "someone who bleaches",
        "clazz": "3",
        "$$hashKey": "object:4093"
    },
    {
        "nameEng": "Braider",
        "code": "TEXB",
        "gender": "All",
        "nameInd": "Penganyam",
        "minAge": "0",
        "descriptionInd": "seseorang yang menganyam",
        "descriptionEng": "someone who braids",
        "clazz": "3",
        "$$hashKey": "object:4146"
    },
    {
        "nameEng": "Milliner",
        "code": "MLIN",
        "gender": "All",
        "nameInd": "Pembuat topi wanita",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat topi wanita",
        "descriptionEng": "someone who makes women's hats",
        "clazz": "3",
        "$$hashKey": "object:4045"
    },
    {
        "nameEng": "Machinist / Mechanic (textiles)",
        "code": "TEMC",
        "gender": "All",
        "nameInd": "Ahli mesin / Mekanik (tekstil)",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli di permesinan",
        "descriptionEng": "someone who specializes in machinery",
        "clazz": "3",
        "$$hashKey": "object:3363"
    },
    {
        "nameEng": "Machine attendant (textiles)",
        "code": "TEMH",
        "gender": "All",
        "nameInd": "Penjaga mesin (tekstil)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mejaga mesin",
        "descriptionEng": "someone who attends machine",
        "clazz": "3",
        "$$hashKey": "object:4311"
    },
    {
        "nameEng": "Pattern card cutter",
        "code": "CRDC",
        "gender": "All",
        "nameInd": "Pemotong kartu pola",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong kartu pola",
        "descriptionEng": "somoen who cuts pattern card",
        "clazz": "3",
        "$$hashKey": "object:4080"
    },
    {
        "nameEng": "Sewer",
        "code": "SEWR",
        "gender": "All",
        "nameInd": "Tukang jahit",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di saluran pembuangan",
        "descriptionEng": "someone who works in sew",
        "clazz": "3",
        "$$hashKey": "object:4669"
    },
    {
        "nameEng": "Spinner",
        "code": "SPIN",
        "gender": "All",
        "nameInd": "Pemutar",
        "minAge": "0",
        "descriptionInd": "seorang operator dari mesin yang berputar",
        "descriptionEng": "an operator of machine that spins",
        "clazz": "3",
        "$$hashKey": "object:4092"
    },
    {
        "nameEng": "Upholsterer",
        "code": "FURU",
        "gender": "All",
        "nameInd": "Tukang Pelapis Furniture",
        "minAge": "0",
        "descriptionInd": "Tukang pelapis perabotan rumah adalah orang yang bekerja dengan kain pelapis, khususnya tempat duduk, lapisan, anyaman, dan pelapis kain dan kulit.",
        "descriptionEng": "Upholsterer is someone who works with upholstery , especially seats, with padding, springs, webbing, and fabric or leather covers.",
        "clazz": "2",
        "$$hashKey": "object:4688"
    },
    {
        "nameEng": "Weaver",
        "code": "WEAV",
        "gender": "All",
        "nameInd": "Penenun",
        "minAge": "0",
        "descriptionInd": "seseorang yang menenun",
        "descriptionEng": "someone who weaves",
        "clazz": "2",
        "$$hashKey": "object:4135"
    },
    {
        "nameEng": "Assembler",
        "code": "ASSR",
        "gender": "All",
        "nameInd": "Perakit",
        "minAge": "0",
        "descriptionInd": "seseorang yang merakit",
        "descriptionEng": "someone who assembles",
        "clazz": "3",
        "$$hashKey": "object:4373"
    },
    {
        "nameEng": "Chassis builder",
        "code": "CHAS",
        "gender": "All",
        "nameInd": "Pembuat sasis",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat sasis",
        "descriptionEng": "someone who builds chassis",
        "clazz": "3",
        "$$hashKey": "object:4040"
    },
    {
        "nameEng": "Coach body maker  / Coach builder / Coach trimmer (vehicles)",
        "code": "COAB",
        "gender": "All",
        "nameInd": "Pembuat rangka bangun / Pembuat rangka bangun / Pemotong rangka (kendaraan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat rangka bangun",
        "descriptionEng": "someone who makes coach body",
        "clazz": "3",
        "$$hashKey": "object:4037"
    },
    {
        "nameEng": "Conveyor operator (motor vehicles)",
        "code": "MOCV",
        "gender": "All",
        "nameInd": "Operator konveyor (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan conveyor",
        "descriptionEng": "someone who operates conveyor",
        "clazz": "3",
        "$$hashKey": "object:3775"
    },
    {
        "nameEng": "Crane slinger (motor vehicles)",
        "code": "MOTS",
        "gender": "All",
        "nameInd": "Pengguna sling derek (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggunakan sling derek",
        "descriptionEng": "someone who uses crane slinger",
        "clazz": "3",
        "$$hashKey": "object:4235"
    },
    {
        "nameEng": "Engine tester / Engine rectifier",
        "code": "ENRC",
        "gender": "All",
        "nameInd": "Penguji mesin / Penyearah mesin",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji mesin",
        "descriptionEng": "someone who tests engine",
        "clazz": "3",
        "$$hashKey": "object:4263"
    },
    {
        "nameEng": "Examiner (motor vehicles)",
        "code": "EXMT",
        "gender": "All",
        "nameInd": "Pemeriksa (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji transportasi",
        "descriptionEng": "someone who examines transport",
        "clazz": "2",
        "$$hashKey": "object:4056"
    },
    {
        "nameEng": "Glazier (aircraft)",
        "code": "GLAZ",
        "gender": "All",
        "nameInd": "Tukang kaca (pesawat terbang)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang kaca di pesawat terbang",
        "descriptionEng": "someone who glazes the aircraft",
        "clazz": "3",
        "$$hashKey": "object:4672"
    },
    {
        "nameEng": "Locomotive fitter",
        "code": "LCOM",
        "gender": "All",
        "nameInd": "Pemasang lokomotif",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang lokomotif",
        "descriptionEng": "someone who fits the locomotive",
        "clazz": "3",
        "$$hashKey": "object:3967"
    },
    {
        "nameEng": "Machine operator (motor vehicles)",
        "code": "OPMC",
        "gender": "All",
        "nameInd": "Operator mesin (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan kendaraan mesin",
        "descriptionEng": "someone who operates vehicle machine",
        "clazz": "3",
        "$$hashKey": "object:3786"
    },
    {
        "nameEng": "Maintenance technician (motor vehicles)",
        "code": "TCMC",
        "gender": "All",
        "nameInd": "Teknisi pemeliharaan (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "orang yang dipekerjakan untuk merawat peralatan teknis perawatan kendaraan",
        "descriptionEng": "a person employed to look after technical equipment  of vehicle maintenance",
        "clazz": "3",
        "$$hashKey": "object:4624"
    },
    {
        "nameEng": "Mechanic (motor vehicles)  / Motor vehicle mechanic",
        "code": "MCHT",
        "gender": "All",
        "nameInd": "Mekanik (kendaraan bermotor) / mekanik kendaraan bermotor",
        "minAge": "0",
        "descriptionInd": "seseorang yang memperbaiki dan merawat kendaraan motor",
        "descriptionEng": "a person who repairs and maintains motor vehicle",
        "clazz": "3",
        "$$hashKey": "object:3728"
    },
    {
        "nameEng": "Automobile mechanic",
        "code": "AUMC",
        "gender": "All",
        "nameInd": "Mekanik Mobil",
        "minAge": "0",
        "descriptionInd": "Orang yang terampil dalam memperbaiki dan melakukan pemeliharaan mobil dan truk.",
        "descriptionEng": "Auto mechanics perform skilled repair and maintenance on automobiles and light trucks with related duties as required.",
        "clazz": "3",
        "$$hashKey": "object:3732"
    },
    {
        "nameEng": "Painter (coach) Spray painter (motor vehicle)",
        "code": "PAIN",
        "gender": "All",
        "nameInd": "Petugas Pengecat Kereta Api",
        "minAge": "0",
        "descriptionInd": "Berpengalaman dalam mengecat kereta api dengan menggunakan kuas dengan hasil yang baik. Bekerja sesuai dengan permintaan, dapat mengerjakan lapisan, membuat huruf berbahan viniyl dan memperbaiki pernis. Harus mampu mempersiapkan badan kereta api untuk lukisan, melakukan pengamplasan, filler, perbaikan kecil pada permukaan baja dan kayu dan perbaikan vernis panel interior.",
        "descriptionEng": "Experience preferred in painting of railway vehicles using brush application, working to a high standard of finish. Working to bespoke requirements, be able to apply lining, vinyl lettering and varnish fix transfers. Must be capable of preparing bodywork for painting, involving sanding, body filler, small repairs to steel and timber surfaces and the refurbishment of interior varnished panels and fittings.",
        "clazz": "2",
        "$$hashKey": "object:4472"
    },
    {
        "nameEng": "Painting plant operator",
        "code": "PPLO",
        "gender": "All",
        "nameInd": "Operator pabrik pengecatan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pabrik pengecatan",
        "descriptionEng": "someone who operates painting plant",
        "clazz": "3",
        "$$hashKey": "object:3804"
    },
    {
        "nameEng": "Railway wagon fitter",
        "code": "RLWY",
        "gender": "All",
        "nameInd": "Pemasang gerbong kereta",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang gerbong kereta",
        "descriptionEng": "someone who fits railway wagon",
        "clazz": "3",
        "$$hashKey": "object:3959"
    },
    {
        "nameEng": "Road tester (motor vehicle)",
        "code": "ROAT",
        "gender": "All",
        "nameInd": "Penguji jalanan (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menguji jalanan",
        "descriptionEng": "someone who tests  road",
        "clazz": "3",
        "$$hashKey": "object:4262"
    },
    {
        "nameEng": "Vehicle body builder  / Wehicle body fitter",
        "code": "VECH",
        "gender": "All",
        "nameInd": "Pembangun bodi kendaraan / petugas pemasang bodi kendaraan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membangun bodi kendaraan",
        "descriptionEng": "someone who builds vehicle bodi",
        "clazz": "3",
        "$$hashKey": "object:3982"
    },
    {
        "nameEng": "Arc cutter / Arc welder / Welding machine operator / Welders / Welder / Cutters / Brazer / Solderer / Welder (ship building and repair)",
        "code": "ARCW",
        "gender": "All",
        "nameInd": "Tukang Las",
        "minAge": "0",
        "descriptionInd": "Seorang pedagang yang mengkhususkan diri dalam pengelasan.",
        "descriptionEng": "is a tradesman who specializes in welding materials together.",
        "clazz": "3",
        "$$hashKey": "object:4681"
    },
    {
        "nameEng": "Flame cutter  / Oxy-acetylene cutter",
        "code": "FLMC",
        "gender": "All",
        "nameInd": "Pemotong api / Pemotong oksi-asetilena",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong api",
        "descriptionEng": "someone who cuts flame",
        "clazz": "3",
        "$$hashKey": "object:4076"
    },
    {
        "nameEng": "Abrasive paper goods maker",
        "code": "APGM",
        "gender": "All",
        "nameInd": "Pembuat barang kertas amplas",
        "minAge": "0",
        "descriptionInd": "seseorag yang membuat barang kertas amplas",
        "descriptionEng": "someone who makes abrasive paper goods",
        "clazz": "3",
        "$$hashKey": "object:4006"
    },
    {
        "nameEng": "Wood assembler / Assembler (woodworking)",
        "code": "WODA",
        "gender": "All",
        "nameInd": "Perakit kayu / Perakit (bahan kayu)",
        "minAge": "0",
        "descriptionInd": "seseorang yang merakit kayu",
        "descriptionEng": "someone who assembles wood",
        "clazz": "3",
        "$$hashKey": "object:4378"
    },
    {
        "nameEng": "Cabinet maker (wood)",
        "code": "CBNM",
        "gender": "All",
        "nameInd": "Pembuat lemari (kayu)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat lemari kayu",
        "descriptionEng": "someone who makes wood cabinet",
        "clazz": "3",
        "$$hashKey": "object:4018"
    },
    {
        "nameEng": "Straddle carrier driver",
        "code": "STRD",
        "gender": "All",
        "nameInd": "Pengemudi kendaraan bongkar muat",
        "minAge": "0",
        "descriptionInd": "seseroang yang mengemudi stradlle carrier",
        "descriptionEng": "someone who drives straddle carrier",
        "clazz": "3",
        "$$hashKey": "object:4212"
    },
    {
        "nameEng": "Siloman",
        "code": "SILO",
        "gender": "All",
        "nameInd": "Pencurah",
        "minAge": "0",
        "descriptionInd": "pemberian air irigasi ke tanaman",
        "descriptionEng": "an irrigation water supply to plants",
        "clazz": "3",
        "$$hashKey": "object:4117"
    },
    {
        "nameEng": "Road worker",
        "code": "ROAW",
        "gender": "All",
        "nameInd": "Pekerja jalanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di jalan",
        "descriptionEng": "someone who works in the road",
        "clazz": "3",
        "$$hashKey": "object:3866"
    },
    {
        "nameEng": "Carpenter  / Sander / Machine operator (woodworking) / Wood work machine operator / Wood carver  / Wood worker / Fitter (woodworking) / Wood fitter / Wood joiner / Kitchen fitter",
        "code": "CHCP",
        "gender": "All",
        "nameInd": "Tukang Kayu / Pekerja sander kayu / Operator mesin (bahan kayu) / Operator mesin pekerjaan kayu / Pengukir kayu / Pekerja kayu / Petugas pemasang (bahan kayu) / Petugas pemasang kayu / Penyambung kayu / Petugas pemasang dapur",
        "minAge": "0",
        "descriptionInd": "Pekerja yang mempunyai keahlian dalam membuat, menyelesaikan dan memperbaiki barang-barang/struktur dari kayu.",
        "descriptionEng": "A skilled worker who makes, finishes, and repairs wooden objects and structures.",
        "clazz": "3",
        "$$hashKey": "object:4676"
    },
    {
        "nameEng": "Circular sawyer",
        "code": "CICS",
        "gender": "All",
        "nameInd": "Gergaji putar",
        "minAge": "0",
        "descriptionInd": "Seseorang yang menyiapkan dan mengoperasikan gergaji gigi melingkar dari berlian atau silikon karbida untuk memotong balok-balok batu menjadi dimensi tertentu: Membangun tempat tidur dari kayu pada persiapan mobil untuk menempatkan batu pada mobil.",
        "descriptionEng": "Someone who sets up and operates diamond-or silicon carbide-tooth circular saw to cut blocks of stone into specified dimension: Builds bed of timbers on car preparatory to positioning stone on car.",
        "clazz": "3",
        "$$hashKey": "object:3514"
    },
    {
        "nameEng": "Coffin maker",
        "code": "COFF",
        "gender": "All",
        "nameInd": "Pembuat peti mati",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat peti mati",
        "descriptionEng": "someone who makes coffin",
        "clazz": "3",
        "$$hashKey": "object:4033"
    },
    {
        "nameEng": "Furniture designer",
        "code": "DSGF",
        "gender": "All",
        "nameInd": "Perancang furnitur",
        "minAge": "0",
        "descriptionInd": "seseorang yang merancang furnitur",
        "descriptionEng": "someone who designs furniture",
        "clazz": "1",
        "$$hashKey": "object:4385"
    },
    {
        "nameEng": "Saw repairer  / Saw sharpener",
        "code": "SAWR",
        "gender": "All",
        "nameInd": "Tukang reparasi gergaji / Pengasah gergaji",
        "minAge": "0",
        "descriptionInd": "seseorang yang memperbaiki dan mengasah gergaji",
        "descriptionEng": "someone who repairs and sharpens saw",
        "clazz": "3",
        "$$hashKey": "object:4698"
    },
    {
        "nameEng": "Sawing machine operators",
        "code": "SAWM",
        "gender": "All",
        "nameInd": "Operator mesin gergaji",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin gergaji",
        "descriptionEng": "someone who operates sawing machine",
        "clazz": "3",
        "$$hashKey": "object:3792"
    },
    {
        "nameEng": "Sawmill manager",
        "code": "SAWG",
        "gender": "All",
        "nameInd": "Manajer kilang gergaji",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola kilang gergaji",
        "descriptionEng": "someone who manages sawmill",
        "clazz": "3",
        "$$hashKey": "object:3681"
    },
    {
        "nameEng": "Varnisher",
        "code": "VARN",
        "gender": "All",
        "nameInd": "Tukang pernis",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempernis",
        "descriptionEng": "someone who varnishes",
        "clazz": "3",
        "$$hashKey": "object:4693"
    },
    {
        "nameEng": "Baggage master",
        "code": "BAGG",
        "gender": "All",
        "nameInd": "Pekerja bagasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di bagasi",
        "descriptionEng": "someone who works in baggage",
        "clazz": "3",
        "$$hashKey": "object:3859"
    },
    {
        "nameEng": "Bargeman",
        "code": "BARG",
        "gender": "All",
        "nameInd": "Pekerja kapal tongkang",
        "minAge": "0",
        "descriptionInd": "seseorang yang bertanggung jawab atas, atau bekerja pada, tongkang",
        "descriptionEng": "a person who has charge of, or works on, a barge.",
        "clazz": "3",
        "$$hashKey": "object:3868"
    },
    {
        "nameEng": "Dredgerman",
        "code": "DRVD",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Kapal Keruk",
        "minAge": "0",
        "descriptionInd": "Orang yang mengoperasikan perangkat, mesin atau kapal yang digunakan untuk menggali dan menyingkirkan materi dari bagian bawah badan air.",
        "descriptionEng": "Someone who operates device, machine, or vessel that is used to excavate and remove material from the bottom of a body of water.",
        "clazz": "3",
        "$$hashKey": "object:4194"
    },
    {
        "nameEng": "Boat builder",
        "code": "BTBU",
        "gender": "All",
        "nameInd": "Pembuat perahu",
        "minAge": "0",
        "descriptionInd": "seseorang yang membangun perahu",
        "descriptionEng": "someone who builds boat",
        "clazz": "3",
        "$$hashKey": "object:4025"
    },
    {
        "nameEng": "Dredgermaster",
        "code": "DRED",
        "gender": "All",
        "nameInd": "Master kapal keruk",
        "minAge": "0",
        "descriptionInd": "seseorang yang beroperasi mengeruk untuk menghilangkan pasir, kerikil, atau bahan lain dari danau, sungai, atau sungai; dan untuk menggali dan memelihara saluran navigasi di saluran air.",
        "descriptionEng": "someone who operates dredge to remove sand, gravel, or other materials from lakes, rivers, or streams; and to excavate and maintain navigable channels in waterways.",
        "clazz": "3",
        "$$hashKey": "object:3726"
    },
    {
        "nameEng": "Leadsman",
        "code": "LDSM",
        "gender": "All",
        "nameInd": "Pengukur kedalaman laut",
        "minAge": "0",
        "descriptionInd": "seorang pria yang menggunakan petunjuk untuk menentukan kedalaman air.",
        "descriptionEng": "a man who uses a sounding lead to determine depth of water.",
        "clazz": "3",
        "$$hashKey": "object:4272"
    },
    {
        "nameEng": "Lighterman",
        "code": "LGHT",
        "gender": "All",
        "nameInd": "Pengoperasi tongkang",
        "minAge": "0",
        "descriptionInd": "seorang pekerja yang mengoperasikan pemantik, sejenis tongkang beralas datar, yang mungkin diberi tenaga atau tidak bertenaga.",
        "descriptionEng": "a worker who operates a lighter, a type of flat-bottomed barge, which may be powered or unpowered.",
        "clazz": "3",
        "$$hashKey": "object:4257"
    },
    {
        "nameEng": "Navigator",
        "code": "NVGT",
        "gender": "All",
        "nameInd": "Ahli navigasi (kapal niaga)",
        "minAge": "0",
        "descriptionInd": "orang di atas kapal yang bertanggung jawab untuk navigasi.",
        "descriptionEng": "�the person on board a ship who responsible for its navigation.�",
        "clazz": "1",
        "$$hashKey": "object:3367"
    },
    {
        "nameEng": "Pilot",
        "code": "MPIL",
        "gender": "All",
        "nameInd": "Pilot (kapal niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menavigasi kapal (kapal niaga)",
        "descriptionEng": "a person who navigates a ship (merchant marine)",
        "clazz": "3",
        "$$hashKey": "object:4508"
    },
    {
        "nameEng": "Radio officer (merchant marine)",
        "code": "RDIF",
        "gender": "All",
        "nameInd": "Staf radio (kapal niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di radio kapal niaga",
        "descriptionEng": "someone who works in radio merchant marine",
        "clazz": "1",
        "$$hashKey": "object:4579"
    },
    {
        "nameEng": "Survey sounder",
        "code": "SRVS",
        "gender": "All",
        "nameInd": "Penduga survei",
        "minAge": "0",
        "descriptionInd": "seseorang yang menduga survey",
        "descriptionEng": "someone who guesses on survey",
        "clazz": "3",
        "$$hashKey": "object:4122"
    },
    {
        "nameEng": "Tugboatman",
        "code": "TUGB",
        "gender": "All",
        "nameInd": "Kru tugboat",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di tugboat",
        "descriptionEng": "someone who works in a tugboat",
        "clazz": "3",
        "$$hashKey": "object:3656"
    },
    {
        "nameEng": "Computer engineer",
        "code": "CMPE",
        "gender": "All",
        "nameInd": "Insinyur komputer",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain komputer",
        "descriptionEng": "a person who designs computer",
        "clazz": "1",
        "$$hashKey": "object:3536"
    },
    {
        "nameEng": "Design Engineer",
        "code": "DSGR",
        "gender": "All",
        "nameInd": "Insinyur desain",
        "minAge": "0",
        "descriptionInd": "seseroang yang merancang desain",
        "descriptionEng": "a person who builds design",
        "clazz": "1",
        "$$hashKey": "object:3532"
    },
    {
        "nameEng": "Embedded systems scientist",
        "code": "EMSY",
        "gender": "All",
        "nameInd": "Peneliti sistem tertanam",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti sistem tertanam",
        "descriptionEng": "someone who does research on embedded system",
        "clazz": "1",
        "$$hashKey": "object:4133"
    },
    {
        "nameEng": "Fabrication engineer",
        "code": "FABR",
        "gender": "All",
        "nameInd": "Insinyur pabrikasi",
        "minAge": "0",
        "descriptionInd": "Seseorang yang meneliti, merancang, pengembangan, modifikasi, dan pemasangan produk palsu untuk tujuan yang bervariasi.",
        "descriptionEng": "A person who research, design, development, modification, and installation of fabricated products for varied purposes.",
        "clazz": "1",
        "$$hashKey": "object:3545"
    },
    {
        "nameEng": "Research technologist",
        "code": "RSER",
        "gender": "All",
        "nameInd": "Ahli teknologi riset",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam teknologi riset",
        "descriptionEng": "someone who specializes in research technology",
        "clazz": "1",
        "$$hashKey": "object:3383"
    },
    {
        "nameEng": "Robot operator",
        "code": "RBOT",
        "gender": "All",
        "nameInd": "Operator robot",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan robot",
        "descriptionEng": "someone who operates robot",
        "clazz": "2",
        "$$hashKey": "object:3818"
    },
    {
        "nameEng": "Software development",
        "code": "SFWR",
        "gender": "All",
        "nameInd": "Pengembangan perangkat lunak",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengembangkan perangkat lunak",
        "descriptionEng": "someone who develops software",
        "clazz": "1",
        "$$hashKey": "object:4186"
    },
    {
        "nameEng": "Software Analyst",
        "code": "SWPR",
        "gender": "All",
        "nameInd": "Analist Software",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang ahli dalam domain aplikasi perangkat lunak dan mempersiapkan spesifikasi persyaratan perangkat lunak.",
        "descriptionEng": "is the person who studies the software application domain and prepares the software requirements and specification (Software Requirements Specification) document.",
        "clazz": "1",
        "$$hashKey": "object:3402"
    },
    {
        "nameEng": "Book keeper / Financial book keeper",
        "code": "BOOK",
        "gender": "All",
        "nameInd": "Pencatat pembukuan / Pencatat pembukuan keuangan",
        "minAge": "0",
        "descriptionInd": "Orang yang melakukan pencatatan rekening dan transaksi bisnis.",
        "descriptionEng": "A person who records the accounts and transactions of a business.",
        "clazz": "1",
        "$$hashKey": "object:4111"
    },
    {
        "nameEng": "Student",
        "code": "STDN",
        "gender": "All",
        "nameInd": "Pelajar",
        "minAge": "0",
        "descriptionInd": "Pelajar adalah seseorang yang sedang belajar pada institusi pendidikan.",
        "descriptionEng": "A student is a learner, or someone who attends an educational institution.",
        "clazz": "1",
        "$$hashKey": "object:3911"
    },
    {
        "nameEng": "Court usher",
        "code": "CUSH",
        "gender": "All",
        "nameInd": "Staf pengadilan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di pengadilan",
        "descriptionEng": "someone who works in court",
        "clazz": "1",
        "$$hashKey": "object:4571"
    },
    {
        "nameEng": "Civil engineer / Construction planning engineer / Construction structural engineer",
        "code": "CSTE",
        "gender": "All",
        "nameInd": "Insinyur sipil / Insinyur perencanaan konstruksi / Insinyur struktur konstruksi",
        "minAge": "0",
        "descriptionInd": "Seorang insinyur yang merancang dan memelihara jalan, jembatan, bendungan, dan struktur serupa lainnya.",
        "descriptionEng": "An engineer who designs and maintains roads, bridges, dams, and similar structures.",
        "clazz": "1",
        "$$hashKey": "object:3556"
    },
    {
        "nameEng": "Banksman",
        "code": "BNKS",
        "gender": "All",
        "nameInd": "Pengoperasi crane",
        "minAge": "0",
        "descriptionInd": "Orang yang mengoperasikan Crane atau Kendaraan berat",
        "descriptionEng": "the person who directs the operation of a crane or larger vehicle from the point near where loads are attached and detached.",
        "clazz": "3",
        "$$hashKey": "object:4254"
    },
    {
        "nameEng": "Boiler operatorBoilerman",
        "code": "BLRM",
        "gender": "All",
        "nameInd": "Petugas Tungku Ruang Pemanas pada mesin uap",
        "minAge": "0",
        "descriptionInd": "Orang yang tugasnya adalah menyalakan api untuk menjalankan mesin uap.",
        "descriptionEng": "Someone whose job is to tend the fire for the running of a steam engine.",
        "clazz": "3",
        "$$hashKey": "object:4503"
    },
    {
        "nameEng": "Oceanographer",
        "code": "OCGR",
        "gender": "All",
        "nameInd": "Ahli ilmu kelautan",
        "minAge": "0",
        "descriptionInd": "ilmuwan yang mempelajari laut",
        "descriptionEng": "scientists who study the sea",
        "clazz": "2",
        "$$hashKey": "object:3345"
    },
    {
        "nameEng": "Engine and machine assemblers / Mechanic (ship building and repair) / Team assemblers (machinery) / Wrapping machine attendant mechanic (ship building and repair)",
        "code": "WRMC",
        "gender": "All",
        "nameInd": "Perakit engine dan mesin /  / Mekanik (pembangunan dan perbaikan kapal) / Tim perakit (permesinan) / Mekanik petugas mesin pengemas (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memperbaiki dan merawat mesin",
        "descriptionEng": "a person who repairs and maintains machinery",
        "clazz": "3",
        "$$hashKey": "object:4376"
    },
    {
        "nameEng": "Mechanic / Mechanic (machinery)",
        "code": "GARW",
        "gender": "All",
        "nameInd": "Mekanik / Mekanik (permesinan)",
        "minAge": "0",
        "descriptionInd": "Tukang Bengkel yaitu seseorang yang bekerja di bengkel (mekanik).",
        "descriptionEng": "A garage worker is someone who works in workshop.",
        "clazz": "3",
        "$$hashKey": "object:3729"
    },
    {
        "nameEng": "Maintenance technician (chemicals and plastics) / Maintenance technician (metals) /",
        "code": "MATC",
        "gender": "All",
        "nameInd": "Teknisi perawatan (bahan kimia dan plastik) / Teknisi perawatan (logam)",
        "minAge": "0",
        "descriptionInd": "Orang yang menangani pembayaran dan menerima pembayaran di toko,bank atau usaha lainnya.",
        "descriptionEng": "A person handling payments and receipts in a store, bank, or other business.",
        "clazz": "2",
        "$$hashKey": "object:4632"
    },
    {
        "nameEng": "Cashier",
        "code": "CASH",
        "gender": "All",
        "nameInd": "Kasir",
        "minAge": "0",
        "descriptionInd": "Orang yang menangani pembayaran dan menerima pembayaran di toko,bank atau usaha lainnya.",
        "descriptionEng": "A person handling payments and receipts in a store, bank, or other business.",
        "clazz": "1",
        "$$hashKey": "object:3599"
    },
    {
        "nameEng": "Governor / Prison senior manager",
        "code": "GOVT",
        "gender": "All",
        "nameInd": "Kepala penjara / Manajer senior penjara",
        "minAge": "0",
        "descriptionInd": "Aparat pemerintahan adalah orang-orang yang bekerja di kantor pemerintahan.",
        "descriptionEng": "Government officer are people who work in government.",
        "clazz": "2",
        "$$hashKey": "object:3610"
    },
    {
        "nameEng": "Prison manager",
        "code": "PRIG",
        "gender": "All",
        "nameInd": "Manajer penjara",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola penjara",
        "descriptionEng": "someone who manages prison",
        "clazz": "2",
        "$$hashKey": "object:3694"
    },
    {
        "nameEng": "Prison officer / Prison warder / Detention centre warder",
        "code": "PRIO",
        "gender": "All",
        "nameInd": "Staf penjara / Sipir penjara  / Sipir rumah tahanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di penjara",
        "descriptionEng": "someone who works in prison",
        "clazz": "3",
        "$$hashKey": "object:4573"
    },
    {
        "nameEng": "Prisonner Officer",
        "code": "PRIS",
        "gender": "All",
        "nameInd": "Petugas Lapas (Lembaga Pemasyarakatan)",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab dalam mengawasi, menjaga keamanan dan keselamatan para tahanan di dalam penjara, rumah tahanan atau tempat serupa.",
        "descriptionEng": "is a person responsible for the supervision, safety and security of prisoners in a prison, jail, or similar form of secure custody.",
        "clazz": "3",
        "$$hashKey": "object:4441"
    },
    {
        "nameEng": "Probation officer",
        "code": "PROB",
        "gender": "All",
        "nameInd": "Staf percobaan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja dalam masa percobaan",
        "descriptionEng": "someone who works in probation",
        "clazz": "1",
        "$$hashKey": "object:4575"
    },
    {
        "nameEng": "Advertising manager",
        "code": "ADVM",
        "gender": "All",
        "nameInd": "Manajer periklanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola periklanan",
        "descriptionEng": "someone who manages in advertising",
        "clazz": "1",
        "$$hashKey": "object:3696"
    },
    {
        "nameEng": "Artworker",
        "code": "ARTW",
        "gender": "All",
        "nameInd": "Pekerja seni",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja seni",
        "descriptionEng": "someone who works for art",
        "clazz": "1",
        "$$hashKey": "object:3904"
    },
    {
        "nameEng": "Copywriter",
        "code": "CPYW",
        "gender": "All",
        "nameInd": "Penulis iklan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja menulis copy",
        "descriptionEng": "seseorang who writes copy",
        "clazz": "1",
        "$$hashKey": "object:4345"
    },
    {
        "nameEng": "Marketing manager",
        "code": "MKTM",
        "gender": "All",
        "nameInd": "Manajer pemasaran",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola pemasaran",
        "descriptionEng": "someone who manages marketing",
        "clazz": "1",
        "$$hashKey": "object:3690"
    },
    {
        "nameEng": "Marketing",
        "code": "MKTG",
        "gender": "All",
        "nameInd": "Tenaga Pemasaran",
        "minAge": "0",
        "descriptionInd": "Tenaga pemasaran yang membantu penjualan dan manajemen pemasaran dengan media komunikasi dan pemasangan iklan secara efektif mewakili produk dan layanan perusahaan kepada pelanggan dan calon pelanggan.",
        "descriptionEng": "To assist sales and marketing management with communications media and advertising materials to effectively represent the company's products and services to customers and prospects.",
        "clazz": "2",
        "$$hashKey": "object:4644"
    },
    {
        "nameEng": "Media designer",
        "code": "MEDD",
        "gender": "All",
        "nameInd": "Desainer media",
        "minAge": "0",
        "descriptionInd": "seseorang yang merancang media",
        "descriptionEng": "someone who designs media",
        "clazz": "1",
        "$$hashKey": "object:3475"
    },
    {
        "nameEng": "Publisher (media) / Media publisher",
        "code": "PUBM",
        "gender": "All",
        "nameInd": "Penerbit (media) / Media penerbit",
        "minAge": "0",
        "descriptionInd": "seseorang yang menerbitkan media",
        "descriptionEng": "someone who publishes media",
        "clazz": "1",
        "$$hashKey": "object:4137"
    },
    {
        "nameEng": "Video editor",
        "code": "VDED",
        "gender": "All",
        "nameInd": "Editor video",
        "minAge": "0",
        "descriptionInd": "Seseorang yang terlibat secara teknis dalam proses pengeditan suatu video.",
        "descriptionEng": "A video editor is a technically inclined individual that is involved with making creative video editing decision in the post-production of film making and video production.",
        "clazz": "1",
        "$$hashKey": "object:3500"
    },
    {
        "nameEng": "Website content manager",
        "code": "WEBC",
        "gender": "All",
        "nameInd": "Manajer konten situs web",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola konten situs web",
        "descriptionEng": "someone who manages wesbsite content",
        "clazz": "1",
        "$$hashKey": "object:3683"
    },
    {
        "nameEng": "Columnist",
        "code": "COLU",
        "gender": "All",
        "nameInd": "Penulis kolom",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis kolom",
        "descriptionEng": "someone who writes coloumn",
        "clazz": "1",
        "$$hashKey": "object:4347"
    },
    {
        "nameEng": "Copytaker",
        "code": "CPYT",
        "gender": "All",
        "nameInd": "Penulis jurnalis",
        "minAge": "0",
        "descriptionInd": "seseorang yang mencatat untuk jurnalis",
        "descriptionEng": "someone who takes notes for journalist",
        "clazz": "1",
        "$$hashKey": "object:4346"
    },
    {
        "nameEng": "Correspondent",
        "code": "CRSP",
        "gender": "All",
        "nameInd": "Koresponden",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis surat kepada seseorang atau surat kabar, terutama secara teratur.",
        "descriptionEng": "a person who writes letters to a person or a newspaper, especially on a regular basis.",
        "clazz": "1",
        "$$hashKey": "object:3652"
    },
    {
        "nameEng": "Critic",
        "code": "CRIT",
        "gender": "All",
        "nameInd": "Kritikus",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengungkapkan pendapat yang tidak menyenangkan tentang sesuatu.",
        "descriptionEng": "a person who expresses an unfavorable opinion of something.",
        "clazz": "1",
        "$$hashKey": "object:3653"
    },
    {
        "nameEng": "News editor / Editor (publishing and printing)",
        "code": "EDIT",
        "gender": "All",
        "nameInd": "Editor berita / Editor (penerbit dan percetakan)",
        "minAge": "0",
        "descriptionInd": "Editor adalah seorang yang bekerja sebagai jurnalis yang memberikan kontribusi atas suatu publikasi, dapat juga disebut sebagai reporter.",
        "descriptionEng": "An editor is a journalist who contributes content to a publication. Sometimes it is called a roving reporter or reving editor.",
        "clazz": "1",
        "$$hashKey": "object:3498"
    },
    {
        "nameEng": "Publication Editor",
        "code": "PUBE",
        "gender": "All",
        "nameInd": "Editor Publikasi",
        "minAge": "0",
        "descriptionInd": "Menyusun rencana, mengkoordinasikan atau mengedit isi dari materi yang akan dipublikasikan. Menyusun proposal atau draft yang akan dipublikasikan, termasuk tekhnikal editor.",
        "descriptionEng": "Plan, coordinate, or edit content of material for publication. May review proposals and drafts for possible publication. Includes technical editors.",
        "clazz": "2",
        "$$hashKey": "object:3499"
    },
    {
        "nameEng": "Reporter - no travel",
        "code": "REPN",
        "gender": "All",
        "nameInd": "Wartawan (Tidak berpergian)",
        "minAge": "0",
        "descriptionInd": "Adalah jenis wartawan yang meneliti, menulis, dan membuat laporan informasi, melakukan wawancara, terlibat dalam penelitian, dan membuat laporan.",
        "descriptionEng": "is a type of journalist who researches, writes, and reports information to present in sources, conduct interviews, engage in research, and make reports.",
        "clazz": "2",
        "$$hashKey": "object:4718"
    },
    {
        "nameEng": "Reporter - with travel",
        "code": "REPR",
        "gender": "All",
        "nameInd": "Wartawan (Bepergian)",
        "minAge": "0",
        "descriptionInd": "Adalah jenis wartawan yang meneliti, menulis, dan membuat laporan informasi, melakukan wawancara, terlibat dalam penelitian, dan membuat laporan dan kadang kadang melakukan perjalanan ke daerah tertentu untuk melakukan reportase.",
        "descriptionEng": "is a type of journalist who researches, writes, and reports information to present in sources, conduct interviews, engage in research, make reports and they sometimes go to specific areas to do the reporting.",
        "clazz": "3",
        "$$hashKey": "object:4717"
    },
    {
        "nameEng": "News photographer",
        "code": "NEWP",
        "gender": "All",
        "nameInd": "Fotografer berita",
        "minAge": "0",
        "descriptionInd": "seseorag yang mengambil gambar untuk berita",
        "descriptionEng": "someone who takes pictures for news",
        "clazz": "1",
        "$$hashKey": "object:3512"
    },
    {
        "nameEng": "Researcher (journalism) / Media researcher",
        "code": "JORS",
        "gender": "All",
        "nameInd": "Peneliti (jurnalisme) / Peneliti media",
        "minAge": "0",
        "descriptionInd": "seseorang yang meneliti media",
        "descriptionEng": "someone who researches the media",
        "clazz": "2",
        "$$hashKey": "object:4127"
    },
    {
        "nameEng": "Writer (news) / Media writer / Writer",
        "code": "WRTR",
        "gender": "All",
        "nameInd": "Penulis (berita) / Penulis media / Penulis",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas mengumpulkan, menulis, dan mendistribusikan berita maupun informasi lainnya.",
        "descriptionEng": "A person who collects, writes, and distributes news and other information.",
        "clazz": "1",
        "$$hashKey": "object:4344"
    },
    {
        "nameEng": "Technical Writer",
        "code": "TCHW",
        "gender": "All",
        "nameInd": "Penulis Teknis",
        "minAge": "0",
        "descriptionInd": "Seorang penulis profesional yang terlibat dalam teknis penulisan dan teknis penghasilan suatu dokumentasi.",
        "descriptionEng": "is a professional writer who engages in technical writing and produces technical documentation.",
        "clazz": "1",
        "$$hashKey": "object:4351"
    },
    {
        "nameEng": "Author",
        "code": "AUTH",
        "gender": "All",
        "nameInd": "Pengarang",
        "minAge": "0",
        "descriptionInd": "Orang yang menulis buku atau novel sebagai profesinya.",
        "descriptionEng": "A person who practices writing of books/novels as a profession.",
        "clazz": "1",
        "$$hashKey": "object:4147"
    },
    {
        "nameEng": "Bill sticker",
        "code": "BIST",
        "gender": "All",
        "nameInd": "Pemasang poster",
        "minAge": "0",
        "descriptionInd": "seseorang yang menempelkan tempelan atau plakat di dinding atau papan iklan.",
        "descriptionEng": "someone who pastes up�bills�or placards on walls or billboards.",
        "clazz": "1",
        "$$hashKey": "object:3974"
    },
    {
        "nameEng": "Bindery worker  / Bookbinder",
        "code": "BOOB",
        "gender": "All",
        "nameInd": "Pekerja mesin pengikat / Penjilid buku",
        "minAge": "0",
        "descriptionInd": "Orang atau perusahaan yang pekerjaannya adalah menjilid buku.",
        "descriptionEng": "A person or company whose business or work is the binding of books.",
        "clazz": "1",
        "$$hashKey": "object:3877"
    },
    {
        "nameEng": "Book illustrator",
        "code": "BOKI",
        "gender": "All",
        "nameInd": "Pembuat ilustrasi buku",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat ilustrasi pada buku",
        "descriptionEng": "someone who illustrate for books",
        "clazz": "1",
        "$$hashKey": "object:4011"
    },
    {
        "nameEng": "Design cutter",
        "code": "DCUT",
        "gender": "All",
        "nameInd": "Pemotong pola",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong pola",
        "descriptionEng": "someone who cuts design",
        "clazz": "1",
        "$$hashKey": "object:4084"
    },
    {
        "nameEng": "Engraver (publishing and printing )",
        "code": "EGRV",
        "gender": "All",
        "nameInd": "Pengukir (penerbitan dan percetakan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengukir media",
        "descriptionEng": "somone who engraves media",
        "clazz": "1",
        "$$hashKey": "object:4269"
    },
    {
        "nameEng": "Estimator (publishing and printing )",
        "code": "ESTM",
        "gender": "All",
        "nameInd": "Estimator (penerbitan dan percetakan)",
        "minAge": "0",
        "descriptionInd": "seseorang  yang membuat estimasi pada media",
        "descriptionEng": "someone who estimates for media",
        "clazz": "1",
        "$$hashKey": "object:3507"
    },
    {
        "nameEng": "Etcher (publishing and printing )",
        "code": "ETCH",
        "gender": "All",
        "nameInd": "Etsa (penerbitan dan percetakan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengetsa media",
        "descriptionEng": "someone who etches  media",
        "clazz": "3",
        "$$hashKey": "object:3508"
    },
    {
        "nameEng": "Laminator (publishing and printing )",
        "code": "LAMI",
        "gender": "All",
        "nameInd": "Pelaminasi (penerbitan dan percetakan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memisahkan atau membagi menjadi lapisan tipis.",
        "descriptionEng": "someone who separates or splits into thin layers.",
        "clazz": "2",
        "$$hashKey": "object:3914"
    },
    {
        "nameEng": "Linotyper",
        "code": "LINO",
        "gender": "All",
        "nameInd": "Petugas linotype",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan keyboard mesin linotype",
        "descriptionEng": "�someone that operates the keyboard of a Linotype machine.",
        "clazz": "2",
        "$$hashKey": "object:4445"
    },
    {
        "nameEng": "Train guard / Guard (rail)",
        "code": "TRGD",
        "gender": "All",
        "nameInd": "Penjaga kereta / Penjaga (rel)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga kereta",
        "descriptionEng": "someone who guards the train",
        "clazz": "2",
        "$$hashKey": "object:4307"
    },
    {
        "nameEng": "Door to door sales",
        "code": "DOOD",
        "gender": "All",
        "nameInd": "Penjual dari pintu ke pintu",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual barang dari pintu ke pintu",
        "descriptionEng": "someone who selles stuff door to door",
        "clazz": "2",
        "$$hashKey": "object:4333"
    },
    {
        "nameEng": "Literary agent",
        "code": "LITE",
        "gender": "All",
        "nameInd": "Agen literatur",
        "minAge": "0",
        "descriptionInd": "agen yang mewakili penulis dan karya tulis mereka untuk penerbit, produser teater, produser film, dan studio film, dan membantu dalam penjualan dan negosiasi kesepakatan yang sama.",
        "descriptionEng": "�an agent who represents writers and their written works to publishers, theatrical producers, film producers, and film studios, and assists in the sale and deal negotiation of the same.",
        "clazz": "1",
        "$$hashKey": "object:3320"
    },
    {
        "nameEng": "Lithographer",
        "code": "LITO",
        "gender": "All",
        "nameInd": "Petugas litografi",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di litografi",
        "descriptionEng": "a person who works at�lithography",
        "clazz": "1",
        "$$hashKey": "object:4448"
    },
    {
        "nameEng": "Negative assembler",
        "code": "NEGA",
        "gender": "All",
        "nameInd": "Assembler negatif",
        "minAge": "0",
        "descriptionInd": "seseorang yang merakit negatif",
        "descriptionEng": "someone who assembles negative",
        "clazz": "1",
        "$$hashKey": "object:3440"
    },
    {
        "nameEng": "Negative cutter",
        "code": "NEGC",
        "gender": "All",
        "nameInd": "Pemotong negatif",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong negatif",
        "descriptionEng": "someone who cuts negative",
        "clazz": "1",
        "$$hashKey": "object:4082"
    },
    {
        "nameEng": "Offset press operator",
        "code": "OFFM",
        "gender": "All",
        "nameInd": "Operator mesin cetak",
        "minAge": "0",
        "descriptionInd": "Mengoperasikan digital, litograf, flexographic, gravure, atau mesin cetak lainnya.",
        "descriptionEng": "Set up and operate digital, lithographic, flexographic, gravure, or other printing machines.",
        "clazz": "1",
        "$$hashKey": "object:3788"
    },
    {
        "nameEng": "Photocopying machine operator",
        "code": "POTM",
        "gender": "All",
        "nameInd": "Operator mesin fotokopi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin fotokopi",
        "descriptionEng": "someone who operates photocopying machine",
        "clazz": "1",
        "$$hashKey": "object:3791"
    },
    {
        "nameEng": "Photocopy assistant (clerical)",
        "code": "POTO",
        "gender": "All",
        "nameInd": "Teknisi Mesin Fotocopy",
        "minAge": "0",
        "descriptionInd": "Memonitor printer digital dan pengoperasian fotocopy dengan memprogram, mengoperasikan, mengatur dan memelihara jaringan, printer digital dengan kecepatan tinggi, printer berwarna, alat scan dan pengunduhan CD dan mengoperasikan alat penjilid dan berbagai pekerjaan yang berhubungan dengan percetakan. Tambahan lainnya seorang teknisi fotokopi juga menentukan prioritas dan memberikan arahan kepada pekerja yang lebih rendah.",
        "descriptionEng": "Monitors digital printing and copying operations by programming, operating, adjusting, and maintaining networked, high-speed digital printers, color printers, scanners, and CD burners and operating automatic bindery equipment in the production of various printed materials. In addition, aPhotocopy Technician determines priorities for and may provide work direction over lower-level personnel.",
        "clazz": "1",
        "$$hashKey": "object:4615"
    },
    {
        "nameEng": "Pressman",
        "code": "PREM",
        "gender": "All",
        "nameInd": "Petugas penekan",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk menekan",
        "descriptionEng": "someone who works to press",
        "clazz": "2",
        "$$hashKey": "object:4470"
    },
    {
        "nameEng": "Pressroom manager",
        "code": "PRMG",
        "gender": "All",
        "nameInd": "Manajer ruang penekan percetakan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola ruang tekan",
        "descriptionEng": "someone who manages pressroom",
        "clazz": "1",
        "$$hashKey": "object:3703"
    },
    {
        "nameEng": "Printer (publishing and printing ) / Printing machine operator",
        "code": "LPPO",
        "gender": "All",
        "nameInd": "Pencetak (penerbitan dan percetakan) / Operator mesin percetakan",
        "minAge": "0",
        "descriptionInd": "Operator mesin cetak, juga dikenal sebagai pers operator, mempersiapkan, mengoperasikan, dan memelihara mesin cetak di ruang cetak. Tugas operastor mesin cetak bervariasi sesuai dengan jenis pers mereka beroperasi- offset litografi, gravure, flexography, sablon, letterpress, dan digital",
        "descriptionEng": "Printing machine operators, also known as press operators, prepare, operate, and maintain the printing presses in a pressroom. Duties of printing machine operators vary according to the type of press they operate�offset lithography, gravure, flexography, screen printing, letterpress, and digital .",
        "clazz": "2",
        "$$hashKey": "object:4113"
    },
    {
        "nameEng": "Printer's assistant  / Printer assistant",
        "code": "PRIN",
        "gender": "All",
        "nameInd": "Asisten pencetak / Asisten pencetak",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu untuk mencetak",
        "descriptionEng": "someone who assists  to print",
        "clazz": "1",
        "$$hashKey": "object:3430"
    },
    {
        "nameEng": "Process camera operator",
        "code": "CAMO",
        "gender": "All",
        "nameInd": "Operator proses kamera",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan proses kamera",
        "descriptionEng": "someone who operates process camera",
        "clazz": "1",
        "$$hashKey": "object:3815"
    },
    {
        "nameEng": "Proofer",
        "code": "PROO",
        "gender": "All",
        "nameInd": "Proofreader",
        "minAge": "0",
        "descriptionInd": "seseorang yang membaca salinan elektronik publikasi untuk mendeteksi dan memperbaiki kesalahan produksi teks atau seni.",
        "descriptionEng": "someone who reads an electronic copy of a publication to detect and correct production errors of text or art.",
        "clazz": "2",
        "$$hashKey": "object:4527"
    },
    {
        "nameEng": "Publisher",
        "code": "PBLS",
        "gender": "All",
        "nameInd": "Penerbit",
        "minAge": "0",
        "descriptionInd": "individu atau perusahaan yang bertanggung jawab untuk mempublikasikan, mencetak dan mendistribusikan publikasi digital atau cetakan.",
        "descriptionEng": "individual or corporation responsible for the printing and distribution of digital or printed publications.",
        "clazz": "1",
        "$$hashKey": "object:4136"
    },
    {
        "nameEng": "Reader",
        "code": "READ",
        "gender": "All",
        "nameInd": "Pembaca",
        "minAge": "0",
        "descriptionInd": "seseorang yang membaca",
        "descriptionEng": "someone who reads",
        "clazz": "1",
        "$$hashKey": "object:3978"
    },
    {
        "nameEng": "Screenmaker",
        "code": "SCRM",
        "gender": "All",
        "nameInd": "Pembuat layar",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat layar",
        "descriptionEng": "someone who makes screen",
        "clazz": "2",
        "$$hashKey": "object:4016"
    },
    {
        "nameEng": "Screenprinter",
        "code": "SCPR",
        "gender": "All",
        "nameInd": "Pencetak layar",
        "minAge": "0",
        "descriptionInd": "seseorang yang mencetak layar",
        "descriptionEng": "someone who prints screen",
        "clazz": "1",
        "$$hashKey": "object:4114"
    },
    {
        "nameEng": "Road marker",
        "code": "ROAM",
        "gender": "All",
        "nameInd": "Penanda jalanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menandai jalan",
        "descriptionEng": "someone who marks the road",
        "clazz": "3",
        "$$hashKey": "object:4096"
    },
    {
        "nameEng": "Studio layout artist (Printing)",
        "code": "STUL",
        "gender": "All",
        "nameInd": "Juru tata letak studio (percetakan)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di studio seni, membuat seni visual dan digital dalam program komputer.",
        "descriptionEng": "A person who work in studio art, they make visual and digital art in computer program.",
        "clazz": "2",
        "$$hashKey": "object:3588"
    },
    {
        "nameEng": "Web offset pressman / Web publisher",
        "code": "WEBO",
        "gender": "All",
        "nameInd": "Petugas offset web / Penerbit web",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di web offset",
        "descriptionEng": "someone who work in web offset",
        "clazz": "1",
        "$$hashKey": "object:4452"
    },
    {
        "nameEng": "Railways station manager / Station manager (railways) / Station inspector (railways) / Station chargeman (railways)",
        "code": "STIP",
        "gender": "All",
        "nameInd": "Manajer stasiun kereta / Manajer stasiun (kereta) / Inspektur stasiun (kereta) / Kepala stasiun (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola stasiun kereta",
        "descriptionEng": "someone who manages railways station",
        "clazz": "1",
        "$$hashKey": "object:3705"
    },
    {
        "nameEng": "Rail car attendant / Dining car attendant / Dining car attendant (rail)",
        "code": "CARR",
        "gender": "All",
        "nameInd": "Penjaga gerbong kereta / Penjaga gerbong makanan / Penjaga gerbong makanan (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga gerbong kereta",
        "descriptionEng": "someone who attends rail car",
        "clazz": "2",
        "$$hashKey": "object:4299"
    },
    {
        "nameEng": "Rail engine driver  / Train operator",
        "code": "RAIE",
        "gender": "All",
        "nameInd": "Masinis kereta / Operator kereta",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudi kereta",
        "descriptionEng": "someone who drives rail engine",
        "clazz": "2",
        "$$hashKey": "object:3724"
    },
    {
        "nameEng": "Train driver (Railways)",
        "code": "MRTC",
        "gender": "All",
        "nameInd": "Pengemudi Kereta Api",
        "minAge": "0",
        "descriptionInd": "Seorang pengemudi kereta akan mengantar penumpang dan mengemudikan kereta barang pada jaringan kereta lokal dan nasional.",
        "descriptionEng": "A train driver would drive passenger and freight trains on local and national rail networks.",
        "clazz": "2",
        "$$hashKey": "object:4213"
    },
    {
        "nameEng": "Track layer (railways) / Trackman / Trackman (railways)",
        "code": "TRCK",
        "gender": "All",
        "nameInd": "Pemasang trek (rel kereta) / Petugas pemasang trek / Petugas pemasang trek (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang trek",
        "descriptionEng": "someone who fits the track",
        "clazz": "3",
        "$$hashKey": "object:3977"
    },
    {
        "nameEng": "Train controller",
        "code": "TRCC",
        "gender": "All",
        "nameInd": "Pengontrol kereta",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengkontrol kereta",
        "descriptionEng": "someone who controls train",
        "clazz": "1",
        "$$hashKey": "object:4248"
    },
    {
        "nameEng": "Train cleaner / Cleaner (rail)",
        "code": "TRCL",
        "gender": "All",
        "nameInd": "Pembersih kereta / Pembersih (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membersihkan kereta",
        "descriptionEng": "someone who cleans train",
        "clazz": "3",
        "$$hashKey": "object:4002"
    },
    {
        "nameEng": "Train conductor / Conductor (rail)",
        "code": "TRCO",
        "gender": "All",
        "nameInd": "Konduktor kereta / Konduktor (kereta)",
        "minAge": "0",
        "descriptionInd": "anggota awak kereta yang bertanggung jawab atas tugas-tugas operasional dan keselamatan yang tidak melibatkan operasi kereta yang sebenarnya",
        "descriptionEng": "a train crew member responsible for operational and safety duties that do not involve actual operation of the train",
        "clazz": "2",
        "$$hashKey": "object:3632"
    },
    {
        "nameEng": "Crossing keeper / crossing keeper (rail)",
        "code": "CROS",
        "gender": "All",
        "nameInd": "Penjaga perlintasan kereta / Penjaga perlintasan kereta (rel)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga perlintasan kereta",
        "descriptionEng": "someone who keeps the  crossing",
        "clazz": "2",
        "$$hashKey": "object:4314"
    },
    {
        "nameEng": "Inspector (rail) / Railways inspector  / Track maintenance inspector",
        "code": "TRRW",
        "gender": "All",
        "nameInd": "Inspektur (rel) / Inspektur kereta / Inspektur perawatan jalur",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi kereta",
        "descriptionEng": "someone who inspects railways",
        "clazz": "1",
        "$$hashKey": "object:3564"
    },
    {
        "nameEng": "Track equipment installer / Installer (rail track equipment)",
        "code": "TREQ",
        "gender": "All",
        "nameInd": "Pemasang peralatan trek / Pemasang (peralatan rel trek)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang peralatan trek",
        "descriptionEng": "someone who installs track equipment",
        "clazz": "3",
        "$$hashKey": "object:3972"
    },
    {
        "nameEng": "Train maintenance fitter / Maintenance fitter (rail)",
        "code": "TRMF",
        "gender": "All",
        "nameInd": "Pemasang pemeliharaan kereta / Petugas pemasang pemeliharaan (rel)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang pemeliharaan rel",
        "descriptionEng": "someone who fits train maintenance",
        "clazz": "3",
        "$$hashKey": "object:3971"
    },
    {
        "nameEng": "Overhead linesman / Overhead linesman (railways)",
        "code": "TROV",
        "gender": "All",
        "nameInd": "Petugas listrik gantung / Petugas listrik gantung (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di listrik gantung",
        "descriptionEng": "someone who works in linesman",
        "clazz": "3",
        "$$hashKey": "object:4447"
    },
    {
        "nameEng": "Platelayer / Platelayer (railways)",
        "code": "TRPL",
        "gender": "All",
        "nameInd": "Pelapis pelat  / Pelapis pelat (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi pelat",
        "descriptionEng": "someone who lays plate",
        "clazz": "3",
        "$$hashKey": "object:3918"
    },
    {
        "nameEng": "Pointsman / Pointsman (railways)",
        "code": "TRPN",
        "gender": "All",
        "nameInd": "Pengatur jalur / Pengatur jalur (rel kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur jalur",
        "descriptionEng": "someone who sets the points",
        "clazz": "2",
        "$$hashKey": "object:4150"
    },
    {
        "nameEng": "Railways porter / Porter (railways)",
        "code": "TRPO",
        "gender": "All",
        "nameInd": "Porter kereta / Porter (kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengangkut barang di kereta",
        "descriptionEng": "someone who helps to lift stuff in railways",
        "clazz": "2",
        "$$hashKey": "object:4517"
    },
    {
        "nameEng": "Railway signal fitter",
        "code": "SGRW",
        "gender": "All",
        "nameInd": "Petugas pemasang sinyal kereta",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang sinyal kereta",
        "descriptionEng": "someone who fits railway signal",
        "clazz": "2",
        "$$hashKey": "object:4462"
    },
    {
        "nameEng": "Shunter",
        "code": "SHNT",
        "gender": "All",
        "nameInd": "Pelangsir",
        "minAge": "0",
        "descriptionInd": "mesin kereta api kecil yang digunakan untuk menggerakkan gerbong di sekitar rel daripada melakukan perjalanan antar stasiun",
        "descriptionEng": "a small railway engine that is used for moving carriages around on the tracks rather than making journeys between stations.",
        "clazz": "2",
        "$$hashKey": "object:3915"
    },
    {
        "nameEng": "Signalman / Signalman (railways)",
        "code": "SIGN",
        "gender": "All",
        "nameInd": "Penjaga sinyal  / Penjaga sinyal (rel kereta)",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang bekerja membuat sinyal dengan bendera dan cahaya. Saat ini perannya sudah berkembang dan biasanya menggunakan peralatan komunikasi elektronik. Biasanya bekerja dalam jaringan transportasi kereta api, angkatan bersenjata atau konstruksi (untuk mengarahkan alat berat seperti crane).",
        "descriptionEng": "A Signalman is a person who historically made signals using flags and light. In modern times the role of Signalmen has evolved and now usually uses electronic communication equipment. Signalmen usually work in rail transport networks, armed forces, or construction (to direct heavy equipment such as cranes).",
        "clazz": "2",
        "$$hashKey": "object:4321"
    },
    {
        "nameEng": "Switch operator / Switch operator (railways)",
        "code": "SWOP",
        "gender": "All",
        "nameInd": "Operator pengganti / Operator pengganti (rel kereta)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pengganti",
        "descriptionEng": "someone who operates the switch",
        "clazz": "2",
        "$$hashKey": "object:3812"
    },
    {
        "nameEng": "Ticket collector / Train ticket collector",
        "code": "TICC",
        "gender": "All",
        "nameInd": "Pemeriksa tiket / Pemeriksa tiket kereta",
        "minAge": "0",
        "descriptionInd": "seseorang yang memeriksa/mengkoleksi tiket",
        "descriptionEng": "someone who collects ticket",
        "clazz": "1",
        "$$hashKey": "object:4060"
    },
    {
        "nameEng": "Track laying machine operator",
        "code": "TRLY",
        "gender": "All",
        "nameInd": "Operator mesin pemasangan trek",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan mesin pemasang trek",
        "descriptionEng": "someone who operates track laying machine",
        "clazz": "3",
        "$$hashKey": "object:3797"
    },
    {
        "nameEng": "Asphalter",
        "code": "ASPH",
        "gender": "All",
        "nameInd": "Pekerja aspal",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyebarkan lapisan aspal",
        "descriptionEng": "a person who spreads a layer of asphalt",
        "clazz": "3",
        "$$hashKey": "object:3858"
    },
    {
        "nameEng": "Chipper hand",
        "code": "CHIH",
        "gender": "All",
        "nameInd": "Pemotong daging",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong daging",
        "descriptionEng": "someone who cuts meat",
        "clazz": "3",
        "$$hashKey": "object:4078"
    },
    {
        "nameEng": "Ganger",
        "code": "GANG",
        "gender": "All",
        "nameInd": "Kepala regu",
        "minAge": "0",
        "descriptionInd": "seseorang yang memimpin regu",
        "descriptionEng": "someone who leads the gang",
        "clazz": "3",
        "$$hashKey": "object:3615"
    },
    {
        "nameEng": "Kerb layer",
        "code": "KERB",
        "gender": "All",
        "nameInd": "Pembuat pinggiran jalan",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi pinggiran jalan",
        "descriptionEng": "someone who layer side of the road",
        "clazz": "3",
        "$$hashKey": "object:4034"
    },
    {
        "nameEng": "Pavior",
        "code": "PAVI",
        "gender": "All",
        "nameInd": "Pembuat trotoar",
        "minAge": "0",
        "descriptionInd": "seseorang yang meletakkan batu paving.",
        "descriptionEng": "a person who lays paving stones.",
        "clazz": "3",
        "$$hashKey": "object:4046"
    },
    {
        "nameEng": "Pneumatic drill operator",
        "code": "PNEU",
        "gender": "All",
        "nameInd": "Operator bor pneumatik",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pneumatik pengeboran",
        "descriptionEng": "someone who operates pnemuatic drill",
        "clazz": "3",
        "$$hashKey": "object:3758"
    },
    {
        "nameEng": "Raker",
        "code": "RAKE",
        "gender": "All",
        "nameInd": "Petugas alat penjepit",
        "minAge": "0",
        "descriptionInd": "sebuah alat yang dilengkapi dengan prongsing yang diproyeksikan untuk mengumpulkan material (seperti daun) atau untuk melonggarkan atau menghaluskan permukaan tanah",
        "descriptionEng": "an implement equipped with projecting prongs to gather material (such as leaves) or for loosening or smoothing the surface of the ground",
        "clazz": "3",
        "$$hashKey": "object:4414"
    },
    {
        "nameEng": "Tarmac layer",
        "code": "TARM",
        "gender": "All",
        "nameInd": "Pelapis tarmak",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi tarmak",
        "descriptionEng": "someone who lays tarmac",
        "clazz": "3",
        "$$hashKey": "object:3920"
    },
    {
        "nameEng": "Account executive",
        "code": "ACEX",
        "gender": "All",
        "nameInd": "Akun eksekutif",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab atas servis klien dan akuisisi klien. Eksekutif akun berfungsi sebagai penghubung langsung antara biro iklan dan klien yang ada, mengelola urusan sehari-hari dan memastikan kepuasan pelanggan.",
        "descriptionEng": "are typically responsible for client servicing and client acquisition. The account executive serves as the direct link between the advertising agency and the existing client, managing day-to-day affairs and ensuring customer satisfaction.",
        "clazz": "1",
        "$$hashKey": "object:3389"
    },
    {
        "nameEng": "Bookmaker (on course)",
        "code": "BOKM",
        "gender": "All",
        "nameInd": "Petugas taruhan olahraga",
        "minAge": "0",
        "descriptionInd": "adalah organisasi atau seseorang yang menerima dan membayar taruhan pada pertandingan olahraga dan acara lainnya dengan odds yang disepakati.",
        "descriptionEng": "is an organization or a person that accepts and pays off bets on sporting and other events at agreed-upon odds.",
        "clazz": "3",
        "$$hashKey": "object:4497"
    },
    {
        "nameEng": "Bookseller",
        "code": "BOKS",
        "gender": "All",
        "nameInd": "Penjual buku",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual buku",
        "descriptionEng": "someone who sells book",
        "clazz": "1",
        "$$hashKey": "object:4331"
    },
    {
        "nameEng": "Box office manager",
        "code": "BOXO",
        "gender": "All",
        "nameInd": "Manajer tiket dan keuangan",
        "minAge": "0",
        "descriptionInd": "orang ini bekerja di bawah arahan manajer penjualan tiket dan bertanggung jawab untuk mengawasi staf box office, termasuk penjual tiket dan asisten.",
        "descriptionEng": "this person works under the direction of the ticket sales manager and is responsible for overseeing the box office staff, including ticket sellers and assistants.",
        "clazz": "1",
        "$$hashKey": "object:3707"
    },
    {
        "nameEng": "Builder's merchant / coal merchant",
        "code": "COAM",
        "gender": "All",
        "nameInd": "Pedagang tukang bangunan / Pedagang batu bara",
        "minAge": "0",
        "descriptionInd": "seseirang yang menjual barang bangunan",
        "descriptionEng": "someone who sells builders",
        "clazz": "3",
        "$$hashKey": "object:3838"
    },
    {
        "nameEng": "Bus ticket seller",
        "code": "BUST",
        "gender": "All",
        "nameInd": "Penjual tiket bus",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual tiket bus",
        "descriptionEng": "someone who sells bus ticket",
        "clazz": "3",
        "$$hashKey": "object:4339"
    },
    {
        "nameEng": "Bus conductor / Conductor (bus)",
        "code": "BUSC",
        "gender": "All",
        "nameInd": "Kondektur bus  / Kondektur (bus)",
        "minAge": "0",
        "descriptionInd": "Orang yang mengumpulkan tarif, menerbitkan tiket untuk penumpang dalam sebuah bus.",
        "descriptionEng": "Person who collect fares, issue tickets to passengers in a bus.",
        "clazz": "3",
        "$$hashKey": "object:3630"
    },
    {
        "nameEng": "Buyer",
        "code": "BUYS",
        "gender": "All",
        "nameInd": "Pembeli",
        "minAge": "0",
        "descriptionInd": "Pembeli adalah orang yang berusaha untuk mendapatkan barang dengan kualitas terbaik dengan harga terendah.",
        "descriptionEng": "A buyer's primary responsibility is obtaining the highest quality goods at the lowest cost. This usually requires research, writing requests for bids, proposals or quotes, and evaluating information received.",
        "clazz": "1",
        "$$hashKey": "object:3992"
    },
    {
        "nameEng": "Car salesman",
        "code": "CARS",
        "gender": "All",
        "nameInd": "Penjual mobil",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual mobil",
        "descriptionEng": "someone who sales car",
        "clazz": "1",
        "$$hashKey": "object:4336"
    },
    {
        "nameEng": "Checkout worker",
        "code": "CHWO",
        "gender": "All",
        "nameInd": "Petugas kasir",
        "minAge": "0",
        "descriptionInd": "seseorang yang melayani di tempat pembayaran",
        "descriptionEng": "someone who checks out on cashier",
        "clazz": "1",
        "$$hashKey": "object:4429"
    },
    {
        "nameEng": "Estate agent",
        "code": "ESTT",
        "gender": "All",
        "nameInd": "Agen perumahan",
        "minAge": "0",
        "descriptionInd": "Sewa, beli, atau jual properti untuk klien. Lakukan tugas, seperti daftar properti penelitian, wawancara calon klien, temani klien ke situs properti, diskusikan kondisi penjualan, dan susun kontrak real estat. Termasuk agen yang mewakili pembeli.",
        "descriptionEng": "Rent, buy, or sell property for clients. Perform duties, such as study property listings, interview prospective clients, accompany clients to property site, discuss conditions of sale, and draw up real estate contracts. Includes agents who represent buyer.",
        "clazz": "1",
        "$$hashKey": "object:3323"
    },
    {
        "nameEng": "Market stall trader",
        "code": "MKTS",
        "gender": "All",
        "nameInd": "Pedagang kedai pasar",
        "minAge": "0",
        "descriptionInd": "seseorang yang berjualan di pasar",
        "descriptionEng": "someone who selles in market",
        "clazz": "2",
        "$$hashKey": "object:3836"
    },
    {
        "nameEng": "Hawkers",
        "code": "HAWK",
        "gender": "All",
        "nameInd": "Penjaja Makanan dan minuman",
        "minAge": "0",
        "descriptionInd": "Seorang penjual atau  vendor barang dagangan yang  menjual barang-barang atau makanan yang asli daerah.",
        "descriptionEng": "A hawker is a vendor of merchandise that can be easily transported; the term is roughly synonymous with peddler or costermonger. In most places where the term is used, a hawker sells items or food that are native to the area.",
        "clazz": "2",
        "$$hashKey": "object:4326"
    },
    {
        "nameEng": "Merchandiser",
        "code": "MRCH",
        "gender": "All",
        "nameInd": "Produk ritel",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual berbagai produk yang tersedia untuk dijual dan menampilkan produk-produk tersebut sedemikian rupa sehingga merangsang minat dan membujuk pelanggan untuk melakukan pembelian.",
        "descriptionEng": "someone who sales variety of products available for sale and the display of those products in such a way that it stimulates interest and entices customers to make a purchase.",
        "clazz": "1",
        "$$hashKey": "object:4522"
    },
    {
        "nameEng": "Newsagent / News paper seller",
        "code": "NEWG",
        "gender": "All",
        "nameInd": "Agen berita / Penjual koran",
        "minAge": "0",
        "descriptionInd": "seseorang atau toko yang menjual koran dan majalah.",
        "descriptionEng": "a person or a shop selling newspapers and magazines.",
        "clazz": "1",
        "$$hashKey": "object:3318"
    },
    {
        "nameEng": "News-vendor",
        "code": "NEWV",
        "gender": "All",
        "nameInd": "Penjual berita",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual berita",
        "descriptionEng": "someone who sells news",
        "clazz": "3",
        "$$hashKey": "object:4330"
    },
    {
        "nameEng": "Paper merchant",
        "code": "PAPM",
        "gender": "All",
        "nameInd": "Penjual kertas",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberikan kertas, dan pabrik membuatnya",
        "descriptionEng": "someone who delivers the paper, and the mill makes it",
        "clazz": "1",
        "$$hashKey": "object:4335"
    },
    {
        "nameEng": "Product demonstrator",
        "code": "PRDD",
        "gender": "All",
        "nameInd": "Pemberi demonstrasi produk",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendemonstrasikan suatu produk",
        "descriptionEng": "someone who demonstrates a product",
        "clazz": "1",
        "$$hashKey": "object:3994"
    },
    {
        "nameEng": "Sales representative / Salesman",
        "code": "SALE",
        "gender": "All",
        "nameInd": "Sales",
        "minAge": "0",
        "descriptionInd": "Orang yang menjual produk, barang atau layanan.",
        "descriptionEng": "A person who sells products, goods, or services.",
        "clazz": "1",
        "$$hashKey": "object:4538"
    },
    {
        "nameEng": "Shop staff",
        "code": "SHOS",
        "gender": "All",
        "nameInd": "Pegawai toko",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di toko",
        "descriptionEng": "someone who works In shop",
        "clazz": "1",
        "$$hashKey": "object:3855"
    },
    {
        "nameEng": "Turnstile operator",
        "code": "TNST",
        "gender": "All",
        "nameInd": "Operator pagar putar",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pagar putar",
        "descriptionEng": "someone who operates turnstile",
        "clazz": "2",
        "$$hashKey": "object:3805"
    },
    {
        "nameEng": "Valuer",
        "code": "VALR",
        "gender": "All",
        "nameInd": "Penilai",
        "minAge": "0",
        "descriptionInd": "seseorang yang menilai",
        "descriptionEng": "someone who values",
        "clazz": "1",
        "$$hashKey": "object:4288"
    },
    {
        "nameEng": "Window dresser",
        "code": "WIDD",
        "gender": "All",
        "nameInd": "Penata etalase",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur pajangan barang di jendela toko atau di dalam toko itu sendiri.",
        "descriptionEng": "someone who arranges displays of goods in shop windows or within a shop itself.",
        "clazz": "1",
        "$$hashKey": "object:4106"
    },
    {
        "nameEng": "Compass adjuster",
        "code": "CPAS",
        "gender": "All",
        "nameInd": "Penyetel kompas",
        "minAge": "0",
        "descriptionInd": "seseorng yang menyetel kompas",
        "descriptionEng": "someone who adjusts compass",
        "clazz": "2",
        "$$hashKey": "object:4359"
    },
    {
        "nameEng": "Conveyor operator (ship building and repair)  / Conveyor operator ship building",
        "code": "SHIB",
        "gender": "All",
        "nameInd": "Operator konveyor (pembangunan dan perbaikan kapal) / Operator konveyor pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengeoperasikan pembangunan kapal",
        "descriptionEng": "someone who operates ship building",
        "clazz": "2",
        "$$hashKey": "object:3777"
    },
    {
        "nameEng": "Crane driver (ship building and repair)  / Crane operator (ship building and repair)  / Crane slinger (ship building and repair)  / Crane driver ship building",
        "code": "SHIC",
        "gender": "All",
        "nameInd": "Pengemudi derek (pembangunan dan perbaikan kapal) / Operator derek (pembangunan dan perbaikan kapal) / Pengguna sling derek (pembangunan kapal dan perbaikan) / Pengemudi derek pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudi derek di pembangunan kapal",
        "descriptionEng": "somone who drives crane in ship building",
        "clazz": "3",
        "$$hashKey": "object:4207"
    },
    {
        "nameEng": "Draftsman (ship building and repair)",
        "code": "SHID",
        "gender": "All",
        "nameInd": "Perancang (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang merancang",
        "descriptionEng": "someone who designs",
        "clazz": "2",
        "$$hashKey": "object:4383"
    },
    {
        "nameEng": "Driller (ship building and repair) / Driller ship building",
        "code": "SHDR",
        "gender": "All",
        "nameInd": "Pengebor (pembangunan dan perbaikan kapal) / Pengebor pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengebor di pembangunan kapal",
        "descriptionEng": "someone who drills in ship building",
        "clazz": "3",
        "$$hashKey": "object:4166"
    },
    {
        "nameEng": "Electrician (ship building and repair)",
        "code": "SHIE",
        "gender": "All",
        "nameInd": "Ahli listrik (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menginstal dan memelihara sistem pengkabelan, kontrol, dan pencahayaan.",
        "descriptionEng": "someone who installs and maintains wiring, control, and lighting systems.",
        "clazz": "3",
        "$$hashKey": "object:3359"
    },
    {
        "nameEng": "Engineer (ship building and repair)",
        "code": "SHEN",
        "gender": "All",
        "nameInd": "Insinyur (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mendesain, membangun, atau memelihara mesin, mesin, atau pekerjaan umum.",
        "descriptionEng": "a person who designs, builds, or maintains engines, machines, or public works.",
        "clazz": "2",
        "$$hashKey": "object:3528"
    },
    {
        "nameEng": "Estimator (ship building and repair)",
        "code": "SHES",
        "gender": "All",
        "nameInd": "Estimator (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mempersiapkan pekerjaan untuk diperkirakan dengan mengumpulkan proposal, cetak biru, spesifikasi, dan dokumen terkait. Mengidentifikasi persyaratan tenaga kerja, material, dan waktu dengan mempelajari proposal, cetak biru, spesifikasi, dan dokumen terkait. Menghitung biaya dengan menganalisis kebutuhan tenaga kerja, material, dan waktu.",
        "descriptionEng": "someone who prepares work to be estimated by gathering proposals, blueprints, specifications, and related documents. Identifies labor, material, and time requirements by studying proposals, blueprints, specifications, and related documents. Computes costs by analyzing labor, material, and time requirements.",
        "clazz": "2",
        "$$hashKey": "object:3506"
    },
    {
        "nameEng": "Fitter (ship building and repair)",
        "code": "FTSH",
        "gender": "All",
        "nameInd": "Pemasang (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang",
        "descriptionEng": "someone who fits",
        "clazz": "2",
        "$$hashKey": "object:3957"
    },
    {
        "nameEng": "Flame burner (ship building and repair) / Flame cutter (ship building and repair)",
        "code": "SHFL",
        "gender": "All",
        "nameInd": "Pekerja tungku api (pembangunan dan perbaikan kapal) / Pemotong api (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membakar api",
        "descriptionEng": "someone who burns flame",
        "clazz": "3",
        "$$hashKey": "object:3909"
    },
    {
        "nameEng": "Hoist operator (construction) / Hoist operator (ship building and repair)",
        "code": "SHHO",
        "gender": "All",
        "nameInd": "Operator mesin hoist (konstruksi) / Operator mesin hoist (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasi mesin hoist",
        "descriptionEng": "someone who operates hoist",
        "clazz": "3",
        "$$hashKey": "object:3793"
    },
    {
        "nameEng": "Joiner (ship building and repair)",
        "code": "SHJO",
        "gender": "All",
        "nameInd": "Tukang kayu (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat furnitur kayu",
        "descriptionEng": "someone who furnishes wood",
        "clazz": "2",
        "$$hashKey": "object:4675"
    },
    {
        "nameEng": "Maintenance technician (ship building and repair) / Ship building maintenance technician",
        "code": "THMN",
        "gender": "All",
        "nameInd": "Teknisi pemeliharaan (pembangunan dan perbaikan kapal) / Teknisi pemeliharaan pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "orang yang terampil dalam teknik seni atau kerajinan untuk mempertahankan pembangunan kapal",
        "descriptionEng": "a person skilled in the technique of an art or craft to maintain ship building",
        "clazz": "2",
        "$$hashKey": "object:4625"
    },
    {
        "nameEng": "Pedicurist",
        "code": "PEDC",
        "gender": "All",
        "nameInd": "Ahli pedikur",
        "minAge": "0",
        "descriptionInd": "orang yang bisnisnya adalah perawatan kaki bedah",
        "descriptionEng": "one whose business is surgical care of feet",
        "clazz": "1",
        "$$hashKey": "object:3370"
    },
    {
        "nameEng": "Tattooist",
        "code": "TATO",
        "gender": "All",
        "nameInd": "Pembuat tato",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat tato",
        "descriptionEng": "someone who makes tattoo",
        "clazz": "2",
        "$$hashKey": "object:4042"
    },
    {
        "nameEng": "Wig maker",
        "code": "WIGM",
        "gender": "All",
        "nameInd": "Pembuat wig",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat tato",
        "descriptionEng": "someone who makes wig",
        "clazz": "1",
        "$$hashKey": "object:4048"
    },
    {
        "nameEng": "Painter (ship building and repair) / Ship building painter",
        "code": "PAIS",
        "gender": "All",
        "nameInd": "Pengecat (pembangunan dan perbaikan kapal) / Pengecat pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "Mempersiapkan permukaan kayu , fiberglass dan metal untuk dilakukan pengecetan, mempersiapkan peralatan, interior dan eksterior kapal, gedung di area pelabuhan dengan menggunakan kuas, spray atau roller. Membakar atau menghilangkan cat dengan menggunakan api, membersihkan dan melapisi permukan dgn minyak, terpentin dan melakukan persiapan lainnya.",
        "descriptionEng": "Prepares wood, fiberglass, and metal surfaces for painting, and paints parts, equipment, interiors, and exteriors of ships, boats, and shipyard and marina buildings, using brushes, spray guns, and rollers. Burns off old paint, using blowtorch, washes and treats surfaces with oil, turpentine, and other preparations.",
        "clazz": "3",
        "$$hashKey": "object:4172"
    },
    {
        "nameEng": "Pipe fitter (ship building and repair)  / Ship building pipe fitter",
        "code": "PPFI",
        "gender": "All",
        "nameInd": "Pengepas pipa (pembangunan dan perbaikan kapal) / Pengepas pipa pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang pipa di pembangunan kapal",
        "descriptionEng": "someone who fits the pipe In ship building",
        "clazz": "3",
        "$$hashKey": "object:4226"
    },
    {
        "nameEng": "Plater (ship building and repair)",
        "code": "SHPL",
        "gender": "All",
        "nameInd": "Tukang instalasi (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi dan meninstal",
        "descriptionEng": "someone who plates",
        "clazz": "3",
        "$$hashKey": "object:4668"
    },
    {
        "nameEng": "Riveter (ship building and repair) / Ship building riveter",
        "code": "SHRV",
        "gender": "All",
        "nameInd": "Pengeling (pembangunan dan perbaikan kapal) / Pengeling pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang memaku di pembangunan kapal",
        "descriptionEng": "someone who rivets in ship building",
        "clazz": "3",
        "$$hashKey": "object:4175"
    },
    {
        "nameEng": "Safety officer (ship building and repair)",
        "code": "SHSF",
        "gender": "All",
        "nameInd": "Petugas keamanan (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk menjaga keamanana",
        "descriptionEng": "someone who works to guard",
        "clazz": "3",
        "$$hashKey": "object:4434"
    },
    {
        "nameEng": "Scaffolder / Stager (ship building and repair) / Ship building scaffolder",
        "code": "SHTG",
        "gender": "All",
        "nameInd": "Pembuat perancah / Stager (pembangunan dan perbaikan kapal) / Pembuat perancah pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat perancah di pembangunan kapal",
        "descriptionEng": "someone who makes scaffolder",
        "clazz": "3",
        "$$hashKey": "object:4030"
    },
    {
        "nameEng": "Shipwright",
        "code": "SHPH",
        "gender": "All",
        "nameInd": "Pembuat kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat kapal",
        "descriptionEng": "someone who makes ship",
        "clazz": "3",
        "$$hashKey": "object:4013"
    },
    {
        "nameEng": "Shipyard worker",
        "code": "SHIP",
        "gender": "All",
        "nameInd": "Pekerja Kapal",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja membuat dan memperbaiki kapal di galangan kapal.",
        "descriptionEng": "A person who builds and repair ships in the shipyard.",
        "clazz": "3",
        "$$hashKey": "object:3867"
    },
    {
        "nameEng": "Shipyard manager",
        "code": "SHPY",
        "gender": "All",
        "nameInd": "Pengelola galangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola sebuah tempat dimana kapal dibangun dan diperbaiki",
        "descriptionEng": "someone who manages a place where ships are built and repaired.",
        "clazz": "3",
        "$$hashKey": "object:4176"
    },
    {
        "nameEng": "Shotblaster (ship building and repair) / Ship building shotblaster",
        "code": "SOBL",
        "gender": "All",
        "nameInd": "Shotblaster (pembangunan dan perbaikan kapal) / Shotblaster pembangunan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang meleburkan seseuatu di pembangunan kapal",
        "descriptionEng": "someone who shotblasts in ship building",
        "clazz": "3",
        "$$hashKey": "object:4547"
    },
    {
        "nameEng": "Technical assistant (ship building and repair) / Technical controller (ship building and repair)",
        "code": "SHTC",
        "gender": "All",
        "nameInd": "Asisten teknis (pembangunan dan perbaikan kapal) / Pengontrol teknis (pembangunan dan perbaikan kapal)",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di urusan teknikal",
        "descriptionEng": "someone who assist in technical stuff",
        "clazz": "3",
        "$$hashKey": "object:3438"
    },
    {
        "nameEng": "Winch operator (ship building and repair) / Ship building winch operator",
        "code": "SHWN",
        "gender": "All",
        "nameInd": "Operator derek (pembangunan dan perbaikan kapal) / Operator derek pembangunan kapal",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan derek di pembangunan kapal",
        "descriptionEng": "someone who operates winch in ship building",
        "clazz": "3",
        "$$hashKey": "object:3763"
    },
    {
        "nameEng": "Engineer (telecommunications) / Telecommunications engineer",
        "code": "TLEN",
        "gender": "All",
        "nameInd": "Insinyur (telekomunikasi) / Insinyur telekomunikasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang merancang di telekomunikasi",
        "descriptionEng": "someone who designs telecommunications",
        "clazz": "2",
        "$$hashKey": "object:3531"
    },
    {
        "nameEng": "Linesman (telecommunications)",
        "code": "TLLI",
        "gender": "All",
        "nameInd": "Petugas kabel (telekomunikasi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga kabel",
        "descriptionEng": "someone who guards the line",
        "clazz": "3",
        "$$hashKey": "object:4427"
    },
    {
        "nameEng": "Maintenance technician (telecommunications) / Telecommunications maintenance technician",
        "code": "TLEM",
        "gender": "All",
        "nameInd": "Teknisi pemeliharaan (telekomunikasi) / Teknisi pemeliharaan telekomunikasi",
        "minAge": "0",
        "descriptionInd": "seseorang yanng menjaga teknis telekomunikasi",
        "descriptionEng": "someone who maintains the telecommunications technicality",
        "clazz": "2",
        "$$hashKey": "object:4627"
    },
    {
        "nameEng": "Operator (telecommunications)",
        "code": "TLEO",
        "gender": "All",
        "nameInd": "Operator (telekomuikasi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan",
        "descriptionEng": "someone who operates",
        "clazz": "1",
        "$$hashKey": "object:3754"
    },
    {
        "nameEng": "Radio or telephone operator",
        "code": "RTOP",
        "gender": "All",
        "nameInd": "Operator Radio atau Televisi",
        "minAge": "0",
        "descriptionInd": "Pekerjaan umum:di bawah pengawasan badan umum, mengoperasikan dan memonitor sistem komunikasi radio telepon, sesuai dengan pekerjaan yang diperlukan. Seseorang dalam posisi ini beroperasi dan memantausirkuit komunikasi radio, menjaga  mencatat aktivitas lalu lintas komunikasi harian.",
        "descriptionEng": "General statement of duties: under general supervision, operates and monitors a radio-telephone communication system, does related work as required. A person in this position operates and monitors municipal radio communication circuits, keeping a daily log of all traffic.",
        "clazz": "1",
        "$$hashKey": "object:3817"
    },
    {
        "nameEng": "Telephonist (telecommunications)",
        "code": "TLPH",
        "gender": "All",
        "nameInd": "Teleponis (telekomunikasi)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di sentral telepon atau yang bertugas menjawab telepon untuk bisnis atau organisasi lain",
        "descriptionEng": "someone who works at a telephone exchange or whose job is to answer the telephone for a business or other organization",
        "clazz": "1",
        "$$hashKey": "object:4642"
    },
    {
        "nameEng": "Telex operator",
        "code": "TELX",
        "gender": "All",
        "nameInd": "Operator Mesin Fax",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengoperasikan mesin fax untuk mengirim pesan.",
        "descriptionEng": "A person who operate the telex machine to send message.",
        "clazz": "1",
        "$$hashKey": "object:3790"
    },
    {
        "nameEng": "Beautician shop manager / Beautician shop proprietor / Beautician shop owner",
        "code": "BASM",
        "gender": "All",
        "nameInd": "Manajer toko kecantikan / Pemilik toko kecantikan / Pemilik toko kecantikan",
        "minAge": "0",
        "descriptionInd": "Orang yang terlatih untuk memberikan perawatan kecantikan, baik rambut atau lainnya.",
        "descriptionEng": "A skilled trained person to style & dress the hair & also other beauty treatments.",
        "clazz": "1",
        "$$hashKey": "object:3708"
    },
    {
        "nameEng": "Barber",
        "code": "BARB",
        "gender": "All",
        "nameInd": "Tukang cukur",
        "minAge": "0",
        "descriptionInd": "Orang yang menggunting rambut pria.",
        "descriptionEng": "A barber is a person whose occupation is mainly to cut, dress, groom, style and shave males' hair. Same like a Hairdresser.",
        "clazz": "2",
        "$$hashKey": "object:4666"
    },
    {
        "nameEng": "Beautician",
        "code": "BEAU",
        "gender": "All",
        "nameInd": "Ahli kecantikan",
        "minAge": "0",
        "descriptionInd": "Orang yang terlatih untuk memberikan perawatan kecantikan, baik rambut atau lainnya.",
        "descriptionEng": "A skilled trained person to style & dress the hair & also other beauty treatments.",
        "clazz": "2",
        "$$hashKey": "object:3349"
    },
    {
        "nameEng": "Cosmetologist",
        "code": "COSM",
        "gender": "All",
        "nameInd": "Ahli Kosmetik",
        "minAge": "0",
        "descriptionInd": "seorang profesional dalam bidang kecantikan dan perawatan rambut, perawatan wajah, perawatan kulit, dan perawatan tubuh lainnya.",
        "descriptionEng": "Cosmetologist is a professional in the field of beauty care and hair care, facials, skin care and other care related to beauty.",
        "clazz": "2",
        "$$hashKey": "object:3357"
    },
    {
        "nameEng": "Nail technician",
        "code": "NAIT",
        "gender": "All",
        "nameInd": "Teknisi kuku",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam kuku",
        "descriptionEng": "someone who specializes in nails",
        "clazz": "1",
        "$$hashKey": "object:4607"
    },
    {
        "nameEng": "Manicurist",
        "code": "MANC",
        "gender": "All",
        "nameInd": "Ahli manikur",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan manikur secara profesional.",
        "descriptionEng": "a person who performs manicures professionally.",
        "clazz": "1",
        "$$hashKey": "object:3360"
    },
    {
        "nameEng": "Masseur / Masseuse",
        "code": "MASS",
        "gender": "All",
        "nameInd": "Tukang pijat / Terapis pijat",
        "minAge": "0",
        "descriptionInd": "Seseorang yang tugasnya melakukan pemijatan kepada pelanggannya dan melakukan perawatan tubuh lainnya untuk mengembalikan kondisi tubuh menjadi lebih baik, memijat dengan cairan/pelumas atau senyawa lainnya.",
        "descriptionEng": "Massages customers and administers other body conditioning treatments for hygienic or remedial purposes: Applies alcohol, lubricants, or other rubbing compounds.",
        "clazz": "1",
        "$$hashKey": "object:4694"
    },
    {
        "nameEng": "Accountant",
        "code": "ACCT",
        "gender": "All",
        "nameInd": "Akuntan",
        "minAge": "0",
        "descriptionInd": "Orang yang ahli dalam melakukan fungsi akuntansi seperti audit atau analisis laporan keuangan.",
        "descriptionEng": "A professional person who performs accounting functions such as audits or financial statement analysis.",
        "clazz": "1",
        "$$hashKey": "object:3390"
    },
    {
        "nameEng": "Actuary",
        "code": "ACTU",
        "gender": "All",
        "nameInd": "Aktuaris",
        "minAge": "0",
        "descriptionInd": "Ahli yang berhubungan dengan dampak dari risiko finansial dan ketidakpastian.",
        "descriptionEng": "An actuary is a business professional who deals with the financial impact of risk and uncertainty.",
        "clazz": "1",
        "$$hashKey": "object:3388"
    },
    {
        "nameEng": "Auditor",
        "code": "AUDI",
        "gender": "All",
        "nameInd": "Petugas Audit Laporan Keuangan/Pemeriksa Laporan Keuangan",
        "minAge": "0",
        "descriptionInd": "Orang yang memeriksa ketepatan catatan bisnis, memastikan perusahaan menjalankan catatan keuangan yang tepat dan jujur.",
        "descriptionEng": "An official whose job it is to carefully check the accuracy of business records. Auditors are used to ensure that organizations are maintaining accurate and honest financial records and statements.",
        "clazz": "2",
        "$$hashKey": "object:4416"
    },
    {
        "nameEng": "Financial controller",
        "code": "FNCT",
        "gender": "All",
        "nameInd": "Pengontrol Keuangan",
        "minAge": "0",
        "descriptionInd": "Adalah seorang akuntan/auditor dalam suatu usaha yang melakukan supervisi atas kondisi keuangan dan melakukan pengawasan internal.",
        "descriptionEng": "A Financial Controller, or Comptroller, or Financial Control Officer (FCO) is an accounting/audit expert in a business who oversees accounting and the implementation and monitoring of internal controls.",
        "clazz": "1",
        "$$hashKey": "object:4249"
    },
    {
        "nameEng": "Bank staff",
        "code": "BANK",
        "gender": "All",
        "nameInd": "Pegawai Bank",
        "minAge": "0",
        "descriptionInd": "Pegawai bank.",
        "descriptionEng": "A general term for employee in a bank.",
        "clazz": "1",
        "$$hashKey": "object:3840"
    },
    {
        "nameEng": "Tellers",
        "code": "TELL",
        "gender": "All",
        "nameInd": "Teller Bank",
        "minAge": "0",
        "descriptionInd": "Pegawai Bank atau Lembaga sejenis yang berhubungan secara langsung dengan sebagian besar konsumen untuk membantu berbagai kebutuhan perbankan mereka, seperti setoran cek atau penarikan uang.",
        "descriptionEng": "an employee of bank, or similar institution, whose job includes the responsibilities of helping the bank customers with their banking needs, such as depositing a check or making a withdrawal. Or A teller is an employee of a bank who deals directly with most customers. In some places, this employee is known as a cashier. Most teller jobs require cash handling experience and a high school diploma. Most banks provide on the job training.",
        "clazz": "1",
        "$$hashKey": "object:4643"
    },
    {
        "nameEng": "Compliance officer",
        "code": "COMO",
        "gender": "All",
        "nameInd": "Staf kepatuhan",
        "minAge": "0",
        "descriptionInd": "karyawan yang tanggung jawabnya termasuk memastikan perusahaan mematuhi persyaratan peraturan luar dan kebijakan internalnya.",
        "descriptionEng": "an employee whose responsibilities include ensuring the company complies with its outside regulatory requirements and internal policies.",
        "clazz": "1",
        "$$hashKey": "object:4562"
    },
    {
        "nameEng": "Economist",
        "code": "ECOM",
        "gender": "All",
        "nameInd": "Ahli Ekonomi",
        "minAge": "0",
        "descriptionInd": "Ekonom adalah seorang profesional dalam disiplin ilmu ekonomi.",
        "descriptionEng": "An economist is a professional in the social science discipline of economics.",
        "clazz": "1",
        "$$hashKey": "object:3333"
    },
    {
        "nameEng": "Finance officer",
        "code": "FINO",
        "gender": "All",
        "nameInd": "Staf keuangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang memiliki tanggung jawab utama untuk mengelola keuangan perusahaan, termasuk perencanaan keuangan, manajemen risiko keuangan, pencatatan, dan pelaporan keuangan.",
        "descriptionEng": "someone who has primary responsibility for managing the company's finances, including financial planning, management of financial risks, record-keeping, and financial reporting.",
        "clazz": "1",
        "$$hashKey": "object:4566"
    },
    {
        "nameEng": "Billing assistant",
        "code": "BIAS",
        "gender": "All",
        "nameInd": "Staff Billing",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk membuat dan mengirimkan faktur ke klien untuk pembayaran dan meneliti sengketa faktur, bekerja di bawah pengawasan billing manager.",
        "descriptionEng": "A billing assistant is responsible for creating and sending invoices to clients for payment and researching disputed invoices. Under the supervision of the billing manager.",
        "clazz": "1",
        "$$hashKey": "object:4581"
    },
    {
        "nameEng": "Recreation assistant",
        "code": "RECR",
        "gender": "All",
        "nameInd": "Asisten rekreasi",
        "minAge": "0",
        "descriptionInd": "seseorng yang membantu di rekreasi",
        "descriptionEng": "someone who assist in recreatiion",
        "clazz": "2",
        "$$hashKey": "object:3436"
    },
    {
        "nameEng": "Sports coach",
        "code": "SPCO",
        "gender": "All",
        "nameInd": "Pelatih olahraga",
        "minAge": "0",
        "descriptionInd": "seseorang yang melatih sebuah tim",
        "descriptionEng": "someone who trains a team",
        "clazz": "2",
        "$$hashKey": "object:3923"
    },
    {
        "nameEng": "Sports development officer",
        "code": "SPOD",
        "gender": "All",
        "nameInd": "Petugas pengembangan olahraga",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di pengembangan olahraga",
        "descriptionEng": "someone who works in sports development",
        "clazz": "2",
        "$$hashKey": "object:4473"
    },
    {
        "nameEng": "Cost assistant",
        "code": "CSAS",
        "gender": "All",
        "nameInd": "Asisten Bagian Pembiayaan",
        "minAge": "0",
        "descriptionInd": "seorang Asisten Pembiayaan bertugas membantu Pengawas Pembiayaan dalam sebuah proyek, dengan penerapan proses-proses Pengawasan Pembiayaan. Sang Asisten bekerja sama dengan banyak manajer, insinyur, dan staf teknisi dari pihak klien, di bawah arahan Pengawas Pembiayaan.",
        "descriptionEng": "The role of the Cost Assistant is to assist the project's Cost Controller with the implementation of Cost control processes. The Assistant will work with various managers, engineers, and technical staff of the client under the general direction of the Cost Controller.",
        "clazz": "1",
        "$$hashKey": "object:3419"
    },
    {
        "nameEng": "Inward and outward executive",
        "code": "INOT",
        "gender": "All",
        "nameInd": "Eksekutif Bagian Inward dan Outward",
        "minAge": "0",
        "descriptionInd": "Orang yang bertugas: Untuk memastikan semua biaya (invoice penagihan) dikumpulkan. Melakukan koordinasi dan menjaga hubungan baik  dengan staf penjualan untuk kepentingan Perusahaan. Untuk menentukan biaya penerimaan barang. Untuk memberikan instruksi untuk cara berkomunikasi yang benar ,khususnya dengan  pihak luar negeri.",
        "descriptionEng": "�To ensure all customers are attended promptlyTo ensure all charges (billed invoices) are collected To coordinate closely with the sale staff and maintain a good relationship for the interest of the Company To determine charges for consignees To give instructions for feasible ways of communication, especially to overseas parties",
        "clazz": "1",
        "$$hashKey": "object:3502"
    },
    {
        "nameEng": "Treasury assistant",
        "code": "TRAS",
        "gender": "All",
        "nameInd": "Asisten Bendahara",
        "minAge": "0",
        "descriptionInd": "Seorang bendahara profesional yang bekerja pada Departemen Perbendaharaan milik pemerintah maupun perusahaan besar.",
        "descriptionEng": "A treasury assistant is a treasury professional who works in the Treasury Dept of a govt or a large company.",
        "clazz": "1",
        "$$hashKey": "object:3420"
    },
    {
        "nameEng": "Financial adviser",
        "code": "FNLP",
        "gender": "All",
        "nameInd": "Konsutan/Perencana Keuangan",
        "minAge": "0",
        "descriptionInd": "Perencana keuangan adalah orang yang memberikan pelayanan berupa perencanaan keuangan untuk orang-oramh yang mempunyai beberapa aspek keuangan meliputu pengaturan keluar masuknya uang, edukasi perencanaan keuangan, pensiun, investasi, manajemen resiko, asuransi, pajak dan rencana sukses dalam usaha (untuk pemilik usaha).",
        "descriptionEng": "A financial planner or personal financial planner is a practicing professional who prepares financial plans for people covering various aspects of personal finance which includes: cash flow management, education planning, retirement planning, investment planning, risk management and insurance planning, tax planning, estate planning and business succession planning (for business owners).",
        "clazz": "1",
        "$$hashKey": "object:3645"
    },
    {
        "nameEng": "Financial planner/ financial planner employees",
        "code": "FIPL",
        "gender": "All",
        "nameInd": "Konsultan perencanaan keuangan",
        "minAge": "0",
        "descriptionInd": "Seorang yang bekerja di konsultan perencanaan keuangan",
        "descriptionEng": "financial planner/ financial planner employees",
        "clazz": "1",
        "$$hashKey": "object:3643"
    },
    {
        "nameEng": "Investment fund managers",
        "code": "IFUN",
        "gender": "All",
        "nameInd": "Manajer dana investasi",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberikan nasihat dan layanan keuangan kepada klien swasta dan perusahaan tentang berbagai hal investasi, termasuk membeli dan menjual kepercayaan investasi dan saham atau obligasi, untuk membantu klien ini menginvestasikan uang mereka di tempat-tempat terbaik.",
        "descriptionEng": "someone who provides financial advice and services to private and corporate clients about a range of investment matters, including buying and selling investment trusts and shares or bonds, to help these clients invest their money in the best places.",
        "clazz": "1",
        "$$hashKey": "object:3675"
    },
    {
        "nameEng": "Slater",
        "code": "SLAT",
        "gender": "All",
        "nameInd": "Pekerja pelapis bangunan",
        "minAge": "0",
        "descriptionInd": "seseorang yang melapisi bangunan dengan batu tulis.",
        "descriptionEng": "someone who covers buildings with slate.",
        "clazz": "3",
        "$$hashKey": "object:3880"
    },
    {
        "nameEng": "Rent collector",
        "code": "RENC",
        "gender": "All",
        "nameInd": "Kolektor penyewaan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menempatkan dan memberi tahu pelanggan tentang akun yang bermasalah melalui surat, telepon, atau kunjungan pribadi untuk meminta pembayaran. Tugasnya termasuk menerima pembayaran dan jumlah posting ke akun pelanggan; menyiapkan pernyataan kepada departemen kredit jika pelanggan gagal menjawab; memulai proses kepemilikan kembali atau pemutusan layanan; dan menyimpan catatan pengumpulan dan status akun.",
        "descriptionEng": "someone who locates and notifies customers of delinquent accounts by mail, telephone, or personal visit to solicit payment. Duties include receiving payment and posting amount to customer's account; preparing statements to credit department if customer fails to respond; initiating repossession proceedings or service disconnection; and keeping records of collection and status of accounts.",
        "clazz": "2",
        "$$hashKey": "object:3625"
    },
    {
        "nameEng": "Rent officer",
        "code": "RENO",
        "gender": "All",
        "nameInd": "Staf penyewaan",
        "minAge": "0",
        "descriptionInd": "mempertahankan daftar sewa yang adil menetapkan sewa maksimum yang dapat dibebankan untuk 'sewa diatur' (juga dikenal sebagai 'dilindungi' atau 'aman' sewa) menentukan Tunjangan Perumahan Lokal (LHA) berdasarkan tingkat sewa pasar swasta",
        "descriptionEng": "maintaining a register of fair�rents�setting the maximum�rentthat can be charged for a 'regulated tenancy' (also known as a 'protected' or 'secure' tenancy) determining Local Housing Allowance (LHA) based on private market�rentlevels",
        "clazz": "1",
        "$$hashKey": "object:4574"
    },
    {
        "nameEng": "Risk management specialist",
        "code": "RSKM",
        "gender": "All",
        "nameInd": "Spesialis manajemen risiko",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam manajemen resiko atau kerugian",
        "descriptionEng": "someone who specializes in risk management",
        "clazz": "1",
        "$$hashKey": "object:4552"
    },
    {
        "nameEng": "Tax consultant",
        "code": "TXCS",
        "gender": "All",
        "nameInd": "Konsultan Pajak",
        "minAge": "0",
        "descriptionInd": "Seorang yang bekerja di konsultan pajak",
        "descriptionEng": "tax consultant/ tax consultant employees",
        "clazz": "1",
        "$$hashKey": "object:3641"
    },
    {
        "nameEng": "Tax assistant (clerical)",
        "code": "TXAS",
        "gender": "All",
        "nameInd": "Pegawai Pajak",
        "minAge": "0",
        "descriptionInd": "Seseorang yang membantu Inspektur dalam proses penilaian, pekerjaan administratif, maupun menjawab permintaan pelanggan.",
        "descriptionEng": "A person who help inspector in assessment, clerical work, answer to customer queries.",
        "clazz": "1",
        "$$hashKey": "object:3853"
    },
    {
        "nameEng": "Fitness centre manager  / Gym manager / Spa manager",
        "code": "GYMM",
        "gender": "All",
        "nameInd": "Manajer pusat kebugaran / Manajer gim / Manajer spa",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola gelanggang olahraga",
        "descriptionEng": "someone who manages gym",
        "clazz": "2",
        "$$hashKey": "object:3701"
    },
    {
        "nameEng": "Fitness instructor / Personal trainer",
        "code": "FTTR",
        "gender": "All",
        "nameInd": "Pelatih Fitness",
        "minAge": "0",
        "descriptionInd": "Pelatih kebugaran pribadi adalah seorang profesional yang terlibat dalam kegiatan olah raga yang telah direncanakan dan di instruksikan. Mereka memberi motivasi kepada konsumen sengan menetapkan target dan memberikan masukkan kepada konsumen. Pelatih juga mengukur kekuatan konsumen dan kelemahannya dengan menggunakan analisa kebugaran.",
        "descriptionEng": "A personal trainer (fitness trainer) is a fitness professional involved in exercise prescription and instruction. They motivate clients by setting goals and providing feedback and accountability to clients. Trainers also measure their client's strengths and weaknesses with fitness assessments.",
        "clazz": "2",
        "$$hashKey": "object:3921"
    },
    {
        "nameEng": "Personal Trainer",
        "code": "PETR",
        "gender": "All",
        "nameInd": "Pelatih olahraga pribadi",
        "minAge": "0",
        "descriptionInd": "seseorang yang melatih orang-orang di sarana olahraga",
        "descriptionEng": "someone who trains people in gym",
        "clazz": "2",
        "$$hashKey": "object:3924"
    },
    {
        "nameEng": "Lifeguard",
        "code": "LFGD",
        "gender": "All",
        "nameInd": "Penjaga Pantai",
        "minAge": "0",
        "descriptionInd": "yang mengawasi keamanan dan penyelamatan perenang, peselancar, dan peserta olahraga lainnya seperti di kolam renang, taman air atau pantai.",
        "descriptionEng": "Supervises the safety and rescue of swimmers, surfers, and other water sports participants such as in a swimming pool, water park, or beach.",
        "clazz": "3",
        "$$hashKey": "object:4313"
    },
    {
        "nameEng": "Membership consultant  / Consultant (fitness membership)",
        "code": "MEMB",
        "gender": "All",
        "nameInd": "Konsultan keanggotaan / Konsultan (keanggotaan kebugaran)",
        "minAge": "0",
        "descriptionInd": "untuk mendapatkan keanggotaan untuk mencapai tujuan penjualan. Tanggung jawab tambahan termasuk membantu dengan layanan pelanggan, membantu calon anggota dan anggota klub yang ada dengan kekhawatiran mengenai klub dan memulai akun perusahaan baru.",
        "descriptionEng": "to gain�memberships�in order to meet�sales�goals. Additional�responsibilities�include assisting with customer service, helping prospective members and existing club members with concerns regarding the club and starting new corporate accounts.",
        "clazz": "1",
        "$$hashKey": "object:3638"
    },
    {
        "nameEng": "Mountain guide",
        "code": "MOUN",
        "gender": "All",
        "nameInd": "Pemandu naik gunung",
        "minAge": "0",
        "descriptionInd": "seseorang yang memnadu ketika naik gunung",
        "descriptionEng": "someone who guides when hiking",
        "clazz": "3",
        "$$hashKey": "object:3952"
    },
    {
        "nameEng": "Swimming pool attendant",
        "code": "SPAT",
        "gender": "All",
        "nameInd": "Penjaga Kolam Renang",
        "minAge": "0",
        "descriptionInd": "Regu penyelamat di kolam renang.",
        "descriptionEng": "A lifeguard at a swimming pool.",
        "clazz": "2",
        "$$hashKey": "object:4308"
    },
    {
        "nameEng": "Fitness therapist / Sports therapist",
        "code": "FITH",
        "gender": "All",
        "nameInd": "Terapis kebugaran / Terapis olahraga",
        "minAge": "0",
        "descriptionInd": "untuk membantu pasien membuat keputusan dan mengklarifikasi perasaan mereka untuk memecahkan masalah.",
        "descriptionEng": "to help patients make decisions and clarify their feelings in order to solve problems.",
        "clazz": "2",
        "$$hashKey": "object:4646"
    },
    {
        "nameEng": "Embalmer",
        "code": "EMBA",
        "gender": "All",
        "nameInd": "Pembalsem",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan seni dan ilmu untuk melestarikan sementara tubuh manusia setelah mati agar cocok untuk dilihat di pemakaman, yang umum dalam banyak budaya dan agama.",
        "descriptionEng": "someone who does the art and science of temporarily preserving a human body after death to make it suitable for viewing at a funeral, which is common in many cultures and religions.",
        "clazz": "2",
        "$$hashKey": "object:3981"
    },
    {
        "nameEng": "Funeral director",
        "code": "FUNI",
        "gender": "All",
        "nameInd": "Perencana pemakaman",
        "minAge": "0",
        "descriptionInd": "seseorang yang merencanakan atau mengarahkan pemakaman",
        "descriptionEng": "someone who directs a funeral",
        "clazz": "2",
        "$$hashKey": "object:4398"
    },
    {
        "nameEng": "Grave digger",
        "code": "GRAV",
        "gender": "All",
        "nameInd": "Penggali kuburan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menggali kuburan",
        "descriptionEng": "someone who digs a grave",
        "clazz": "3",
        "$$hashKey": "object:4229"
    },
    {
        "nameEng": "Mortuary attendant  / Mortuary technician",
        "code": "MORT",
        "gender": "All",
        "nameInd": "Penjaga kamar mayat / Teknisi kamar mayat",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga kamar mayat",
        "descriptionEng": "someone who guards the mortuary",
        "clazz": "3",
        "$$hashKey": "object:4305"
    },
    {
        "nameEng": "Automotic technician",
        "code": "ATOM",
        "gender": "All",
        "nameInd": "Teknisi otomotif",
        "minAge": "0",
        "descriptionInd": "orang yang dipekerjakan untuk menjaga peralatan teknis secara otomatis",
        "descriptionEng": "a person employed to look after technical equipment in automotic",
        "clazz": "3",
        "$$hashKey": "object:4619"
    },
    {
        "nameEng": "Car valeter",
        "code": "VALE",
        "gender": "All",
        "nameInd": "Petugas Parkir Valet",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas memberi pelayanan berupa memarkirkan kendaraan para tamu atau penumpang secara khusus.",
        "descriptionEng": "An employee, as in a hotel or on a ship, who performs personal services for guests or passengers.",
        "clazz": "2",
        "$$hashKey": "object:4453"
    },
    {
        "nameEng": "Car wash attendant",
        "code": "CWGR",
        "gender": "All",
        "nameInd": "Petugas Tempat Pencucian Mobil",
        "minAge": "0",
        "descriptionInd": "Pegawai pembersih mobil yang melakukan beberapa pekerjaan seperti menyedot debu, membersihkan dan memelihara interior kendaraan, membersihkan engsel pintu dll.",
        "descriptionEng": "A car cleaner who performs various tasks like vacuum, clean and maintain vehicle interiors,clean door trims and hinges etc.",
        "clazz": "2",
        "$$hashKey": "object:4500"
    },
    {
        "nameEng": "Exhaust technician",
        "code": "EXHA",
        "gender": "All",
        "nameInd": "Teknisi pembuangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat pembuangan",
        "descriptionEng": "someoen who looks after the exhaust",
        "clazz": "3",
        "$$hashKey": "object:4622"
    },
    {
        "nameEng": "Fuel cell technician",
        "code": "FUEL",
        "gender": "All",
        "nameInd": "Teknisi sel bahan bakar",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat sel bahan bakar",
        "descriptionEng": "someone who looks after the fuel cell",
        "clazz": "3",
        "$$hashKey": "object:4638"
    },
    {
        "nameEng": "Garage assistant",
        "code": "GAGA",
        "gender": "All",
        "nameInd": "Asisten bengkel",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di garasi",
        "descriptionEng": "someone who assist the garage",
        "clazz": "3",
        "$$hashKey": "object:3421"
    },
    {
        "nameEng": "Garage manager / Garage owner",
        "code": "GAGM",
        "gender": "All",
        "nameInd": "Manajer bengkel / pemilik bengkel",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola garasi",
        "descriptionEng": "someoen who manages the garage",
        "clazz": "2",
        "$$hashKey": "object:3673"
    },
    {
        "nameEng": "Maintenance electrician (motor vehicles)",
        "code": "MELC",
        "gender": "All",
        "nameInd": "Teknisi perawatan listrik (kendaraan bermotor)",
        "minAge": "0",
        "descriptionInd": "Pasang dan pertahankan sistem pengkabelan, kontrol, dan pencahayaan dalam pemeliharaan",
        "descriptionEng": "Install and maintain wiring, control, and lighting systems in maintenance",
        "clazz": "3",
        "$$hashKey": "object:4633"
    },
    {
        "nameEng": "Garage mechanic",
        "code": "GARM",
        "gender": "All",
        "nameInd": "Mekanik bengkel",
        "minAge": "0",
        "descriptionInd": "seorang pedagang, pengrajin, atau teknisi yang menggunakan alat untuk membangun atau memperbaiki mesin di garasi",
        "descriptionEng": "a tradesman, craftsman, or technician who uses tools to build or repair machinery in garage",
        "clazz": "3",
        "$$hashKey": "object:3730"
    },
    {
        "nameEng": "Garage trade (fitter, mechanic)",
        "code": "GART",
        "gender": "All",
        "nameInd": "Mekanik",
        "minAge": "0",
        "descriptionInd": "Tukang Bengkel yaitu seseorang yang bekerja di bengkel (mekanik).",
        "descriptionEng": "A garage worker is someone who works in workshop.",
        "clazz": "3",
        "$$hashKey": "object:3727"
    },
    {
        "nameEng": "Panel beater",
        "code": "PBEA",
        "gender": "All",
        "nameInd": "Pemulih bodi kendaraan",
        "minAge": "0",
        "descriptionInd": "seseorang yang emmulihkan panel",
        "descriptionEng": "someoen who restores panel",
        "clazz": "3",
        "$$hashKey": "object:4089"
    },
    {
        "nameEng": "Petrol pump attendant",
        "code": "PEPA",
        "gender": "All",
        "nameInd": "Petugas Pengisian BBM",
        "minAge": "0",
        "descriptionInd": "Memompa bahan bakar ke dalam kendaraan, memastikan kepada pelanggan bahan bakar yang sesuai kebutuhan. Mereka bekerja secara shift karena banyak dari pompa bensin beroperasi 24 jam dalam 7 hari.",
        "descriptionEng": "Pump fuel into the motor vehicle. Confirm with the customer what type of fuel he needs before pumping. May have to work in shifts as many fuelling stations are open 24*7.",
        "clazz": "3",
        "$$hashKey": "object:4476"
    },
    {
        "nameEng": "Gas attendant",
        "code": "GASA",
        "gender": "All",
        "nameInd": "Petugas SPBU",
        "minAge": "0",
        "descriptionInd": "Petugas SPBU yaitu pekerja di sebuah stasiun pengisian layanan lengkap yang melakukan jasa lain (pompa bahan bakar, pembersih kaca depan, dan memeriksa tingkat minyak kendaraan) selain menerima pembayaran.",
        "descriptionEng": "A gas station attendant  is a worker at a full-service filling station who performs services other than accepting payment. Tasks usually include pumping fuel, cleaning windshields, and checking vehicle oil levels.",
        "clazz": "2",
        "$$hashKey": "object:4494"
    },
    {
        "nameEng": "Houseperson",
        "code": "HSPN",
        "gender": "All",
        "nameInd": "Pekerja Hotel",
        "minAge": "0",
        "descriptionInd": "Yang bertugas untuk memainatain kebersihan lobby dan toilet termasuk penyediaan barang-barang yang diperlukan termasuk sabun dan handuk.",
        "descriptionEng": "Housemen are also responsible for cleaning lobbies and bathrooms along with stocking guest rooms with necessary items like soaps and towels.",
        "clazz": "2",
        "$$hashKey": "object:3864"
    },
    {
        "nameEng": "Room service",
        "code": "RMSV",
        "gender": "All",
        "nameInd": "Pelayan Kamar Hotel",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja membantu dan melayani kebutuhan para tamu di hotel.",
        "descriptionEng": "A person whose job to assist and fulfill the customer's need in the hotel room.",
        "clazz": "2",
        "$$hashKey": "object:3932"
    },
    {
        "nameEng": "Bar proprietor",
        "code": "BARP",
        "gender": "All",
        "nameInd": "Pemilik bar",
        "minAge": "0",
        "descriptionInd": "seseorang yang memiliki bar",
        "descriptionEng": "someone who owns a bar",
        "clazz": "3",
        "$$hashKey": "object:4062"
    },
    {
        "nameEng": "Bar worker",
        "code": "BARW",
        "gender": "All",
        "nameInd": "Pekerja bar",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekeja di bar",
        "descriptionEng": "someone who works in a bar",
        "clazz": "3",
        "$$hashKey": "object:3860"
    },
    {
        "nameEng": "Barman/Barmaid",
        "code": "BARM",
        "gender": "All",
        "nameInd": "Pelayan Bar",
        "minAge": "0",
        "descriptionInd": "Orang yang menyajikan minuman di bar, biasanya minuman beralkohol.",
        "descriptionEng": "is a person who serves usually alcoholic beverages behind the bar.",
        "clazz": "3",
        "$$hashKey": "object:3928"
    },
    {
        "nameEng": "Bartender",
        "code": "BART",
        "gender": "All",
        "nameInd": "Peracik Minuman di Bar atau Restoran",
        "minAge": "0",
        "descriptionInd": "Orang yang menyajikan minuman beralkohol di bar yang berlisensi.",
        "descriptionEng": "is a person who serves usually alcoholic beverages behind the bar in a licensed establishment.",
        "clazz": "3",
        "$$hashKey": "object:4371"
    },
    {
        "nameEng": "Butler",
        "code": "BTLR",
        "gender": "All",
        "nameInd": "Kepala Pelayan",
        "minAge": "0",
        "descriptionInd": "Kepala pelayan laki-laki, biasanya bertugas untuk menyediakan makanan, merawat barang-barang dari perak, dll.",
        "descriptionEng": "The chief male servant of a household, usually in charge of serving food, the care of silverware, etc.",
        "clazz": "2",
        "$$hashKey": "object:3608"
    },
    {
        "nameEng": "Car park attendant",
        "code": "CPAT",
        "gender": "All",
        "nameInd": "Petugas Penjaga Parkiran Mobil",
        "minAge": "0",
        "descriptionInd": "Orang yang memarkir kendaraan di area parkir, memberikan tiket parkir pada saat kedatangan, mengumpulkan uang parkir.",
        "descriptionEng": "Persons who drive and direct cards within parking areas, issue tickets at time of arrival, collect parking fees from customers.",
        "clazz": "2",
        "$$hashKey": "object:4477"
    },
    {
        "nameEng": "Event co-ordinator / Wedding co-ordinator",
        "code": "WEDC",
        "gender": "All",
        "nameInd": "Koordinator acara / Koordinator pernikahan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola sebuah acara",
        "descriptionEng": "someone who manages the event",
        "clazz": "2",
        "$$hashKey": "object:3648"
    },
    {
        "nameEng": "Catering events manager / Food service manager",
        "code": "EVNT",
        "gender": "All",
        "nameInd": "Manajer acara katering / Manajer layanan makanan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola acara katering",
        "descriptionEng": "someone who manages catering event",
        "clazz": "2",
        "$$hashKey": "object:3668"
    },
    {
        "nameEng": "Verger",
        "code": "VRGR",
        "gender": "All",
        "nameInd": "Petugas gereja",
        "minAge": "0",
        "descriptionInd": "seorang pejabat di sebuah gereja yang bertindak sebagai juru kunci dan petugas.",
        "descriptionEng": "an official in a church who acts as a caretaker and attendant.",
        "clazz": "2",
        "$$hashKey": "object:4423"
    },
    {
        "nameEng": "Exhibition promoter (Event Organizer)",
        "code": "EXPR",
        "gender": "All",
        "nameInd": "Promotor Eksibisi (EO)",
        "minAge": "0",
        "descriptionInd": "Pengatur acara adalah orang yang mengatur suatu upacara, pertandingan, festival, pesta, atau rapat akbar meliputi pembuatan anggaran,menetapkan tanggal dan alternatif tanggal, memilih dan memesan tempat pelaksanaan acara, meminta ijin dan mengkoordinasikan sarana transportasi dan tempat parkir.",
        "descriptionEng": "An exhibition promotor (event organizer) is person who organize a festival, ceremony, competition, party, concert, or convention, includes budgeting, establishing dates and alternate dates, selecting and reserving the event site, acquiring permits (alcohol permits, insurance licenses, etc), and coordinating transportation and parking.",
        "clazz": "2",
        "$$hashKey": "object:4526"
    },
    {
        "nameEng": "Domestic worker",
        "code": "DOMS",
        "gender": "All",
        "nameInd": "Pekerja rumah tangga",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di rumah tangga",
        "descriptionEng": "someone who works domestically",
        "clazz": "3",
        "$$hashKey": "object:3903"
    },
    {
        "nameEng": "Hospitality assistant",
        "code": "HOSP",
        "gender": "All",
        "nameInd": "Asisten keramahan",
        "minAge": "0",
        "descriptionInd": "Memberikan layanan yang sopan dan profesional kepada tamu / pelanggan. Bantu dalam persiapan pengaturan makanan, layanan dan bersih-bersih di fasilitas makan. Bantu dengan pelatihan karyawan baru.",
        "descriptionEng": "Provide courteous, professional service to guests/patrons. Assist in preparation of food set-up, service and clean-up in dining facilities. Assist with training of new employees.",
        "clazz": "3",
        "$$hashKey": "object:3428"
    },
    {
        "nameEng": "Catering assisstant",
        "code": "CAAS",
        "gender": "All",
        "nameInd": "Petugas Katering",
        "minAge": "0",
        "descriptionInd": "Orang yang membantu mempersiapkan, mengantarkan dan melayani makanan kepada pelanggan.",
        "descriptionEng": "Help to prepare, transport & serve meals for the customers.",
        "clazz": "3",
        "$$hashKey": "object:4430"
    },
    {
        "nameEng": "Hotel doorman",
        "code": "HTEL",
        "gender": "All",
        "nameInd": "Penjaga pintu hotel",
        "minAge": "0",
        "descriptionInd": "sesoerang yang menyapa dan membantu para tamu",
        "descriptionEng": "someone who greets and helps the guests",
        "clazz": "3",
        "$$hashKey": "object:4318"
    },
    {
        "nameEng": "Hotel manager / Conference manager",
        "code": "HTEM",
        "gender": "All",
        "nameInd": "Manajer hotel / Manajer konferensi",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola hotel",
        "descriptionEng": "someone who manages the hotel",
        "clazz": "1",
        "$$hashKey": "object:3678"
    },
    {
        "nameEng": "Resort executive",
        "code": "RESO",
        "gender": "All",
        "nameInd": "Pengelola Resort",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja sebagai pengelola sebuah resort seperti hotel atau spa.",
        "descriptionEng": "A person who manages the resort such as hotel and spa.",
        "clazz": "2",
        "$$hashKey": "object:4179"
    },
    {
        "nameEng": "Hotel porter / Bell Boy",
        "code": "BELL",
        "gender": "All",
        "nameInd": "Pelayan Hotel (Pria)",
        "minAge": "0",
        "descriptionInd": "Pria atau anak lelaki yang bekerja di hotel, klub dsb untuk mengangkat bagasi, menerima panggilan untuk memberikan pelayanan.",
        "descriptionEng": "A man or boy employed in a hotel, club, etc., to carry luggage and answer calls for service; page; porter.",
        "clazz": "2",
        "$$hashKey": "object:3930"
    },
    {
        "nameEng": "Page boy (hotel)",
        "code": "PGBY",
        "gender": "All",
        "nameInd": "Pelayan Hotel",
        "minAge": "0",
        "descriptionInd": "Menyambut dan mengantarkan tamu dari dan ke kamar mereka dan membantu mengangkat koper mereka. Memberitahukan tamu tentang fitur keselamatan dan promosi dari outlet hotel. Menyimpan bawaan tamu sesuai dengan keinginan mereka dan membantu menurunkan dan menaikan bawaan mereka ke dalam atau keluar kendaraan.",
        "descriptionEng": "Welcome and escort guests to and from their rooms and assisting with luggage. Inform guests of safety features and promotion of hotel outlets. Store guest baggage upon request assist with loading and unloading of baggage into and out of automobiles .",
        "clazz": "2",
        "$$hashKey": "object:3929"
    },
    {
        "nameEng": "Housekeeper",
        "code": "HOSE",
        "gender": "All",
        "nameInd": "Pekerja Perbaikan Hotel/ Restaurant",
        "minAge": "0",
        "descriptionInd": "Orang yang bertugas melakukan  maintanance internal baik di Hotel/Restoran..",
        "descriptionEng": "Housekeeper (servant), a person heading up domestic maintenance.",
        "clazz": "2",
        "$$hashKey": "object:3893"
    },
    {
        "nameEng": "Steel erector",
        "code": "STLE",
        "gender": "All",
        "nameInd": "Erektor baja",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengerektor atau memasang baja",
        "descriptionEng": "someone who erects steel",
        "clazz": "3",
        "$$hashKey": "object:3505"
    },
    {
        "nameEng": "Floor housekeeper",
        "code": "FLHK",
        "gender": "All",
        "nameInd": "Petugas Kebersihan Lantai",
        "minAge": "0",
        "descriptionInd": "Pelayan lantai adalah pekerja domestik dalam suatu rumah yang besar,pelayan kadang-kadang di bagi menjadi beberapa bagian tersendiri yang masing-masing bertugas di ruang makan, dapur, gudang anggur. Beberapa dari mereka juga bertanggung jawab atas semua lantai dan pelayan rumah tangga memeliharan keseluruhan rumah dan penampilannya.",
        "descriptionEng": "Floor housekeeper is a domestic worker in a large household. In great houses, the household is sometimes divided into departments with the butler in charge of the dining room, wine cellar, and pantry. Some also have charge of the entire parlour floor, and housekeepers caring for the entire house and its appearance.",
        "clazz": "2",
        "$$hashKey": "object:4437"
    },
    {
        "nameEng": "Ice cream van driver",
        "code": "ICED",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) mobil Van Es Krim",
        "minAge": "0",
        "descriptionInd": "Supir yang mengendarai van penjual es krim.",
        "descriptionEng": "Ice cream van driver driver is someone who drives a Ice cream van.",
        "clazz": "2",
        "$$hashKey": "object:4200"
    },
    {
        "nameEng": "Maitre D",
        "code": "MAIT",
        "gender": "All",
        "nameInd": "Kepala pelayan restoran",
        "minAge": "0",
        "descriptionInd": "orang di restoran yang mengawasi para pelayan dan busboy, dan yang biasanya menangani reservasi.",
        "descriptionEng": "the person in a restaurant who oversees the waitpersons and busboys, and who typically handles reservations.",
        "clazz": "2",
        "$$hashKey": "object:3609"
    },
    {
        "nameEng": "Receptionist",
        "code": "HSRP",
        "gender": "All",
        "nameInd": "Resepsionis",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja di sebuah kantor yang menyambut pengunjung, menjawab telepon, menyambungkan panggilan telepon dan menyampaikan pesan.",
        "descriptionEng": "a person who works at an office who greets visitors, answers the phones, routes calls and takes messages.",
        "clazz": "1",
        "$$hashKey": "object:4536"
    },
    {
        "nameEng": "Restaurant manager",
        "code": "RSTM",
        "gender": "All",
        "nameInd": "Manajer restoran",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola dan ambil alih restoran",
        "descriptionEng": "someone who manages and runs the restaurant",
        "clazz": "2",
        "$$hashKey": "object:3702"
    },
    {
        "nameEng": "Hotel & Restaurant Captain",
        "code": "HOTL",
        "gender": "All",
        "nameInd": "Kapten Hotel & Restoran",
        "minAge": "0",
        "descriptionInd": "Kapten Hotel/Restoran adalah orang yang berwenang atas suatu unit atau sekelompok orang di hotel dan restoran.",
        "descriptionEng": "A Hotel and restaurant captain is a person in authority over a certain area, unit, or group of people at hotel and restaurant.",
        "clazz": "2",
        "$$hashKey": "object:3593"
    },
    {
        "nameEng": "Tour guide",
        "code": "TOUR",
        "gender": "All",
        "nameInd": "Pemandu wisata",
        "minAge": "0",
        "descriptionInd": "seseorang yang memandu para turis ketika bepergian",
        "descriptionEng": "someone who guides tourists when traveling",
        "clazz": "2",
        "$$hashKey": "object:3953"
    },
    {
        "nameEng": "Guide",
        "code": "GUID",
        "gender": "All",
        "nameInd": "Penunjuk Jalan atau Pemandu",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang bertugas mengantarkan dan memberikan penjelasan kepada tamu mengenai tempat-tempat yang belum diketahui.",
        "descriptionEng": "A guide is a person who leads anyone through unknown or unmapped country.",
        "clazz": "2",
        "$$hashKey": "object:4352"
    },
    {
        "nameEng": "Travel agent",
        "code": "TRAV",
        "gender": "All",
        "nameInd": "Agen Travel Perjalanan",
        "minAge": "0",
        "descriptionInd": "Seseorang yang menawarkan dan menjual paket wisata kepada pelanggan.",
        "descriptionEng": "A person who offers and sells travel packages to customers.",
        "clazz": "2",
        "$$hashKey": "object:3325"
    },
    {
        "nameEng": "Hotel/restaurant/bar/theatres waiter/waitress",
        "code": "HOTW",
        "gender": "All",
        "nameInd": "Pelayan Hotel/Restoran/Bioskop",
        "minAge": "0",
        "descriptionInd": "Pelayan Hotel/Restoran/Bar yaitu orang  yang bekerja di sebuah hotel/restoran/bar dan bertugas melayani tamu dan menyediakan makanan dan minuman.",
        "descriptionEng": "Hotel/restaurant/bar/theatres waiter/waitress are those who work at a Hotel/restaurant/bar/theatres attending customers, supplying them with food and drink as requested.",
        "clazz": "2",
        "$$hashKey": "object:3931"
    },
    {
        "nameEng": "Barista",
        "code": "BARR",
        "gender": "All",
        "nameInd": "Peracik Kopi di Coffe Shop",
        "minAge": "0",
        "descriptionInd": "Orang, biasanya karyawan kedai kopi, yang menyiapkan dan menyajikan kopi",
        "descriptionEng": "person, usually a coffee-house employee, who prepares and serves espresso-based coffee drinks.",
        "clazz": "2",
        "$$hashKey": "object:4370"
    },
    {
        "nameEng": "Beverage dispenser",
        "code": "BEVE",
        "gender": "All",
        "nameInd": "Penyaji Minuman",
        "minAge": "0",
        "descriptionInd": "Orang yang menyajikan minuman.",
        "descriptionEng": "is a person who serve beverage.",
        "clazz": "2",
        "$$hashKey": "object:4355"
    },
    {
        "nameEng": "Drink Waitstaff",
        "code": "DWSF",
        "gender": "All",
        "nameInd": "Pelayan Minuman",
        "minAge": "0",
        "descriptionInd": "Pramusaji minuman, adalah orang yang khusus melayani permintaan minuman dari pengunjung resoran atau bar.",
        "descriptionEng": "Drinks waitstaff are those who works at a restaurant or a bar attending customers, supplying them with drink as requested.",
        "clazz": "2",
        "$$hashKey": "object:3934"
    },
    {
        "nameEng": "F & C service crew",
        "code": "FCSC",
        "gender": "All",
        "nameInd": "Kru pelayanan dan makanan",
        "minAge": "0",
        "descriptionInd": "Petugas yang menyajikan makanan dan minuman, membersihkan piring yang telah digunakan, menata meja dan mencatat pesanan. Bertanggung jawab untuk memastikan tamu puas atas pelayanan yang diberikan.",
        "descriptionEng": "Delivering food and beverages, removing used dishes, setting up and taking down tables and taking orders. Their responsibility is to make sure the guests are satisfied.",
        "clazz": "3",
        "$$hashKey": "object:3654"
    },
    {
        "nameEng": "Prosecutor",
        "code": "PRCT",
        "gender": "All",
        "nameInd": "Jaksa",
        "minAge": "0",
        "descriptionInd": "Seorang yang berprofesi sebagai Jaksa",
        "descriptionEng": "Prosecutor",
        "clazz": "2",
        "$$hashKey": "object:3574"
    },
    {
        "nameEng": "Barrister",
        "code": "BARN",
        "gender": "All",
        "nameInd": "Pengacara jurisdiksi hukum",
        "minAge": "0",
        "descriptionInd": "orang yang mempraktekkan hukum, sebagai pengacara, pengacara, pengacara di hukum, pengacara, pengacara, pengacara, pengacara, konselor, konselor,",
        "descriptionEng": "a person who practices law, as an advocate, attorney, attorney at law, barrister, barrister-at-law, bar-at-law, counsel, counselor, counsellor,�",
        "clazz": "2",
        "$$hashKey": "object:4139"
    },
    {
        "nameEng": "Coroner",
        "code": "CORO",
        "gender": "All",
        "nameInd": "Pemeriksa kematian",
        "minAge": "0",
        "descriptionInd": "orang yang peran standarnya adalah untuk mengkonfirmasi dan mengesahkan kematian seorang individu dalam suatu yurisdiksi",
        "descriptionEng": "a�person whose standard role is to confirm and certify the death of an individual within a jurisdiction",
        "clazz": "2",
        "$$hashKey": "object:4059"
    },
    {
        "nameEng": "Court bailiff",
        "code": "CORT",
        "gender": "All",
        "nameInd": "Staf penjaga pengadilan",
        "minAge": "0",
        "descriptionInd": "adalah petugas penegak hukum yang berada di ruang sidang untuk menjaga ketertiban dan memberikan keamanan. Bersamaan dengan menjaga juri dan menegakkan aturan pengadilan, petugas pengadilan terbuka dengan mengumumkan kedatangan hakim dan pengadilan tertutup dengan mengumumkan kepergian hakim.",
        "descriptionEng": "are law enforcement officers who are situated in courtrooms to maintain order and provide security. Along with guarding juries and enforcing rules of the courts, bailiffs open court by announcing the judges' arrival and close court by announcing the judges' departure.",
        "clazz": "2",
        "$$hashKey": "object:4572"
    },
    {
        "nameEng": "Judge",
        "code": "JUDG",
        "gender": "All",
        "nameInd": "Hakim (Federal)",
        "minAge": "0",
        "descriptionInd": "Hakim yaitu orang yang bertugas mengadili, mengelola sistem peradilan.",
        "descriptionEng": "Arbitrates disputes, advises counsel, jury, litigants, or court personnel, and administers judicial system.",
        "clazz": "2",
        "$$hashKey": "object:3522"
    },
    {
        "nameEng": "Lawyer",
        "code": "LWYR",
        "gender": "All",
        "nameInd": "Pengacara",
        "minAge": "0",
        "descriptionInd": "Pengacara yaitu orang yang mewakili klien dalam litigasi pidana dan perdata dan proses hukum lainnya, menyusun dokumen hukum, dan mengelola atau menyarankan klien atas  transaksi legal.",
        "descriptionEng": "Represent clients in criminal and civil litigation and other legal proceedings, draw up legal documents, and manage or advise clients on legal transactions. May specialize in a single area or may practice broadly in many areas of law.",
        "clazz": "2",
        "$$hashKey": "object:4138"
    },
    {
        "nameEng": "Magistrate",
        "code": "MAGI",
        "gender": "All",
        "nameInd": "Pegawai negeri pengelola kota",
        "minAge": "0",
        "descriptionInd": "seorang perwira sipil yang didakwa dengan administrasi hukum; seorang perwira peradilan kecil, sebagai hakim perdamaian atau hakim pengadilan polisi, memiliki yurisdiksi untuk mengadili kasus-kasus kriminal ringan dan melakukan pemeriksaan awal terhadap orang-orang yang dituduh melakukan kejahatan berat.",
        "descriptionEng": "a civil officer charged with the administration of the law;  a minor judicial officer, as a justice of the peace or the judge of a police court, having jurisdiction to try minor criminal cases and to conduct preliminary examinations of persons charged with serious crimes.",
        "clazz": "1",
        "$$hashKey": "object:3844"
    },
    {
        "nameEng": "Notary public / Notary public officer",
        "code": "NOTA",
        "gender": "All",
        "nameInd": "Notaris",
        "minAge": "0",
        "descriptionInd": "Adalah pejabat publik yang bersumpah/afirmasi, mengambil keterangan tertulis, deklarasi hukum, saksi dan mengesahkan suatu dokumen.",
        "descriptionEng": "Is a public authority established by law oath and affirmation, take a written statement, a declaration of law, witness and certify a document.",
        "clazz": "2",
        "$$hashKey": "object:3752"
    },
    {
        "nameEng": "Registrar",
        "code": "REGI",
        "gender": "All",
        "nameInd": "Admin pendaftaran",
        "minAge": "0",
        "descriptionInd": "penjaga resmi catatan yang dibuat dalam daftar.",
        "descriptionEng": "an official keeper of records made in a register.",
        "clazz": "1",
        "$$hashKey": "object:3315"
    },
    {
        "nameEng": "Solicitor",
        "code": "SOLR",
        "gender": "All",
        "nameInd": "Penasihat/Konsultan Hukum",
        "minAge": "0",
        "descriptionInd": "Suatu jenis tipe praktek pengacara di Inggris yang khusus menangani pekerjaan kantor. Mirip dengan seorang pengacara di Amerika yang tidak muncul di pengadilan.",
        "descriptionEng": "A type of practicing lawyer in England who handles primarily office work. similar to that of a lawyer in the United States who does not appear in court.",
        "clazz": "2",
        "$$hashKey": "object:4104"
    },
    {
        "nameEng": "Tribunal member",
        "code": "TRIB",
        "gender": "All",
        "nameInd": "Anggota tribunal",
        "minAge": "0",
        "descriptionInd": "adalah badan peradilan khusus yang memutuskan perselisihan di bidang hukum tertentu.",
        "descriptionEng": "are specialist judicial bodies which decide disputes in a particular area of law.�",
        "clazz": "1",
        "$$hashKey": "object:3412"
    },
    {
        "nameEng": "Clergyman",
        "code": "CLER",
        "gender": "All",
        "nameInd": "Pastor",
        "minAge": "0",
        "descriptionInd": "seorang imam laki-laki, menteri, atau pemimpin agama, terutama yang Kristen.",
        "descriptionEng": "a male priest, minister, or religious leader, especially a Christian one.",
        "clazz": "1",
        "$$hashKey": "object:3832"
    },
    {
        "nameEng": "Imam",
        "code": "IMAM",
        "gender": "All",
        "nameInd": "Imam",
        "minAge": "0",
        "descriptionInd": "adalah posisi kepemimpinan Islam. Ini paling sering digunakan sebagai judul pemimpin penyembahan masjid dan komunitas Muslim di kalangan Muslim Sunni.",
        "descriptionEng": "is an Islamic leadership position. It is most commonly used as the title of a worship leader of a mosque and Muslim community among Sunni Muslims.",
        "clazz": "2",
        "$$hashKey": "object:3524"
    },
    {
        "nameEng": "Monk",
        "code": "MONK",
        "gender": "All",
        "nameInd": "Biksu",
        "minAge": "0",
        "descriptionInd": "Seorang bhikkhu adalah seseorang yang mempraktekkan asketisme religius oleh kehidupan monastik, baik sendiri atau dengan sejumlah bhikkhu lainnya.",
        "descriptionEng": "A�monk�is a person who practices religious asceticism by monastic living, either alone or with any number of other�monks.",
        "clazz": "3",
        "$$hashKey": "object:3450"
    },
    {
        "nameEng": "Muezzin",
        "code": "MUEZ",
        "gender": "All",
        "nameInd": "Muadzin",
        "minAge": "0",
        "descriptionInd": "adalah orang yang ditunjuk di masjid untuk memimpin dan membaca panggilan untuk doa untuk setiap acara doa dan ibadah di masjid.",
        "descriptionEng": "�is the person appointed at a mosque to lead and recite the call to prayer for every event of prayer and worship in the mosque.",
        "clazz": "2",
        "$$hashKey": "object:3742"
    },
    {
        "nameEng": "Mullah",
        "code": "MULL",
        "gender": "All",
        "nameInd": "Ulama",
        "minAge": "0",
        "descriptionInd": "seorang Muslim belajar dalam teologi Islam dan hukum sakral.",
        "descriptionEng": "a Muslim learned in Islamic theology and sacred law.",
        "clazz": "2",
        "$$hashKey": "object:4706"
    },
    {
        "nameEng": "Priest",
        "code": "PRST",
        "gender": "All",
        "nameInd": "Pendeta",
        "minAge": "0",
        "descriptionInd": "Orang yang berwenang dalam memimpin ritual keagamaan terutama sebagai mediator antara manusia dengam Tuhannya.",
        "descriptionEng": "is a person authorized to perform the sacred rituals of a religion, especially as a mediatory agent between humans and one or multiple deities",
        "clazz": "2",
        "$$hashKey": "object:4119"
    },
    {
        "nameEng": "Rabbi",
        "code": "RABB",
        "gender": "All",
        "nameInd": "Rabi",
        "minAge": "0",
        "descriptionInd": "seorang sarjana atau guru Yahudi, terutama yang mempelajari atau mengajar hukum Yahudi; seseorang yang ditunjuk sebagai pemimpin agama Yahudi.",
        "descriptionEng": "a Jewish scholar or teacher, especially one who studies or teaches Jewish law; a person appointed as a Jewish religious leader.",
        "clazz": "2",
        "$$hashKey": "object:4531"
    },
    {
        "nameEng": "Rector",
        "code": "RECT",
        "gender": "All",
        "nameInd": "Rektor",
        "minAge": "0",
        "descriptionInd": "seorang anggota ulama yang bertanggung jawab atas paroki.",
        "descriptionEng": "a member of the clergy who has charge of a parish.",
        "clazz": "2",
        "$$hashKey": "object:4533"
    },
    {
        "nameEng": "Vicar",
        "code": "VICA",
        "gender": "All",
        "nameInd": "Vikaris",
        "minAge": "0",
        "descriptionInd": "Seorang vikaris adalah wakil, wakil atau pengganti; siapa pun yang bertindak \"dalam pribadi\" atau agen untuk atasan. Secara linguistik, vicar adalah serumpun dengan awalan bahasa Inggris \"wakil\", yang juga berarti \"wakil\".",
        "descriptionEng": "A vicar is a representative, deputy or substitute; anyone acting \"in the person of\" or agent for a superior. Linguistically, vicar is cognate with the English prefix \"vice\", similarly meaning \"deputy\".�",
        "clazz": "2",
        "$$hashKey": "object:4708"
    },
    {
        "nameEng": "Business continuity planner",
        "code": "BCPM",
        "gender": "All",
        "nameInd": "Perencana kelangsungan bisnis",
        "minAge": "0",
        "descriptionInd": "seseorang yang memproses pembuatan sistem pencegahan dan pemulihan untuk menghadapi ancaman potensial terhadap perusahaan.",
        "descriptionEng": "someone who processes the creating systems of prevention and recovery to deal with potential threats to a company.",
        "clazz": "2",
        "$$hashKey": "object:4396"
    },
    {
        "nameEng": "Chief security officer",
        "code": "CHSF",
        "gender": "All",
        "nameInd": "Kepala keamanan",
        "minAge": "0",
        "descriptionInd": "organisasi eksekutif senior yang paling bertanggung jawab untuk pengembangan dan pengawasan kebijakan dan program yang ditujukan untuk mitigasi dan / atau pengurangan strategi risiko keamanan kepatuhan, operasional, strategis, keuangan dan reputasi yang berkaitan dengan perlindungan orang,",
        "descriptionEng": "an organization's senior most executive accountable for the development and oversight of policies and programs intended for the mitigation and/or reduction of compliance, operational, strategic, financial and reputational security risk strategies relating to the protection of people,",
        "clazz": "2",
        "$$hashKey": "object:3602"
    },
    {
        "nameEng": "Private detective",
        "code": "PRIV",
        "gender": "All",
        "nameInd": "Detektif swasta",
        "minAge": "0",
        "descriptionInd": "detektif dan penyelidik swasta menemukan fakta dan menganalisis informasi tentang masalah hukum, keuangan, dan pribadi. Mereka menawarkan banyak layanan, termasuk memverifikasi latar belakang orang, menemukan orang hilang, dan menyelidiki kejahatan komputer.",
        "descriptionEng": "private detectives�and�investigators�find facts and analyze information about legal, financial, and personal matters. They offer many services, including verifying people's backgrounds, finding missing persons, and investigating computer crimes.",
        "clazz": "3",
        "$$hashKey": "object:3478"
    },
    {
        "nameEng": "Removers **",
        "code": "RMVR",
        "gender": "All",
        "nameInd": "Tukang Sampah",
        "minAge": "0",
        "descriptionInd": "Orang yang mengelola pengambilan, transportasi, pengolahan atau pembuangan, pengelolaan dan monitoring bahan bahan limbah.",
        "descriptionEng": "a person who manages the collection, transport, processing or disposal, managing and monitoring of waste materials.",
        "clazz": "2",
        "$$hashKey": "object:4699"
    },
    {
        "nameEng": "Rubbish collection driver",
        "code": "RUBB",
        "gender": "All",
        "nameInd": "Pengemudi mobil sampah",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengemudi mobil sampah",
        "descriptionEng": "someone who drives rubbish van",
        "clazz": "3",
        "$$hashKey": "object:4216"
    },
    {
        "nameEng": "Bodyguard",
        "code": "BDYG",
        "gender": "All",
        "nameInd": "Pengawal",
        "minAge": "0",
        "descriptionInd": "sejenis penjaga keamanan atau petugas penegak hukum atau tentara yang melindungi seseorang atau orang - biasanya pejabat tinggi atau pejabat publik, orang kaya, dan selebriti - dari bahaya: umumnya pencurian, penyerangan, penculikan, pembunuhan,",
        "descriptionEng": "a type of security guard or government law enforcement officer or soldier who protects a person or people — usually high-ranking public officials or officers, wealthy people, and celebrities — from danger: generally theft, assault, kidnapping, assassination,",
        "clazz": "3",
        "$$hashKey": "object:4151"
    },
    {
        "nameEng": "Detective",
        "code": "DTTV",
        "gender": "All",
        "nameInd": "Detektif (Penyelidik)",
        "minAge": "0",
        "descriptionInd": "Detektif adalah seorang penyelidik, dapat merupakan anggota kepolisian atau penyelidik lepas.Dapat juga dikenal sebagai \"mata-mata\", ada yang berlisensi ada juga yang tidak, mereka dapat menangani masalah kriminal, kejahatan atau menyelidiki dokumen-dokumen penting.",
        "descriptionEng": "A detective is an investigator, either a member of a police agency or a private person. The latter may be known as private investigators or \"private eyes\". Informally, and primarily in fiction, a detective is any licensed or unlicensed person who solves crimes, including historical crimes, or looks into records.",
        "clazz": "3",
        "$$hashKey": "object:3477"
    },
    {
        "nameEng": "Store detective",
        "code": "STDE",
        "gender": "All",
        "nameInd": "Pendeteksi pencurian",
        "minAge": "0",
        "descriptionInd": "anggota Pencegahan Kehilangan yang peran utamanya adalah untuk mencegah dan mendeteksi pencurian (umumnya dikenal sebagai pengutil) dan mengurangi penyusutan di gerai ritel. Mereka melakukan ini dengan berpatroli di toko dengan pakaian polos yang ingin mengidentifikasi anggota masyarakat yang mencuri dari toko.",
        "descriptionEng": "a member of�Loss Preventionwhose main role is to prevent and detect theft (commonly known as shoplifting) and reduce shrink in retail outlets. They do this by patrolling the�store�in plain clothes looking to identify members of the public who are stealing from the�store.",
        "clazz": "3",
        "$$hashKey": "object:4120"
    },
    {
        "nameEng": "Nightwatchman",
        "code": "NGHW",
        "gender": "All",
        "nameInd": "Penjaga malam",
        "minAge": "0",
        "descriptionInd": "memberikan keamanan semalam untuk bangunan dan / atau penghuninya. Dapat berpatroli dengan berjalan kaki atau di mobil atau menghabiskan giliran Anda dengan menonton pekarangan melalui sistem televisi sirkuit tertutup.",
        "descriptionEng": "provide overnight security for a building and/or its occupants. May patrol on foot or in a car or spend your shift watching the grounds via a closed-circuit television system.",
        "clazz": "3",
        "$$hashKey": "object:4310"
    },
    {
        "nameEng": "Doorman (Nightclub)",
        "code": "DOOR",
        "gender": "All",
        "nameInd": "Petugas Penjaga Pintu (klub malam)",
        "minAge": "0",
        "descriptionInd": "Petugas pintu klub malam adalah seorang yang ditempatkan dan seringkali berfungsi sebagai penjaga pintu suatu klub malam.",
        "descriptionEng": "A doorman night club, also known as doorkeeper, is someone who is posted at, and often guards, a night club door.",
        "clazz": "3",
        "$$hashKey": "object:4479"
    },
    {
        "nameEng": "Patrolman (Security purposes)",
        "code": "PATR",
        "gender": "All",
        "nameInd": "Petugas patroli (tujuan keamanan)",
        "minAge": "0",
        "descriptionInd": "seorang perwira polisi yang ditugaskan untuk berpatroli di distrik tertentu, rute,",
        "descriptionEng": "a police officer who is assigned to patrol a specific district, route,",
        "clazz": "3",
        "$$hashKey": "object:4455"
    },
    {
        "nameEng": "Security guard",
        "code": "SECG",
        "gender": "All",
        "nameInd": "Petugas Keamanan",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja menjaga keamanan dan lokasi nya di luar kantor.",
        "descriptionEng": "A person whose job to maintain security in an area.",
        "clazz": "3",
        "$$hashKey": "object:4432"
    },
    {
        "nameEng": "Door usher",
        "code": "DOUR",
        "gender": "All",
        "nameInd": "Petugas Penjaga Pintu",
        "minAge": "0",
        "descriptionInd": "Petugas penjaga pintu adalah orang yang ditempatkan untuk menjaga pintu.",
        "descriptionEng": "A door usher, also known as doorkeeper, is someone who is posted at, and often guards, a door, or by extension another entrance.",
        "clazz": "2",
        "$$hashKey": "object:4478"
    },
    {
        "nameEng": "Safety officer",
        "code": "SAFE",
        "gender": "All",
        "nameInd": "Staf Keamanan Perusahaan",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja menjaga keamanan di dalam ruangan kantor.",
        "descriptionEng": "A person whose job to maintain security at the office.",
        "clazz": "2",
        "$$hashKey": "object:4560"
    },
    {
        "nameEng": "Security officer (Premises)",
        "code": "SCOF",
        "gender": "All",
        "nameInd": "Petugas keamanan (di tempat)",
        "minAge": "0",
        "descriptionInd": "Amankan lokasi dan personil dengan patroli properti; pemantauan peralatan pengawasan; memeriksa bangunan, peralatan, dan titik akses; memungkinkan masuk. Dapatkan bantuan dengan membunyikan alarm. Mencegah kerugian dan kerusakan dengan melaporkan ketidakberesan; menginformasikan pelanggar kebijakan dan prosedur; menahan penyusup.",
        "descriptionEng": "Secures premises and personnel by patrolling property; monitoring surveillance equipment; inspecting buildings, equipment, and access points; permitting entry. Obtains help by sounding alarms. Prevents losses and damage by reporting irregularities; informing violators of policy and procedures; restraining trespassers.",
        "clazz": "3",
        "$$hashKey": "object:4433"
    },
    {
        "nameEng": "Shop doorman",
        "code": "SHDO",
        "gender": "All",
        "nameInd": "Penjaga pintu toko",
        "minAge": "0",
        "descriptionInd": "manjadwalkan pengiriman atau pengambilan kembali online selama 1 jam, hingga tengah malam, tujuh hari seminggu.",
        "descriptionEng": "Schedule deliveries or online return pickup during a 1 hour window, until midnight, seven days a week.",
        "clazz": "3",
        "$$hashKey": "object:4320"
    },
    {
        "nameEng": "Fork lift truck driver",
        "code": "FOLT",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Forklift",
        "minAge": "0",
        "descriptionInd": "Supir truk pengangkat barang adalah orang yang mengemudikan truk pengangkat barang.",
        "descriptionEng": "Fork lift truck driver is someone who drives a fork lift truck.",
        "clazz": "3",
        "$$hashKey": "object:4193"
    },
    {
        "nameEng": "Stockroom storeman",
        "code": "STOS",
        "gender": "All",
        "nameInd": "Penjaga gudang stok",
        "minAge": "0",
        "descriptionInd": "adalah memastikan keamanan dan keamanan stok. Ini mengambil bentuk memastikan bahwa ada sistem keamanan yang memadai di tempat, termasuk penjaga, kamera, dan sistem alarm.",
        "descriptionEng": "is ensuring the safety and security of the stock. This takes the form of ensuring that there are adequate security systems in place, including guards, cameras, and alarm systems.",
        "clazz": "3",
        "$$hashKey": "object:4303"
    },
    {
        "nameEng": "Warehouse keeper",
        "code": "WARE",
        "gender": "All",
        "nameInd": "Penjaga Gudang",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas menjaga dan mengatur suatu gudang.",
        "descriptionEng": "A person who manage and guard a warehouse.",
        "clazz": "2",
        "$$hashKey": "object:4300"
    },
    {
        "nameEng": "Godown keepers",
        "code": "GODO",
        "gender": "All",
        "nameInd": "Pengawas Gudang",
        "minAge": "0",
        "descriptionInd": "Adalah seseorang yang bertugas  untuk menjaga gudang.",
        "descriptionEng": "Godown keepers is someone whose job is to keep warehouse.",
        "clazz": "3",
        "$$hashKey": "object:4157"
    },
    {
        "nameEng": "Warehouse manager",
        "code": "WARG",
        "gender": "All",
        "nameInd": "Manajer gudang",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola gudang",
        "descriptionEng": "someone who managees warehouse",
        "clazz": "2",
        "$$hashKey": "object:3677"
    },
    {
        "nameEng": "Traffic and warehouse officer",
        "code": "TRAF",
        "gender": "All",
        "nameInd": "Pekerja Pergudangan",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengembangkan metode dan prosedur untuk transportasi bahan baku ke daerah pengolahan dan produksi, serta komoditas ke konsumen, gudang, dan atau fasilitas penyimpanan lainnya.",
        "descriptionEng": "Develops methods and procedures for transportation of raw materials to processing and production areas and commodities from departments to customers, warehouses, or other storage facilities.",
        "clazz": "2",
        "$$hashKey": "object:3894"
    },
    {
        "nameEng": "Warehouse porter",
        "code": "WARP",
        "gender": "All",
        "nameInd": "Porter Gudang",
        "minAge": "0",
        "descriptionInd": "Orang yang dipekerjakan untuk mengangkat bagasi, parsel, persediaan, dan lain-lain terutama di stasiun kereta api atau hotel.",
        "descriptionEng": "A person employed to carry luggage, parcels, supplies, etc., esp at a railway station or hotel.",
        "clazz": "3",
        "$$hashKey": "object:4516"
    },
    {
        "nameEng": "Warehouseman",
        "code": "WARH",
        "gender": "All",
        "nameInd": "Pengelola gudang",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di gudang",
        "descriptionEng": "someone who works in warehouse",
        "clazz": "3",
        "$$hashKey": "object:4177"
    },
    {
        "nameEng": "Foreman sewerman",
        "code": "FRSW",
        "gender": "All",
        "nameInd": "Mandor terowongan pembuangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengatur terowongan pembuangan sampah",
        "descriptionEng": "someone who manage waste disposal sewer",
        "clazz": "3",
        "$$hashKey": "object:3721"
    },
    {
        "nameEng": "Incinerator operator",
        "code": "INOP",
        "gender": "All",
        "nameInd": "Operator pembakaran sampah",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan pembakaran sampah",
        "descriptionEng": "someone who oeperates incinerator",
        "clazz": "3",
        "$$hashKey": "object:3807"
    },
    {
        "nameEng": "Rag and bone dealer",
        "code": "RGNB",
        "gender": "All",
        "nameInd": "Penjual barang bekas",
        "minAge": "0",
        "descriptionInd": "seseoerang yang menjual barang bekas",
        "descriptionEng": "someone who deals rag and bone",
        "clazz": "3",
        "$$hashKey": "object:4329"
    },
    {
        "nameEng": "Recycling operative",
        "code": "RCYC",
        "gender": "All",
        "nameInd": "Operator daur ulang",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan dau ulang",
        "descriptionEng": "someone who operates recycling",
        "clazz": "3",
        "$$hashKey": "object:3761"
    },
    {
        "nameEng": "Carpet fitter",
        "code": "CARP",
        "gender": "All",
        "nameInd": "Pemasang karpet",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang karpet",
        "descriptionEng": "someone who fits the carpet",
        "clazz": "3",
        "$$hashKey": "object:3961"
    },
    {
        "nameEng": "Mechanical road sweeper driver",
        "code": "MERS",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Mobil Penyapu Jalan",
        "minAge": "0",
        "descriptionInd": "Mengemudikan mesin penyapu jalan meliputi pembersihan jalan dari sampah, menggerakkan kontrol mesin sehingga mesin secara otomatis mengambil debu dan sampah dari jalan beraspal dan menyimpan sampah tersebut dalam mesin.",
        "descriptionEng": "Drives sweeping machine that cleans streets of trash, moves controls to activate rotary brushes and water spray so that machine automatically picks up dust and trash from paved street and deposits it in dirt trap at rear of machine.",
        "clazz": "2",
        "$$hashKey": "object:4199"
    },
    {
        "nameEng": "Salvage person",
        "code": "SALV",
        "gender": "All",
        "nameInd": "Petugas penyelamat",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyelamatkan",
        "descriptionEng": "someoen who rescues",
        "clazz": "3",
        "$$hashKey": "object:4481"
    },
    {
        "nameEng": "Scrap dealer  / Scrap cutter  / Scrap breaker  / Scrap baler",
        "code": "SCRP",
        "gender": "All",
        "nameInd": "Penjual rongsokan / Pemotong rongsokan / Pemecah rongsokan / Pengepak rongsokan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual barang rongsokan",
        "descriptionEng": "someone who delals for crap",
        "clazz": "3",
        "$$hashKey": "object:4337"
    },
    {
        "nameEng": "Sewage works attendant",
        "code": "SWGA",
        "gender": "All",
        "nameInd": "Pengawas pekerja saluran pembuangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di saluran pembuangan",
        "descriptionEng": "someone who helps in sewage",
        "clazz": "3",
        "$$hashKey": "object:4159"
    },
    {
        "nameEng": "Sewage Plant Operator",
        "code": "SEPO",
        "gender": "All",
        "nameInd": "Pekerja pabrik Limbah",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja pada pabrik pembuangan limbah.",
        "descriptionEng": "A person who works in the waste disposal plant.",
        "clazz": "3",
        "$$hashKey": "object:3879"
    },
    {
        "nameEng": "Sorter",
        "code": "SORT",
        "gender": "All",
        "nameInd": "Pensortir",
        "minAge": "0",
        "descriptionInd": "Seseorang yang dipekerjakan untuk mengurutkan.",
        "descriptionEng": "�A person employed to sort.",
        "clazz": "3",
        "$$hashKey": "object:4342"
    },
    {
        "nameEng": "Counter staff",
        "code": "CREW",
        "gender": "All",
        "nameInd": "Penjaga Counter Loket",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab pada suatu loket.",
        "descriptionEng": "Counter crew is the person in charge at the counter.",
        "clazz": "2",
        "$$hashKey": "object:4296"
    },
    {
        "nameEng": "Dry cleaning worker / Dry cleaning machine operator",
        "code": "DRYC",
        "gender": "All",
        "nameInd": "Petugas Binatu",
        "minAge": "0",
        "descriptionInd": "Pencuci kering adalah proses membersihkan pakaian, bahan-bahan tekstil menggunakan bahan kimia cair selain air.",
        "descriptionEng": "Dry cleaning is any cleaning process for clothing and textiles using a chemical solvent other than water. Dry Cleaner executes it.",
        "clazz": "2",
        "$$hashKey": "object:4418"
    },
    {
        "nameEng": "Laundry assistant",
        "code": "LAUN",
        "gender": "All",
        "nameInd": "Petugas Laundry Pakaian",
        "minAge": "0",
        "descriptionInd": "Yaitu orang yang bertugas melakukan proses laundry dan distribusi produk setelah proses laundry.",
        "descriptionEng": "Prepares laundry for processing and distributes laundry, performing any combination of following duties: Opens bundles of soiled laundry. Places bundles onto conveyor belt or drops down chute for distribution to marking and classification sections.",
        "clazz": "2",
        "$$hashKey": "object:4443"
    },
    {
        "nameEng": "Linen room attendant",
        "code": "LRAT",
        "gender": "All",
        "nameInd": "Petugas Ruang Linen",
        "minAge": "0",
        "descriptionInd": "Menyimpan, mencatat dan mendistribusikan sprei dan seragam perusahaan seperti hotel, rumah sakit, dan klinik dan juga memeriksa item yg dicuci untuk terjaga kebersihannya.",
        "descriptionEng": "Stores, inventories, and issues or distributes bed and table linen and uniforms in establishments, such as hotels, hospitals, and clinics. Also examines laundered items to ensure cleanliness and serviceability.",
        "clazz": "2",
        "$$hashKey": "object:4491"
    },
    {
        "nameEng": "Grocer",
        "code": "GROC",
        "gender": "All",
        "nameInd": "Penjual bahan pangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjual bahan pangan",
        "descriptionEng": "someone who selles grocery",
        "clazz": "2",
        "$$hashKey": "object:4328"
    },
    {
        "nameEng": "Fast food worker",
        "code": "FSFO",
        "gender": "All",
        "nameInd": "Pekerja makanan cepat saji",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di restoran cepat saji",
        "descriptionEng": "someone who works in fast food",
        "clazz": "2",
        "$$hashKey": "object:3876"
    },
    {
        "nameEng": "Loss prevention specialist",
        "code": "LOPS",
        "gender": "All",
        "nameInd": "Spesialis pencegahan kehilangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam pencegahan kehilangan",
        "descriptionEng": "someone who specializes in loss prevention",
        "clazz": "2",
        "$$hashKey": "object:4553"
    },
    {
        "nameEng": "Market porter",
        "code": "MAPO",
        "gender": "All",
        "nameInd": "Porter Pasar",
        "minAge": "0",
        "descriptionInd": "Orang yang dipekerjakan untuk mengangkat bagasi, parsel, persediaan, dan lain-lain terutama di stasiun kereta api atau hotel.",
        "descriptionEng": "A person employed to carry luggage, parcels, supplies, etc., esp at a railway station or hotel.",
        "clazz": "3",
        "$$hashKey": "object:4518"
    },
    {
        "nameEng": "Milk roundsman",
        "code": "MILK",
        "gender": "All",
        "nameInd": "Penjaja susu keliling",
        "minAge": "0",
        "descriptionInd": "seseorang yang membawa susu keliling",
        "descriptionEng": "A person who carries out a milk round.",
        "clazz": "3",
        "$$hashKey": "object:4327"
    },
    {
        "nameEng": "Off-licence manager",
        "code": "LICM",
        "gender": "All",
        "nameInd": "Manajer lisensi minuman keras",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola lisensi minuman keras",
        "descriptionEng": "someone who manages the off-licence",
        "clazz": "2",
        "$$hashKey": "object:3685"
    },
    {
        "nameEng": "Retail assistant",
        "code": "RETL",
        "gender": "All",
        "nameInd": "Asisten ritel",
        "minAge": "0",
        "descriptionInd": "seseorang yang membantu di ritel",
        "descriptionEng": "someone who assist in retail",
        "clazz": "2",
        "$$hashKey": "object:3437"
    },
    {
        "nameEng": "Sandwich artist",
        "code": "SNDW",
        "gender": "All",
        "nameInd": "Pelayan pelanggan",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyapa tamu",
        "descriptionEng": "someone who greets guests",
        "clazz": "2",
        "$$hashKey": "object:3935"
    },
    {
        "nameEng": "Supermarket worker",
        "code": "SUWK",
        "gender": "All",
        "nameInd": "Pekerja supermarket",
        "minAge": "0",
        "descriptionInd": "Orang yang mempunyai perusahaan, memiliki peran manajer.\\",
        "descriptionEng": "A person who owns something. They are expected to play the role of manager, market researcher, accountant, and even receptionist. is one person (perhaps the founder); several people (perhaps family members, business partners, even investors).",
        "clazz": "2",
        "$$hashKey": "object:3907"
    },
    {
        "nameEng": "Shopowner  / Shop assistant / Shop worker",
        "code": "SHOP",
        "gender": "All",
        "nameInd": "Pemilik Toko / Asisten toko / Pekerja toko",
        "minAge": "0",
        "descriptionInd": "Orang yang memiliki toko.",
        "descriptionEng": "A person who owns the shop.",
        "clazz": "2",
        "$$hashKey": "object:4069"
    },
    {
        "nameEng": "Shopkeeper",
        "code": "SHKP",
        "gender": "All",
        "nameInd": "Pelayan Toko",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja dan melayani pembeli di toko.",
        "descriptionEng": "A person who works and serve the customer at the shop.",
        "clazz": "2",
        "$$hashKey": "object:3937"
    },
    {
        "nameEng": "Shop porter",
        "code": "SHPP",
        "gender": "All",
        "nameInd": "Porter Tempat Berbelanja",
        "minAge": "0",
        "descriptionInd": "Orang yang dipekerjakan untuk mengangkat bagasi, parsel, persediaan, dan lain-lain terutama di stasiun kereta api atau hotel.",
        "descriptionEng": "A person employed to carry luggage, parcels, supplies, etc., esp at a railway station or hotel.",
        "clazz": "3",
        "$$hashKey": "object:4519"
    },
    {
        "nameEng": "Caretaker",
        "code": "CRTK",
        "gender": "All",
        "nameInd": "Perawat manula",
        "minAge": "0",
        "descriptionInd": "orang yang dipekerjakan untuk menjaga orang atau binatang.",
        "descriptionEng": "a person employed to look after people or animals.",
        "clazz": "2",
        "$$hashKey": "object:4392"
    },
    {
        "nameEng": "Building maintenance officer",
        "code": "BLMO",
        "gender": "All",
        "nameInd": "Petugas Pemeliharaan Gedung",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk pemeliharaan dan perbaikan gedung, dari mengganti lampu sampai memperbaiki saluran yang bocor, memasang dinding gipsum, memperbaiki ventilator plafon.",
        "descriptionEng": "A maintenance officer is responsible for the upkeep and repairs in a building. Maintenance officers do everything from changing light bulbs to fixing leaky sinks to putting up drywall and replacing ceiling fans.",
        "clazz": "2",
        "$$hashKey": "object:4466"
    },
    {
        "nameEng": "Estate maintenance officer",
        "code": "ESTO",
        "gender": "All",
        "nameInd": "Petugas Pemeliharaan Perumahan",
        "minAge": "0",
        "descriptionInd": "Orang yang berada di jajaran tingkat atas dalam rumah tangga, bekerja langsung dengan pemilik untuk merencanakan dan melaksanakan manajemen pelayanan dan gedung.",
        "descriptionEng": "A person who is at the top level in the household. He or she works directly with the owners to plan and execute the overall management of property and service.",
        "clazz": "2",
        "$$hashKey": "object:4467"
    },
    {
        "nameEng": "Chimney sweep",
        "code": "CHSW",
        "gender": "All",
        "nameInd": "Tukang bersih cerobong asap",
        "minAge": "0",
        "descriptionInd": "seseorang yang membersihkan cerobong",
        "descriptionEng": "someone who sweeps chimney",
        "clazz": "3",
        "$$hashKey": "object:4660"
    },
    {
        "nameEng": "Cleaner",
        "code": "CLNR",
        "gender": "All",
        "nameInd": "Petugas Kebersihan",
        "minAge": "0",
        "descriptionInd": "Pekerja yang bertugas membersihkan/menjaga kebersihan suatu area/tempat",
        "descriptionEng": "A person employed to clean something in particular.",
        "clazz": "2",
        "$$hashKey": "object:4435"
    },
    {
        "nameEng": "Chambermaid",
        "code": "CBMD",
        "gender": "All",
        "nameInd": "Pembantu/Pelayan Rumah Tangga",
        "minAge": "0",
        "descriptionInd": "Pekerja yang bertugas membersihkan kamar tidur dan kamar mandi, terutama di hotel.",
        "descriptionEng": "A maid who cleans bedrooms and bathrooms, esp. in a hotel.",
        "clazz": "2",
        "$$hashKey": "object:3987"
    },
    {
        "nameEng": "Roofer",
        "code": "ROOF",
        "gender": "All",
        "nameInd": "Tukang atap",
        "minAge": "0",
        "descriptionInd": "Pekerja konstruksi yang ahli dalam kontruksi atap.",
        "descriptionEng": "A construction worker who specializes in roof construction.",
        "clazz": "3",
        "$$hashKey": "object:4654"
    },
    {
        "nameEng": "Scaffolder",
        "code": "SCAF",
        "gender": "All",
        "nameInd": "Pembuat perancah",
        "minAge": "0",
        "descriptionInd": "orang yang mendirikan dan membongkar perancah.",
        "descriptionEng": "a person who erects and dismantles scaffolding.",
        "clazz": "3",
        "$$hashKey": "object:4029"
    },
    {
        "nameEng": "Cleaning supervisor",
        "code": "CLEA",
        "gender": "All",
        "nameInd": "Supervisor Petugas Kebersihan",
        "minAge": "0",
        "descriptionInd": "Mengawasi dan mengkoordinasikan kegiatan pekerja yang terlibat dalam kebersihan mesin, peralatan, dan area dalam industri minuman atau makanan.",
        "descriptionEng": "Supervises and coordinates activities of workers engaged in cleaning machines, equipment, and work areas in beverage or food industries.",
        "clazz": "2",
        "$$hashKey": "object:4595"
    },
    {
        "nameEng": "Fence erector",
        "code": "FEER",
        "gender": "All",
        "nameInd": "Tukang pagar",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat pagar",
        "descriptionEng": "someone who erects fence",
        "clazz": "3",
        "$$hashKey": "object:4686"
    },
    {
        "nameEng": "Gamekeeper",
        "code": "GAMK",
        "gender": "All",
        "nameInd": "Penjaga permainan",
        "minAge": "0",
        "descriptionInd": "orang yang dipekerjakan untuk membiakkan dan melindungi permainan, biasanya untuk sebuah perkebunan besar.",
        "descriptionEng": "a person employed to breed and protect game, typically for a large estate.",
        "clazz": "3",
        "$$hashKey": "object:4315"
    },
    {
        "nameEng": "Greenkeeper",
        "code": "GRNK",
        "gender": "All",
        "nameInd": "Pemelihara lapangan golf",
        "minAge": "0",
        "descriptionInd": "bertanggung jawab untuk pemeliharaan, perawatan dan penampilan keseluruhan lapangan golf. Ini adalah tugas mereka untuk mempertahankan permukaan bermain yang baik dan memastikan kursus ini menawarkan tantangan yang konsisten dan pengalaman yang menyenangkan bagi para pemain golf.",
        "descriptionEng": "is responsible for the maintenance, care and overall appearance of a golf course. It is their�job�to maintain a good playing surface and ensure the course offers a consistent challenge and an enjoyable experience to golfers.",
        "clazz": "3",
        "$$hashKey": "object:4052"
    },
    {
        "nameEng": "Janitor",
        "code": "JANI",
        "gender": "All",
        "nameInd": "Pembersih kantor",
        "minAge": "0",
        "descriptionInd": "orang yang dipekerjakan sebagai penjaga bangunan; seorang penjaga.",
        "descriptionEng": "a person employed as a caretaker of a building; a custodian.",
        "clazz": "2",
        "$$hashKey": "object:4001"
    },
    {
        "nameEng": "Washroom attendant",
        "code": "WASH",
        "gender": "All",
        "nameInd": "Penjaga Kamar Kecil",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas untuk membersihkan dan menjaga kebersihan kamar kecil.",
        "descriptionEng": "A person whose job to maintain hygiene and clean the washroom.",
        "clazz": "2",
        "$$hashKey": "object:4304"
    },
    {
        "nameEng": "Maintenance fitter",
        "code": "MAIN",
        "gender": "All",
        "nameInd": "Pemasang perawatan",
        "minAge": "0",
        "descriptionInd": "Meliputi pemeliharaan pada mesin dan peralatan, bertanggung jawab terhadap kerusakan pada mesin, instalasi mesin.",
        "descriptionEng": "Duties to include; preventative maintenance on machines and equipment; as well as responding to emergency machine break downs throughout theplant; involvement with new design, installation and movements of existingmachines.",
        "clazz": "3",
        "$$hashKey": "object:3973"
    },
    {
        "nameEng": "Maintenance manager",
        "code": "MAGR",
        "gender": "All",
        "nameInd": "Manajer perawatan",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola perawatan",
        "descriptionEng": "someone who manages maintenance",
        "clazz": "2",
        "$$hashKey": "object:3695"
    },
    {
        "nameEng": "Facilities specialist",
        "code": "FCSP",
        "gender": "All",
        "nameInd": "Spesialis Fasilitas",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk melaksanakan tugas operasional dari Departemen Fasilitas Manajemen. Membantu manajer fasilitas, memastikan bahwa semua fasilitas, milik dan pelayanan kantor bergunsi efektif dan efisien, mengatur jadwal pemeliharaan gedung, memproses permintaan dari cabang dan departemen untuk memastikan permintaan selesai tepat waktu. Melakukan berbagai tugas rutin harian, mengulas dan menyiapkan laporan dan korespondensi, berpartisipasi dalam proyek khusus departemen.",
        "descriptionEng": "The Facilities Specialist is responsible for performing operational support duties of the Facilities Management Department. Assists the Facilities Manager as directed; ensures that all facilities, properties and office service functions operate effectively and efficiently; maintains schedule of building maintenance; processes requests from branches and departments to ensure requests are completed in a timely fashion. Performs a variety of routine daily tasks; reviews and prepares reports and correspondence; participates in special department projects.",
        "clazz": "2",
        "$$hashKey": "object:4550"
    },
    {
        "nameEng": "Nurseryman",
        "code": "NUSY",
        "gender": "All",
        "nameInd": "Pemelihara tanaman",
        "minAge": "0",
        "descriptionInd": "seorang pekerja di atau pemilik pembibitan tanaman atau pohon.",
        "descriptionEng": "a worker in or owner of a plant or tree nursery.",
        "clazz": "3",
        "$$hashKey": "object:4053"
    },
    {
        "nameEng": "Park keeper / Park ranger",
        "code": "PARK",
        "gender": "All",
        "nameInd": "Penjaga taman / Petugas taman",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga taman",
        "descriptionEng": "someone who guards the park",
        "clazz": "3",
        "$$hashKey": "object:4322"
    },
    {
        "nameEng": "Parks superintendent",
        "code": "PARS",
        "gender": "All",
        "nameInd": "Pengawas taman",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi taman",
        "descriptionEng": "someone who suprvises the park",
        "clazz": "2",
        "$$hashKey": "object:4163"
    },
    {
        "nameEng": "Pest control operator",
        "code": "PESO",
        "gender": "All",
        "nameInd": "Operator kontrol hama",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan kontrol hama",
        "descriptionEng": "someoen who operates pest control",
        "clazz": "3",
        "$$hashKey": "object:3772"
    },
    {
        "nameEng": "Others Class 2",
        "code": "OTC2",
        "gender": "All",
        "nameInd": "Pekerja Lainnya Kelas 2",
        "minAge": "0",
        "descriptionInd": "Pekerja Lainnya Kelas 2",
        "descriptionEng": "Other jobs are 2nd class",
        "clazz": "2",
        "$$hashKey": "object:3873"
    },
    {
        "nameEng": "Pest control manager",
        "code": "PEST",
        "gender": "All",
        "nameInd": "Manajer Pengendalian Hama",
        "minAge": "0",
        "descriptionInd": "Manager pengawasan pembasmi hama bisa atau tidak bertugas di lapangan. Hanya pada saat tertentu saja mereka melakukannya. Mereka yang memberikan instruksi kepada pekerja pembasmi hama. Mereka melakukan inspeksi lapangan dan gedung serta mengidentifikasikan kerusakan yang terjadi. Lalu mereka mencatat dan membuat laporan serta pembelajaran. Manager pengawasan pembasmi hama juga mengevaluasi biaya yang dikeluarkan. Termasuk didalamnya peralatan, bahan kimia dan jasa pelayanan.",
        "descriptionEng": "A pest control manager may or may not accompany his workers in the field. On the occasion that they do, they are the ones that give instructions to the pest control workers. They inspect the grounds and premises and identify how grave the property�s damage is. They then write, record and study the reports for them. The pest control manager evaluates how much the cost will reach. This includes the materials, the chemicals and the service fee.",
        "clazz": "1",
        "$$hashKey": "object:3693"
    },
    {
        "nameEng": "Public lighting fitter-erector",
        "code": "PUBF",
        "gender": "All",
        "nameInd": "Pemasang lampu umum",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang lampu umum",
        "descriptionEng": "someone who erects and fits public lighting",
        "clazz": "3",
        "$$hashKey": "object:3962"
    },
    {
        "nameEng": "Radio and television repairer",
        "code": "RTEC",
        "gender": "All",
        "nameInd": "Teknisi radio dan televisi",
        "minAge": "0",
        "descriptionInd": "Menjaga pemrograman, seperti yang dipersyaratkan oleh manajemen stasiun dan komisi komunikasi federal, mengatur peralatan audio dalam kaitannya untuk mengatur volume dan kualitas suara selama siaran radio dan televisi, memonitor kekuatan pemantauan, kejelasan, dan kualitas sinyal yang masuk dan keluar, dan menyesuaikan peralatan sebagai diperlukan untuk mempertahankan kualitas siaran, mengamati monitor dan berkomunikasi dengan stasiun untuk menentukan audio dan video dan untuk memastikan program yang sedang ditayangkan.",
        "descriptionEng": "Maintain programming logs, as required by station management and the federal communication commision, control audio equipment in order to regulate the volume and sound quality during radio and relevision broadcasts, monitoring strength, clarity, and reliability of incoming and outgoing signals, and adjust equipment as necessary to maintain quality broadcasts, observe monitors and converse with station in order to determine audio and video levels and to ascertain that program are airing.",
        "clazz": "2",
        "$$hashKey": "object:4634"
    },
    {
        "nameEng": "Road sweeper (hand)",
        "code": "ROAS",
        "gender": "All",
        "nameInd": "Penyapu jalanan (tangan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menyapu jalanan",
        "descriptionEng": "someone who sweeps the road",
        "clazz": "3",
        "$$hashKey": "object:4356"
    },
    {
        "nameEng": "Rodent destroyer",
        "code": "RODE",
        "gender": "All",
        "nameInd": "Pembasmi hewan pengerat",
        "minAge": "0",
        "descriptionInd": "seseorang yang membasmi hewan pengerat",
        "descriptionEng": "someone who destroys rodent",
        "clazz": "3",
        "$$hashKey": "object:3988"
    },
    {
        "nameEng": "Valet",
        "code": "VALT",
        "gender": "All",
        "nameInd": "Valet",
        "minAge": "0",
        "descriptionInd": "petugas laki-laki pribadi laki-laki, bertanggung jawab atas pakaian dan penampilannya.",
        "descriptionEng": "a man's personal male attendant, responsible for his clothes and appearance.",
        "clazz": "2",
        "$$hashKey": "object:4707"
    },
    {
        "nameEng": "Head groundsman",
        "code": "HDGR",
        "gender": "All",
        "nameInd": "Kepala tukang kebun",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat lapangan olahraga, taman, atau pekarangan sekolah atau institusi lain.",
        "descriptionEng": "a person who maintains a sports ground, a park, or the grounds of a school or other institution.",
        "clazz": "2",
        "$$hashKey": "object:3617"
    },
    {
        "nameEng": "Curtain fitter / Curtain Installer",
        "code": "CINS",
        "gender": "All",
        "nameInd": "Instalatur Gorden/ Tirai",
        "minAge": "0",
        "descriptionInd": "Seseorang yang menyediakan semua elemen yang diperlukan untuk pemasangan gorden, batang atau trek, bahan-bahan, dan aksesoris yang dibutuhkan untuk suatu gorden. Pemasangan Gorden seringkali merupakan bagian dari sebuah perusahaan penyedia jasa pemasangan gordin ke rumah-rumah.",
        "descriptionEng": "The installer will supply all of the elements that are necessary for the installation such as the curtains themselves, the rods or tracks, the fixings, and any accessories that your curtains require. The installers are often part of a company that can also provide advice on which curtains to use in your home.",
        "clazz": "3",
        "$$hashKey": "object:3570"
    },
    {
        "nameEng": "Exhibition stand fitter",
        "code": "EXHI",
        "gender": "All",
        "nameInd": "Pemasang stan pameran",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang stan pameran",
        "descriptionEng": "someone who fits the exhibition stand",
        "clazz": "3",
        "$$hashKey": "object:3976"
    },
    {
        "nameEng": "Fitter-assembler (doors and windows)",
        "code": "DWFA",
        "gender": "All",
        "nameInd": "Perakit-pemasang (pintu dan jendela)",
        "minAge": "0",
        "descriptionInd": "seseorang yang merakit dan memasang",
        "descriptionEng": "someone who fits and assembles",
        "clazz": "3",
        "$$hashKey": "object:4380"
    },
    {
        "nameEng": "Furniture remover",
        "code": "FURE",
        "gender": "All",
        "nameInd": "Pengangkut furnitur",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengangkut furnitur",
        "descriptionEng": "someone who removes the furniture",
        "clazz": "3",
        "$$hashKey": "object:4144"
    },
    {
        "nameEng": "Locksmith",
        "code": "LCKS",
        "gender": "All",
        "nameInd": "Ahli kunci",
        "minAge": "0",
        "descriptionInd": "seseorang yang ahli dalam kunci",
        "descriptionEng": "someone who specializes in lock",
        "clazz": "3",
        "$$hashKey": "object:3358"
    },
    {
        "nameEng": "Office fitter",
        "code": "OFFI",
        "gender": "All",
        "nameInd": "Pemasang pemeliharaan kantor",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang kantor`",
        "descriptionEng": "someone who fits the office",
        "clazz": "3",
        "$$hashKey": "object:3970"
    },
    {
        "nameEng": "Maintenance painter / Painter (property maintenance)",
        "code": "MPAN",
        "gender": "All",
        "nameInd": "Tukang perawatan cat / Tukang cat (perawatan properti)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja untuk mengecat perawatan",
        "descriptionEng": "someone who works to paint the maintenance",
        "clazz": "3",
        "$$hashKey": "object:4690"
    },
    {
        "nameEng": "Property developer (no manual work)",
        "code": "PRDE",
        "gender": "All",
        "nameInd": "Pengembang properti (tanpa pekerjaan manual)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengembagkan proprti",
        "descriptionEng": "someone who develops a property",
        "clazz": "2",
        "$$hashKey": "object:4185"
    },
    {
        "nameEng": "Shop fitter",
        "code": "SHFI",
        "gender": "All",
        "nameInd": "Penginstalasi kebutuhan toko",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang kebutuhan toko",
        "descriptionEng": "someone who fits the shop",
        "clazz": "3",
        "$$hashKey": "object:4239"
    },
    {
        "nameEng": "Air compressor operator",
        "code": "AICO",
        "gender": "All",
        "nameInd": "Operator kompresor udara",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan kompresor udara",
        "descriptionEng": "someone who operates air compressor",
        "clazz": "3",
        "$$hashKey": "object:3771"
    },
    {
        "nameEng": "Borer",
        "code": "BORE",
        "gender": "All",
        "nameInd": "Tukang bor",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengebor",
        "descriptionEng": "someone who bores",
        "clazz": "3",
        "$$hashKey": "object:4662"
    },
    {
        "nameEng": "Conveyor operator (tunnelling)",
        "code": "TUNC",
        "gender": "All",
        "nameInd": "Operator konveyor (terowongan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikan di terowongan",
        "descriptionEng": "someone who oeprates in tunneling",
        "clazz": "3",
        "$$hashKey": "object:3780"
    },
    {
        "nameEng": "Driller (tunnelling)",
        "code": "TUND",
        "gender": "All",
        "nameInd": "Pengebor (terowongan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengebor di terowongan",
        "descriptionEng": "someone who drills in tunneling",
        "clazz": "3",
        "$$hashKey": "object:4169"
    },
    {
        "nameEng": "Power loader operator (tunnelling)",
        "code": "TUNP",
        "gender": "All",
        "nameInd": "Operator pemuat daya (terowongan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memuat daya",
        "descriptionEng": "someone who loads power",
        "clazz": "3",
        "$$hashKey": "object:3810"
    },
    {
        "nameEng": "Roof bolter",
        "code": "ROOB",
        "gender": "All",
        "nameInd": "Penginstal atap",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang atap",
        "descriptionEng": "someone who installs the roof",
        "clazz": "3",
        "$$hashKey": "object:4238"
    },
    {
        "nameEng": "Shotfirer (tunnelling)",
        "code": "SHFR",
        "gender": "All",
        "nameInd": "Peledak (pembangunan terowongan)",
        "minAge": "0",
        "descriptionInd": "sesoerang yang meledakkan",
        "descriptionEng": "someone who fires",
        "clazz": "3",
        "$$hashKey": "object:3939"
    },
    {
        "nameEng": "Timberman",
        "code": "TIMB",
        "gender": "All",
        "nameInd": "Tukang kayu",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memasang kayu di tambang;",
        "descriptionEng": "A person who installs timbers in a mine;�",
        "clazz": "3",
        "$$hashKey": "object:4674"
    },
    {
        "nameEng": "Winch operator (tunnelling)",
        "code": "WNCH",
        "gender": "All",
        "nameInd": "Operator derek (pembangunan terowongan)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengoperasikakn derek.",
        "descriptionEng": "someone who operates winch",
        "clazz": "3",
        "$$hashKey": "object:3764"
    },
    {
        "nameEng": "Farmer",
        "code": "FARM",
        "gender": "All",
        "nameInd": "Petani",
        "minAge": "0",
        "descriptionInd": "Petani adalah orang yang menjalankan pertanian,memelihara hewan untuk bahan dasar makanan atau material. Istilah ini biasa digunakan untuk orang yang beberapa pekerjaan,menanam sayuran, buah-buahan,bunga anggrek,dll. Petani dapat memiliki ladangnya atau dapat juga bekerja sebagai buruh. Tetapi biasanya petani adalah pemilik, sedangkan pekerjanya disebut sebagai buruh tani.",
        "descriptionEng": "A farmer (also called an agriculturer) is a person engaged in agriculture, raising living organisms for food or raw materials. The term usually applies to people who do some combination of raising field crops, orchards, vineyards, poultry, or other livestock. A farmer might own the farmed land or might work as a labourer on land owned by others, but in advanced economies, a farmer is usually a farm owner, while employees of the farm are farm workers, farmhands, etc.",
        "clazz": "3",
        "$$hashKey": "object:4404"
    },
    {
        "nameEng": "Animal Trainer",
        "code": "ANTR",
        "gender": "All",
        "nameInd": "Pelatih hewan",
        "minAge": "0",
        "descriptionInd": "seseorang yang melatih binatang",
        "descriptionEng": "Someone who trains the animal",
        "clazz": "3",
        "$$hashKey": "object:3922"
    },
    {
        "nameEng": "Hairdresser",
        "code": "HAIR",
        "gender": "All",
        "nameInd": "Penata rambut",
        "minAge": "0",
        "descriptionInd": "Penata rambut adalah seorang profesional yang berlisensi untuk menata rambut, tukang cukur atau penata kecantikan seorang.",
        "descriptionEng": "Hairdresser is a term referring to anyone whose occupation is to cut or style hair in order to change or maintain a person's image. This is achieved using a combination of hair coloring, haircutting, and hair texturing techniques. Most hairdressers are professionally licensed as either a hairdresser, a barber or a cosmetologist.",
        "clazz": "2",
        "$$hashKey": "object:4108"
    },
    {
        "nameEng": "Call centre worker / Outbound Officer",
        "code": "OUTB",
        "gender": "All",
        "nameInd": "Pekerja pusat panggilan / Kredit Analis",
        "minAge": "0",
        "descriptionInd": "Bertanggung jawab untuk memberikan pelayanan yang memuaskan kepada pelanggan internal dan eksternal, untuk mengidentifikasi kebutuhan keuangan setiap pelanggan dan merekomendasikan solusi yang tepat. Selain itu juga bertanggung jawab untuk memproses aplikasi kredit pelanggan yang diterima melalui kontak dari luar. Menyetujui/menolak pinjaman.",
        "descriptionEng": "Responsible for delivering outstanding service to both internal and external customers. To identify the financial needs of each customer andrecommend an appropriate solution. In addition the position is responsible to process customers� loan applications received through outbound contact. Approve/decline loans.",
        "clazz": "2",
        "$$hashKey": "object:3901"
    },
    {
        "nameEng": "Demolition worker",
        "code": "DEMW",
        "gender": "All",
        "nameInd": "Pekerja pembongkaran",
        "minAge": "0",
        "descriptionInd": "menghancurkan, membongkar dan menghapus struktur bangunan dan bahan termasuk batu bata, kayu, beton dan logam. Tugas dan alat yang digunakan. memasang layar, dustsheets, pagar sementara dan barikade keselamatan di sekitar lokasi dan area pembongkaran; menyegel saluran pembuangan sesuai kebutuhan;",
        "descriptionEng": "demolish, dismantle and remove building structures and materials including brick, timber, concrete and metal. Tasks and tools used. erecting screens, dustsheets, temporary fencing and safety barricades around sites and areas of demolition; sealing drains as required;",
        "clazz": "3",
        "$$hashKey": "object:3882"
    },
    {
        "nameEng": "Painter",
        "code": "PAIX",
        "gender": "All",
        "nameInd": "Tukang cat",
        "minAge": "0",
        "descriptionInd": "Melakukan pengecatan pada dinding, peralatan, bangunan, jembatan, dan permukaan lainnya, dengan menggunakan kuas, rol, dan semprotan. Menghapus cat lama untuk mempersiapkan permukaan sebelumdilakukan pengecatan. Mencampur warna atau minyak untuk mendapatkan warna yang diinginkan atau konsisten. Beberapa tukang cat mengecat jembatan, eksterior gedung-gedung tinggi, dan bekerja di ketinggian. Bekerja sebagai seorang tukang cat banyak melakukan aktivitas membungkuk dan mengangkat, yang dapat mengakibatkan cedera.",
        "descriptionEng": "Paint walls, equipment, buildings, bridges, and other structural surfaces, using brushes, rollers, and spray guns. May remove old paint to prepare surface prior to painting. May mix colors or oils to obtain desired color or consistency. Some painters paint bridges, the exteriors of tall buildings, and other structures that require working from great heights. Working as a painter requires a lot of bending and lifting, which can result in injuries.",
        "clazz": "3",
        "$$hashKey": "object:4663"
    },
    {
        "nameEng": "Delivery driver / Deliveryman (Driving) / Package Delivery",
        "code": "DELI",
        "gender": "All",
        "nameInd": "Pengirim barang",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas mengangkut barang dari suatu sumber ke tujuan yang telah ditentukan.",
        "descriptionEng": "Delivery man is someone whose job is transporting goods from a source location to a predefined destination.",
        "clazz": "3",
        "$$hashKey": "object:4240"
    },
    {
        "nameEng": "Childminder",
        "code": "CHIM",
        "gender": "All",
        "nameInd": "Penjaga anak",
        "minAge": "0",
        "descriptionInd": "seseorang yang memberikan pengasuhan anak untuk anak-anak di rumah pengasuhan sendiri selama lebih dari dua jam sehari",
        "descriptionEng": "somebody who provides childcare for children in the childminder own home for more than two hours a day",
        "clazz": "2",
        "$$hashKey": "object:4292"
    },
    {
        "nameEng": "Zoologist",
        "code": "ZOOL",
        "gender": "All",
        "nameInd": "Ahli zoologi",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memiliki pengetahuan tentang hewan dan kehidupan hewani, termasuk pengetahuan tentang struktur, fisiologi, perkembangan dan klasifikasi hewan-hewan.",
        "descriptionEng": "A person whose has knowledge  about animals and animal life, including the study of the structure, physiology, development, and classification of animals.",
        "clazz": "2",
        "$$hashKey": "object:3385"
    },
    {
        "nameEng": "Haulier",
        "code": "HAUL",
        "gender": "All",
        "nameInd": "Pengangkut",
        "minAge": "0",
        "descriptionInd": "bisnis atau orang yang terlibat dalam bisnis yang mengangkut barang melalui jalan darat.",
        "descriptionEng": "a business or a person involved in a business that transports goods by road.",
        "clazz": "3",
        "$$hashKey": "object:4143"
    },
    {
        "nameEng": "Electrical engineer",
        "code": "ELEN",
        "gender": "All",
        "nameInd": "Insinyur listrik",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan disiplin teknik profesional yang umumnya berhubungan dengan studi dan penerapan listrik, elektronik, dan elektromagnetisme.",
        "descriptionEng": "someone who does a professional engineering discipline that generally deals with the study and application of electricity, electronics, and electromagnetism.",
        "clazz": "3",
        "$$hashKey": "object:3541"
    },
    {
        "nameEng": "Electrical foreman",
        "code": "ELCF",
        "gender": "All",
        "nameInd": "Mandor listrik",
        "minAge": "0",
        "descriptionInd": "seorang supervisor, sering dalam perdagangan atau industri manual, dalam hal ini listrik",
        "descriptionEng": "a supervisor, often in a manual trade or industry, in this case electrical",
        "clazz": "3",
        "$$hashKey": "object:3716"
    },
    {
        "nameEng": "Electrical technician",
        "code": "ELCT",
        "gender": "All",
        "nameInd": "Teknisi listrik",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga hal teknis perihal listrik",
        "descriptionEng": "a person who looks after technical stuff regarding electrical",
        "clazz": "3",
        "$$hashKey": "object:4612"
    },
    {
        "nameEng": "ONG flame cutter",
        "code": "ONGP",
        "gender": "All",
        "nameInd": "Petugas las karbit (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "seseorang yang memotong api",
        "descriptionEng": "someone who cuts flame",
        "clazz": "3",
        "$$hashKey": "object:4442"
    },
    {
        "nameEng": "Gas supply foreman",
        "code": "GASF",
        "gender": "All",
        "nameInd": "Mandor persediaan gas",
        "minAge": "0",
        "descriptionInd": "seorang supervisor, sering dalam perdagangan atau industri manual, dalam hal ini penyediaan gas",
        "descriptionEng": "a supervisor, often in a manual trade or industry, in this case gas supply",
        "clazz": "3",
        "$$hashKey": "object:3719"
    },
    {
        "nameEng": "Entertainments officer (Merchant Marine)",
        "code": "ENOF",
        "gender": "All",
        "nameInd": "Staf hiburan (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di dunia hiburan",
        "descriptionEng": "someone who works in an entertainment",
        "clazz": "3",
        "$$hashKey": "object:4557"
    },
    {
        "nameEng": "Purser (Merchant Marine)",
        "code": "PURS",
        "gender": "All",
        "nameInd": "Kepala keuangan (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "seorang perwira di kapal yang menyimpan rekening, terutama kepala pelayan di kapal penumpang.",
        "descriptionEng": "an officer on a ship who keeps the accounts, especially the head steward on a passenger vessel.",
        "clazz": "3",
        "$$hashKey": "object:3603"
    },
    {
        "nameEng": "Quartermaster (Merchant Marine)",
        "code": "QUAM",
        "gender": "All",
        "nameInd": "Jurumudi (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "seorang perwira militer yang bertanggung jawab untuk menyediakan tempat, jatah, pakaian, dan perlengkapan lainnya.",
        "descriptionEng": "a military officer responsible for providing quarters, rations, clothing, and other supplies.",
        "clazz": "3",
        "$$hashKey": "object:3590"
    },
    {
        "nameEng": "Building repairman",
        "code": "BRMM",
        "gender": "All",
        "nameInd": "Petugas Reparasi Gedung",
        "minAge": "0",
        "descriptionInd": "Orang yang terlibat dalam perbaikan gedung, dapat berupa perbaikan pipa, pengelasan, perbaikan lantai, dll.",
        "descriptionEng": "Person involved in repairing buildings-may involve pipe fitting, welding, installing repair to floors etc.",
        "clazz": "3",
        "$$hashKey": "object:4486"
    },
    {
        "nameEng": "Others Class 3",
        "code": "OTC3",
        "gender": "All",
        "nameInd": "Pekerja Lainnya Kelas 3",
        "minAge": "0",
        "descriptionInd": "Pekerja Lainnya Kelas 3",
        "descriptionEng": "Other jobs are 3rd class",
        "clazz": "3",
        "$$hashKey": "object:3874"
    },
    {
        "nameEng": "Nuclear engineering technician",
        "code": "NUEN",
        "gender": "All",
        "nameInd": "Teknisi rekayasa nuklir",
        "minAge": "0",
        "descriptionInd": "1) Melakukan penelitian masalah sistem energi nuklir, desain dan mengembangkan peralatan nuklir, dan monitor pengujian, pengoperasian, dan pemeliharaan reaktor nuklir: merencanakan dan melakukan penelitian nuklir untuk menemukan fakta-fakta atau untuk menguji, membuktikan, atau memodifikasi teori nuklir dikenal tentang rilis, kontrol, dan pemanfaatan energi nuklir.2) Mengevaluasi temuan untuk mengembangkan konsep baru analisis termonuklir dan penggunaan baru dari proses radioaktif.3) Merencanakan, mendesain, dan mengembangkan peralatan nuklir seperti inti reaktor, perisai radiasi, dan instrumentasi yang terkait dan mekanisme kontrol.4) Studi siklus bahan bakar nuklir untuk menentukan penggunaan yang paling ekonomis bahan nuklir dan sarana paling aman untuk pembuangan limbah dari suatu produk.",
        "descriptionEng": "1) Conducts research into problems of nuclear energy systems; designs and develops nuclear equipment; and monitors testing, operation, and maintenance of nuclear reactors: Plans and conducts nuclear research to discover facts or to test, prove, or modify known nuclear theories concerning release, control, and utilization of nuclear energy. 2) Evaluates findings to develop new concepts of thermonuclear analysis and new uses of radioactive processes. 3) Plans, designs, and develops nuclear equipment such as reactor cores, radiation shielding, and associated instrumentation and control mechanisms. 4) Studies nuclear fuel cycle to define most economical uses of nuclear material and safest means of waste products disposal.",
        "clazz": "3",
        "$$hashKey": "object:4635"
    },
    {
        "nameEng": "Water supply Foreman",
        "code": "WASF",
        "gender": "All",
        "nameInd": "Mandor persediaan air",
        "minAge": "0",
        "descriptionInd": "seorang supervisor, sering dalam perdagangan atau industri manual, dalam hal ini penyediaan air",
        "descriptionEng": "a supervisor, often in a manual trade or industry, in this case water supply",
        "clazz": "2",
        "$$hashKey": "object:3718"
    },
    {
        "nameEng": "Acrobat",
        "code": "ACRB",
        "gender": "All",
        "nameInd": "Akrobat",
        "minAge": "0",
        "descriptionInd": "seorang akrobat yang melakukan akrobat dalam akrobat sirkus - seorang atlet yang melakukan tindakan yang membutuhkan keterampilan dan kelincahan dan koordinasi.",
        "descriptionEng": "an acrobat who performs acrobatic feats in a circus acrobat - an athlete who performs acts requiring skill and agility and coordination.",
        "clazz": "3",
        "$$hashKey": "object:3386"
    },
    {
        "nameEng": "Foreign exchange broker",
        "code": "FOEB",
        "gender": "All",
        "nameInd": "Broker Valuta Asing",
        "minAge": "0",
        "descriptionInd": "Penyelia penukaran uang asing adalah orang yang menawarkan penukaran uang asing dan pembayaran international.",
        "descriptionEng": "Foreign exchange broker is a broker that offers currency exchange and international payments.",
        "clazz": "2",
        "$$hashKey": "object:3452"
    },
    {
        "nameEng": "Stockbroker",
        "code": "STKB",
        "gender": "All",
        "nameInd": "Pialang Saham",
        "minAge": "0",
        "descriptionInd": "Adalah seorang ahli yang berhubungan dengan perusahaan pialang atau broker dealer, yang membeli dan menjual saham dan surat berharga lainnya bagi nasabah ritel maupun institusi melalui bursa saham atau konter dengan imbalan fee atau komisi.",
        "descriptionEng": "A stockbroker is a regulated professional individual, usually associated with a brokerage firm or broker-dealer, who buys and sells shares and other securities for both retail and institutional clients, through a stock exchange or over the counter, in return for a fee or commission.",
        "clazz": "2",
        "$$hashKey": "object:4507"
    },
    {
        "nameEng": "Debt collector",
        "code": "BILL",
        "gender": "All",
        "nameInd": "Penagih hutang",
        "minAge": "0",
        "descriptionInd": "Bagian dari layanan pelanggan di perusahaan kartu kredit dan perusahaan peminjaman lainnya untuk mengembalikan hutang yang belum dibayar.",
        "descriptionEng": "is a specific type of customer-service position that involves working for credit card companies and other debt companies to attempt to recover unpaid debts.",
        "clazz": "3",
        "$$hashKey": "object:4094"
    },
    {
        "nameEng": "Fisherman",
        "code": "FISH",
        "gender": "All",
        "nameInd": "Nelayan",
        "minAge": "0",
        "descriptionInd": "Nelayan adalah orang yang menangkap ikan dan binatang lainnya dari dalam air.",
        "descriptionEng": "A fisherman or fisher is someone who captures fish and other animals from a body of water.",
        "clazz": "3",
        "$$hashKey": "object:3745"
    },
    {
        "nameEng": "Chef Hotel and restaurant chef",
        "code": "HOLC",
        "gender": "All",
        "nameInd": "Koki/Koki hotel & restoran",
        "minAge": "0",
        "descriptionInd": "Koki adalah profesional yang bertugas membuat masakan untuk tamu di Hotel/Restoran.",
        "descriptionEng": "A Hotel and restaurant chef is a person who cooks professionally for other people at hotel and restaurant.",
        "clazz": "3",
        "$$hashKey": "object:3622"
    },
    {
        "nameEng": "Commis Cook",
        "code": "COMM",
        "gender": "All",
        "nameInd": "Koki Masak",
        "minAge": "0",
        "descriptionInd": "Adalah profesional yang memasak untuk orang lain,secara tradisional mengacu pada koki profesional yang sangat terampil/mahir dalam aspek persiapan makanan.",
        "descriptionEng": "A chef is a person who cooks profesionally for other people.Tradionally it refers to a highly skilled professional cook who is proficient in all aspects of food preparation.",
        "clazz": "3",
        "$$hashKey": "object:3620"
    },
    {
        "nameEng": "Funeral Undertaker",
        "code": "UNDT",
        "gender": "All",
        "nameInd": "Pengurus Pemakaman",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas dalam pengaturan upacara pemakaman atau kremasi, maupun mengurus pemakaman.",
        "descriptionEng": "a person whose profession is the preparation of the dead for burial or cremation and the management of funerals; funeral director.",
        "clazz": "2",
        "$$hashKey": "object:4276"
    },
    {
        "nameEng": "First aider",
        "code": "FIAD",
        "gender": "All",
        "nameInd": "Penolong pertama",
        "minAge": "0",
        "descriptionInd": "seseorang yang menilai situasi, melindungi diri Anda dari infeksi, kenyamanan, meyakinkan dan menilai korban.",
        "descriptionEng": "someone who assesses the situation, protect yourself from infection, comfort, reassure and assess the casualty.",
        "clazz": "2",
        "$$hashKey": "object:4340"
    },
    {
        "nameEng": "Nurse",
        "code": "NURS",
        "gender": "All",
        "nameInd": "Perawat",
        "minAge": "0",
        "descriptionInd": "Menilai masalah kesehatan dan kebutuhan pasien, mengembangkan dan mengimplementasikan rencana asuhan keperawatan, dan mengelola rekam medis.",
        "descriptionEng": "Assess patient health problems and needs, develop and implement nursing care plans, and maintain medical records.",
        "clazz": "2",
        "$$hashKey": "object:4389"
    },
    {
        "nameEng": "Plumber",
        "code": "PLUM",
        "gender": "All",
        "nameInd": "Tukang ledeng",
        "minAge": "0",
        "descriptionInd": "Merakit, memasang dan memperbaiki pipa , melakukan pemasangan dan memperlengkapi pemanas, air dan serta sistem drainase sesuai dengan spesifikasi dan kode pipa.",
        "descriptionEng": "Is assemble, install, and repair pipes, fittings, and fixtures of heating, water, and drainage systems, according to specifications and plumbing codes.",
        "clazz": "3",
        "$$hashKey": "object:4683"
    },
    {
        "nameEng": "Window cleaner",
        "code": "WICL",
        "gender": "All",
        "nameInd": "Pembersih jendela",
        "minAge": "0",
        "descriptionInd": "seseorang yang membersihkan jendela",
        "descriptionEng": "someone who cleans window",
        "clazz": "3",
        "$$hashKey": "object:4000"
    },
    {
        "nameEng": "Boatswain",
        "code": "BOSW",
        "gender": "All",
        "nameInd": "Perwira kapal",
        "minAge": "0",
        "descriptionInd": "petugas kapal yang bertanggung jawab atas peralatan dan kru.",
        "descriptionEng": "a ship's officer in charge of equipment and the crew.",
        "clazz": "3",
        "$$hashKey": "object:4400"
    },
    {
        "nameEng": "Captain",
        "code": "CAPT",
        "gender": "All",
        "nameInd": "Kapten",
        "minAge": "0",
        "descriptionInd": "pelaut berlisensi bermutu tinggi dalam komando tertinggi kapal dagang.",
        "descriptionEng": "a high-grade licensed mariner in ultimate command of the merchant vessel.�",
        "clazz": "3",
        "$$hashKey": "object:3591"
    },
    {
        "nameEng": "Catering Staff (Merchant marine)",
        "code": "CATS",
        "gender": "All",
        "nameInd": "Staf katering (kapal niaga)",
        "minAge": "0",
        "descriptionInd": "Staff who prepares food and drinks for all ship crew/customers",
        "descriptionEng": "Staff who prepares food and drinks for all ship crew/customers",
        "clazz": "3",
        "$$hashKey": "object:4558"
    },
    {
        "nameEng": "Chef (Merchant Marine)",
        "code": "CHEF",
        "gender": "All",
        "nameInd": "Koki Masak (Kapal Laut)",
        "minAge": "0",
        "descriptionInd": "Seorang juru masak profesional,terutama kepala juru masak di sebuah dapur dengan staf yang cukup besar.",
        "descriptionEng": "A professional cook, especially the chief cook of a large kitchen staff.",
        "clazz": "3",
        "$$hashKey": "object:3621"
    },
    {
        "nameEng": "Cook (Merchant Marine)",
        "code": "COOK",
        "gender": "All",
        "nameInd": "Koki di Kapal",
        "minAge": "0",
        "descriptionInd": "Koki kapal ialah seseorang yang bertugas menyiapkan dan memasak makanan di dalam kapal.",
        "descriptionEng": "Cook (merchant marine) is someone whose job is to prepare and cook of meals in the ship",
        "clazz": "3",
        "$$hashKey": "object:3619"
    },
    {
        "nameEng": "Engineer (Merchant marine)",
        "code": "EMHM",
        "gender": "All",
        "nameInd": "Insinyur (kapal niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang merancang dan membangun kapal niaga",
        "descriptionEng": "someone who designs and builds merchant marine",
        "clazz": "3",
        "$$hashKey": "object:3527"
    },
    {
        "nameEng": "Engine-room worker (Merchant Marine)",
        "code": "ENRW",
        "gender": "All",
        "nameInd": "Pekerja ruang mesin (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di ruang mesin",
        "descriptionEng": "someone who works in an engine-room",
        "clazz": "3",
        "$$hashKey": "object:3902"
    },
    {
        "nameEng": "Seaman (Merchant Marine)",
        "code": "SEMA",
        "gender": "All",
        "nameInd": "Pelaut (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "peringkat Angkatan Laut dari departemen dek kapal dagang. Posisi ini adalah magang untuk menjadi pelaut yang bisa diandalkan, dan sudah ada selama berabad-abad. Di zaman modern, OS diperlukan untuk bekerja di kapal untuk jumlah waktu tertentu, mendapatkan apa yang disebut sebagai \"waktu laut\".",
        "descriptionEng": "a  Naval rating of the deck department of a merchant ship. The position is an apprenticeship to become an Able seaman, and has been for centuries. In modern times, an OS is required to work on a ship for a specific amount of time, gaining what is referred to as \"sea time\".",
        "clazz": "3",
        "$$hashKey": "object:3927"
    },
    {
        "nameEng": "Steerer (Merchant Marine)",
        "code": "STEE",
        "gender": "All",
        "nameInd": "Juru kemudi (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengarahkan kapal.",
        "descriptionEng": "a person who steers a vehicle or vessel.",
        "clazz": "3",
        "$$hashKey": "object:3584"
    },
    {
        "nameEng": "Steward (Merchant Marine)",
        "code": "STEW",
        "gender": "All",
        "nameInd": "Petugas (Kapal Niaga)",
        "minAge": "0",
        "descriptionInd": "seseorang yang menjaga penumpang di kapal, pesawat terbang, atau kereta api dan membawa mereka makan.",
        "descriptionEng": "a person who looks after the passengers on a ship, aircraft, or train and brings them meals.",
        "clazz": "3",
        "$$hashKey": "object:4410"
    },
    {
        "nameEng": "Metal foreman",
        "code": "METF",
        "gender": "All",
        "nameInd": "Mandor logam",
        "minAge": "0",
        "descriptionInd": "seorang supervisor, sering dalam perdagangan atau industri manual, dalam hal ini metal",
        "descriptionEng": "a supervisor, often in a manual trade or industry, in this case metal",
        "clazz": "3",
        "$$hashKey": "object:3717"
    },
    {
        "nameEng": "Sign writer",
        "code": "SIGW",
        "gender": "All",
        "nameInd": "Penulis tanda",
        "minAge": "0",
        "descriptionInd": "seseorang yang menulis tanda",
        "descriptionEng": "someone who writes sign",
        "clazz": "3",
        "$$hashKey": "object:4350"
    },
    {
        "nameEng": "Foreman",
        "code": "FRMN",
        "gender": "All",
        "nameInd": "Mandor",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengawasi",
        "descriptionEng": "someone who supervises",
        "clazz": "2",
        "$$hashKey": "object:3711"
    },
    {
        "nameEng": "Aerial erector",
        "code": "AERE",
        "gender": "All",
        "nameInd": "Pemasang antena",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang antena",
        "descriptionEng": "someone who erects aerial",
        "clazz": "3",
        "$$hashKey": "object:3958"
    },
    {
        "nameEng": "Lagger",
        "code": "LAGG",
        "gender": "All",
        "nameInd": "Tukang pipa",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di pipa",
        "descriptionEng": "someone who does work in pipes",
        "clazz": "3",
        "$$hashKey": "object:4695"
    },
    {
        "nameEng": "Tunneller",
        "code": "TUNN",
        "gender": "All",
        "nameInd": "Pembuat terowongan",
        "minAge": "0",
        "descriptionInd": "seseorang yang membuat terowongan",
        "descriptionEng": "someone who makes tunnel",
        "clazz": "3",
        "$$hashKey": "object:4044"
    },
    {
        "nameEng": "Actor / Actress",
        "code": "ACTR",
        "gender": "All",
        "nameInd": "Aktor / Aktris",
        "minAge": "0",
        "descriptionInd": "Orang yang memainkan suatu peran dalam drama atau komik dan bekerja di bidang film, televisi, teater atau radio.",
        "descriptionEng": "An actor (alternatively actress for a female; see terminology) is a person who acts in a dramatic or comic production and works in film, television, theatre, or radio in that capacity.",
        "clazz": "3",
        "$$hashKey": "object:3387"
    },
    {
        "nameEng": "Construction Insulator",
        "code": "CONI",
        "gender": "All",
        "nameInd": "Pemasang sekat konstruksi",
        "minAge": "0",
        "descriptionInd": "seseorang yang memasang sekat konstruksi",
        "descriptionEng": "someone who installs isolation of construction",
        "clazz": "3",
        "$$hashKey": "object:3975"
    },
    {
        "nameEng": "Surveyor",
        "code": "SURV",
        "gender": "All",
        "nameInd": "Pelaksana survey/Pemeriksa",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan survei/pemeriksaan",
        "descriptionEng": "someone who surveys",
        "clazz": "3",
        "$$hashKey": "object:3912"
    },
    {
        "nameEng": "Teacher general",
        "code": "TCHR",
        "gender": "All",
        "nameInd": "Guru umum",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengajarkan materi dan mata pelajaran untuk kepentingan pendidikan.",
        "descriptionEng": "A person who teaches material and subject for education purpose",
        "clazz": "1",
        "$$hashKey": "object:3521"
    },
    {
        "nameEng": "Lecturer",
        "code": "LCTR",
        "gender": "All",
        "nameInd": "Dosen",
        "minAge": "0",
        "descriptionInd": "Dosen yaitu orang yang bertugas memfasilitasi pembelajaran dan memberikan bimbingan kepada siswa dalam bidang khusus pada pendidikan tingkat tinggi. Para profesional bertanggung jawab dalam penyusunan dan penyajian kuliah, membuat dan mengawasi ujian, dan menandai kertas ujian.",
        "descriptionEng": "Are required to facilitate learning and provide guidance to students in a specialised field on a tertiary level of education. These professionals are responsible for preparing and presenting lectures, creating and supervising examinations, and marking examination papers. There are some cases where they need to help senior students in their independent study researches.",
        "clazz": "1",
        "$$hashKey": "object:3492"
    },
    {
        "nameEng": "Aerospace engineer",
        "code": "AERO",
        "gender": "All",
        "nameInd": "Insinyur/ Tekhnisi Kerdigantaraan (Luar Angkasa)",
        "minAge": "0",
        "descriptionInd": "Insinyur yang menerapkan prinsip-prinsip ilmiah dan teknologi untuk penelitian, merancang, mengembangkan, mempertahankan dan menguji kinerja pesawat sipil dan militer, rudal, sistem senjata, satelit dan kendaraan ruang angkasa.",
        "descriptionEng": "An aeronautical, or aerospace, engineer applies scientific and technological principles to research, design, develop, maintain and test the performance of civil and military aircraft, missiles, weapons systems, satellites and space vehicles.",
        "clazz": "2",
        "$$hashKey": "object:3558"
    },
    {
        "nameEng": "Airfreight Officer",
        "code": "ACOR",
        "gender": "All",
        "nameInd": "Petugas Pengiriman Udara",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab atas barang-barang yang dikirim melalui kargo, menjaga muatan kargo saat dimuat dan diturunkan.",
        "descriptionEng": "A person who is in charge of the goods that are delivered through freight carriers, responsible to look after all the cargo the loads & unloads of plane.",
        "clazz": "3",
        "$$hashKey": "object:4475"
    },
    {
        "nameEng": "Anaesthetist",
        "code": "ANAE",
        "gender": "All",
        "nameInd": "Dokter Anestesi",
        "minAge": "0",
        "descriptionInd": "Dokter yang mendalami bidang anestesi.",
        "descriptionEng": "A consultant Anaesthetist is a doctor who has undergone further medical training in the specialty of Anaesthesia.",
        "clazz": "2",
        "$$hashKey": "object:3485"
    },
    {
        "nameEng": "Anthropologist",
        "code": "ANTH",
        "gender": "All",
        "nameInd": "Antropolog",
        "minAge": "0",
        "descriptionInd": "Orang yang memiliki pengetahuan yang luas tentang antropologi dan menggunakan pengetahuan ini dalam pekerjaan, biasanya untuk memecahkan masalah antropologi.",
        "descriptionEng": "An anthropologist is a person with an extensive knowledge of anthropology who uses this knowledge in their work, typically to solve anthropological problems.",
        "clazz": "2",
        "$$hashKey": "object:3414"
    },
    {
        "nameEng": "Apprentice (general)",
        "code": "APPT",
        "gender": "All",
        "nameInd": "Magang Kerja/Pemagang",
        "minAge": "0",
        "descriptionInd": "Orang yang belajar dari pegawai yang terlatih, setuju untuk bekerja dalam jangka waktu tertentu dengan upah yang rendah.",
        "descriptionEng": "A person who is learning a trade from a skilled employer, having agreed to work for a fixed period at low wages.",
        "clazz": "2",
        "$$hashKey": "object:3663"
    },
    {
        "nameEng": "Assembly fitters",
        "code": "ASFT",
        "gender": "All",
        "nameInd": "Petugas Perakitan/Pemasangan",
        "minAge": "0",
        "descriptionInd": "Orang yang merakit bagian mesin, kebanyakan bekerja di pabrik.",
        "descriptionEng": "Person who fits & assembles various parts of a machine mostly working in various Production factories.",
        "clazz": "3",
        "$$hashKey": "object:4482"
    },
    {
        "nameEng": "Auto Dealer",
        "code": "AUDE",
        "gender": "All",
        "nameInd": "Dealer Mobil",
        "minAge": "0",
        "descriptionInd": "Orang yang terlibat dalam jual beli mobil.",
        "descriptionEng": "A person engaged in buying or selling the automobiles between the buyer & seller.",
        "clazz": "2",
        "$$hashKey": "object:3467"
    },
    {
        "nameEng": "Automobile Body Repairer",
        "code": "AUBR",
        "gender": "All",
        "nameInd": "Bengkel Mobil",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk memperbaiki kendaraan yang mengalami kerusakan karena kecelakaan atau kejadian alam.",
        "descriptionEng": "An individual with a job in auto body repair is responsible for repairing vehicles that have sustained damage due to automobile accidents or acts of nature.",
        "clazz": "3",
        "$$hashKey": "object:3447"
    },
    {
        "nameEng": "Baggage porter",
        "code": "BAPR",
        "gender": "All",
        "nameInd": "Porter Bagasi",
        "minAge": "0",
        "descriptionInd": "Orang yang dipekerjakan untuk mengangkat bagasi, parsel, persediaan, dan lain-lain terutama di stasiun kereta api atau hotel.",
        "descriptionEng": "A person employed to carry luggage, parcels, supplies, etc., esp at a railway station or hotel.",
        "clazz": "3",
        "$$hashKey": "object:4515"
    },
    {
        "nameEng": "Boarding officer",
        "code": "BDOF",
        "gender": "All",
        "nameInd": "Petugas embarkasi / bea cukai pelabuhan",
        "minAge": "0",
        "descriptionInd": "Orang yang memeriksa dokumen dan muatan kapal untuk mencegah penyeludupan sebelum kapal diberikan ijin untuk memasuki pelabuhan, petugas bea cukai yang memeriksa dokumen/muatan untuk mencegah penyeludupan.",
        "descriptionEng": "1) A person who checks ships papers and cargo for contraband before permission is granted to enter port or 2)An officer of the custom-house who boards ships on their arrival in port or stationed in airport in order to examine their papers/cargo evaluation and to prevent smuggling.",
        "clazz": "1",
        "$$hashKey": "object:4422"
    },
    {
        "nameEng": "Bread roundsman driver",
        "code": "BREA",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) dan Pedagang Mobil Roti Keliling",
        "minAge": "0",
        "descriptionInd": "Orang yang menjual roti dengan berkeliling menggunakan kendaraan.",
        "descriptionEng": "Person who drives a vehiclearound  that carries bread or bakery items & sells it.",
        "clazz": "2",
        "$$hashKey": "object:4191"
    },
    {
        "nameEng": "Vice Mayor",
        "code": "VMYR",
        "gender": "All",
        "nameInd": "Wakil Walikota",
        "minAge": "0",
        "descriptionInd": "Seorang wakil walikota",
        "descriptionEng": "Vice Mayor",
        "clazz": "2",
        "$$hashKey": "object:4715"
    },
    {
        "nameEng": "Building surveyor",
        "code": "BLGS",
        "gender": "All",
        "nameInd": "Inspektur Surveyor Gedung",
        "minAge": "0",
        "descriptionInd": "Tenaga terlatih dalam memahami dan menafsirkan hukum bangunan, memiliki wewenang untuk menilai perencanaan bangunan untuk memastikan pembangunan tersebut mematuhi peraturan bangunan.",
        "descriptionEng": "A building surveyor is a professional trained in understanding and interpreting building law. He or she is authorised to assess building plans with a view to ensuring they are compliant with the Building Regulations.",
        "clazz": "3",
        "$$hashKey": "object:3569"
    },
    {
        "nameEng": "Bulldozer driver",
        "code": "BULL",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Buldoser",
        "minAge": "0",
        "descriptionInd": "Orang yang mengendarai buldoser di area pembangunan.",
        "descriptionEng": "Person who drives a bulldozer that is involved in any construction site.",
        "clazz": "3",
        "$$hashKey": "object:4190"
    },
    {
        "nameEng": "Caddie master",
        "code": "CADD",
        "gender": "All",
        "nameInd": "Kepala Caddie",
        "minAge": "0",
        "descriptionInd": "Karyawan lapangan yang bertanggung jawab untuk mengatur pelayan pemain golf dan menugaskan mereka kepada pemain jika diperlukan.",
        "descriptionEng": "A course employee responsible for managing caddies and assigning them to players as required.",
        "clazz": "2",
        "$$hashKey": "object:3600"
    },
    {
        "nameEng": "Campus attendant **",
        "code": "CAMP",
        "gender": "All",
        "nameInd": "Pembantu Umum atau General Affair",
        "minAge": "0",
        "descriptionInd": "Orang yang dipekerjakan untuk memberikan pelayanan kepada suatu atau beberapa departemen di suatu institusi.",
        "descriptionEng": "A person employed to provide a service to an individual/any department in any institute.",
        "clazz": "2",
        "$$hashKey": "object:3986"
    },
    {
        "nameEng": "Car Delivery Driver",
        "code": "CARD",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Mobil Pengiriman",
        "minAge": "0",
        "descriptionInd": "Pengemudi (orang) yang mengendarai mobil untuk mengantar barang kepada pelanggan.",
        "descriptionEng": "Driver who drives the car that needs to be delivered to the respective customer/owner.",
        "clazz": "2",
        "$$hashKey": "object:4198"
    },
    {
        "nameEng": "Chief dealer",
        "code": "CFDL",
        "gender": "All",
        "nameInd": "Kepala Perbendaharaan",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab untuk mengelola proses pendanaan atau pengalihan dana secara keseluruhan antar rekening bank. Manajemen kas dan resiko atas mata uang. Operasi pengendalian perbendaharaan.",
        "descriptionEng": "Responsible to manage the overall funding/transfers between bank accounts.Cash management and currency exposure.  Control treasury operations.",
        "clazz": "2",
        "$$hashKey": "object:3612"
    },
    {
        "nameEng": "Child care Worker/Baby Sitter",
        "code": "CHIL",
        "gender": "All",
        "nameInd": "Pekerja Penitipan/pengawasan Anak",
        "minAge": "0",
        "descriptionInd": "Orang yang bertugas menjaga/merawat satu atau lebih anak-anak untuk sementara waktu pada saat orang tuanya tidak dapat menjaga mereka.",
        "descriptionEng": "A person engaged to care for one or more children in the temporary absence of parents or guardians.",
        "clazz": "2",
        "$$hashKey": "object:3890"
    },
    {
        "nameEng": "Clinic assistant",
        "code": "CLAS",
        "gender": "All",
        "nameInd": "Asisten Klinik",
        "minAge": "0",
        "descriptionInd": "Seorang asisten klinik juga disebut sebagai asisten medis dan melakukan tugas klinis dan administratif di bawah pengawasan dan arahan dari dokter. Asisten klinik juga bertugas mengurus catatan medis, penagihan dan coding untuk tujuan asuransi, jadwal janji, memeriksa tanda-tanda vital dan menanyakan riwayat medis, mengambil darah di bawah arahan dokter.",
        "descriptionEng": "A clinic assistant is also referred to as a medical assistant and performs clinical and administrative duties under the supervision and direction of a physician. Clinic assistants may have to maintain medical records, billing and coding for insurance purposes, schedule appointments, taking and documenting vital signs and medical histories, drawing blood, prepping patients for examinations and administering medications under the direction of a physician.",
        "clazz": "1",
        "$$hashKey": "object:3429"
    },
    {
        "nameEng": "Commissioner",
        "code": "COMS",
        "gender": "All",
        "nameInd": "Komisaris",
        "minAge": "0",
        "descriptionInd": "Seorang komisaris adalah pangkat/jabatan yang diberikan kepada suatu anggota komisi atau seseorang yang telah diberikan suatu komisi.",
        "descriptionEng": "A commissioner is, in principle, the title given to a member of a commission or to an individual who has been given a commission.",
        "clazz": "1",
        "$$hashKey": "object:3627"
    },
    {
        "nameEng": "Communications Equipment Mechanic",
        "code": "COMU",
        "gender": "All",
        "nameInd": "Mekanik Peralatan Komunikasi",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengatur tampilan dan pemasangan peralatan data komunikasi.",
        "descriptionEng": "A person who Plans layout and installation of data communications equipment.",
        "clazz": "2",
        "$$hashKey": "object:3734"
    },
    {
        "nameEng": "Construction Machinery Operator",
        "code": "CONM",
        "gender": "All",
        "nameInd": "Operator Mesin Konstruksi",
        "minAge": "0",
        "descriptionInd": "Adalah yang mengoperasikan alat berat yang digunakan dalam konstruksi.",
        "descriptionEng": "A construction machinery operator is someone who operates heavy equipment used in construction.",
        "clazz": "3",
        "$$hashKey": "object:3795"
    },
    {
        "nameEng": "Consultant",
        "code": "CONS",
        "gender": "All",
        "nameInd": "Konsultan",
        "minAge": "0",
        "descriptionInd": "Seorang konsultan adalah profesional yang memberikan nasihat/masukan atau ahli dalam bidang tertentu seperti keamanan, manajemen, akuntansi, hukum (hukum pajak), SDM, marketing (dan hubungan masyarakat), keuangan, teknik atau salah satu dari banyak bidang khusus lainnya.",
        "descriptionEng": "A consultant is a professional who provides professional or expert advice in a particular area such as security, management, accountancy, law (tax law) , human resources, marketing (and public relations), finance, engineering, or any of many other specialized fields.",
        "clazz": "2",
        "$$hashKey": "object:3635"
    },
    {
        "nameEng": "Container clerk",
        "code": "CONT",
        "gender": "All",
        "nameInd": "Petugas Admin kontainer barang",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di dalam kantor meliputi keahlian penginputan pada komputer.Beberapa pekerjaan dalam kategori ini dapat juga dilakukan di luar kantor dan dalam lingkungan yang tidak berbahaya.",
        "descriptionEng": "Container clerk is someone whose job is office based work, often involving computer input and keyboard skills. Some occupations within this category may be performed outside an office environment but they are generally non-hazardous in nature.",
        "clazz": "2",
        "$$hashKey": "object:4411"
    },
    {
        "nameEng": "Container equipment supervisor",
        "code": "CONE",
        "gender": "All",
        "nameInd": "Supervisor Peralatan Kontainer",
        "minAge": "0",
        "descriptionInd": "Orang yang bertanggung jawab dalam mengawasi/mengatur pemasukan ke dan pengeluaran dari dalam kontainer, biasanya bekerja di perusahaan pengiriman kargo lewat laut.",
        "descriptionEng": "Person responsible for supervising/managing the ooffload and onload of Container mostly working in Cargo ship companies.",
        "clazz": "2",
        "$$hashKey": "object:4594"
    },
    {
        "nameEng": "Contractors",
        "code": "COTR",
        "gender": "All",
        "nameInd": "Kontraktor",
        "minAge": "0",
        "descriptionInd": "Organisasi atau seseorang yang dikontrak dengan organisasi atau orang lain (pemilik) dalam hal konstruksi bangunan, jalanan, atau prasarana lainnya.",
        "descriptionEng": "Contractor are organization or individual that contracts with another organization or individual (the owner) for the construction of a building, road or other facility.",
        "clazz": "3",
        "$$hashKey": "object:3646"
    },
    {
        "nameEng": "Control panel fitter",
        "code": "CTPF",
        "gender": "All",
        "nameInd": "Instalatur Panel Kontrol",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas menyesuaikan/memasang panel kontrol.",
        "descriptionEng": "Control pannel fitter is someone whose job is to fit control panel.",
        "clazz": "2",
        "$$hashKey": "object:3571"
    },
    {
        "nameEng": "Control room operator",
        "code": "CNTR",
        "gender": "All",
        "nameInd": "Operator Ruang Kontrol",
        "minAge": "0",
        "descriptionInd": "ruang kontrol ialah ruangan pusat operasional di mana sebuah fasilitas atau layanan dapat dimonitor dan diawasi.  Lazimnya terdapat di stasiun TV/studio rekaman/PLTN/fasilitas militer/pusat pengaduan. Orang yang bertanggung jawab terhadap ruangan tersebut disebut sebagai Operator Ruang Kontrol.",
        "descriptionEng": "A control room is a room serving as an operations centre where a facility or service can be monitored and controlled. Control rooms are generally prevelant in Television Station/Recording Studio/Nuclear Power Plants/Military Facilities/Call Center. A person who is a part of such a control room will be known as Control Room Operator.",
        "clazz": "2",
        "$$hashKey": "object:3819"
    },
    {
        "nameEng": "Furniture dealer",
        "code": "FURD",
        "gender": "All",
        "nameInd": "Penjual Furniture",
        "minAge": "0",
        "descriptionInd": "Pedagang furnitur adalah orang yang menjual furnitur.",
        "descriptionEng": "Furniture dealer is someone who sells Furniture.",
        "clazz": "2",
        "$$hashKey": "object:4334"
    },
    {
        "nameEng": "Gas distributor",
        "code": "GASD",
        "gender": "All",
        "nameInd": "Distributor Gas",
        "minAge": "0",
        "descriptionInd": "Distributor gas yaitu orang yang mendistribusikan gas dari produsen ke konsumen.",
        "descriptionEng": "Gas distributor is a person who distributes of gas from producers to consumers.",
        "clazz": "2",
        "$$hashKey": "object:3481"
    },
    {
        "nameEng": "Vice Minister",
        "code": "VMST",
        "gender": "All",
        "nameInd": "Wakil Menteri",
        "minAge": "0",
        "descriptionInd": "Seorang menjabat sebagai wakil Menteri",
        "descriptionEng": "Vice Minister",
        "clazz": "2",
        "$$hashKey": "object:4714"
    },
    {
        "nameEng": "Vice Regent",
        "code": "VRGN",
        "gender": "All",
        "nameInd": "Wakil Bupati",
        "minAge": "0",
        "descriptionInd": "Seorang wakil bupati",
        "descriptionEng": "Vice Regent",
        "clazz": "2",
        "$$hashKey": "object:4711"
    },
    {
        "nameEng": "Conveyancing search clerk",
        "code": "CVSC",
        "gender": "All",
        "nameInd": "Petugas pembuat akte tanah",
        "minAge": "0",
        "descriptionInd": "Merujuk kepada ketentuan informasi spesifik tentang suatu properti tertentu dan area sekitarnya bagi pembeli dan penjual. Hal ini dilakukan sebagai bagian dari proses penyampaian oleh seorang pengacara dan biasanya merupakan prasyarat untuk transaksi jual-beli properti komersial.",
        "descriptionEng": "Conveyancing search clerk and a Local Authority Search (also known as local land charges search or local search) refers to the provision of specific information about a particular property and the surrounding area for buyers and sellers. This is undertaken as part of the conveyancing process by a solicitor or a licensed conveyancer, and is normally a requirement for transactions of commercial properties.",
        "clazz": "2",
        "$$hashKey": "object:4465"
    },
    {
        "nameEng": "Corporate dealer",
        "code": "CODL",
        "gender": "All",
        "nameInd": "Agen Perusahaan",
        "minAge": "0",
        "descriptionInd": "Agen perusahaan ialah seseorang yang pekerjaannya melakukan penjualan mewakili suatu perusahaan atau organisasi, khususnya di industri kendaraan bermotor.",
        "descriptionEng": "Corporate dealer is a person who sells on behalf of a company or organization, particularly in the automobile industry.",
        "clazz": "2",
        "$$hashKey": "object:3324"
    },
    {
        "nameEng": "Corporate's Owner",
        "code": "CORP",
        "gender": "All",
        "nameInd": "Pemilik Perusahaan",
        "minAge": "0",
        "descriptionInd": "Orang yang memiliki perusahaan.",
        "descriptionEng": "People who own the company.",
        "clazz": "1",
        "$$hashKey": "object:4065"
    },
    {
        "nameEng": "Civil Service Police Unit",
        "code": "CSPU",
        "gender": "All",
        "nameInd": "Satpol PP",
        "minAge": "0",
        "descriptionInd": "Unit Kepolisian Pelayan Masyarakat, atau dikenal sebagai Satpol PP, ialah badan penegak hukum Indonesia, beroperasi di bawah Departemen Dalam Negeri. Anggota-anggotanya dikenal sebagai 'petugas tramtib', di mana sedikit berbeda dari POLRI (Kepolisian Nasional Indonesia), karena Satpol PP merupakan penegak hukum yang khusus menegakkan peraturan walikota dan mengambil tindakan terhadap mereka yang melawan aturan tersebut.",
        "descriptionEng": "The Civil Service Police Unit, or in Indonesian Satuan Polisi Pamong Praja (Satpol PP), is an Indonesian law-enforcement body, operated by the Department of Home Affairs. Its members are known as 'public order officers'. It is a little bit different from the POLRI or Indonesian National Police, because it is a law enforcement body which has the specialty for only to enforce the regulations and rules from the city mayor and to take action for those who are against it.",
        "clazz": "3",
        "$$hashKey": "object:4540"
    },
    {
        "nameEng": "Course worker **",
        "code": "COUR",
        "gender": "All",
        "nameInd": "Pekerja di tempat Kursus",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja pada suatu tempat kursus.",
        "descriptionEng": "Course worker are someone who work in the course.",
        "clazz": "1",
        "$$hashKey": "object:3862"
    },
    {
        "nameEng": "Crane operator",
        "code": "CROP",
        "gender": "All",
        "nameInd": "Operator Mobil Derek",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas mengoperasikan Crane/Mobil derek.",
        "descriptionEng": "A crane operator is someone whose job is to operate crane.",
        "clazz": "3",
        "$$hashKey": "object:3801"
    },
    {
        "nameEng": "Distributor assistant",
        "code": "DSAS",
        "gender": "All",
        "nameInd": "Asisten Distributor",
        "minAge": "0",
        "descriptionInd": "Distributor makanan adalah orang yang bekerja sebagai penyalur dan memberikan pelayanan dari produsen ke konsumen.",
        "descriptionEng": "Distributor assistant is a person who distributes of goods and services from producers to consumers.",
        "clazz": "2",
        "$$hashKey": "object:3423"
    },
    {
        "nameEng": "District Head",
        "code": "DIST",
        "gender": "All",
        "nameInd": "Camat/ Lurah",
        "minAge": "0",
        "descriptionInd": "Mengelola keseluruhan operasi dan alur kerja kecamatan dan kelurahan.",
        "descriptionEng": "Manages overall district operation and work flow.",
        "clazz": "2",
        "$$hashKey": "object:3464"
    },
    {
        "nameEng": "Industrial Designer",
        "code": "IDUD",
        "gender": "All",
        "nameInd": "Desainer Industri",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang pekerjaannya mencari ide /solusi dalam pengembangan design, pengembangan merk, pemasaran dan penjualan.",
        "descriptionEng": "An industrial designer is person who creates and executes design solutions for problems of form, usability, physical ergonomics, marketing, brand development, and sales.",
        "clazz": "2",
        "$$hashKey": "object:3474"
    },
    {
        "nameEng": "Dragline driver",
        "code": "DRAG",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Pembuat Marka Jalan Pengemudi (Supir) dragline (alat berat)",
        "minAge": "0",
        "descriptionInd": "Orang yang mengoperasikan alat derek yang dilengkapi dengan ember dragline yang tergantung dengan kabel untuk menggali atau memindahkan pasir, kerikil, tanah liat, lumpur, batu bara atau bahan lainnya.",
        "descriptionEng": "Someone who operates power-driven crane equipped with dragline bucket, suspended from boom by cable to excavate or move sand, gravel, clay, mud, coal, or other materials.",
        "clazz": "3",
        "$$hashKey": "object:4201"
    },
    {
        "nameEng": "Elevator/lift attendant",
        "code": "ELEV",
        "gender": "All",
        "nameInd": "Petugas Lift/ Elevator",
        "minAge": "0",
        "descriptionInd": "Petugas Lift adalah orang yang mengoperasikan lift secara manual. Selainmereka dilatih untuk mengoperasikan dan keamanan,mereka juga dilatih untuk menyambut para pengunjung dan sebagai penunjuk arah, memberitahukan barang-barang yang ada di departemen, di setiap lantai dan kadang-kadang menginformasikan adanya program-progran potongan harga yang sedang berlangsung.",
        "descriptionEng": "Elevator/lift attendant is a person specifically employed to operate a manually operated elevator. Besides their training in operation and safety, later, department stores extended the roles of operators as combination greeters and tour guides, announcing product departments, floor-by-floor, and occasionally mentioning special price offers.",
        "clazz": "2",
        "$$hashKey": "object:4444"
    },
    {
        "nameEng": "Engineer",
        "code": "ENGR",
        "gender": "All",
        "nameInd": "Insinyur",
        "minAge": "0",
        "descriptionInd": "Insinyur adalah seorang praktisi profeisonal yang  memperhatikan ilmu terapan, ,matematika dan dengan kecerdasannya mengembangkan jalan keluar untuk memecahkan masalah-masalah teknis.",
        "descriptionEng": "An engineer is a professional practitioner of engineering, concerned with applying scientific knowledge, mathematics, and ingenuity to develop solutions for technical problems.",
        "clazz": "3",
        "$$hashKey": "object:3526"
    },
    {
        "nameEng": "Entrepreneur",
        "code": "ENTR",
        "gender": "All",
        "nameInd": "Wiraswasta (Pengusaha)",
        "minAge": "0",
        "descriptionInd": "Pengusaha adalah orang yang mengatur dan menjalankan usaha, serta mengambil resiko yang mungkin dihadapi.",
        "descriptionEng": "An entrepreneur is an individual who organizes and operates a business or businesses, taking on financial risk to do so.",
        "clazz": "2",
        "$$hashKey": "object:4722"
    },
    {
        "nameEng": "Estate maintenance officer",
        "code": "EMTO",
        "gender": "All",
        "nameInd": "Petugas Pemeliharaan Perumahan",
        "minAge": "0",
        "descriptionInd": "Orang yang berada di jajaran tingkat atas dalam rumah tangga, bekerja langsung dengan pemilik untuk merencanakan dan melaksanakan manajemen pelayanan dan gedung.",
        "descriptionEng": "A person who is at the top level in the household. He or she works directly with the owners to plan and execute the overall management of property and service.",
        "clazz": "2",
        "$$hashKey": "object:4468"
    },
    {
        "nameEng": "Ex minister",
        "code": "XMIN",
        "gender": "All",
        "nameInd": "Mantan Perdana Menteri",
        "minAge": "0",
        "descriptionInd": "Mantan Perdana Menteri yang pernah memerintah suatu negara.",
        "descriptionEng": "The former Prime Minister who once ruled a country",
        "clazz": "2",
        "$$hashKey": "object:3722"
    },
    {
        "nameEng": "Film layout assistant",
        "code": "FLAS",
        "gender": "All",
        "nameInd": "Asisten Perancang Film",
        "minAge": "0",
        "descriptionInd": "Asisten perancang film adalah orang yang mengerjakan rancangan gambar dan teks sesuai dengan format yang diinginkan.",
        "descriptionEng": "Film layout assistant is a person whose job is to deal the structure and layout of images and text in a pleasing format.",
        "clazz": "1",
        "$$hashKey": "object:3433"
    },
    {
        "nameEng": "Florist",
        "code": "FLOR",
        "gender": "All",
        "nameInd": "Penjual Bunga",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang bekerja dengan bunga dan tanaman, pada umumnya dalam skala kecil/pedagang.",
        "descriptionEng": "Florists are people who work with flowers and plants, generally at the retail level.",
        "clazz": "2",
        "$$hashKey": "object:4332"
    },
    {
        "nameEng": "Foreign currency agent",
        "code": "FORC",
        "gender": "All",
        "nameInd": "Agen Penukaran Mata Uang Asing",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang menawarkan penukaran uang asing dan pembayaran internasional.",
        "descriptionEng": "Foreign currency agent is a agent that offers currency exchange and international payments.",
        "clazz": "2",
        "$$hashKey": "object:3322"
    },
    {
        "nameEng": "Foreman",
        "code": "FORE",
        "gender": "All",
        "nameInd": "Mandor Lapangan",
        "minAge": "0",
        "descriptionInd": "Mandor adalah orang yang bertanggung jawab atas suatu team atau petugas.",
        "descriptionEng": "Foreman is a person who is in charge of the team or crew.",
        "clazz": "3",
        "$$hashKey": "object:3715"
    },
    {
        "nameEng": "Fork lift operator",
        "code": "FOLO",
        "gender": "All",
        "nameInd": "Operator Forklif",
        "minAge": "0",
        "descriptionInd": "Pegawai mesin pengangkat barang adalah orang yang mengoperasikan mesin pengangkat barang.",
        "descriptionEng": "Fork lift operator is someone who operates a fork lift.",
        "clazz": "3",
        "$$hashKey": "object:3767"
    },
    {
        "nameEng": "Foundry worker",
        "code": "FOUD",
        "gender": "All",
        "nameInd": "Pekerja Pengecoran Logam",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang melakukan proses pengecoran logam dari suatu benda dengan menuangkan metal cair ke dalam suatu cetakan. Cetakan dibuat menggunakan pola dari barang yang diinginkan.",
        "descriptionEng": "Foundry worker  is person who processes of making a metal casting of an object by pouring molten metal into a mould. The mould is made using a pattern of the article required.",
        "clazz": "2",
        "$$hashKey": "object:3886"
    },
    {
        "nameEng": "Gold & Copper Prospector",
        "code": "GOCO",
        "gender": "All",
        "nameInd": "Pendulang Emas",
        "minAge": "0",
        "descriptionInd": "Penambang emas & tembaga  adalah orang yang bertugas mencari deposit emas dan tembaga dengan menggunakan metode yang bervariasi.",
        "descriptionEng": "Gold & copper prospector is someone whose job is searching for new gold & cooper deposits. Methods used vary with the type of deposit sought and the resources of the prospector.",
        "clazz": "3",
        "$$hashKey": "object:4123"
    },
    {
        "nameEng": "Golf course maintenance worker **",
        "code": "GOLF",
        "gender": "All",
        "nameInd": "Pekerja Pemelihara Lapangan Golf",
        "minAge": "0",
        "descriptionInd": "Maintanance Lapangan Golf adalah orang yang bertanggung jawab atas maintanance/pemeliharaan lapangan golf.",
        "descriptionEng": "Golf course maintenance worker is somenoe who works to maintain Golf course.",
        "clazz": "2",
        "$$hashKey": "object:3883"
    },
    {
        "nameEng": "Gondola supervisor",
        "code": "GOND",
        "gender": "All",
        "nameInd": "Supervisor Gondola",
        "minAge": "0",
        "descriptionInd": "Yaitu orang yang bertugas untuk mengawasi  instalasi,  pembongkaran atau perubahan Gondola.",
        "descriptionEng": "Gondola supervisor is person whose job to supervise the erection, installation, re-positioning, dismantling or alteration of a Gondola.",
        "clazz": "3",
        "$$hashKey": "object:4593"
    },
    {
        "nameEng": "Greengrocer",
        "code": "GREE",
        "gender": "All",
        "nameInd": "Penjual Sayuran",
        "minAge": "0",
        "descriptionInd": "Pedagang ritel dalam buah dan sayuran, yaitu bahan makanan hijau.",
        "descriptionEng": "A greengrocer, also called a produce market or fruiterer, is a retail trader in fruit and vegetables; that is, in green groceries.",
        "clazz": "2",
        "$$hashKey": "object:4338"
    },
    {
        "nameEng": "Heat Treatment Technician",
        "code": "HEAT",
        "gender": "All",
        "nameInd": "Teknisi Alat Pemanas",
        "minAge": "0",
        "descriptionInd": "Yaitu bertugas mengatur, mengoperasikan mesin pemanas.",
        "descriptionEng": "Set up, operate, or tend heating equipment, such as heat-treating furnaces, flame-hardening machines, induction machines, soaking pits, or vacuum equipment to temper, harden, anneal, or heat-treat metal or plastic objects.",
        "clazz": "3",
        "$$hashKey": "object:4601"
    },
    {
        "nameEng": "Heating/ Refrigeration Mechanic",
        "code": "HETI",
        "gender": "All",
        "nameInd": "Teknisi Mesin Pemanas/ Pendinginan",
        "minAge": "0",
        "descriptionInd": "Adalah orang  yang ahli dalam memperbaiki mesin pemanas/pendingin.",
        "descriptionEng": "Heating/Refrigeration mechanic is a technician who repair Heating/Refrigeration machine.",
        "clazz": "2",
        "$$hashKey": "object:4617"
    },
    {
        "nameEng": "Horse-drawn vehicle driver",
        "code": "HORS",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Kendaraan Pembawa Kuda",
        "minAge": "0",
        "descriptionInd": "Kusir yaitu orang yang mengendarai kendaraan yang ditarik oleh kuda.",
        "descriptionEng": "Horse-drawn vehicle Driver is someone who drives a Horse-drawn vehicle.",
        "clazz": "2",
        "$$hashKey": "object:4195"
    },
    {
        "nameEng": "Housewife",
        "code": "HSWF",
        "gender": "F",
        "nameInd": "Ibu Rumah Tangga",
        "minAge": "0",
        "descriptionInd": "Ibu rumah tangga adalah wanita yang pekerjaan utamanya mengelola keluarga dan  rumah, merawat dan mendidik anak-anaknya, memasak dan menyimpan makanan, membeli barang-barang kebutuhan keluarga dalam kehidupan sehari-hari.",
        "descriptionEng": "A housewife is a woman whose main occupation is running or managing the family's home�caring for and educating her children, cooking and storing food, buying goods the family needs in day to day life, cleaning and maintaining the home, making clothes for the family, etc.�and who is generally not employed outside the home.",
        "clazz": "1",
        "$$hashKey": "object:3523"
    },
    {
        "nameEng": "Importer and exporter",
        "code": "IMEX",
        "gender": "All",
        "nameInd": "Importir dan Eksportir",
        "minAge": "0",
        "descriptionInd": "Importir adalah pembeli barang dan jasa dimana penjual berbasis di luar negeri dan eksportir adalah penjual barang dan jasa di mana pembeli berbasis di luar negeri.",
        "descriptionEng": "Importer is the buyer of goods and services where the overseas based seller and exporter is the seller of goods and services where the overseas based buyer.",
        "clazz": "2",
        "$$hashKey": "object:3525"
    },
    {
        "nameEng": "Industrial Engineer",
        "code": "IDUE",
        "gender": "All",
        "nameInd": "Sarjana Perindustrian",
        "minAge": "0",
        "descriptionInd": "Mengkoordinasikan obyektif dan kegiatan pengendalian mutu  untuk mengatasi masalah yang timbul dalam proses produksi, memaksimalkan keandalan produk, dan meminimalkan biaya produksi.",
        "descriptionEng": "Coordinate quality control objectives and activities to resolve production problems, maximize product reliability, and minimize cost.Apply statistical methods and perform mathematical calculations to determine manufacturing processes, staff requirements, and production standards.",
        "clazz": "2",
        "$$hashKey": "object:4539"
    },
    {
        "nameEng": "Industrial Machine Repairer",
        "code": "IDUM",
        "gender": "All",
        "nameInd": "Teknisi Mesin Industri",
        "minAge": "0",
        "descriptionInd": "Yaitu orang yang bertugas memperbaiki mesin industri.",
        "descriptionEng": "Industrial machine repairer is a technician who repair industrial  machine.",
        "clazz": "3",
        "$$hashKey": "object:4616"
    },
    {
        "nameEng": "Instructor (Other)",
        "code": "INST",
        "gender": "All",
        "nameInd": "Instruktur (Lainnya)",
        "minAge": "0",
        "descriptionInd": "Seorang guru atau ahli dari suatu bidang  khusus yang memerlukan  keahlian.",
        "descriptionEng": "A teacher or expert, of a specialised subject that involves skill.",
        "clazz": "3",
        "$$hashKey": "object:3572"
    },
    {
        "nameEng": "Interior decorator",
        "code": "INDE",
        "gender": "All",
        "nameInd": "Desain Interior",
        "minAge": "0",
        "descriptionInd": "Designer interior yaitu orang yang bekerja meningkatkan fungsi, keamanan dan estetika suatu ruang  dengan mempertimbangkan berbagai aspek seperti warna, tekstur, furnitur, pencahayaan untuk memenuhi kebutuhan penghuni atau pengunjung.",
        "descriptionEng": "enhances the function, safety and aesthetics of interior spaces while taking into account how different colors, textures, furniture, lighting and space work together to meet occupants' or visitors' needs. He or she works with both private and public spaces including residences, shopping malls, schools, offices and hospitals.",
        "clazz": "2",
        "$$hashKey": "object:3471"
    },
    {
        "nameEng": "Inventory assistant",
        "code": "IVAS",
        "gender": "All",
        "nameInd": "Staff Inventaris",
        "minAge": "0",
        "descriptionInd": "Petugas inventaris yaitu orang yang bertugas mengawasi penyediaan, penyimpanan dan aksesibilitas material untuk memastikan stock yang cukup tapi tidak berlebihan.",
        "descriptionEng": "is the supervision of supply, storage and accessibility of items in order to ensure an adequate supply without excessive oversupply. Compiles and maintains records of quantity, type, and value of material, equipment, merchandise, or supplies stocked in establishment: Counts material, equipment, merchandise, or supplies in stock and posts totals to inventory records, manually or using computer.",
        "clazz": "1",
        "$$hashKey": "object:4583"
    },
    {
        "nameEng": "Investor",
        "code": "IVES",
        "gender": "All",
        "nameInd": "Pengalokasi Dana",
        "minAge": "0",
        "descriptionInd": "Investor yaitu orang yang mengalokasikan modal untuk mendapatkan keuntungan finansial.",
        "descriptionEng": "a person who allocates capital with the expectation of a financial return. The types of investments include, � gambling and speculation, equity, debt securities, real estate, currency, commodity, derivatives such as put and call options, etc.",
        "clazz": "1",
        "$$hashKey": "object:4140"
    },
    {
        "nameEng": "Ironworker",
        "code": "IRON",
        "gender": "All",
        "nameInd": "Pekerja Perakit Besi",
        "minAge": "0",
        "descriptionInd": "Pekerja Perangkat Besi adalah [1] merakit kerangka struktural sesuai dengan gambar rekayasa. [2] pembuat besi juga membongkar, tempat dan dasi tulangan baja (rebar) serta menginstal sistem pasca-tensioning, baik yang memberikan kekuatan pada beton yang digunakan dalam dermaga, pondasi, lembaran, bangunan dan jembatan. Dapat mengatur mesin dan peralatan serta mengoperasikan kerekan listrik, forklift, dan lift udara. Menyelesaikan bangunan dengan mendirikan dinding tirai dan jendela dinding sistem, beton pre-cast dan batu, tangga dan pegangan tangan, pintu logam, lembaran dan front lift. Ironworkers melakukan semua jenis pemeliharaan industri.",
        "descriptionEng": "Ironworkers assemble the structural framework in accordance with engineered drawings.[2] Ironworkers also unload, place and tie reinforcing steel bars (rebar) as well as install post-tensioning systems, both of which give strength to the concrete used in piers, footings, slabs, buildings and bridges. Ironworkers load, unload, place and set machinery and equipment and operate power hoists, forklifts, and aerial lifts. They unload, place and fasten metal decking, safety netting and edge rails to facilitate safe working practices. Ironworkers finish buildings by erecting curtain wall and window wall systems, pre-cast concrete and stone, stairs and handrails, metal doors, sheeting and elevator fronts. Ironworkers perform all types of industrial maintenance as well.[",
        "clazz": "3",
        "$$hashKey": "object:3892"
    },
    {
        "nameEng": "Labourer (unskilled trades)",
        "code": "LABR",
        "gender": "All",
        "nameInd": "Buruh (tidak terampil)",
        "minAge": "0",
        "descriptionInd": "Buruh yaitu orang yang bekerja kasar di bidang pembangunan kapal/konstruksi/pertanian.",
        "descriptionEng": "Laborers have all blasting, hand tools, power tools, air tools, and small heavy equipment, and act as assistants to other trades.",
        "clazz": "3",
        "$$hashKey": "object:3455"
    },
    {
        "nameEng": "Land surveyor",
        "code": "LDSV",
        "gender": "All",
        "nameInd": "Surveyor Tanah",
        "minAge": "0",
        "descriptionInd": "Yaitu orang yang bertugas merencanakan, mengatur, dan mengarahkan pekerjaan satu atau lebih surveyor yang terlibat dalam survei permukaan bumi untuk menentukan lokasi yang tepat dan titik pengukuran ketinggian, garis, bidang, dan kontur untuk konstruksi, pembuatan peta, pembagian tanah, judul, pertambangan atau lainnya tujuan: penelitian bukti survei sebelumnya, peta, perbuatan, bukti fisik, dan catatan lain untuk mendapatkan data yang diperlukan untuk survei.",
        "descriptionEng": "Plans, organizes, and directs work of one or more survey parties engaged in surveying earth's surface to determine precise location and measurements of points, elevations, lines, areas, and contours for construction, mapmaking, land division, titles, mining or other purposes: Researches previous survey evidence, maps, deeds, physical evidence, and other records to obtain data needed for surveys.",
        "clazz": "2",
        "$$hashKey": "object:4597"
    },
    {
        "nameEng": "Legal Aid Institution Officer",
        "code": "LEAI",
        "gender": "All",
        "nameInd": "Pegawai Lembaga Bantuan Hukum (LBH)",
        "minAge": "0",
        "descriptionInd": "Yaitu pegawai perusahaan yang menangani urusan hukum dari sebuah perusahaan, lembaga, atau organisasi. Profesional ini harus memiliki keterampilan hukum luar biasa dan disiplin untuk menjaga fungsi lembaga dan keluar dari masalah hukum.",
        "descriptionEng": "is a corporate officer that handles the legal affairs of a corporation, agency, or organization. The legal officer works with other legal staff to address the internal and external legal concerns of the business. This professional must have superb legal skills and discipline to keep the agency functioning and out of legal trouble.",
        "clazz": "2",
        "$$hashKey": "object:3843"
    },
    {
        "nameEng": "Legal assistant (clerical)",
        "code": "LEAS",
        "gender": "All",
        "nameInd": "Legal Staff (Admin)",
        "minAge": "0",
        "descriptionInd": "Yaitu staf perusahaan yang mempersiapkan dokumen hukum dan korespondensi hukum, seperti surat panggilan, complain dan panggilan dari pengadilan,  meninjau jurnal hukum dan publikasi hukum lainnya untuk mengidentifikasi keputusan pengadilan yang berkaitan dengan kasus tertunda dan mengirimkan artikel ke pejabat perusahaan.",
        "descriptionEng": "Prepares legal papers and correspondence of legal nature, such as summonses, complaints, motions, and subpoenas, using typewriter, word processor, or personal computer. May review law journals and other legal publications to identify court decisions pertinent to pending cases and submit articles to company officials.",
        "clazz": "1",
        "$$hashKey": "object:3660"
    },
    {
        "nameEng": "Liner executive (Merchant Marine)",
        "code": "LNEX",
        "gender": "All",
        "nameInd": "Eksekutif Kapal",
        "minAge": "0",
        "descriptionInd": "Aktivitas utamanya adalah penanganan efisien kapal dan kargo di pelabuhan/penanganan penumpang secara efisien dan terpercaya di forwarding dari berbagai kargo ke tujuan yang berbeda (baik kapal kargo/kapal penumpang). Meningkatkan efisiensi dan operasional organisasi di dalam kapal seperti training dan pengembangan tim. Mengutamakan layanan terbaik bagi pelanggan.",
        "descriptionEng": "Principal activity is the efficient handling of vessels and cargoes in ports/handling passenger efficiently and the reliable on-forwarding of a wide variety of cargoes to different destinations(Cargo ship/Passenger ship) Improve the efficiency of the liner organisation and operation.Training and development of the liner team. Ensuring first class customer service.",
        "clazz": "3",
        "$$hashKey": "object:3504"
    },
    {
        "nameEng": "Locker room attendant",
        "code": "LOCK",
        "gender": "All",
        "nameInd": "Petugas Ruang Ganti",
        "minAge": "0",
        "descriptionInd": "Yang bertanggung jawab menjaga kerapihan ruang ganti dan membantu berbagai kebutuhan yg mungkin timbul di ruang ganti. Ruang ganti seperti yg ada di gym, salon dan arena olahraga.",
        "descriptionEng": "A locker room attendant is usually responsible for keeping a locker room presentable. He or She may clean restocks supplies or offer customer service.(who are there to help with a variety of needs that may arise in the locker room) A wide variety of establisments have locker room including gyms, salon, and sports arena.",
        "clazz": "1",
        "$$hashKey": "object:4490"
    },
    {
        "nameEng": "Locomotive driver",
        "code": "LOCO",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Lokomotif",
        "minAge": "0",
        "descriptionInd": "Pengemudi (Supir) lokomotif mengoperasikan kereta/lokomotif, mengangkut penumpang dan barang pada kereta listrik/diesel, yang memiliki pengetahuan terperinci diantaranya rute, trek, batas kecepatan dan jadwal.",
        "descriptionEng": "Locomotive Drivers operate locomotive hauled passenger and freight trains, as well as electric and diesel rail-cars. Train drivers drive diesel or electric trains carrying passengers and/or goods.They have a detailed knowledge of their route, the track lay out, speed limits and timetables.",
        "clazz": "3",
        "$$hashKey": "object:4197"
    },
    {
        "nameEng": "Machinist",
        "code": "MACH",
        "gender": "All",
        "nameInd": "Masinis Kereta Api",
        "minAge": "0",
        "descriptionInd": "Seorang masinis memiliki keterampilan yang jauh lebih baik dibandingkan operator mesin biasa dan memiliki keahlian dalam mengoperasikan banyak jenis alat mesin dan melakukan operasi yang kompleks/rumit.",
        "descriptionEng": "A machinist is typically much more highly skilled compared than machine operator and has expertise in operating many types of machining tools and performing intricate operations.",
        "clazz": "3",
        "$$hashKey": "object:3725"
    },
    {
        "nameEng": "Material handlers",
        "code": "MAHD",
        "gender": "All",
        "nameInd": "Pengawas penanganan kebutuhan material",
        "minAge": "0",
        "descriptionInd": "Bagian dari proses produksi yang meliputi penyimpanan, pemuatan, penurunan, dan juga bagian transportasi mengangkut material ke pengepakan sampai barang jadi yang siap dipasarkan.",
        "descriptionEng": "Loads, unloads, and moves materials within or near plant, yard, or work site, performing any combination of following duties: Reads work order or follows oral instructions to ascertain materials or containers to be moved.  Opens containers, using steel cutters, crowbar, clawhammer, or other handtools.",
        "clazz": "3",
        "$$hashKey": "object:4161"
    },
    {
        "nameEng": "Mathematician",
        "code": "MATH",
        "gender": "All",
        "nameInd": "Ahli Matematika",
        "minAge": "0",
        "descriptionInd": "Adalah ahli matematika yang melakukan penelitian dalam matematika dasar dan penerapan teknik matematika untuk ilmu pengetahuan, manajemen dan bidang lainnya. Memecahkan atau mengarahkan solusi di berbagai bidang dengan metode matematika serta melakukan penelitian di cabang matematika seperti aljabar, geometri, topologi dan teori-teori alternatif.",
        "descriptionEng": "Conducts research in fundamental mathematics and in application of mathematical techniques to science, management, and other fields, and solves or directs solutions to problems in various fields by mathematical methods: Conducts research in such branches of mathematics as algebra, geometry, topology, and alternative theories.",
        "clazz": "1",
        "$$hashKey": "object:3361"
    },
    {
        "nameEng": "Merchant",
        "code": "MCAS",
        "gender": "All",
        "nameInd": "Pedagang",
        "minAge": "0",
        "descriptionInd": "Orang yang melakukan perdagangan untuk memperoleh suatu keuntungan",
        "descriptionEng": "People who are doing product's trading to gain profit",
        "clazz": "2",
        "$$hashKey": "object:3834"
    },
    {
        "nameEng": "Metal fabricator",
        "code": "MTFB",
        "gender": "All",
        "nameInd": "Pegawai Pabrik Logam",
        "minAge": "0",
        "descriptionInd": "Orang yang membuat dan merakit produk logam, seperti kerangka kerja untuk mesin, tank ,tumpukan dan bagian logam untuk bangunan dan jembatan sesuai dengan permintaan pekerjaan, instruksi. Mengembangkan tata letak dan rencana urutan operasi, menerapkan pengetahuan trigonometri, mesin las dan sifat fisik logam. Mengatur dan mengoperasikan mesin fabrikasi, seperti rem, gulungan, gunting dan menekan bor.",
        "descriptionEng": "Fabricates and assembles structural metal products, such as framework or shells for machinery, tanks, stacks, and metal parts for buildings and bridges according to job order, verbal instructions. Develops layout and plans sequence of operations, applying knowledge of trigonometry, machine and welding shrinkage, and physical properties of metal. Sets up and operates fabricating machines, such as brakes, rolls, shears, flame cutters, and drill presses.",
        "clazz": "3",
        "$$hashKey": "object:3852"
    },
    {
        "nameEng": "Agent non-insurance",
        "code": "AGNT",
        "gender": "All",
        "nameInd": "Agen non-asuransi",
        "minAge": "0",
        "descriptionInd": "Seorang  tenaga pemasar selain industri asuransi (contoh: agen minyak, agen bahan pokok, dll)",
        "descriptionEng": "Agent, other than insurance",
        "clazz": "2",
        "$$hashKey": "object:3321"
    },
    {
        "nameEng": "Minister",
        "code": "MIN",
        "gender": "All",
        "nameInd": "Menteri",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memegang jabatan penting dalam suatu pemerintahan nasional atau regional, membuat dan melaksanakan keputusan tentang kebijakan dalam hubungannya dengan menteri lainnya.",
        "descriptionEng": "who holds significant public office in a national or regional government, making and implementing decisions on policies in conjunction with the other ministers.",
        "clazz": "2",
        "$$hashKey": "object:3738"
    },
    {
        "nameEng": "Money changer (licensed)",
        "code": "MOCG",
        "gender": "All",
        "nameInd": "Petugas Penukaran Uang",
        "minAge": "0",
        "descriptionInd": "Orang yang menukarkan koin atau mata uang satu negara ke mata uang atau koin negara lainnya.",
        "descriptionEng": "is a person who exchanges the coins or currency of one country for that of another.",
        "clazz": "1",
        "$$hashKey": "object:4480"
    },
    {
        "nameEng": "Money lender",
        "code": "MONL",
        "gender": "All",
        "nameInd": "Pemberi Kredit",
        "minAge": "0",
        "descriptionInd": "Orang atau sekelompok orang yang meminjamkan/menawarkan pinjaman kepada orang lain dengan tingkat suku bunga yang tinggi.suku bunga yang tinggi di bebakan kepada para peminjam.",
        "descriptionEng": "A moneylender is a person or group who offers small personal loans at high rates of interest. The high interest rates charged by them is justified in many cases by the risk involved.",
        "clazz": "1",
        "$$hashKey": "object:3995"
    },
    {
        "nameEng": "Motorcycle Taxi",
        "code": "MTTX",
        "gender": "All",
        "nameInd": "Tukang Ojek",
        "minAge": "0",
        "descriptionInd": "Kendaraan yang membawa satu penumpang (dibonceng di belakang sepeda motor), adalah suatu bentuk transportasi umum di Indonesia yang di sebut ojeg.",
        "descriptionEng": "Typically the taxi carries one passenger, and sometimes two or more who ride as the pillion, behind the motorcycle operator. Motorcycle taxis (ojek) are a very common unlicensed form of transport in Indonesia.",
        "clazz": "3",
        "$$hashKey": "object:4685"
    },
    {
        "nameEng": "Mould maker (Manufacturing)",
        "code": "MOMK",
        "gender": "All",
        "nameInd": "Pembuat Cetakan (Manufaktur)",
        "minAge": "0",
        "descriptionInd": "Adalah seorang pekerja yang memiliki keahlian membuat cetakan yang digunakan untuk pengerjaan logam dan industri manufaktur lainnya.",
        "descriptionEng": "is a skilled trades worker who makes molds for use in metalworking and other manufacturing industries.",
        "clazz": "2",
        "$$hashKey": "object:4009"
    },
    {
        "nameEng": "Newsboy/girl",
        "code": "NEWS",
        "gender": "All",
        "nameInd": "Loper Koran",
        "minAge": "0",
        "descriptionInd": "Adalah seseorang biasanya seorang anak-anak yang mengantarkan surat kabar.",
        "descriptionEng": "an individual, often a child, employed to deliver newspapers.",
        "clazz": "2",
        "$$hashKey": "object:3662"
    },
    {
        "nameEng": "Nun/Sister",
        "code": "NUNS",
        "gender": "F",
        "nameInd": "Biarawati",
        "minAge": "0",
        "descriptionInd": "adalah anggota dari sebuah komunitas religius/keagamaan wanita, biasanya hidup di bawah sumpah, kemurnian, dan ketaatan, yang memutuskan untuk mendedikasikan hidupnya untuk melayani semua makhluk hidup lainnya, atau untuk menjadi seorang pertapa yang secara sukarela memilih untuk meninggalkan arus masyarakat dan menjalani hidupnya dalam doa dan di sebuah biara atau biara.Istilah \"\" suster \"\" berlaku untuk orang Katolik (tradisi Barat dan Timur), Kristen Ortodoks, Anglikan, Lutheran, Jain, Buddha, Tao, dan Hindu.",
        "descriptionEng": "is a member of a religious community of women, typically one living under vows of poverty, chastity, and obedience.who decided to dedicate her life to serving all other living beings, or to be an ascetic who voluntarily chooses to leave mainstream society and live her life in prayer and contemplation in a monastery or convent. The term \"nun\" is applicable to Catholics (eastern and western traditions), Orthodox Christians, Anglicans, Lutherans, Jains, Buddhists, Taoists, and Hindus.",
        "clazz": "1",
        "$$hashKey": "object:3448"
    },
    {
        "nameEng": "Sportsman (athlete)",
        "code": "SPOT",
        "gender": "All",
        "nameInd": "Atlet Olahraga",
        "minAge": "0",
        "descriptionInd": "Orang yang melakukan olahraga untuk kompetisi besar seperti liga dan olimpiade",
        "descriptionEng": "A person who do sports for a big competition such as league and olympic.",
        "clazz": "3",
        "$$hashKey": "object:3442"
    },
    {
        "nameEng": "Observer for Agriculture/Forestry/Poultry/Fishery",
        "code": "OBSR",
        "gender": "All",
        "nameInd": "Peneliti Perkebunan/Pertanian/Kehutanan/Peternakan/Perikanan",
        "minAge": "0",
        "descriptionInd": "adalah spesialis independen dan dipekerjakan oleh program observer(pengamat). baik secara langsung oleh instansi pemerintah atau oleh kontraktor pihak ketiga. Meninjau setiap kejadian yang tidak biasa atau pengamatan, masalah keselamatan atau kesulitan lain yang mereka alami selama perjalanan.",
        "descriptionEng": "is an independent specialist, and is employed by a observer program. either directly by a government agency or by a third party contractor. A debriefing consists of reviewing any unusual occurrences or observations, violations observed, and any safety problems or other hardships they endured during the trip.",
        "clazz": "2",
        "$$hashKey": "object:4131"
    },
    {
        "nameEng": "Office boy/girl",
        "code": "OFFB",
        "gender": "All",
        "nameInd": "Pelayan Kantor",
        "minAge": "0",
        "descriptionInd": "Memantau penggunaan peralatan dan perlengkapan di dalam kantor. Menjaga kebersihan peralatan kantor dan furnitur. Memantau pembersih eksternal. Membuat teh dan kopi untuk para tamu dan manajer. Menyiapkan alat-alat tulis untuk semua toko dan kantor pusat. Mengganti tinta printer. Membantu mengatur proyektor dan laptop. Mengarsip dokumen sesuai kebutuhan departemen. Mengumpulkan dan mendistribusikan paket untuk karyawan, menyortir surat. Memberikan fax. Melaminating dan menjilid dokumen sesuai permintaan. Membantu receptionis, sekretaris atau asisten administrasi lainnya dalam menjalankan tugas mereka.",
        "descriptionEng": "Monitoring the use of equipment and supplies within the office. Maintain cleanliness of office equipment and furniture. Monitoring the external cleaners. Making and serving tea and coffee to guests and managers. Prepare stationary for all shops and the head office. Change printer cartridges. Assist in board rooms to set up projector and laptop. Filing documents as per the department requirement. Collecting and distributing couriers or parcels among employees and opening and sorting emails. Delivering facsimiles and transmitting them. Laminating and binding documents as per the requests. Helping the receptionist, secretaries, or other administrative assistants in performing their duties.",
        "clazz": "2",
        "$$hashKey": "object:3933"
    },
    {
        "nameEng": "Order management",
        "code": "ORDR",
        "gender": "All",
        "nameInd": "Manajemen Pemesanan",
        "minAge": "0",
        "descriptionInd": "Spesialis Order Management (OMS) bertanggung jawab atas seluruh pesanan (pemrosesan order, penagihan) dan data pelangan termasuk membuat persyaratan dan tenggat waktu secara akurat dan tepat waktu.Juga bertanggung jawab atas proses penagihan, memberikan dukungan administratif utama untuk bagian penjualan dan klien.",
        "descriptionEng": "The Order Management Specialist (OMS) is responsible for the entire order life cycle (order processing, permissioning, and billing) while providing support to the account team and associated client base. This includes meeting requirements and deadlines in an accurate and timely manner, and ensuring customer satisfaction throughout the quote to billing process. Responsible for the quote to billing process, this function is the main administrative support role for sales and clients. The OMS takes actions to ensure all client positions are accurate for sales reporting, order and billing processing, and client management.",
        "clazz": "1",
        "$$hashKey": "object:3665"
    },
    {
        "nameEng": "Owner of Others",
        "code": "OWNR",
        "gender": "All",
        "nameInd": "Pemilik Usaha (Lainnya)",
        "minAge": "0",
        "descriptionInd": "Orang yang mempunyai perusahaan, memiliki peran manajer.",
        "descriptionEng": "A person who owns something. They are expected to play the role of manager, market researcher, accountant, and even receptionist. is one person (perhaps the founder); several people (perhaps family members, business partners, even investors).",
        "clazz": "2",
        "$$hashKey": "object:4070"
    },
    {
        "nameEng": "Packer (manufacturing)",
        "code": "PCKM",
        "gender": "All",
        "nameInd": "Pengepakan (Industri Manufaktur)",
        "minAge": "0",
        "descriptionInd": "Pekerja packing/pengemas melakukan pekerjaan sesuai dengan catatan dan mengindentifikasi produk di dalam gudang yang akan dikirim. Pekerja packing/pengemas  juga kadang-kadang terlibat dalam pekerjaan perakitan, karena banyak produk tidak sepenuhnya sudah dirakit. Mereka juga memuat dan membongkar truk, menurut Sistem Penanganan Material.",
        "descriptionEng": "Packing workers pull orders from packing slips and identify which products within the warehouse are to be shipped. Packing workers also sometimes engage in assembly work, since many products do not show up fully assembled. Packing workers also load and unload trucks, according to Systems Material Handling.",
        "clazz": "2",
        "$$hashKey": "object:4223"
    },
    {
        "nameEng": "Workshop assistant (construction)",
        "code": "WORK",
        "gender": "All",
        "nameInd": "Asisten Bengkel",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di bengkel yang memproduksi atau memasok alat-alat konstruksi.",
        "descriptionEng": "A person who work in the workshop that produces construction tool and supply.",
        "clazz": "2",
        "$$hashKey": "object:3422"
    },
    {
        "nameEng": "Packer (woodworking)",
        "code": "PCKW",
        "gender": "All",
        "nameInd": "Pengepakan Kerajinan Kayu",
        "minAge": "0",
        "descriptionInd": "Memotong kayu dan merancang potongan kayu menjadi kotak atau kerat dgn menggunakan peralatan manual atau alat listrik. Mengukur, menandai dan memotong papan menjadi ukuran ukuran tertentu dengan menggunakan pengukur, pensil dan gergaji mesin. Memasang dan memaku papan dengan menggunakan palu, stapler listrik atau mesin pemaku. Mendaur ulang  papan bekas dengan melepas paku dari papan dengan menggunakan palu, pencopot paku atau linggis dan memotong dengan gergaji listrik . Menyisipkan pengisi kardus, bantalan atau separator kayu ke kotak.",
        "descriptionEng": "Cuts lumber and assembles cut lumber into boxes and crates, using handtools or power tools. Measures, marks, and saws boards to specified size, using ruler, pencil, and power saws. Assembles and nails boards together, using hammer, power stapler, or nailing machine. Salvages used crating by removing nails from board with hammer, nail puller, or crowbar and by sawing ends with portable electric handsaw. May insert cardboard fillers, felt pads, and wooden separators in containers.",
        "clazz": "2",
        "$$hashKey": "object:4225"
    },
    {
        "nameEng": "Paralegal Assistant",
        "code": "PARA",
        "gender": "All",
        "nameInd": "Assistant Pengacara",
        "minAge": "0",
        "descriptionInd": "Membantu pengacara dengan melakukan penelitian soal legal, melakukan investigasi atau mempersiapkan dokumen legal. Mengatur penelitian untuk membantu proses hukum, memformulasikan pembelaan atau memprakarsai tindakan hukum.",
        "descriptionEng": "is Assist lawyers by researching legal precedent, investigating facts, or preparing legal documents. Conduct research to support a legal proceeding, to formulate a defense, or to initiate legal action.",
        "clazz": "2",
        "$$hashKey": "object:3441"
    },
    {
        "nameEng": "Passenger Services Assistant",
        "code": "PGSA",
        "gender": "All",
        "nameInd": "Petugas Bandara Udara",
        "minAge": "0",
        "descriptionInd": "Bertugas memastikan penumpang dan barang bawaannya berada di pesawat yang tepat . Kadang disebut asisten informator bandara, agen pelayanan pelanggan penerbangan atau asisten check in (melakukan pemeriksaan tiket dan paspor serta mencocokannya dengan daftar penumpang). Melakukan denda apabila penumpang membawa barang lebih dari yang ditentukan. Memberikan informasi penerbangan dan menuntun penumpang ke gerbang keberangkatan, membantu menjawab pertanyaan mengenai keterlambatan, ketinggalan atau pembatalan pesawat. Memeriksa tiket keberangkatan di depan gerbang.",
        "descriptionEng": "Is ensure that passengers, and their luggage, get on the right flight. They are sometimes called airport information assistant, airline customer service agent or check-in assistant. (checking their tickets and passports against the passenger list, allocating seats and giving out boarding cards and luggage labels, weighing luggage and charging the passenger extra if the luggage is overweight, giving flight information and directing passengers to departure gates, dealing with issues from delayed, cancelled or missed flights, checking boarding passes at the departure gate).",
        "clazz": "1",
        "$$hashKey": "object:4417"
    },
    {
        "nameEng": "Pastry chef",
        "code": "PAST",
        "gender": "All",
        "nameInd": "Juru Masak Kue",
        "minAge": "0",
        "descriptionInd": "Seorang koki  profesional, yang terampil dalam pembuatan kue kering, makanan penutup, roti dan makanan yang dipanggang lainnya.",
        "descriptionEng": "A station chef in a professional kitchen, skilled in the making of pastries, desserts, breads and other baked goods.",
        "clazz": "3",
        "$$hashKey": "object:3586"
    },
    {
        "nameEng": "Pawnbroker",
        "code": "PAWN",
        "gender": "All",
        "nameInd": "Makelar Gadai",
        "minAge": "0",
        "descriptionInd": "Adalah bisnis profesional yang mengkhususkan dirinya membeli barang berharga, memberikan pinjaman kepada orang lain  dengan barang jaminan dan ada yang menjalankan toko dengan menjual kembali barang jaminan yang tidak di tebus pemiliknya. Pemilik penggadaian harus ahli dalam menilai harga barang dan menilai pinjaman sesuai dengan harga jual barang tersebut.",
        "descriptionEng": "Is a business professional who specializes in buying merchandise of value, making loans to individuals using tangible property as collateral, and in some cases, running a storefront operation to resell collateral pieces not recovered by owners. A pawnbroker must be well-versed in appraising a wide range of merchandise and in negotiating appropriate sale and loan prices.",
        "clazz": "2",
        "$$hashKey": "object:3664"
    },
    {
        "nameEng": "Payroll clerk (clerical)",
        "code": "PYCL",
        "gender": "All",
        "nameInd": "Staff Penggajian",
        "minAge": "0",
        "descriptionInd": "Petugas  penggajian bertanggung jawab mengumpulkan informasi mengenai jam kerja karyawan, menggabungkan berbagai pemotongan kedalam gaji berkala dan mengeluarkan gaji dan informasi mengenai pembayaran gaji kepada karyawan.",
        "descriptionEng": "The payroll clerk position is accountable for collecting timekeeping information, incorporating a variety of deductions into a periodic payroll, and issuing pay and pay-related information to employees.",
        "clazz": "1",
        "$$hashKey": "object:4587"
    },
    {
        "nameEng": "Blue collar worker",
        "code": "PRSB",
        "gender": "All",
        "nameInd": "Karyawan Lepas",
        "minAge": "0",
        "descriptionInd": "Pekerja kelas bawah atau menengah.",
        "descriptionEng": "Considered anyone of lower and middle class. Working class.",
        "clazz": "2",
        "$$hashKey": "object:3596"
    },
    {
        "nameEng": "White collar worker",
        "code": "PRSW",
        "gender": "All",
        "nameInd": "Karyawan Umum",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas melakukan tugas kantor secara umum, atau pekerja yang melakukan pekerjaan serupa seperti penjualan secara retail (petugas penjual retail). Tanggung jawab pekerja tersebut biasanya mencakup pencatatan barang, pemasukan, menjaga counter dan tugas administratif lainnya.",
        "descriptionEng": "who conducts general office tasks, or a worker who performs similar sales-related tasks in a retail environment (a retail clerk). The responsibilities of clerical workers commonly include record keeping, filing, staffing service counters and other administrative tasks.",
        "clazz": "1",
        "$$hashKey": "object:3597"
    },
    {
        "nameEng": "Petroleum Engineer",
        "code": "PTRO",
        "gender": "All",
        "nameInd": "Ahli Perminyakan",
        "minAge": "0",
        "descriptionInd": "Menganalisa faktor teknis dan biaya untuk merencanakan metode untuk mengadakan pemulihan cadangan minyak dan gas di tambang, memanfaatkan pengetahuan dan tekhnologi terkait. Memeriksa peta dan lokasi gas reservoir untuk merekomendasikan penempatan sumur untuk memaksimalkan produksi yang ekonomis dari tempat penyimpanan.",
        "descriptionEng": "Analyzes technical and cost factors to plan methods to recover maximum oil and gas in oil-field operations, utilizing knowledge of petroleum engineering and related technologies: Examines map of subsurface oil and gas reservoir locations to recommend placement of wells to maximize economical production from reservoir.",
        "clazz": "3",
        "$$hashKey": "object:3373"
    },
    {
        "nameEng": "Philosopher",
        "code": "PHLO",
        "gender": "All",
        "nameInd": "Filsuf",
        "minAge": "0",
        "descriptionInd": "Pekerjaan dari seorang filsuf adalah untuk mempertanyakan pertanyaan terbesar dan misteri dalam kehidupan. Mereka secara terus menerus terlibat dengan pertanyaan mengenai moral. Spiritual dan pertanyaan secara universal.",
        "descriptionEng": "The job of the philosopher is to question lifes great questions and mysteries. They are continually engaged in the moral, spiritual, or universal questions that pertain to the human condition. The majority of philosophers will teach about certain areas of philosophy, and often work for colleges. Others will publish their own articles and books.",
        "clazz": "1",
        "$$hashKey": "object:3509"
    },
    {
        "nameEng": "Physiologist",
        "code": "PHSO",
        "gender": "All",
        "nameInd": "Ahli Fisiologi",
        "minAge": "0",
        "descriptionInd": "Seorang ahli fisiologi mempelajari makhluk hidup, sistem tubuh dan bagaimana bekerjanya. Biasanya mereka bekerja sebagai peneliti dan melakukan percobaan serta mengajar di perguruan tinggi.",
        "descriptionEng": "A physiologist studies living creatures, their bodily systems and how they function. Physiologists usually work as researchers and experiments or teachers in universities.",
        "clazz": "1",
        "$$hashKey": "object:3336"
    },
    {
        "nameEng": "Planner",
        "code": "PLAN",
        "gender": "All",
        "nameInd": "Perencana atau Perancang",
        "minAge": "0",
        "descriptionInd": "yang Melakukan berbagai perencanaan tugas dalam mendukung perluasan transportasi layanan daerah, akses, layanan koordinasi, dan proyek-proyek ridership; mempersiapkan berbagai dokumen perencanaan termasuk laporan analisis survei dan teknis serta melakukan melakukan tugas yang terkait sebagaimana ditugaskan",
        "descriptionEng": "are performs a variety of planning duties in support of District transportation service extensions, access, service coordination, and ridership projects; prepares a variety of planning documents including survey analysis reports and technical descriptions; and  performs related duties as assigned.",
        "clazz": "2",
        "$$hashKey": "object:4395"
    },
    {
        "nameEng": "Plant technician",
        "code": "PLTE",
        "gender": "All",
        "nameInd": "Teknisi Pabrik",
        "minAge": "0",
        "descriptionInd": "Adalah teknisi yang melakukan berbagai jenis pekerjaan, termasuk menjalankan alat konversi dan packing/kemas berkecepatan tinggi, mengontrol proses dari terminal komputer, dan melakukan perawatan peralatan tersebut.",
        "descriptionEng": "Is a technicians do various types of work, including running high�speed converting and packing equipment, controlling the process from a computer terminal, and performing preventive maintenance on equipment.",
        "clazz": "2",
        "$$hashKey": "object:4620"
    },
    {
        "nameEng": "Plantation Owner",
        "code": "PLTO",
        "gender": "All",
        "nameInd": "Pemilik Perkebunan",
        "minAge": "0",
        "descriptionInd": "Pemilik perkebunan mengatur properti mereka termasuk pada saat menanam dan panen serta mengatur semua operasi bisnisnya.",
        "descriptionEng": "A plantation owner manages each aspect of his property, including the planting and harvesting of agriculture as well as directing all business operations.",
        "clazz": "2",
        "$$hashKey": "object:4064"
    },
    {
        "nameEng": "Political Party",
        "code": "PTCP",
        "gender": "All",
        "nameInd": "Anggota Partai Politik",
        "minAge": "0",
        "descriptionInd": "Suatu organisasi politik yang biasa mencari pengaruh atau kontrol total, kebijakan pemerintah biasanya dengan cara menominasikan kandidat-kandidat yang berpandangan politik yang sama dan mencoba untuk menempatkan kandidat-kandidat tersebut dalam kantor politis.",
        "descriptionEng": "is a political organization that typically seeks to influence, or entirely control, government policy, usually by nominating candidates with aligned political views and trying to seat them in political office.",
        "clazz": "2",
        "$$hashKey": "object:3411"
    },
    {
        "nameEng": "Politician",
        "code": "PLTN",
        "gender": "All",
        "nameInd": "Politisi",
        "minAge": "0",
        "descriptionInd": "Orang yang berpengaruh dalam pembuatan keputusan dan kebijakan politik. Politis mencari posisi kuat yang memampukan mereka untuk mempengaruhi , menciptakan atau menegakan kebijakan pemerintah di tingkat lokal, negara bagian atau nasional.",
        "descriptionEng": "is a person who is involved in influencing public policy and decision making.  Politicians seek a position of power that enables them to influence, create or enforce government policy at the local, state or federal level.",
        "clazz": "3",
        "$$hashKey": "object:4514"
    },
    {
        "nameEng": "President",
        "code": "PSDT",
        "gender": "All",
        "nameInd": "Kepala Negara/ Kepala Pemerintahan",
        "minAge": "0",
        "descriptionInd": "Presiden bertanggung jawab dalam kepemimpinan strategis dalam suatu perusahaan dengan bekerja sama dengan dewan direksi dan manajemen lainnya untuk menciptakan tujuan-tujuan, strategi dan rencana serta kebijakan jangka panjang.",
        "descriptionEng": "The President is responsible for providing strategic leadership for the company by working with the Board and other management to establish long-range goals, strategies, plans, and policies.",
        "clazz": "2",
        "$$hashKey": "object:3606"
    },
    {
        "nameEng": "Production co-ordinator (Manufacturing)",
        "code": "PCOD",
        "gender": "All",
        "nameInd": "Koordinator Produksi",
        "minAge": "0",
        "descriptionInd": "Orang yang mengkoordinasikan semua kegiatan yang berkaitan dengan departemen perakitan dan produksi di sebuah organisasi.",
        "descriptionEng": "is the one who coordinates all the activities related to the manufacturing and the production department of any organization.",
        "clazz": "2",
        "$$hashKey": "object:3649"
    },
    {
        "nameEng": "Supermart sales assistant",
        "code": "SSAS",
        "gender": "All",
        "nameInd": "Petugas Supermarket",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja mengelola persediaan barang-barang di supermarket.",
        "descriptionEng": "A person who organize the supplies and goods in the supemarket.",
        "clazz": "2",
        "$$hashKey": "object:4496"
    },
    {
        "nameEng": "Professor",
        "code": "PROF",
        "gender": "All",
        "nameInd": "Profesor",
        "minAge": "0",
        "descriptionInd": "Biasanya dibagi menjadi Pengajar (mengikuti perkembangan-perkembangan terkini), riset (mencari pemecahan masalah yang sebelumnya tidak terselesaikan) dan Pelayanan (temasuk melayani berbagai kepanitiaan di departemen, perguruan tinggi dan kampus).",
        "descriptionEng": "are typically divided between teaching (keeping up to date with current advances), research (involve solving problems that were previously unsolved) , and service  (involve serving on various committees at the Department, college, campus).",
        "clazz": "1",
        "$$hashKey": "object:4524"
    },
    {
        "nameEng": "Project co-ordinator",
        "code": "PRCO",
        "gender": "All",
        "nameInd": "Koordinator Proyek",
        "minAge": "0",
        "descriptionInd": "Mengembangkan, mengatur, mengarahkan sistem yang didanai modal atau desain struktur dan proyek konstruksi untuk suatu distrik. Area proyek dapat termasuk pembelian dan perbaikan rail car, konstruksi dan perbaikan stasiun, penarikan tarif otomatis, desain dan konstruksi sistem dan struktur transit, mengkoordinasikan aktifitas proyek dan departemen atau divisi dan agensi external lainnya dan melakukan tugas terkait sesuai yang ditugaskan.",
        "descriptionEng": "is developing, manages and administers capitally funded system or structure engineering design and construction projects for the District; project areas may include rail car procurement and rehabilitation, stations construction and rehabilitation, automated fare collection, and transit systems and structures design and construction; coordinates project activities with other departments, divisions and external agencies and organizations; and performs related duties as assigned.",
        "clazz": "3",
        "$$hashKey": "object:3650"
    },
    {
        "nameEng": "Purchasing officer",
        "code": "PCOF",
        "gender": "All",
        "nameInd": "Staff Pembelian",
        "minAge": "0",
        "descriptionInd": "Seorang yang mengatur, menyusun dan secara langsung bertugas dalam pembelian materi, persediaan, jasa dan peralatan.",
        "descriptionEng": "a person who  plans, organizes, directs and personally participates in the purchasing of materials, supplies, services and equipment.",
        "clazz": "2",
        "$$hashKey": "object:4584"
    },
    {
        "nameEng": "QC checkers",
        "code": "QCCK",
        "gender": "All",
        "nameInd": "Petugas Quality Kontrol",
        "minAge": "0",
        "descriptionInd": "Adalah seseorang yang bertanggung jawab dalam melakukan pemeriksaan produk yang akan dipasarkan. Untuk memastikan bahwa kualitas produk dan dokumentasi yang dilakukan sesuai dengan standar prosedur operasional internal.",
        "descriptionEng": "Quality Control Checker is a person who responsible for performing all defined quality checks of products exiting. To confirm that product quality and associated batch documentation are of the required standard to comply with internal Standard Operating Procedures.",
        "clazz": "2",
        "$$hashKey": "object:4485"
    },
    {
        "nameEng": "Ranch Owner",
        "code": "RNCH",
        "gender": "All",
        "nameInd": "Pemilik Peternakan",
        "minAge": "0",
        "descriptionInd": "Orang yang memiliki dan mengatur operasional dari suatu peternakan.",
        "descriptionEng": "The person who owns and manages the operation of a ranch.",
        "clazz": "2",
        "$$hashKey": "object:4066"
    },
    {
        "nameEng": "Ranch Worker",
        "code": "RNCW",
        "gender": "All",
        "nameInd": "Pekerja Peternakan",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja sebagai pekerja peternakan atau pertanian, bervariasi sesuai dengan jenis pertanian dan musim, pekerja tanaman, pemanen dengan tangan atau menggunakan mesin. Mengemudi atau mengoperasikan mesin pertanian untuk membajak, menanam, mengolah tanah atau panen. Atau menanam benih atau bibit dengan menggunakan tangan.",
        "descriptionEng": "Duties of farm and ranch workers vary with the type of farm and the seasons. The workers plant or harvest by hand or use machines. Drive or operate farm equipment to plow, plant, cultivate, or harvest crops. May plant seeds or transplant seedlings by hand.",
        "clazz": "3",
        "$$hashKey": "object:3897"
    },
    {
        "nameEng": "Retired",
        "code": "RETI",
        "gender": "All",
        "nameInd": "Pensiunan",
        "minAge": "0",
        "descriptionInd": "Pensiunan.",
        "descriptionEng": "someone who is not working anymore because of his age is advanced and must be dismissed, or at his own request (young pension)",
        "clazz": "1",
        "$$hashKey": "object:4341"
    },
    {
        "nameEng": "Rework technician",
        "code": "REWK",
        "gender": "All",
        "nameInd": "Teknisi Pengolah",
        "minAge": "0",
        "descriptionInd": "Manajemen senior perusahaan menerapkan prosedur pengendalian untuk memastikan kualitas produk dan proses berjalan efektif dalam kegiatan operasional. Rework technician bertugas membantu top manajemen meningkatkan kegiatan operasional perusahaan dan penawaran produk dalam jangka pendek dan jangka panjang.",
        "descriptionEng": "A company's senior management implements adequate and functional control procedures to ensure product quality and process effectiveness in operating activities. Rework technicians help top executives improve operating activities and product offerings in the short and long term.",
        "clazz": "3",
        "$$hashKey": "object:4629"
    },
    {
        "nameEng": "Sales manager",
        "code": "SLSM",
        "gender": "All",
        "nameInd": "Manajer Pemasaran",
        "minAge": "0",
        "descriptionInd": "Manajer Penjualan adalah sebutan untuk seseorang yang berperan dalam manajemen penjualan. Manajemen penjualan adalah disiplin bisnis yang berfokus pada penerapan praktis dari teknik penjualan dan manajemen operasional penjualan di perusahaan.",
        "descriptionEng": "Sales manager is the typical title of someone whose role is sales management. Sales management is a business discipline which is focused on the practical application of sales techniques and the management of a firm's sales operations.",
        "clazz": "2",
        "$$hashKey": "object:3691"
    },
    {
        "nameEng": "Others Class 1",
        "code": "OTC1",
        "gender": "All",
        "nameInd": "Pekerja Lainnya Kelas 1",
        "minAge": "0",
        "descriptionInd": "Pekerja Lainnya Kelas 1",
        "descriptionEng": "Other jobs are 1st class",
        "clazz": "1",
        "$$hashKey": "object:3872"
    },
    {
        "nameEng": "Sales order assistant",
        "code": "SLOA",
        "gender": "All",
        "nameInd": "Staff Pemesanan Penjualan",
        "minAge": "0",
        "descriptionInd": "Orang yang mengambil pesanan barang yang dikeluarkan oleh sebuah perusahaan kepada pelanggannya. Pesanan bisa berupa barang atau jasa.",
        "descriptionEng": "A person who take a sales order issued by a business to a customer. A sales order may be for products and/or services.",
        "clazz": "2",
        "$$hashKey": "object:4585"
    },
    {
        "nameEng": "School Principal",
        "code": "SCOP",
        "gender": "All",
        "nameInd": "Kepala Sekolah",
        "minAge": "0",
        "descriptionInd": "Kepala sekolah adalah guru yang paling senior, pemimpin dan pengelola sekolah.",
        "descriptionEng": "is the most senior teacher, leader and manager of a school.",
        "clazz": "1",
        "$$hashKey": "object:3616"
    },
    {
        "nameEng": "Scraper driver",
        "code": "SCRD",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Truk Pengeruk",
        "minAge": "0",
        "descriptionInd": "Orang yang ahli mengemudikan scraper. Scraper adalah alat berat yang digunakan untuk memindahkan tanah.",
        "descriptionEng": "A person who drives a scraper. Scraper is a piece of heavy equipment used for earthmoving.",
        "clazz": "3",
        "$$hashKey": "object:4203"
    },
    {
        "nameEng": "Sea freight operation assistant",
        "code": "SFOA",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Angkutan Laut (Penumpang dan Kargo)",
        "minAge": "0",
        "descriptionInd": "Orang yang mengemudikan dan mengoperasikan angkutan laut. Angkutan laut adalah kapal yang digunakan untuk mengangkut penumpang atau barang kargo.",
        "descriptionEng": "A person who operates and drives sea freight. Sea freight is a ship that used to transport people or cargo.",
        "clazz": "3",
        "$$hashKey": "object:4189"
    },
    {
        "nameEng": "Shipping clerk",
        "code": "SHCL",
        "gender": "All",
        "nameInd": "Pegawai Perkapalan",
        "minAge": "0",
        "descriptionInd": "Orang yang bertugas untuk mengatur, menerima, membuat catatan dan mengirimkan barang barang perusahaan dengan angkutan laut.",
        "descriptionEng": "a person employed by a company to arrange, receive, record, and send shipments of goods.",
        "clazz": "2",
        "$$hashKey": "object:3854"
    },
    {
        "nameEng": "Skilled pipe fitter (Other)",
        "code": "SPFT",
        "gender": "All",
        "nameInd": "Mekanik Pipa (Lainnya)",
        "minAge": "0",
        "descriptionInd": "Adalah pekerja industri yang bekerja merencanakan, merakit, memelihara dan memperbaiki sistem pipa mekanik.",
        "descriptionEng": "is a tradesperson who lays out, assembles, fabricates, maintains and repairs mechanical piping systems.",
        "clazz": "3",
        "$$hashKey": "object:3736"
    },
    {
        "nameEng": "Specialist Doctor",
        "code": "SPDO",
        "gender": "All",
        "nameInd": "Dokter Spesialis",
        "minAge": "0",
        "descriptionInd": "Seorang dokter yang mengkhususkan diri dalam bidang tertentu di pengobatan medis.",
        "descriptionEng": "A medical doctor who specialize in a specific field in medical treatment.",
        "clazz": "2",
        "$$hashKey": "object:3491"
    },
    {
        "nameEng": "Sport complex assistant",
        "code": "SPOR",
        "gender": "All",
        "nameInd": "Petugas Kebersihan Kompleks Olahraga",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja sebagai penjaga sanitasi dan kebersihan suatu komplek olahraga. Sebuah komplek olah raga adalah sekelompok fasilitas olah raga. Misalnya ada stadion untuk sepakbola dan atletik, stadion bisbol, kolam renang, gimnasium. Daerah ini merupakan komplek olah raga.",
        "descriptionEng": "A person who maintain a sanitation and hygiene in sport complex. A sports complex is a group of sports facilities. For example, there are stadiums for athletic and football, baseball stadiums, swimming pools, gymnasiums. This area is a sports complex.",
        "clazz": "2",
        "$$hashKey": "object:4436"
    },
    {
        "nameEng": "Technician (Other)",
        "code": "TECH",
        "gender": "All",
        "nameInd": "Teknisi (Lainnya)",
        "minAge": "0",
        "descriptionInd": "Pekerja di bidang teknologi yang mahir serta memiliki kemampuan keterampilan dan teknik tertentu, sekaligus pemahaman yang yang baik atas prinsip teoritis.",
        "descriptionEng": "is a worker in a field of technology who is proficient in the relevant skills and techniques, with a relatively practical understanding of the theoretical principles.",
        "clazz": "2",
        "$$hashKey": "object:4599"
    },
    {
        "nameEng": "Telemarketer / E-marketer",
        "code": "TELE",
        "gender": "All",
        "nameInd": "Marketing Tele (By Phone/ WEB)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang menjual produk baik melalui telepon atau situs penjualan, ataupun bertemu langsung setelah perjanjian melalui telepon sebelumnya.",
        "descriptionEng": "A person who sell a product either over the phone or through a subsequent face to face or Web conferencing appointment scheduled during the call.",
        "clazz": "1",
        "$$hashKey": "object:3723"
    },
    {
        "nameEng": "Ticketing -tour executive",
        "code": "TICK",
        "gender": "All",
        "nameInd": "Petugas Tiketing Tur Perjalanan",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengelola tata cara pembelian tiket pada agen perjalanan.",
        "descriptionEng": "A person who manages ticket buying procedure and work in travelling agencies.",
        "clazz": "2",
        "$$hashKey": "object:4501"
    },
    {
        "nameEng": "Toolsetter (Manufacturing)",
        "code": "TOOL",
        "gender": "All",
        "nameInd": "Pekerja Penguji Perkakas",
        "minAge": "0",
        "descriptionInd": "Seseorang yang menguji coba barang sebelum menjalankan produksi sepenuhnya dalam suatu industri.",
        "descriptionEng": "A person who perform a trial run before a full production run in industry.",
        "clazz": "3",
        "$$hashKey": "object:3889"
    },
    {
        "nameEng": "Tradenet clerk",
        "code": "TRAD",
        "gender": "All",
        "nameInd": "Admin E-Commerce",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengelola sistem yang dapat diakses secara umum, di mana melalui sistem tersebut orang-orang dapat melakukan proses penjualan, pembelian, mencari maupun menegosiasikan suatu barang dan jasa.",
        "descriptionEng": "A person who manages the system which universally accessible chat wherein people sometimes sell, purchase, seek and talk about goods, services and items (Such as kaskus).",
        "clazz": "1",
        "$$hashKey": "object:3314"
    },
    {
        "nameEng": "Traders (Stock)",
        "code": "TDRS",
        "gender": "All",
        "nameInd": "Trader di Bursa Saham",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertanggung jawab dalam menentukan harga dan melaksanakan perdagangan dalam ekuitas, obligasi, komoditas dan bursa luar negeri; pekerjaannya berurusan dengan tujuan untuk keuntungan pada suatu investasi bank.",
        "descriptionEng": "A person whose responsible for making prices and executing trades in equities, bonds, commodities and foreign exchanges, dealing on behalf of or for the benefit of investment banks.",
        "clazz": "2",
        "$$hashKey": "object:4651"
    },
    {
        "nameEng": "Trainer",
        "code": "TRNR",
        "gender": "All",
        "nameInd": "Trainer",
        "minAge": "0",
        "descriptionInd": "Orang yang melengkapi staff dengan pengetahuan, ketrampilan dan motivasi untuk melakukan tugas yang berkaitan dengan pekerjaan.",
        "descriptionEng": "A person who equip staff with the knowledge, practical skills and motivation to carry out work-related tasks.",
        "clazz": "2",
        "$$hashKey": "object:4652"
    },
    {
        "nameEng": "Transhipment export officer",
        "code": "TECO",
        "gender": "All",
        "nameInd": "Petugas Ekspor Barang",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengelola transportasi barang yang baru datang dari luar negeri.",
        "descriptionEng": "A person who manages the transportation of goods which just came from outside the country.",
        "clazz": "1",
        "$$hashKey": "object:4421"
    },
    {
        "nameEng": "Transport (lorry/bus) managers",
        "code": "TRAM",
        "gender": "All",
        "nameInd": "Manajemen Transportasi (Bus)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengatur jadwal kedatangan maupun keberangkatan bus, dan mengatur kapasitas penumpangnya.",
        "descriptionEng": "A person who manages the schedule when the bus is leaving or coming and how many passangers to take etc.",
        "clazz": "2",
        "$$hashKey": "object:3666"
    },
    {
        "nameEng": "Trichologist",
        "code": "TRIC",
        "gender": "All",
        "nameInd": "Ahli Kesehatan Rambut",
        "minAge": "0",
        "descriptionInd": "Seseorang yang pekerjaannya berkaitan dengan urusan rambut dan penyakitnya, serta mengkhususkan diri dalam perawatan rambut dan kulit kepala.",
        "descriptionEng": "the branch of medicine concerned with the hair and its diseases. A person who specializes in hair and scalp care.",
        "clazz": "2",
        "$$hashKey": "object:3353"
    },
    {
        "nameEng": "Tyre fitter",
        "code": "TYRE",
        "gender": "All",
        "nameInd": "Tukang Ban",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memperbaiki kerusakan ban, menyesuaikan dan menyeimbangkan ban-ban pada suatu kendaraan.",
        "descriptionEng": "Tyre fitters repair damage to tyres and fit and balance new tyres to vehicles.",
        "clazz": "2",
        "$$hashKey": "object:4655"
    },
    {
        "nameEng": "Unemployed",
        "code": "UNEM",
        "gender": "All",
        "nameInd": "Pengangguran atau Tidak Bekerja",
        "minAge": "0",
        "descriptionInd": "Seseorang yang tidak bekerja.",
        "descriptionEng": "A person don�t has a job.",
        "clazz": "3",
        "$$hashKey": "object:4142"
    },
    {
        "nameEng": "Vice President",
        "code": "VIPE",
        "gender": "All",
        "nameInd": "Wakil Kepala Negara",
        "minAge": "0",
        "descriptionInd": "Seseorang yang berkedudukan sebagai wakil presiden.",
        "descriptionEng": "an officer ranking immediately below a president and serving as his deputy.",
        "clazz": "2",
        "$$hashKey": "object:4713"
    },
    {
        "nameEng": "Village Chief/Headman/Prince",
        "code": "VILL",
        "gender": "All",
        "nameInd": "Kepala desa / Lurah / Pemimpin",
        "minAge": "0",
        "descriptionInd": "Seorang yang ditunjuk oleh pemerintah pusat untuk mengatur suatu bagian negara atau wilayah tertentu.",
        "descriptionEng": "is a central government post who manages a country or a region.",
        "clazz": "2",
        "$$hashKey": "object:3601"
    },
    {
        "nameEng": "Ambassador",
        "code": "AMBS",
        "gender": "All",
        "nameInd": "Duta Besar",
        "minAge": "0",
        "descriptionInd": "Pejabat diplomatik yang ditunjuk sebagai perwakilan negaranya pada suatu negara tertentu selama kurun waktu tertentu.",
        "descriptionEng": "A diplomatic official of the highest rank appointed and accredited as representative in residence by one government or sovereign to another, usually for a specific length of time.",
        "clazz": "2",
        "$$hashKey": "object:3496"
    },
    {
        "nameEng": "Stockholder",
        "code": "STOK",
        "gender": "All",
        "nameInd": "Pemegang Saham",
        "minAge": "0",
        "descriptionInd": "Seseorang yang memiliki saham dalam suatu perusahaan.",
        "descriptionEng": "One who owns a share or shares of stock in a company.",
        "clazz": "1",
        "$$hashKey": "object:4051"
    },
    {
        "nameEng": "Non Student",
        "code": "NSTN",
        "gender": "All",
        "nameInd": "Bukan Pelajar atau Mahasiswa",
        "minAge": "0",
        "descriptionInd": "Tertanggung dengan usia antara 1 sampai dengan 15 tahun usia ulang tahun selanjutnya, dan tidak/ belum bersekolah",
        "descriptionEng": "Insured with ages between 1 and 15 years of next birthday, and not / do not attend school",
        "clazz": "1",
        "$$hashKey": "object:3453"
    },
    {
        "nameEng": "Clerk of Court",
        "code": "CROK",
        "gender": "All",
        "nameInd": "Pegawai kejaksaan/kehakiman",
        "minAge": "0",
        "descriptionInd": "Pegawai kejaksaan/kehakiman",
        "descriptionEng": "Clerk of Court",
        "clazz": "2",
        "$$hashKey": "object:3842"
    },
    {
        "nameEng": "commissioner of State Own Company",
        "code": "CMSO",
        "gender": "All",
        "nameInd": "Komisaris BUMN",
        "minAge": "0",
        "descriptionInd": "Seorang sebagai komisaris memiliki negara",
        "descriptionEng": "commissioner of State Own Company",
        "clazz": "1",
        "$$hashKey": "object:3628"
    },
    {
        "nameEng": "Dean",
        "code": "DEAN",
        "gender": "All",
        "nameInd": "Dekan",
        "minAge": "0",
        "descriptionInd": "Seorang yang berjabatan di bawah Rektor atas lembaga pendidikan",
        "descriptionEng": "The head of a college or university faculty or department",
        "clazz": "1",
        "$$hashKey": "object:3468"
    },
    {
        "nameEng": "Director State Own Company",
        "code": "DSOC",
        "gender": "All",
        "nameInd": "Direktur Utama BUMN",
        "minAge": "0",
        "descriptionInd": "Seorang direktur dari badan usaha milik negara (BUMN)",
        "descriptionEng": "Director State Own Company",
        "clazz": "1",
        "$$hashKey": "object:3480"
    },
    {
        "nameEng": "Enterpreneur in Art and Antiques",
        "code": "ENAA",
        "gender": "All",
        "nameInd": "Pengusaha di bidang seni dan barang antik",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha yang bergerak di bidang seni dan barang antik",
        "descriptionEng": "Enterpreneur in Art and Antiques",
        "clazz": "2",
        "$$hashKey": "object:4280"
    },
    {
        "nameEng": "Enterpreneur in Export/Import  Natural Resources",
        "code": "ENNR",
        "gender": "All",
        "nameInd": "Pengusaha di bidang pengiriman barang keluar negeri dan pengiriman barang ke dalam negeri dalam bentuk sumber daya alam",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha yang bergerak di bidang pengiriman barang keluar negeri dan pengiriman barang ke dalam negeri dalam bentuk sumber daya alam",
        "descriptionEng": "Enterpreneur in Export/Import  Natural Resources",
        "clazz": "2",
        "$$hashKey": "object:4278"
    },
    {
        "nameEng": "Enterpreneur in Forestry",
        "code": "ENFO",
        "gender": "All",
        "nameInd": "Pengusaha di bidang perhutanan",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha bergerak di bidang perhutanan",
        "descriptionEng": "Enterpreneur in Forestry",
        "clazz": "2",
        "$$hashKey": "object:4279"
    },
    {
        "nameEng": "Enterpreneur in Freight Forwarding",
        "code": "ENFF",
        "gender": "All",
        "nameInd": "Pengusaha Pengiriman Barang dalam & luar negeri",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha yang bergerak di bidang pengiriman barang keluar negeri dan pengiriman barang ke dalam negeri",
        "descriptionEng": "Enterpreneur in Freight Forwarding",
        "clazz": "2",
        "$$hashKey": "object:4283"
    },
    {
        "nameEng": "Enterpreneur in Fuel Station",
        "code": "ENFS",
        "gender": "All",
        "nameInd": "Pengusaha SPBU",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha yang bergerak di bidang SPBU",
        "descriptionEng": "Enterpreneur in Fuel Station",
        "clazz": "2",
        "$$hashKey": "object:4285"
    },
    {
        "nameEng": "Enterpreneur in Gems and Jewelery Trading",
        "code": "ENGJ",
        "gender": "All",
        "nameInd": "Pengusaha / Penjual berlian,perhiasan, dan emas",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha yang bergerak di bidang penjualan berlian,perhiasan, dan emas",
        "descriptionEng": "Enterpreneur in Gems and Jewelery Trading",
        "clazz": "2",
        "$$hashKey": "object:4277"
    },
    {
        "nameEng": "Enterpreneur in Gold/Precious metal Invesment",
        "code": "ENGI",
        "gender": "All",
        "nameInd": "Investastor Emas",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha yang bergerak di bidang investasi Emas",
        "descriptionEng": "Enterpreneur in Gold/Precious metal Invesment",
        "clazz": "2",
        "$$hashKey": "object:3573"
    },
    {
        "nameEng": "Enterpreneur in Luxurious Vehicle Dealer",
        "code": "ENLV",
        "gender": "All",
        "nameInd": "Pengusaha kendaraan mewah (mobil,kapal,jet pribadi)",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha di bidang kendaraan mewah (mobil,kapal,jet pribadi)",
        "descriptionEng": "Enterpreneur in Luxurious Vehicle Dealer",
        "clazz": "2",
        "$$hashKey": "object:4281"
    },
    {
        "nameEng": "Enterpreneur in Minimarket/supermarket",
        "code": "ENMS",
        "gender": "All",
        "nameInd": "Pemilik supermarket atau minimarket",
        "minAge": "0",
        "descriptionInd": "Seorang yang memiliki supermarket atau minimarket",
        "descriptionEng": "Enterpreneur in Minimarket/supermarket",
        "clazz": "2",
        "$$hashKey": "object:4067"
    },
    {
        "nameEng": "Enterpreneur in Money Changer",
        "code": "ENMC",
        "gender": "All",
        "nameInd": "Pengusaha tukar uang mata uang asing",
        "minAge": "0",
        "descriptionInd": "Seorang yang memiliki usaha di bidang tukar uang mata uang asing",
        "descriptionEng": "Enterpreneur in Money Changer",
        "clazz": "2",
        "$$hashKey": "object:4287"
    },
    {
        "nameEng": "Enterpreneur in Money Transfer",
        "code": "ENMT",
        "gender": "All",
        "nameInd": "Jasa Pengirim Bidang Keuangan",
        "minAge": "0",
        "descriptionInd": "Seorang yang memiliki usaha jasa pengiriman uang",
        "descriptionEng": "Enterpreneur in Money Transfer",
        "clazz": "2",
        "$$hashKey": "object:3575"
    },
    {
        "nameEng": "Enterpreneur in Parking Business",
        "code": "ENPB",
        "gender": "All",
        "nameInd": "Pengusaha Lahan Parkir",
        "minAge": "0",
        "descriptionInd": "Seorang yang yang memiliki usaha di bidang lahan parkir",
        "descriptionEng": "Enterpreneur in Parking Business",
        "clazz": "2",
        "$$hashKey": "object:4282"
    },
    {
        "nameEng": "Enterpreneur in Property Selling/Property Agent",
        "code": "ENPS",
        "gender": "All",
        "nameInd": "Pengusaha Property",
        "minAge": "0",
        "descriptionInd": "Seorang yang pengusaha di bidang jual beli property",
        "descriptionEng": "Enterpreneur in Property Selling/Property Agent",
        "clazz": "2",
        "$$hashKey": "object:4284"
    },
    {
        "nameEng": "Enterpreneur in Travel Agent",
        "code": "ENTA",
        "gender": "All",
        "nameInd": "Pengusaha Travel",
        "minAge": "0",
        "descriptionInd": "Seorang pengusaha di bidang travel agen",
        "descriptionEng": "Enterpreneur in Travel Agent",
        "clazz": "2",
        "$$hashKey": "object:4286"
    },
    {
        "nameEng": "Financial Institutions Employees",
        "code": "FICE",
        "gender": "All",
        "nameInd": "Karyawan yang bekerja di lembaga keuangan",
        "minAge": "0",
        "descriptionInd": "Seorang karyawan yang bekerja di lembaga keuangan",
        "descriptionEng": "Financial Institutions Employees",
        "clazz": "1",
        "$$hashKey": "object:3598"
    },
    {
        "nameEng": "Governor",
        "code": "GVRN",
        "gender": "All",
        "nameInd": "Gubernur",
        "minAge": "0",
        "descriptionInd": "Gubernur",
        "descriptionEng": "Governor",
        "clazz": "2",
        "$$hashKey": "object:3516"
    },
    {
        "nameEng": "Head of Office in Ministry of Finance",
        "code": "HOMI",
        "gender": "All",
        "nameInd": "Semua Kepala kantor di lingkungan Kementrian keuangan",
        "minAge": "0",
        "descriptionInd": "Semua Kepala kantor di lingkungan Kementrian keuangan",
        "descriptionEng": "Head of Office in Ministry of Finance",
        "clazz": "2",
        "$$hashKey": "object:4544"
    },
    {
        "nameEng": "Head of State Commission",
        "code": "HSCM",
        "gender": "All",
        "nameInd": "Pimpinan instansi pemerintah yang independen (contoh:Pimpinan Komnas ham,KPU,Bawaslu)",
        "minAge": "0",
        "descriptionInd": "Pimpinan instansi pemerintah yang independen (contoh:Pimpinan Komnas ham,KPU,Bawaslu)",
        "descriptionEng": "Head of State Commission",
        "clazz": "2",
        "$$hashKey": "object:4510"
    },
    {
        "nameEng": "Investigator in Customs",
        "code": "ICOS",
        "gender": "All",
        "nameInd": "Penyidik Bea Cukai",
        "minAge": "0",
        "descriptionInd": "Seorang yang bekerja sebagai penyidik di bea cukai",
        "descriptionEng": "Investigator in Customs",
        "clazz": "2",
        "$$hashKey": "object:4365"
    },
    {
        "nameEng": "Investigator in Tax",
        "code": "ITAX",
        "gender": "All",
        "nameInd": "Penyidik Perpajakan",
        "minAge": "0",
        "descriptionInd": "Seorang yang bekerja sebagai penyidik perpajakan",
        "descriptionEng": "Investigator in Tax",
        "clazz": "2",
        "$$hashKey": "object:4366"
    },
    {
        "nameEng": "Mayor",
        "code": "MAYR",
        "gender": "All",
        "nameInd": "Walikota",
        "minAge": "0",
        "descriptionInd": "Walikota",
        "descriptionEng": "Mayor",
        "clazz": "2",
        "$$hashKey": "object:4716"
    },
    {
        "nameEng": "Member of \"Badan Pemeriksa Keuangan(BPK)\"",
        "code": "MBPK",
        "gender": "All",
        "nameInd": "Anggota Badan Pemeriksa Keuangan (BPK)",
        "minAge": "0",
        "descriptionInd": "Seorang anggota Badan Pemeriksa Keuangan",
        "descriptionEng": "Member of \"Badan Pemeriksa Keuangan(BPK)\"",
        "clazz": "2",
        "$$hashKey": "object:3403"
    },
    {
        "nameEng": "Member of \"Dewan Gubernur Bank Indonesia(BI)\"",
        "code": "MGBI",
        "gender": "All",
        "nameInd": "Anggota Dewan Gubernur Bank Indonesia",
        "minAge": "0",
        "descriptionInd": "Seorang anggota Dewan Gubernur Bank Indonesia",
        "descriptionEng": "Member of \"Dewan Gubernur Bank Indonesia(BI)\"",
        "clazz": "1",
        "$$hashKey": "object:3404"
    },
    {
        "nameEng": "Member of \"Dewan Komisioner Otoritas Jasa Keuangan(OJK)\"",
        "code": "MOJK",
        "gender": "All",
        "nameInd": "Anggota Dewan komisioner Otoritas Jasa Keuangan",
        "minAge": "0",
        "descriptionInd": "Seorang anggota Dewan komisioner Otoritas Jasa Keuangan",
        "descriptionEng": "Member of \"Dewan Komisioner Otoritas Jasa Keuangan(OJK)\"",
        "clazz": "1",
        "$$hashKey": "object:3405"
    },
    {
        "nameEng": "Member of \"Dewan Pertimbangan Presiden\"",
        "code": "MDPP",
        "gender": "All",
        "nameInd": "Anggota dewan Pertimbangan Presiden",
        "minAge": "0",
        "descriptionInd": "Seorang anggota dewan Pertimbangan Presiden",
        "descriptionEng": "Member of \"Dewan Pertimbangan Presiden\"",
        "clazz": "1",
        "$$hashKey": "object:3406"
    },
    {
        "nameEng": "Member of \"Komisi Yudisial (KY)\"",
        "code": "MOKY",
        "gender": "All",
        "nameInd": "Anggota komisi yudisial",
        "minAge": "0",
        "descriptionInd": "Seorang anggota komisi yudisial",
        "descriptionEng": "Member of \"Komisi Yudisial (KY)\"",
        "clazz": "1",
        "$$hashKey": "object:3407"
    },
    {
        "nameEng": "Rector (education)",
        "code": "RCTR",
        "gender": "All",
        "nameInd": "Rektor (Pendidikan)",
        "minAge": "0",
        "descriptionInd": "Seorang Rektor dari lembaga pendidikan",
        "descriptionEng": "Rector",
        "clazz": "1",
        "$$hashKey": "object:4534"
    },
    {
        "nameEng": "Regent",
        "code": "RGNT",
        "gender": "All",
        "nameInd": "Bupati",
        "minAge": "0",
        "descriptionInd": "Bupati",
        "descriptionEng": "Regent",
        "clazz": "2",
        "$$hashKey": "object:3454"
    },
    {
        "nameEng": "Treasurer Govement Project",
        "code": "TRGO",
        "gender": "All",
        "nameInd": "Bendahara Pemerintah",
        "minAge": "0",
        "descriptionInd": "Seorang yang bekerja sebagai bendaharawan pemerintah dalam suatu proyek pemerintah",
        "descriptionEng": "Treasurer Govement Project",
        "clazz": "2",
        "$$hashKey": "object:3446"
    },
    {
        "nameEng": "Vice Governor",
        "code": "VGVR",
        "gender": "All",
        "nameInd": "Wakil Gubernur",
        "minAge": "0",
        "descriptionInd": "Seorang menjabat sebagai wakil Gubernur",
        "descriptionEng": "Vice Governor",
        "clazz": "2",
        "$$hashKey": "object:4712"
    },
    {
        "nameEng": "Policeman",
        "code": "POLM",
        "gender": "All",
        "nameInd": "Polisi",
        "minAge": "0",
        "descriptionInd": "Yang bertugas dalam menjaga keamanan, penegak hukum, melindungi masyarakat dan harta benda serta melakukan investigasi kejahatan.",
        "descriptionEng": "Is typical duties relate to keeping the peace, law enforcement, protection of people and property, and the investigation of crimes.",
        "clazz": "3",
        "$$hashKey": "object:4512"
    },
    {
        "nameEng": "Army",
        "code": "ARMY",
        "gender": "All",
        "nameInd": "Tentara",
        "minAge": "0",
        "descriptionInd": "Orang yang berada di basis militer dan berjuang untuk bangsa, berkaitan dengan angkatan bersenjata.",
        "descriptionEng": "One who fights for the nation being in the military force-land based.Related to Armed Forces.",
        "clazz": "3",
        "$$hashKey": "object:4645"
    },
    {
        "nameEng": "Diver (commercial military)",
        "code": "DIVE",
        "gender": "All",
        "nameInd": "Juru Selam (Militer)",
        "minAge": "0",
        "descriptionInd": "Berhubungan dengan angkatan bersenjata tetapi pekerjaannya mirip dengan orang yang melakukan penyelaman komersial.",
        "descriptionEng": "Linked with the Armed Forces but job is parallel to someone in Commercial Diving and acts are almost similar.",
        "clazz": "3",
        "$$hashKey": "object:3587"
    },
    {
        "nameEng": "Manager - surface (mining)",
        "code": "MGRS",
        "gender": "All",
        "nameInd": "Manajer Pertambangan (Permukaan Tanah)",
        "minAge": "0",
        "descriptionInd": "Manajer yang mengelola pertambangan (termasuk jalur pertambangan, pertambangan puncak gunung) di mana kategori dari pekerjaan ini antara lain memindahkan tanah dan batu yang melapisi mineral (lapisan penutup).",
        "descriptionEng": "Surface mining, including strip mining, open-pit mining and mountaintop removal mining, is a broad category of mining in which soil and rock overlying the mineral deposit (the overburden) are removed. A person in charge of managing such a task.",
        "clazz": "1",
        "$$hashKey": "object:3698"
    },
    {
        "nameEng": "Manager - underground (mining)",
        "code": "MGRU",
        "gender": "All",
        "nameInd": "Manajer Pertambangan (Bawah Tanah)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang mengelola penambangan bawah tanah yang mengacu pada sekelompok teknik penambangan bawah tanah yang digunakan untuk mengekstrak mineral dan logam dari bawah tanah seperti batu bara atau biji emas/perak.",
        "descriptionEng": "Underground mining refers to a group of underground mining techniques used to extract minerals and metals from underground like coal or gold/silver ores. A person in charge of managing such a task.",
        "clazz": "3",
        "$$hashKey": "object:3697"
    },
    {
        "nameEng": "Manager (quarrying)",
        "code": "MGRQ",
        "gender": "All",
        "nameInd": "Manajer Tambang",
        "minAge": "0",
        "descriptionInd": "Mengawasi dan mengkoordinasikan pekerja yang terlibat dalam peleburan dan penghancuran biji mineral di tambang terbuka. Merencanakan lokasi dan pengeboran lubang ledakan serta memastikan ekstrasi biji maksimum. Memantau tersedianya akses jalan bagi truk yang mengangkut biji dari tambang.",
        "descriptionEng": "Supervises and coordinates activities of workers engaged in blasting, removing, and crushing mineral ores in open-pit mines: Plans location and drilling of blast holes to ensure maximum extraction of ore and provide access roads for trucking ores out of mine.",
        "clazz": "2",
        "$$hashKey": "object:3706"
    },
    {
        "nameEng": "National services man **",
        "code": "NSVC",
        "gender": "All",
        "nameInd": "Wajib Militer",
        "minAge": "0",
        "descriptionInd": "Adalah seorang tentara yang tergabung dalam angkatan perang dari suatu negara.",
        "descriptionEng": "Is a soldier belonging to the armed forces of a country.",
        "clazz": "3",
        "$$hashKey": "object:4710"
    },
    {
        "nameEng": "Packer (mining)",
        "code": "PCKN",
        "gender": "All",
        "nameInd": "Pengepakan (Pertambangan)",
        "minAge": "0",
        "descriptionInd": "Dari membangun jalanan serta mengembangkan areal tambang. Orang yang bekerja di divisi pertambangan mengambil sumber alam yang diperlukan.",
        "descriptionEng": "From building roads and developing mine sites, the folks who work in Mining division literally make the earth move to get at the resources the world needs to operate.",
        "clazz": "3",
        "$$hashKey": "object:4224"
    },
    {
        "nameEng": "Pilot",
        "code": "PLOT",
        "gender": "All",
        "nameInd": "Pilot Pesawat Terbang",
        "minAge": "0",
        "descriptionInd": "Menerbangkan dan menavigasi transportasi udara, baik yang berisikan cargo/ penumpang. Bertanggung jawab untuk mengantarkan penumpang ke tujuan dengan selamat. Mengkoordinasikan rencana penerbangan dengan bekerja seperti petugas lalu lintas udara , membuat laporan dengan badan administrasi udara , membaca panel dan dapat bekerja di bawah tekanan serperti pada saat ada turbulen / cuaca buruk",
        "descriptionEng": "Pilots fly and navigate aircraft to transport cargo and passengers. A pilot is responsible for taking people from departure to their destination, in the safest way possible. He coordinates flight plans with workers, such as air-traffic controls, files reports with the Federal Aviation Administration, reads instrument panels,  remains composed under pressure, such as turbulent weather.",
        "clazz": "3",
        "$$hashKey": "object:4509"
    },
    {
        "nameEng": "Racer",
        "code": "RACE",
        "gender": "All",
        "nameInd": "Pembalap",
        "minAge": "0",
        "descriptionInd": "pembalap bersaing dalam balapan melawan pembalap yang lain, ini adalah olahraga yang menuntut konsentrasi utama, kekuatan, fisik kebugaran, teknik dan keberanian. Sebelum berlomba, mereka akan bekerja sama dengan tim untuk menganalisis peta sirkuit, merencanakan untuk memperoleh garis depan dan mencari cara untuk mengambil setiap kesempatan. Mengatur taktik untuk lomba dan memutuskan kapan untuk mengambil stop pit  (jika perlu).",
        "descriptionEng": "racing drivers make their living by competing in motor races against their rivals. This is a sprot which demands ultimate concentration, strength, physical fitness, technique and fearlessness. Before each race, will work with the team to analyse maps of the circuit, plan your lines and figure out how to take each turn. Plan the tactics for the race and decide when to take your pit stopss (if necessary).",
        "clazz": "3",
        "$$hashKey": "object:3980"
    },
    {
        "nameEng": "Seaman (merchant marine)",
        "code": "SAIL",
        "gender": "All",
        "nameInd": "Pelaut",
        "minAge": "0",
        "descriptionInd": "Pekerja terlatih dalam ilmu pelayaran, orang yang bekerja sebagai pelaut. Orang yang ahli dalam ilmu pelayaran juga dikenal sebagai pelaut.",
        "descriptionEng": "a rating trained in seamanship as opposed to electrical engineering, etc | a man who serves as a sailor | a person skilled in seamanship , also known as sailors.",
        "clazz": "3",
        "$$hashKey": "object:3926"
    },
    {
        "nameEng": "Steward",
        "code": "SWRD",
        "gender": "M",
        "nameInd": "Pramugari laki-laki (Pramugara)",
        "minAge": "0",
        "descriptionInd": "Juga dikenal sebagai awak kabin, bagian dari staf kru pesawat yang bertugas menjaga keamanan dan kenyamanan penumpang pesawat penerbangan komersial, pada pesawat jet bisnis atau pada beberapa pesawat militer.",
        "descriptionEng": "Also known as Flight attendants or cabin crew are members of an aircrew employed by airlines primarily to ensure the safety and comfort of passengers aboard commercial flights, on select business jet aircraft, and on some military aircraft.",
        "clazz": "3",
        "$$hashKey": "object:4520"
    },
    {
        "nameEng": "Stewardess",
        "code": "STWD",
        "gender": "F",
        "nameInd": "Pramugari Wanita",
        "minAge": "0",
        "descriptionInd": "Awak kabin dengan jenis kelamin wanita.",
        "descriptionEng": "The same as Steward but different in term of gender: female.",
        "clazz": "3",
        "$$hashKey": "object:4521"
    },
    {
        "nameEng": "Traffic police",
        "code": "TFPO",
        "gender": "All",
        "nameInd": "Polisi Lalu Lintas (Polantas)",
        "minAge": "0",
        "descriptionInd": "Polisi yang bertugas untuk menjaga kestabilan lalu lintas di jalan raya.",
        "descriptionEng": "A police whose job to maintain a steady traffic at the road.",
        "clazz": "3",
        "$$hashKey": "object:4513"
    },
    {
        "nameEng": "Military Generals",
        "code": "MIGR",
        "gender": "All",
        "nameInd": "Jenderal Militer",
        "minAge": "0",
        "descriptionInd": "Seorang yang berpangkat Jendral Militer",
        "descriptionEng": "Military Generals",
        "clazz": "3",
        "$$hashKey": "object:3576"
    },
    {
        "nameEng": "Military Senior Officers",
        "code": "MISO",
        "gender": "All",
        "nameInd": "Perwira menengah  di militer (Letkol,Kolonel,Mayor)",
        "minAge": "0",
        "descriptionInd": "Seorang yang berpangkat sebagai perwira menengah  di militer (Letkol,Kolonel,Mayor)",
        "descriptionEng": "Military Senior Officers",
        "clazz": "3",
        "$$hashKey": "object:4401"
    },
    {
        "nameEng": "Police Generals",
        "code": "POGR",
        "gender": "All",
        "nameInd": "Jenderal Polisi",
        "minAge": "0",
        "descriptionInd": "Jenderal Polisi",
        "descriptionEng": "Police Generals",
        "clazz": "3",
        "$$hashKey": "object:3577"
    },
    {
        "nameEng": "Police Senior Officers",
        "code": "POSO",
        "gender": "All",
        "nameInd": "Perwira menengah di kepolisian (Kombes,AKBP,Kompol)",
        "minAge": "0",
        "descriptionInd": "Seorang yang berpangkat sebagai perwira menengah di kepolisian (Kombes,AKBP,Kompol)",
        "descriptionEng": "Police Senior Officers",
        "clazz": "3",
        "$$hashKey": "object:4402"
    },
    {
        "nameEng": "Ambulance Driver",
        "code": "AMBL",
        "gender": "All",
        "nameInd": "Pengemudi (Supir) Ambulans",
        "minAge": "0",
        "descriptionInd": "Orang yang mengendarai mobil ambulans terkait dengan keadaan gawat darurat.",
        "descriptionEng": "One who drives an ambulance attached to any emergency service.",
        "clazz": "2",
        "$$hashKey": "object:4188"
    },
    {
        "nameEng": "Boxer",
        "code": "BOXE",
        "gender": "All",
        "nameInd": "Petinju",
        "minAge": "0",
        "descriptionInd": "Orang yang ikut serta dalam olahraga tinju (seni bela diri dan olahraga di mana dua orang terlibat dalam sebuah lomba kekuatan, kecepatan, refleks, ketahanan dengan melemparkan tinju ke arah lawannya).",
        "descriptionEng": "A person who engages in the sport of boxing*. *Boxing is a martial art and combat sport in which two people engage in a contest of strength, speed, reflexes, endurance, and will by throwing punches with gloved hands against another opponent.",
        "clazz": "3",
        "$$hashKey": "object:4409"
    },
    {
        "nameEng": "Footballer",
        "code": "FOOT",
        "gender": "All",
        "nameInd": "Pemain Sepak Bola Professional",
        "minAge": "0",
        "descriptionInd": "Adalah olah ragawan yang bermain dalam salah satu dari berbagai macam jenis bola kaki.",
        "descriptionEng": "Footballer is a sportsperson who plays one of the different types of football.",
        "clazz": "3",
        "$$hashKey": "object:3947"
    },
    {
        "nameEng": "Jockey",
        "code": "JOCK",
        "gender": "All",
        "nameInd": "Joki",
        "minAge": "0",
        "descriptionInd": "Yaitu penunggang kuda pacu di arena pacuan kuda.",
        "descriptionEng": "Rides racehorse at racetrack: Confers with training personnel to plan strategy for race, based on ability and peculiarities of own and other horses in competition. Mounts horse in paddock after weighing-in, and rides horse to specified numbered stall of starting gate.",
        "clazz": "3",
        "$$hashKey": "object:3578"
    },
    {
        "nameEng": "Referee",
        "code": "RFRE",
        "gender": "All",
        "nameInd": "Wasit",
        "minAge": "0",
        "descriptionInd": "Orang yang bekerja sebagai wasit atau hakim dalam berbagai olahraga, bertanggung jawab dan memastikan fair play sesuai aturan. Memimpin di acara olahraga, permainan atau kompetisi, mempertahankan standar permainan dan memastikan bahwa aturan permainan diamati. Hakim dalam bidang olah raga.",
        "descriptionEng": "umpire or judge in any of various sports, responsible for ensuring fair play according to the rules. Officiate at sporting events, games or competitions, to maintain standards of play and to ensure that game rules are observed. Judge performances in sport.",
        "clazz": "2",
        "$$hashKey": "object:4719"
    },
    {
        "nameEng": "Tutor",
        "code": "TUTO",
        "gender": "All",
        "nameInd": "Guru Privat",
        "minAge": "0",
        "descriptionInd": "Seorang Guru atau Asisten Pengajar di beberapa universitas dan perguruan tinggi, berkedudukan lebih rendah dari seorang Instrukstur.",
        "descriptionEng": "A teacher or teaching assistant in some universities and colleges having a rank lower than that of an instructor.",
        "clazz": "1",
        "$$hashKey": "object:3518"
    },
    {
        "nameEng": "Clerk / Customer service / Executive assistant / Office receptionist",
        "code": "CLRK",
        "gender": "All",
        "nameInd": "Juru tulis / Layanan pelanggan / Asisten eksekutif / Resepsionis kantor",
        "minAge": "0",
        "descriptionInd": "pegawai komputer adalah seseorang yang pekerjaanya di kantor, sering melibatkan input komputer dan kemampuan keyboard",
        "descriptionEng": "Computer clerk is someone whose job is office based work, often involving computer input and keyboard skills.",
        "clazz": "1",
        "$$hashKey": "object:3589"
    },
    {
        "nameEng": "Rig medic / Rig medic (oil and natural gas production)",
        "code": "RIGM",
        "gender": "All",
        "nameInd": "Paramedis rig / Paramedis rig (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "Petugas paramedis di kasawan lokasi produksi gas dan minyak bumi",
        "descriptionEng": "a paramedic in oil and natural gas production",
        "clazz": "2",
        "$$hashKey": "object:3830"
    },
    {
        "nameEng": "Telephone fitter (telecommunications) / Telephone installer / Telephone repairer (telecommunications)",
        "code": "TPHN",
        "gender": "All",
        "nameInd": "Petugas Pemasang Telpon / Pereparasi telepon (telekomunikasi)",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bertugas memasang telepon baru atau memperbaiki kabel saluran telepon yang rusak",
        "descriptionEng": "A person whose job to install new phone or repairing a broken telephone line cable",
        "clazz": "2",
        "$$hashKey": "object:4463"
    },
    {
        "nameEng": "Waiter / Waitress",
        "code": "WTER",
        "gender": "All",
        "nameInd": "Pelayan Pria / Pelayan Wanita",
        "minAge": "0",
        "descriptionInd": "Seorang lelaki / wanita yang bertugas melayani tamu di meja makan, seperti di Restoran",
        "descriptionEng": "A man / woman whose occupation is to serve at table, as in a restaurant",
        "clazz": "2",
        "$$hashKey": "object:3936"
    },
    {
        "nameEng": "Cafe proprietor",
        "code": "CAFE",
        "gender": "All",
        "nameInd": "Pemilik kafe",
        "minAge": "0",
        "descriptionInd": "seseorang yang memiliki kafe",
        "descriptionEng": "someone who owns a cafe",
        "clazz": "2",
        "$$hashKey": "object:4063"
    },
    {
        "nameEng": "Cinema manager",
        "code": "CIMA",
        "gender": "All",
        "nameInd": "Manajer bioskop",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengelola bioskop",
        "descriptionEng": "someone who manages the cinema",
        "clazz": "1",
        "$$hashKey": "object:3674"
    },
    {
        "nameEng": "Clown (circus) / Circus clown",
        "code": "CLWN",
        "gender": "All",
        "nameInd": "Badut (sirkus) / Badut sirkus",
        "minAge": "0",
        "descriptionInd": "Badut sirkus",
        "descriptionEng": "someone who brings fun to kids",
        "clazz": "3",
        "$$hashKey": "object:3445"
    },
    {
        "nameEng": "Power station superintendent / Power station charge engineer",
        "code": "POWS",
        "gender": "All",
        "nameInd": "Pengawas pembangkit listrik / Insinyur beban pembangkit listrik",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja di bidang pembangkit listrik",
        "descriptionEng": "someone whoo works in the field of power plants",
        "clazz": "2",
        "$$hashKey": "object:4160"
    },
    {
        "nameEng": "Quality control engineer (textiles) / QC engineer (textiles)",
        "code": "QCEN",
        "gender": "All",
        "nameInd": "Insinyur kontrol kualitas (tekstil) / Insinyur QC (tekstil)",
        "minAge": "0",
        "descriptionInd": "seseorang yang mengecek kualitas",
        "descriptionEng": "someone who checks the quality",
        "clazz": "3",
        "$$hashKey": "object:3537"
    },
    {
        "nameEng": "Boom operator / Broadcast engineer  / Radio television and film technician  / Radio TV and film technician  / Cameraman  / Clapper board staff (radio television and film) / Dubbing mixer  / Lighting technician (radio television and film) / Recording engineer  / Sound and lighting technician (radio television and film) / Special effects technician (radio television and film)",
        "code": "CAMR",
        "gender": "All",
        "nameInd": "Operator boom / Insinyur penyiaran / Teknisi radio, televisi, dan film / Teknisi radio, TV, dan film / Petugas kamera / Staf papan nomor adegan (radio, televisi, dan film) / Pengisi suara / Teknisi lampu (radio, televisi, dan film) / Insiyur perekaman / Teknisi lampu dan suara  (radio, televisi, dan film) / Teknisi efek khusus (radio, televisi, dan film)",
        "minAge": "0",
        "descriptionInd": "seseorang yang pekerjaannya melibatkan pelatihan dalam proses teknis tertentu",
        "descriptionEng": "someone whose job involves training in certain technical stuff",
        "clazz": "2",
        "$$hashKey": "object:3757"
    },
    {
        "nameEng": "Care assistant / Medical care assistant",
        "code": "CRAS",
        "gender": "All",
        "nameInd": "Asisten perawat / Asisten perawatan medis",
        "minAge": "0",
        "descriptionInd": "Seseorang yang bekerja dalam lingkup perawatan medis di ambulance",
        "descriptionEng": "someone who works in a medical care in ambulance",
        "clazz": "3",
        "$$hashKey": "object:3435"
    },
    {
        "nameEng": "Journalist  / Reporter",
        "code": "JOUR",
        "gender": "All",
        "nameInd": "Jurnalis / Reporter",
        "minAge": "0",
        "descriptionInd": "Jurnalis yaitu orang yang bertugas menulis dan mengumpulkan berita yang menarik untuk pembaca.",
        "descriptionEng": "Journalists write and assemble together news stories that will interest their audience.",
        "clazz": "2",
        "$$hashKey": "object:3579"
    },
    {
        "nameEng": "Airport maintenance technician / Aircraft maintenance technician / Airport ground equipment service mechanic",
        "code": "AMTC",
        "gender": "All",
        "nameInd": "Teknisi pemeliharaan bandara / Teknisi pemeliharaan pesawat terbang / Mekanik servis peralatan darat bandara",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan berbagai macam perawatan khusus dan memperbaiki demi keamanan dan efisiensi operasi",
        "descriptionEng": "someone who performs a variety of specialized�maintenance�and repair tasks for the safe and efficient operations",
        "clazz": "3",
        "$$hashKey": "object:4628"
    },
    {
        "nameEng": "Insurance sales / Insurance Agent",
        "code": "INSS",
        "gender": "All",
        "nameInd": "Agen asuransi",
        "minAge": "0",
        "descriptionInd": "Jual asuransi jiwa, properti, kecelakaan, kesehatan, otomotif, atau jenis asuransi lainnya. Dapat merujuk klien ke pialang independen, bekerja sebagai pialang independen, atau dipekerjakan oleh perusahaan asuransi.",
        "descriptionEng": "Sell life, property, casualty, health, automotive, or other types of�insurance. May refer clients to independent brokers, work as independent�broker, or be employed by an�insurance�company.",
        "clazz": "1",
        "$$hashKey": "object:3317"
    },
    {
        "nameEng": "Admin Staff",
        "code": "ADMN",
        "gender": "All",
        "nameInd": "Staf Administrasi",
        "minAge": "0",
        "descriptionInd": "Orang yang pekerjaannya bersifat administratif. Tugas umumnya meliputi administrasi, penerimaan dan pekerjaan berbasis projek.",
        "descriptionEng": "Administrative staff work is to provide administrative and clerical support to a specific department or person. General duties include clerical, reception and project-based work.",
        "clazz": "1",
        "$$hashKey": "object:4554"
    },
    {
        "nameEng": "Magician",
        "code": "MGCI",
        "gender": "All",
        "nameInd": "Pesulap",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan sulap",
        "descriptionEng": "someone who does magic",
        "clazz": "2",
        "$$hashKey": "object:4403"
    },
    {
        "nameEng": "Abalone fisherman",
        "code": "ABAL",
        "gender": "All",
        "nameInd": "Nelayan abalone",
        "minAge": "0",
        "descriptionInd": "seseorang yang memancing ikan abalone",
        "descriptionEng": "someone who fishes abalone",
        "clazz": "3",
        "$$hashKey": "object:3746"
    },
    {
        "nameEng": "Market gardener",
        "code": "MARK",
        "gender": "All",
        "nameInd": "Tukang kebun pasar",
        "minAge": "0",
        "descriptionInd": "seseorang yang bekerja di kebun",
        "descriptionEng": "a person who works in garden",
        "clazz": "3",
        "$$hashKey": "object:4680"
    },
    {
        "nameEng": "Bricklayer",
        "code": "BRIC",
        "gender": "All",
        "nameInd": "Tukang batu bata",
        "minAge": "0",
        "descriptionInd": "pengrajin yang pekerjaannya membangun tembok, rumah, dan struktur batu bata lainnya",
        "descriptionEng": "A bricklayer or mason is a craftsman whose job is to build walls, houses, and other structures with bricks.",
        "clazz": "3",
        "$$hashKey": "object:4659"
    },
    {
        "nameEng": "Scaffolder (oil and natural gas production)",
        "code": "SCFF",
        "gender": "All",
        "nameInd": "Petugas perancah bangunan (produksi minyak dan gas alam)",
        "minAge": "0",
        "descriptionInd": "orang yang memasang dan membongkar perancah",
        "descriptionEng": "a person who erects and dismantles scaffolding",
        "clazz": "3",
        "$$hashKey": "object:4483"
    },
    {
        "nameEng": "Electrical technician",
        "code": "ELET",
        "gender": "All",
        "nameInd": "Petugas Listrik",
        "minAge": "0",
        "descriptionInd": "Petugas listrik adalah orang yang khusus mengerjakan kabel-kabel listrik dalam gedung, mesin-mesin dan alat-alat listrik lainnya.Petugas listrik dapat merupakan pegawai instalasi listrik yang baru atau petugas pemeliharan dan perbaikan infrastruktur listrik.",
        "descriptionEng": "An electrician is a trades person specializing in electrical wiring of buildings, stationary machines and related equipment. Electricians may be employed in the installation of new electrical components or the maintenance and repair of existing electrical infrastructure.",
        "clazz": "3",
        "$$hashKey": "object:4446"
    },
    {
        "nameEng": "Attorney",
        "code": "ATOR",
        "gender": "All",
        "nameInd": "Konsultan hukum/Praktisi hukum",
        "minAge": "0",
        "descriptionInd": "orang yang mempraktekkan hukum, sebagai pengacara, pengacara, pengacara di hukum, pengacara, pengacara, pengacara, pengacara, konselor, konselor,",
        "descriptionEng": "a person who practices law, as an advocate, attorney, attorney at law, barrister, barrister-at-law, bar-at-law, counsel, counselor, counsellor,",
        "clazz": "2",
        "$$hashKey": "object:3637"
    },
    {
        "nameEng": "Member of Parliament in Region",
        "code": "DPRD",
        "gender": "All",
        "nameInd": "Anggota Legislatif (DPRD DATI 1 dan 2) daerah",
        "minAge": "0",
        "descriptionInd": "Orang yang dipilih melalui partainya atau daerah pemilihannya sebagai wakil rakyat di majelis legislatif daerah",
        "descriptionEng": "Is Elected in his/her constituency or electoral division, to serve as a representative in the legislative Assembly in The Region",
        "clazz": "2",
        "$$hashKey": "object:3409"
    },
    {
        "nameEng": "Member of Parliament in State",
        "code": "DPRI",
        "gender": "All",
        "nameInd": "Anggota Legislatif (MPR/DPR/DPD) Pusat",
        "minAge": "0",
        "descriptionInd": "Orang yang dipilih melalui partainya atau daerah pemilihannya sebagai wakil rakyat di majelis legislatif Pusat",
        "descriptionEng": "Is Elected in his/her constituency or electoral division, to serve as a representative in the legislative Assembly in The State",
        "clazz": "2",
        "$$hashKey": "object:3410"
    },
    {
        "nameEng": "Refuse collector / Garbage Collector",
        "code": "GARB",
        "gender": "All",
        "nameInd": "Pengumpul Sampah",
        "minAge": "0",
        "descriptionInd": "Adalah orang yang dipekerjakan oleh pemerintah atau swasta untuk mengumpulkan sampah yang dapat didaur ulang dari perumahan, pabrik industri atau lainnya untuk diproses lebih lanjut.",
        "descriptionEng": "A garbage collector is a person employed by a public or private enterprise to collect and remove refuse and recyclables from residential, commercial, industrial or other collection site for further processing and disposal.",
        "clazz": "3",
        "$$hashKey": "object:4274"
    },
    {
        "nameEng": "Publican",
        "code": "PUBL",
        "gender": "All",
        "nameInd": "Pemilik tempat minum-minum",
        "minAge": "0",
        "descriptionInd": "seseorang yang memiliki tempat minum-minum",
        "descriptionEng": "someone who owns a pub",
        "clazz": "3",
        "$$hashKey": "object:4068"
    },
    {
        "nameEng": "Groundsman",
        "code": "GRUN",
        "gender": "All",
        "nameInd": "Tukang kebun lapangan",
        "minAge": "0",
        "descriptionInd": "seseorang yang merawat lapangan olahraga, taman, atau pekarangan sekolah atau institusi lain.",
        "descriptionEng": "a person who maintains a sports ground, a park, or the grounds of a school or other institution.",
        "clazz": "3",
        "$$hashKey": "object:4679"
    },
    {
        "nameEng": "Coastguard",
        "code": "COAS",
        "gender": "All",
        "nameInd": "Penjaga batas maritim negara",
        "minAge": "0",
        "descriptionInd": "sebuah organisasi keamanan maritim suatu negara tertentu.",
        "descriptionEng": "a maritime security organization of a particular country.",
        "clazz": "3",
        "$$hashKey": "object:4295"
    },
    {
        "nameEng": "Gardener",
        "code": "GARD",
        "gender": "All",
        "nameInd": "Tukang kebun",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan kegiatan berkebun",
        "descriptionEng": "A gardener is someone who practices gardening.",
        "clazz": "2",
        "$$hashKey": "object:4677"
    },
    {
        "nameEng": "Conjurer",
        "code": "CNJR",
        "gender": "All",
        "nameInd": "Tukang sulap",
        "minAge": "0",
        "descriptionInd": "seseorang yang melakukan sulap",
        "descriptionEng": "someone who practices magic",
        "clazz": "2",
        "$$hashKey": "object:4702"
    }
];

const positionList = [{
        "code": "AB2",
        "descriptionInd": "Ajun Brigadir Polisi Dua (Abripda)",
        "descriptionEng": "Second Police Adjunct Brigadier",
        "$$hashKey": "object:6133"
    },
    {
        "code": "ABP",
        "descriptionInd": "Ajun Brigadir Polisi (Abrip)",
        "descriptionEng": "Police Adjunct Brigadier",
        "$$hashKey": "object:6132"
    },
    {
        "code": "AI1",
        "descriptionInd": "Ajun Inspektur Polisi Satu (Aiptu)",
        "descriptionEng": "First Police Adjunct Inspector",
        "$$hashKey": "object:6136"
    },
    {
        "code": "AI2",
        "descriptionInd": "Ajun Inspektur Polisi Dua (Aipda)",
        "descriptionEng": "Second Police Adjunct Inspector",
        "$$hashKey": "object:6135"
    },
    {
        "code": "AKB",
        "descriptionInd": "Ajun Komisaris Besar Polisi (AKBP)",
        "descriptionEng": "Police Adjunct Senior Commissioner",
        "$$hashKey": "object:6137"
    },
    {
        "code": "AKP",
        "descriptionInd": "Ajun Komisaris Polisi (AKP)",
        "descriptionEng": "Police Adjunct Commissioner",
        "$$hashKey": "object:6138"
    },
    {
        "code": "AMG",
        "descriptionInd": "Junior/Assistant Manager",
        "descriptionEng": "Junior / Assistant Manager",
        "$$hashKey": "object:6196"
    },
    {
        "code": "ASD",
        "descriptionInd": "Asisten Deputi",
        "descriptionEng": "Assistant Deputy",
        "$$hashKey": "object:6139"
    },
    {
        "code": "BKA",
        "descriptionInd": "Brigadir Polisi Kepala (Bripka)",
        "descriptionEng": "Chief Police Brigadier",
        "$$hashKey": "object:6148"
    },
    {
        "code": "BKP",
        "descriptionInd": "Brigadir Polisi (Brigpol)",
        "descriptionEng": "Police Brigadier",
        "$$hashKey": "object:6146"
    },
    {
        "code": "BR1",
        "descriptionInd": "Brigadir Polisi Satu (Briptu)",
        "descriptionEng": "First Police Brigadier",
        "$$hashKey": "object:6149"
    },
    {
        "code": "BR2",
        "descriptionInd": "Brigadir Polisi Dua (Bripda)",
        "descriptionEng": "Second Police Brigadier",
        "$$hashKey": "object:6147"
    },
    {
        "code": "BRJ",
        "descriptionInd": "Brigadir Jenderal",
        "descriptionEng": "Brigadier General",
        "$$hashKey": "object:6144"
    },
    {
        "code": "BRP",
        "descriptionInd": "Brigadir Jenderal Polisi (Brigjen Pol)",
        "descriptionEng": "Police Brigadier General",
        "$$hashKey": "object:6145"
    },
    {
        "code": "BUP",
        "descriptionInd": "Bupati",
        "descriptionEng": "Regent",
        "$$hashKey": "object:6150"
    },
    {
        "code": "BY1",
        "descriptionInd": "Bhayangkara Satu (Bharatu)",
        "descriptionEng": "First Agent",
        "$$hashKey": "object:6143"
    },
    {
        "code": "BY2",
        "descriptionInd": "Bhayangkara Dua (Bharada)",
        "descriptionEng": "Second Agent",
        "$$hashKey": "object:6141"
    },
    {
        "code": "BYK",
        "descriptionInd": "Bhayangkara Kepala (Baraka)",
        "descriptionEng": "Chief Agent",
        "$$hashKey": "object:6142"
    },
    {
        "code": "CAP",
        "descriptionInd": "Kapten",
        "descriptionEng": "Captain",
        "$$hashKey": "object:6197"
    },
    {
        "code": "CEO",
        "descriptionInd": "Direktur Utama/CEO",
        "descriptionEng": "President Director",
        "$$hashKey": "object:6156"
    },
    {
        "code": "CMT",
        "descriptionInd": "Camat",
        "descriptionEng": "Subdistrict head",
        "$$hashKey": "object:6151"
    },
    {
        "code": "COR",
        "descriptionInd": "Coordinator",
        "descriptionEng": "Coordinator",
        "$$hashKey": "object:6152"
    },
    {
        "code": "DEP",
        "descriptionInd": "Deputi",
        "descriptionEng": "Deputy",
        "$$hashKey": "object:6153"
    },
    {
        "code": "DIR",
        "descriptionInd": "Direktur",
        "descriptionEng": "Director",
        "$$hashKey": "object:6154"
    },
    {
        "code": "DP1",
        "descriptionInd": "DPRD",
        "descriptionEng": "DRPD",
        "$$hashKey": "object:6159"
    },
    {
        "code": "DPD",
        "descriptionInd": "DPD",
        "descriptionEng": "DPD",
        "$$hashKey": "object:6157"
    },
    {
        "code": "DPR",
        "descriptionInd": "DPR",
        "descriptionEng": "DPR",
        "$$hashKey": "object:6158"
    },
    {
        "code": "DRJ",
        "descriptionInd": "Direktur Jenderal",
        "descriptionEng": "Director General",
        "$$hashKey": "object:6155"
    },
    {
        "code": "E1A",
        "descriptionInd": "Eselon IA",
        "descriptionEng": "Echelon IA",
        "$$hashKey": "object:6160"
    },
    {
        "code": "E1B",
        "descriptionInd": "Eselon IB",
        "descriptionEng": "Echelon IB",
        "$$hashKey": "object:6161"
    },
    {
        "code": "E2A",
        "descriptionInd": "Eselon IIA",
        "descriptionEng": "Echelon IIA",
        "$$hashKey": "object:6162"
    },
    {
        "code": "E2B",
        "descriptionInd": "Eselon IIB",
        "descriptionEng": "Echelon IIB",
        "$$hashKey": "object:6163"
    },
    {
        "code": "E3A",
        "descriptionInd": "Eselon IIIA",
        "descriptionEng": "Echelon IIIA",
        "$$hashKey": "object:6164"
    },
    {
        "code": "E3B",
        "descriptionInd": "Eselon IIIB",
        "descriptionEng": "Echelon IIIB",
        "$$hashKey": "object:6165"
    },
    {
        "code": "E4A",
        "descriptionInd": "Eselon IVA",
        "descriptionEng": "Echelon IVA",
        "$$hashKey": "object:6166"
    },
    {
        "code": "E4B",
        "descriptionInd": "Eselon IVB",
        "descriptionEng": "Echelon IVB",
        "$$hashKey": "object:6167"
    },
    {
        "code": "E5A",
        "descriptionInd": "Eselon VA",
        "descriptionEng": "Echelon VA",
        "$$hashKey": "object:6168"
    },
    {
        "code": "G1A",
        "descriptionInd": "Golongan IA",
        "descriptionEng": "Class IA",
        "$$hashKey": "object:6170"
    },
    {
        "code": "G1B",
        "descriptionInd": "Golongan IB",
        "descriptionEng": "Class IB",
        "$$hashKey": "object:6171"
    },
    {
        "code": "G1C",
        "descriptionInd": "Golongan IC",
        "descriptionEng": "Class IC",
        "$$hashKey": "object:6172"
    },
    {
        "code": "G1D",
        "descriptionInd": "Golongan ID",
        "descriptionEng": "Class ID",
        "$$hashKey": "object:6173"
    },
    {
        "code": "G2A",
        "descriptionInd": "Golongan IIA",
        "descriptionEng": "Class IIA",
        "$$hashKey": "object:6174"
    },
    {
        "code": "G2B",
        "descriptionInd": "Golongan IIB",
        "descriptionEng": "Class IIB",
        "$$hashKey": "object:6175"
    },
    {
        "code": "G2C",
        "descriptionInd": "Golongan IIC",
        "descriptionEng": "Class IIC",
        "$$hashKey": "object:6176"
    },
    {
        "code": "G2D",
        "descriptionInd": "Golongan IID",
        "descriptionEng": "Class IID",
        "$$hashKey": "object:6177"
    },
    {
        "code": "G3A",
        "descriptionInd": "Golongan IIIA",
        "descriptionEng": "Class IIIA",
        "$$hashKey": "object:6178"
    },
    {
        "code": "G3B",
        "descriptionInd": "Golongan IIIB",
        "descriptionEng": "Class IIIB",
        "$$hashKey": "object:6179"
    },
    {
        "code": "G3C",
        "descriptionInd": "Golongan IIIC",
        "descriptionEng": "Class IIIC",
        "$$hashKey": "object:6180"
    },
    {
        "code": "G3D",
        "descriptionInd": "Golongan IIID",
        "descriptionEng": "Class IIID",
        "$$hashKey": "object:6181"
    },
    {
        "code": "G4A",
        "descriptionInd": "Golongan IVA",
        "descriptionEng": "Class IVA",
        "$$hashKey": "object:6182"
    },
    {
        "code": "G4B",
        "descriptionInd": "Golongan IVB",
        "descriptionEng": "Class IVB",
        "$$hashKey": "object:6183"
    },
    {
        "code": "G4C",
        "descriptionInd": "Golongan IVC",
        "descriptionEng": "Class IVC",
        "$$hashKey": "object:6184"
    },
    {
        "code": "G4D",
        "descriptionInd": "Golongan IVD",
        "descriptionEng": "Class IVD",
        "$$hashKey": "object:6185"
    },
    {
        "code": "G4E",
        "descriptionInd": "Golongan IVE",
        "descriptionEng": "Class IVE",
        "$$hashKey": "object:6186"
    },
    {
        "code": "GMG",
        "descriptionInd": "General manager",
        "descriptionEng": "General Manager",
        "$$hashKey": "object:6169"
    },
    {
        "code": "GUB",
        "descriptionInd": "Gubernur",
        "descriptionEng": "Governor",
        "$$hashKey": "object:6187"
    },
    {
        "code": "INJ",
        "descriptionInd": "Inspektur Jenderal",
        "descriptionEng": "Inspector General",
        "$$hashKey": "object:6189"
    },
    {
        "code": "INS",
        "descriptionInd": "Inspektur",
        "descriptionEng": "Inspector",
        "$$hashKey": "object:6188"
    },
    {
        "code": "IP1",
        "descriptionInd": "Inspektur Polisi Satu (Iptu)",
        "descriptionEng": "First Police Inspector",
        "$$hashKey": "object:6192"
    },
    {
        "code": "IP2",
        "descriptionInd": "Inspektur Polisi Dua (Ipda)",
        "descriptionEng": "Second Police Inspector",
        "$$hashKey": "object:6191"
    },
    {
        "code": "IRP",
        "descriptionInd": "Inspektur Jenderal Polisi (Irjen Pol)",
        "descriptionEng": "Police Inspector General",
        "$$hashKey": "object:6190"
    },
    {
        "code": "JAG",
        "descriptionInd": "Jaksa Agung",
        "descriptionEng": "Attorney General",
        "$$hashKey": "object:6193"
    },
    {
        "code": "JND",
        "descriptionInd": "Jenderal",
        "descriptionEng": "General",
        "$$hashKey": "object:6194"
    },
    {
        "code": "JNP",
        "descriptionInd": "Jenderal Polisi (Jenderal Pol)",
        "descriptionEng": "Police General",
        "$$hashKey": "object:6195"
    },
    {
        "code": "KAB",
        "descriptionInd": "Kepala Badan/Bidang",
        "descriptionEng": "Head of Division",
        "$$hashKey": "object:6201"
    },
    {
        "code": "KBP",
        "descriptionInd": "Komisaris Besar Polisi (Kombes Pol)",
        "descriptionEng": "Police Senior Commissioner",
        "$$hashKey": "object:6211"
    },
    {
        "code": "KD1",
        "descriptionInd": "Kepala Desa",
        "descriptionEng": "Village head",
        "$$hashKey": "object:6203"
    },
    {
        "code": "KDN",
        "descriptionInd": "Kepala Dinas",
        "descriptionEng": "Head of Department",
        "$$hashKey": "object:6204"
    },
    {
        "code": "KJP",
        "descriptionInd": "Komisaris Jenderal Polisi (Komjen Pol)",
        "descriptionEng": "Police Commissioner General",
        "$$hashKey": "object:6212"
    },
    {
        "code": "KK1",
        "descriptionInd": "Kopral Satu",
        "descriptionEng": "First Corporal",
        "$$hashKey": "object:6216"
    },
    {
        "code": "KK2",
        "descriptionInd": "Kopral Dua",
        "descriptionEng": "Second Corporal",
        "$$hashKey": "object:6214"
    },
    {
        "code": "KKA",
        "descriptionInd": "Kepala Kantor",
        "descriptionEng": "Head Office",
        "$$hashKey": "object:6205"
    },
    {
        "code": "KL1",
        "descriptionInd": "Kelasi Satu",
        "descriptionEng": "Seaman Apprentice",
        "$$hashKey": "object:6200"
    },
    {
        "code": "KL2",
        "descriptionInd": "Kelasi Dua",
        "descriptionEng": "Seaman Recruit",
        "$$hashKey": "object:6198"
    },
    {
        "code": "KLA",
        "descriptionInd": "Kelasi Kepala",
        "descriptionEng": "Seaman",
        "$$hashKey": "object:6199"
    },
    {
        "code": "KOL",
        "descriptionInd": "Kolonel",
        "descriptionEng": "Colonel",
        "$$hashKey": "object:6210"
    },
    {
        "code": "KOM",
        "descriptionInd": "Komisaris Polisi (Kompol)",
        "descriptionEng": "Police Commissioner",
        "$$hashKey": "object:6213"
    },
    {
        "code": "KPA",
        "descriptionInd": "Kopral Kepala",
        "descriptionEng": "Master Corporal",
        "$$hashKey": "object:6215"
    },
    {
        "code": "KPB",
        "descriptionInd": "Kepala Biro",
        "descriptionEng": "Bureau Chief",
        "$$hashKey": "object:6202"
    },
    {
        "code": "KPP",
        "descriptionInd": "Kepala Pusat",
        "descriptionEng": "Head Center",
        "$$hashKey": "object:6206"
    },
    {
        "code": "KSB",
        "descriptionInd": "Kepala Subdirektorat",
        "descriptionEng": "Head of Sub Directorate",
        "$$hashKey": "object:6209"
    },
    {
        "code": "KSI",
        "descriptionInd": "Kepala Seksi",
        "descriptionEng": "Section Head",
        "$$hashKey": "object:6207"
    },
    {
        "code": "KSU",
        "descriptionInd": "Kepala Subbagian/Subbidang",
        "descriptionEng": "Head of the Subdivision / subfields",
        "$$hashKey": "object:6208"
    },
    {
        "code": "LET",
        "descriptionInd": "Letnan",
        "descriptionEng": "Lieutenant",
        "$$hashKey": "object:6222"
    },
    {
        "code": "LK1",
        "descriptionInd": "Laksamana Pertama",
        "descriptionEng": "First Admiral/ Commodore",
        "$$hashKey": "object:6221"
    },
    {
        "code": "LKM",
        "descriptionInd": "Laksamana Madya",
        "descriptionEng": "Vice admiral",
        "$$hashKey": "object:6219"
    },
    {
        "code": "LKS",
        "descriptionInd": "Laksamana",
        "descriptionEng": "Admiral",
        "$$hashKey": "object:6218"
    },
    {
        "code": "LSM",
        "descriptionInd": "Laksamana Muda",
        "descriptionEng": "Rear Admiral/ Young Admiral",
        "$$hashKey": "object:6220"
    },
    {
        "code": "LT1",
        "descriptionInd": "Letnan Satu",
        "descriptionEng": "First lieutenant",
        "$$hashKey": "object:6225"
    },
    {
        "code": "LT2",
        "descriptionInd": "Letnan Dua",
        "descriptionEng": "Second lieutenant",
        "$$hashKey": "object:6223"
    },
    {
        "code": "LTJ",
        "descriptionInd": "Letnan Jenderal",
        "descriptionEng": "Lieutenant general",
        "$$hashKey": "object:6224"
    },
    {
        "code": "MAY",
        "descriptionInd": "Mayor",
        "descriptionEng": "Major",
        "$$hashKey": "object:6231"
    },
    {
        "code": "MGR",
        "descriptionInd": "Manager",
        "descriptionEng": "Manager",
        "$$hashKey": "object:6226"
    },
    {
        "code": "MR1",
        "descriptionInd": "Marsekal Pertama",
        "descriptionEng": "First Marshal",
        "$$hashKey": "object:6230"
    },
    {
        "code": "MRM",
        "descriptionInd": "Marsekal Madya",
        "descriptionEng": "Air Marshal/ Middle Marshal",
        "$$hashKey": "object:6228"
    },
    {
        "code": "MRS",
        "descriptionInd": "Marsekal",
        "descriptionEng": "Air Chief Marshal",
        "$$hashKey": "object:6227"
    },
    {
        "code": "MSM",
        "descriptionInd": "Marsekal Muda",
        "descriptionEng": "Air Vice Marshal/ Young Marshal",
        "$$hashKey": "object:6229"
    },
    {
        "code": "MYJ",
        "descriptionInd": "Mayor Jenderal",
        "descriptionEng": "Major General",
        "$$hashKey": "object:6232"
    },
    {
        "code": "NST",
        "descriptionInd": "Non Staff",
        "descriptionEng": "Non Staff",
        "$$hashKey": "object:6233"
    },
    {
        "code": "PJ1",
        "descriptionInd": "Prajurit Satu",
        "descriptionEng": "Private First Class",
        "$$hashKey": "object:6238"
    },
    {
        "code": "PJ2",
        "descriptionInd": "Prajurit Dua",
        "descriptionEng": "Private",
        "$$hashKey": "object:6236"
    },
    {
        "code": "PKA",
        "descriptionInd": "Prajurit Kepala",
        "descriptionEng": "Master Private",
        "$$hashKey": "object:6237"
    },
    {
        "code": "PL1",
        "descriptionInd": "Pembantu Letnan Satu",
        "descriptionEng": "Chief Warrant Officer/ First Lieutenant Assistant",
        "$$hashKey": "object:6235"
    },
    {
        "code": "PL2",
        "descriptionInd": "Pembantu Letnan Dua",
        "descriptionEng": "Warrant Officer/ Second Lieutenant Assistant",
        "$$hashKey": "object:6234"
    },
    {
        "code": "PRS",
        "descriptionInd": "Presiden",
        "descriptionEng": "President",
        "$$hashKey": "object:6239"
    },
    {
        "code": "SAB",
        "descriptionInd": "Staf Ahli Bupati/Walikota",
        "descriptionEng": "Regent/ Mayor Special Expertise Staff",
        "$$hashKey": "object:6253"
    },
    {
        "code": "SAG",
        "descriptionInd": "Staf Ahli Gubernur",
        "descriptionEng": "Governor Special Expertise Staff",
        "$$hashKey": "object:6254"
    },
    {
        "code": "SAK",
        "descriptionInd": "Staf Ahli Kabinet",
        "descriptionEng": "Cabinet Special Expertise Staff",
        "$$hashKey": "object:6255"
    },
    {
        "code": "SDP",
        "descriptionInd": "Sekretaris DPRD",
        "descriptionEng": "Secretary of Parliament",
        "$$hashKey": "object:6243"
    },
    {
        "code": "SKC",
        "descriptionInd": "Sekretaris Camat",
        "descriptionEng": "Head of Sub District Secretary",
        "$$hashKey": "object:6240"
    },
    {
        "code": "SKD",
        "descriptionInd": "Sekretaris Daerah",
        "descriptionEng": "Regional Secretary",
        "$$hashKey": "object:6241"
    },
    {
        "code": "SKI",
        "descriptionInd": "Sekretaris Dinas/ Badan/Inspektorat",
        "descriptionEng": "Department / Agency / Inspectorate Secretary",
        "$$hashKey": "object:6242"
    },
    {
        "code": "SKJ",
        "descriptionInd": "Sekretaris Jenderal",
        "descriptionEng": "Secretary General",
        "$$hashKey": "object:6244"
    },
    {
        "code": "SKU",
        "descriptionInd": "Sekretaris Utama",
        "descriptionEng": "Principal Secretary",
        "$$hashKey": "object:6245"
    },
    {
        "code": "AUD",
        "descriptionInd": "Auditor Utama",
        "descriptionEng": "Principal Auditor",
        "$$hashKey": "object:6140"
    },
    {
        "code": "SM",
        "descriptionInd": "Senior Manager",
        "descriptionEng": "Senior Manager",
        "$$hashKey": "object:6246"
    },
    {
        "code": "SNS",
        "descriptionInd": "Senior Non Staff",
        "descriptionEng": "Senior Non Staff",
        "$$hashKey": "object:6247"
    },
    {
        "code": "SPV",
        "descriptionInd": "Supervisor",
        "descriptionEng": "Supervisor",
        "$$hashKey": "object:6257"
    },
    {
        "code": "SR1",
        "descriptionInd": "Sersan Satu",
        "descriptionEng": "First Sergant",
        "$$hashKey": "object:6252"
    },
    {
        "code": "SR2",
        "descriptionInd": "Sersan Dua",
        "descriptionEng": "Second Sergant",
        "$$hashKey": "object:6249"
    },
    {
        "code": "SRK",
        "descriptionInd": "Sersan Kepala",
        "descriptionEng": "Master Sergant",
        "$$hashKey": "object:6250"
    },
    {
        "code": "SRM",
        "descriptionInd": "Sersan Mayor",
        "descriptionEng": "Sergeant major",
        "$$hashKey": "object:6251"
    },
    {
        "code": "SST",
        "descriptionInd": "Senior Staff",
        "descriptionEng": "Senior Staff",
        "$$hashKey": "object:6248"
    },
    {
        "code": "STF",
        "descriptionInd": "Staff",
        "descriptionEng": "Staff",
        "$$hashKey": "object:6256"
    },
    {
        "code": "WAL",
        "descriptionInd": "Walikota",
        "descriptionEng": "Mayor",
        "$$hashKey": "object:6265"
    },
    {
        "code": "WBP",
        "descriptionInd": "Wakil Bupati",
        "descriptionEng": "Vice-regent",
        "$$hashKey": "object:6259"
    },
    {
        "code": "WGB",
        "descriptionInd": "Wakil Gubernur",
        "descriptionEng": "Vice Governor",
        "$$hashKey": "object:6260"
    },
    {
        "code": "WJA",
        "descriptionInd": "Wakil Jaksa Agung",
        "descriptionEng": "Deputy Attorney General",
        "$$hashKey": "object:6261"
    },
    {
        "code": "WPR",
        "descriptionInd": "Wakil Presiden",
        "descriptionEng": "Vice President",
        "$$hashKey": "object:6262"
    },
    {
        "code": "WSK",
        "descriptionInd": "Wakil Sekretaris Kabinet",
        "descriptionEng": "Deputy Chief Cabinet Secretary",
        "$$hashKey": "object:6263"
    },
    {
        "code": "WWL",
        "descriptionInd": "Wakil Walikota",
        "descriptionEng": "Vice Mayor",
        "$$hashKey": "object:6264"
    },
    {
        "code": "OTH",
        "descriptionInd": "Lainnya",
        "descriptionEng": "Others",
        "$$hashKey": "object:6217"
    },
    {
        "code": "UNP",
        "descriptionInd": "Tidak Bekerja",
        "descriptionEng": "Unemployed",
        "$$hashKey": "object:6258"
    },
    {
        "code": "AB1",
        "descriptionInd": "Ajun Brigadir Polisi Satu (Abriptu)",
        "descriptionEng": "First Police Adjunct Brigadier",
        "$$hashKey": "object:6134"
    }
];

const incomeList = {
    "Individual": [{
            "rangeEng": "Less than Rp. 2.5 Million",
            "rangeInd": "Kurang dari Rp. 2.5 Juta",
            "code": "A",
            "value": "2500000"
        },
        {
            "rangeEng": "Rp 2.5 Million to < Rp. 5 Million",
            "rangeInd": "Rp. 2.5 Juta s/d < Rp. 5 Juta",
            "code": "B",
            "value": "3750000"
        },
        {
            "rangeEng": "Rp. 5 Million to < Rp. 7.5 Million",
            "rangeInd": "Rp. 5 Juta s/d < Rp. 7.5 Juta",
            "code": "C",
            "value": "6250000"
        },
        {
            "rangeEng": "Rp. 7.5 Million to < Rp. 10 Million",
            "rangeInd": "Rp. 7.5 Juta s/d < Rp. 10 Juta",
            "code": "D",
            "value": "8750000"
        },
        {
            "rangeEng": "Rp. 10 Million to < Rp. 25 Million",
            "rangeInd": "Rp. 10 Juta s/d < Rp. 25 Juta",
            "code": "E",
            "value": "17500000"
        },
        {
            "rangeEng": "Rp. 25 Million to < Rp. 50 Million",
            "rangeInd": "Rp. 25 Juta s/d < Rp. 50 Juta",
            "code": "F",
            "value": "37750000"
        },
        {
            "rangeEng": "Rp. 50 Million to < Rp. 100 Million",
            "rangeInd": "Rp. 50 Juta s/d < Rp. 100 Juta",
            "code": "G",
            "value": "75000000"
        },
        {
            "rangeEng": "Rp. 100 Million to < Rp. 250 Million",
            "rangeInd": "Rp. 100 Juta s/d < Rp. 250 Juta",
            "code": "H",
            "value": "175000000"
        },
        {
            "rangeEng": "Rp. 250 Million to < Rp. 500 Million",
            "rangeInd": "Rp. 250 Juta s/d < Rp. 500 Juta",
            "code": "I",
            "value": "375000000"
        },
        {
            "rangeEng": "Rp. 500 Million to < Rp. 1 Billion",
            "rangeInd": "Rp. 500 Juta s/d < Rp. 1 Miliar",
            "code": "J",
            "value": "750000000"
        },
        {
            "rangeEng": "Rp. 1 Billion to < Rp. 1.5 Billion",
            "rangeInd": "Rp. 1 Miliar s/d < Rp. 1.5 Miliar",
            "code": "K",
            "value": "1250000000"
        },
        {
            "rangeEng": "Rp. 1.5 Billion to < Rp. 2 Billion",
            "rangeInd": "Rp. 1.5 Miliar s/d < Rp. 2 Miliar",
            "code": "L",
            "value": "1750000000"
        },
        {
            "rangeEng": "Rp. 2 Billion to < Rp. 3 Billion",
            "rangeInd": "Rp. 2 Miliar s/d < Rp. 3 Miliar",
            "code": "M",
            "value": "2500000000"
        },
        {
            "rangeEng": "Rp. 3 Billion to < Rp. 4 Billion",
            "rangeInd": "Rp. 3 Miliar s/d < Rp. 4 Miliar",
            "code": "N",
            "value": "3500000000"
        },
        {
            "rangeEng": "Rp. 4 Billion to < Rp. 5 Billion",
            "rangeInd": "Rp. 4 Miliar s/d < Rp. 5 Miliar",
            "code": "O",
            "value": "4500000000"
        },
        {
            "rangeEng": ">/= Rp. 5 Billion",
            "rangeInd": ">/= Rp. 5 Miliar",
            "code": "P",
            "value": "5000000000"
        },
        {
            "rangeEng": "No Income",
            "rangeInd": "Tidak Berpenghasilan",
            "code": "Q",
            "value": "0"
        }
    ],
    "Corporate": [{
            "rangeEng": "Less than Rp.100 Million",
            "rangeInd": "Kurang dari Rp.100 Juta",
            "code": "A",
            "value": "100000000"
        },
        {
            "rangeEng": "Rp.100 Million to < Rp.500 Million",
            "rangeInd": "Rp.100 Juta s/d < Rp.500 Juta",
            "code": "B",
            "value": "250000000"
        },
        {
            "rangeEng": "Rp.500 Million to < Rp.1 Billion",
            "rangeInd": "Rp.500 Juta s/d < Rp.1 Miliar",
            "code": "C",
            "value": "750000000"
        },
        {
            "rangeEng": "Rp.1 Billion to < Rp.5 Billion",
            "rangeInd": "Rp.1 Miliar s/d < Rp.5 Miliar",
            "code": "D",
            "value": "3000000000"
        },
        {
            "rangeEng": "Rp.5 Billion to < Rp.10 Billion",
            "rangeInd": "Rp.5 Miliar s/d < Rp.10 Miliar",
            "code": "E",
            "value": "7500000000"
        },
        {
            "rangeEng": "Rp.10 Billion or more",
            "rangeInd": "Rp.10 Miliar atau lebih",
            "code": "F",
            "value": "10000000000"
        }
    ]
};

const jobsAll = function(jobsCode, jobsField) {
    var value = '';
    if (occupationList) {
        for (var j = 0; j < occupationList.length; j++) {
            if (occupationList[j].code == jobsCode) {
                if (jobsField == 'jobNameEng') {
                    value = occupationList[j].nameEng;
                } else if (jobsField == 'jobNameInd') {
                    value = occupationList[j].nameInd;
                } else if (jobsField == 'descriptionEng') {
                    value = occupationList[j].descriptionEng;
                } else if (jobsField == 'descriptionInd') {
                    value = occupationList[j].descriptionInd;
                } else if (jobsField == 'clazz') {
                    value = occupationList[j].clazz;
                }
            }
        }
    }
    return value;
};

const positionAll = function(position, field) {
    var value = '';
    if (positionList) {
        for (var j = 0; j < positionList.length; j++) {
            if (positionList[j].code == position || positionList[j].descriptionInd == position || positionList[j].descriptionEng == position) {
                if (field == 'code') {
                    value = positionList[j].code;
                } else if (field == 'descriptionInd') {
                    value = positionList[j].descriptionInd;
                } else if (field == 'descriptionEng') {
                    value = positionList[j].descriptionEng;
                }
            }
        }
    }
    return value;
};

let client;

module.exports = {
    setClient: function(inClient) { client = inClient; },
    readJSONFile: readJSONFile,
    bufferToBase64: bufferToBase64,
    sendSMS: sendSMS,
    getRandomVal: getRandomVal,
    convertBase64: convertBase64,
    createShortUrl: createShortUrl,
    convertDocxToPdf: convertDocxToPdf,
    getRandomOtpCode: getRandomOtpCode,
    modifyPolicyAfter: modifyPolicyAfter,
    occupationList: occupationList,
    positionList: positionList,
    jobsAll: jobsAll,
    positionAll: positionAll,
    docxConverter: docxConverter
}