<nav class="navbar navbar-expand-xs fixed-top bg-white shadow-sm">
        <ul class="navbar-nav  ">
            <li class="nav-item">
                <a class="nav-link" href="https://prudential.co.id/id/" target="_blank" ><img src="logo_pru.png" alt="logo_pru" width="150" height="35" ></a>
            </li>
        </ul>
</nav>