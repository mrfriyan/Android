<div class="row justify-content-center animate-bottom mt-5 pt-5">
	<div class="col-12" style="height: 100%; position: fixed;">
		<div class="row mt-5 justify-content-center align-items-center">
			<div class="col-md-6">
				<div class="col-md-12  text-center">
                    <h5 class="text-center">Pengajuan Tidak Setuju</h5>
    <p>Terima kasih atas konfirmasi Anda. Hubungi Tenaga Pemasar Anda untuk informasi lebih lanjut.</p>
                    <p class=" mb-5 pb-5"> Terima kasih</p>
                    <!-- <a href="/"><button class="btn btn-block btn-danger">Tutup</button></a> -->
				</div>
			</div>
		</div>
        </div>
</div>