<script context="module">
  // export let page = "verification";
  let action;
  let action_setuju;
  let action_tidak_setuju;
  let actionSetujuAlter;
  let actionTidakSetujuAlter;
  let actionLanjutkan;
</script>

<script>
  import Disclaimer from "../routes/Disclaimer";
  import CampaignOutput from "../routes/CampaignOutput";
  import AlterOutput from "../routes/AlterOutput";
  import Verification from "../routes/Verification";
  import Confirmation from "../routes/Confirmation";
  import AlterConfirmation from "../routes/AlterConfirmation";
  import Reject from "../routes/Reject";
  import { goto, stores } from "@sapper/app";
  import Loader from "../components/Loader";
  import { Alert } from "sveltestrap";
  import { onMount } from "svelte";
  import browser from "browser-detect";

  const browserDetect = browser();
  // import * as config from '../server/config/server-config.js';

  const config = require("../server/config/server-config.js");
  // const { session } = stores();
  let page = "verification";
  let pdfBase64;
  let pdfBase64Alter;
  let loading;
  let phoneNumber;

  // alert component config
  let alertVisible;
  let alertMessage;
  let alertType;

  export let uid;

  const showAlert = function(type, msg) {
    alertVisible = true;
    alertType = type;
    alertMessage = msg;
    setTimeout(function() {
      alertVisible = false;
    }, 4000);
  };
  loading = true;
  onMount(async () => {
    let queryString = window.location.search;
    console.log(queryString);
    let urlParams = new URLSearchParams(queryString);
    console.log(urlParams);
    uid = urlParams.get("uid");
    console.log(uid);
    loading = false;
  });

  const login = async function(event) {
    loading = true;
    await fetch(config.env_url + "/checkStatus", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ transactionId: uid })
    })
      .then(function(response) {
        return response.json();
      })
      .then(responseJson => {
        loading = false;
        if (responseJson.data.responseCode == "00") {
          if (responseJson.data.OTP.status == "APPROVE") {
            goto(config.basePath + "/route_setuju");
          } else if (responseJson.data.OTP.status == "REJECT") {
            goto(config.basePath + "/route_tidaksetuju");
          } else if (responseJson.data.OTP.status == "EXPIRED") {
            goto(config.basePath + "/expired");
          } else {
            getData(password.value, uid);
          }
        } else {
          goto(config.basePath + "/expired");
        }
      })
      .catch(function(err) {
        loading = false;
        goto(config.basePath + "/rorre");
      });
  };

  const getData = async function(password, uid) {
    loading = true;
    await fetch(config.env_url + "/login", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ password: password, transactionId: uid })
    })
      .then(response => {
        return response.json();
      })
      .then(responseJson => {
        console.log(responseJson);
        if (responseJson.isLoggedIn) {
          if (responseJson.campaignCode == "") {
            pdfBase64Alter = responseJson.base64;
            loading = false;
            page = "alter-output";
          } else if (
            responseJson.campaignCode != "" &&
            responseJson.policyNumber
          ) {
            pdfBase64 = responseJson.base64;
            loading = false;
            page = "campaign-output";
          }
        } else {
          loading = false;
          showAlert("danger", "Maaf password salah atau link sudah expired");
          // page = 'campaign-output';
        }
      })
      .catch(function(err) {
        loading = false;
        showAlert("danger", "Maaf password salah atau link sudah expired");
      });
  };

  const confirmation = async function(event) {
    loading = true;
    await fetch(config.env_url + "/getPhoneNumberByTransactionId", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ transactionId: uid })
    })
      .then(resp => {
        console.log(
          "response from getPhoneNumberByTransactionId in the bottom"
        );
        console.log(resp);
        return resp.json();
      })
      .then(respJson => {
        phoneNumber = respJson.phoneNumber;
        fetch(config.env_url + "/sendOTP", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ transactionId: uid, phoneNumber: phoneNumber })
        })
          .then(response => {
            console.log("response from sendOTP in the bottom");
            console.log(response);
            if (response.status == 500) {
              loading = false;
            }
            return response.json();
          })
          .then(responseJson => {
            if (phoneNumber) {
              console.log("harusnya ke redirect ke halaman konfirmasi");
              loading = false;
              page = "confirmation";
            }
          });
      });
  };

  const alterConfirmation = async function(event) {
    loading = true;
    await fetch(config.env_url + "/getPhoneNumberByTransactionId", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ transactionId: uid })
    })
      .then(resp => {
        console.log(
          "response from getPhoneNumberByTransactionId in the bottom"
        );
        console.log(resp);
        return resp.json();
      })
      .then(respJson => {
        phoneNumber = respJson.phoneNumber;
        fetch(config.env_url + "/sendOTP", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ transactionId: uid, phoneNumber: phoneNumber })
        })
          .then(response => {
            console.log("response from sendOTP in the bottom");
            console.log(response);
            if (response.status == 500) {
              loading = false;
            }
            return response.json();
          })
          .then(responseJson => {
            if (phoneNumber) {
              console.log("harusnya ke redirect ke halaman konfirmasi");
              loading = false;
              page = "alter-confirmation";
            }
          });
      });
  };

  const disclaimer = async function(event) {
    page = "disclaimer";
  };

  const reject = async function(event) {
    page = "reject-page";
  };
  actionLanjutkan = disclaimer;
  action_setuju = confirmation;
  action_tidak_setuju = reject;
  actionSetujuAlter = alterConfirmation;
  actionTidakSetujuAlter = reject;
  action = login;
</script>

<svelte:head>
  <title>Verifikasi</title>
</svelte:head>
{#if alertVisible}
  <div class="row animation-bottom">
    <div class="col-md-12 mt-5 pt-2" style="position:absolute;">
      <Alert
        color={alertType}
        class="float-right"
        style="z-index:99999;"
        isOpen="true"
        toggle={() => (alertVisible = false)}>
        <!-- <h4 class="alert-heading">Well done!</h4> -->
        {alertMessage}
      </Alert>
    </div>
  </div>
{/if}

{#if loading == true}
  <Loader />
{/if}

{#if page == 'verification'}
  <Verification {action} transactionId={uid} />
{/if}

{#if page == 'campaign-output'}
  <CampaignOutput dataPdf={pdfBase64} {action_setuju} {action_tidak_setuju} />
{/if}


{#if page == 'alter-output'}
  <AlterOutput dataPdfAlter={pdfBase64Alter} {actionLanjutkan} />
{/if}

{#if page == 'disclaimer'}
  <Disclaimer  {actionSetujuAlter} {actionTidakSetujuAlter} />
{/if}


{#if page == 'confirmation'}
  <Confirmation transactionId={uid} {phoneNumber} />
{/if}

{#if page == 'alter-confirmation'}
  <AlterConfirmation transactionId={uid} {phoneNumber} />
{/if}

{#if page == 'reject-page'}
  <Reject transactionId={uid} />
{/if}
