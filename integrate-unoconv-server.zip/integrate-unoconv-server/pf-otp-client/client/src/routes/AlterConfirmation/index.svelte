<script>
  import { onMount } from "svelte";
  import Button from "../../../node_modules/sveltestrap/src/Button";
  import Input from "../../../node_modules/sveltestrap/src/Input";
  import Col from "../../../node_modules/sveltestrap/src/Col";
  import Row from "../../../node_modules/sveltestrap/src/Row";
  import Loader from "../../components/Loader";
  import { goto, stores } from "@sapper/app";
  import { Alert } from "sveltestrap";
  import browser from "browser-detect";
  import mobile from "mobile-detect";

  const config = require("../../server/config/server-config.js");
  const browserDetect = browser();
  var md = new mobile(window.innerHeight.UserAgent);
  // const { session } = stores();

  let expiredTime;
  let loading;

  // alert component config
  let alertVisible;
  let alertMessage;
  let alertType;

  export let transactionId;
  export let phoneNumber;
  // export let action_submit_otp;
  let x;

  let isPotrait = function() {
    if (window.innerHeight > window.innerWidth) {
      return true;
    } else {
      return false;
    }
  };

  let focus = function() {
    var layout_otp = document.getElementById("layout-otp");
    if (browserDetect.mobile === true && isPotrait() && !md.tablet()) {
      //mobile potrait
      console.log(window.innerHeight);
      layout_otp.style.marginTop = "-45%";
      layout_otp.style.transition = ".35s ease-in-out";
      // console.log(layout - otp.style.marginTop);
    } else if (browserDetect.mobile === true && !isPotrait() && !md.tablet()) {
      // mobile landscape
      layout_otp.style.marginTop = "-20%";
      layout_otp.style.transition = ".35s ease-in-out";
    }
  };

  let blur = function() {
    var layout_otp = document.getElementById("layout-otp");
    if (browserDetect.mobile === true && isPotrait()) {
      //mobile potrait
      layout_otp.style.marginTop = "0%";
      layout_otp.style.transition = ".35s ease-in-out";
    } else if (browserDetect.mobile === true && !isPotrait()) {
      // mobile landscape
      layout_otp.style.marginTop = "0%";
      layout_otp.style.transition = ".35s ease-in-out";
    }
  };

  onMount(async () => {
    if (!transactionId) {
      goto(config.basePath + "/rorre");
    }
    const result = await fetch(config.env_url + "/getOTP", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ transactionId: transactionId })
    })
      .then(response => {
        return response.json();
      })
      .then(responseJson => {
        count_otp();
      });
  });

  let submitPenawaran = async function() {
    loading = true;
    document.getElementById("Ajukan").disabled = true;
    setTimeout(function() {
      document.getElementById("Ajukan").disabled = false;
    }, 3000);
    // console.log(document.getElementById("kodeOTP"));

    await fetch(config.env_url + "/checkStatus", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ transactionId: transactionId })
    })
      .then(response => {
        return response.json();
      })
      .then(responseJson => {
        console.log(responseJson);
        if (responseJson.data.responseCode == "00") {
          if (responseJson.data.OTP.status == "ACTIVE") {
            fetch(config.env_url + "/submitOTPAlter", {
              method: "POST",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json"
              },
              body: JSON.stringify({
                transactionId: transactionId,
                otp: document.getElementById("kodeOTP").value,
                statusCode: "77"
              })
            })
              .then(resp => {
                return resp.json();
              })
              .then(respJson => {
                console.log(respJson);

                if (respJson.data.responseCode == "00") {
                  loading = true;
                  goto(config.basePath + "/route_setuju");
                } else {
                  loading = false;
                  document.getElementById("alert").style.display = "block";
                  let alert;
                  alert = setTimeout(Alert, 3000);
                  function Alert() {
                    document.getElementById("alert").style.display = "none";
                  }
                }
              })
              .catch(err => {
                loading = false;
                // alert("Code OTP tidak sesuai");
              });
          } else {
            loading = false;
            goto(config.basePath + "/expired");
          }
        } else {
          loading = false;
          document.getElementById("failed").style.display = "block";
        }
      })
      .catch(err => {
        loading = false;
        // alert("Code OTP tidak sesuai");
      });
  };

  function count_otp() {
    let countDownDate = new Date(Date.now() + 302000).getTime(); // Update the count down every 1 second
    x = setInterval(function() {
      // Get todays date and time
      let now = new Date().getTime();
      let distance = countDownDate - now; // Find the distance between now and the count down date
      let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)); // Time calculations for days, hours, minutes and seconds
      let seconds = Math.floor((distance % (1000 * 60)) / 1000);

      document.getElementById("expire").innerHTML =
        "Berlaku : " +
        "<b class='text-danger'>" +
        "0" +
        minutes +
        ":" +
        seconds;
      "</b>"; // Output the result in an element with id="demo"
      if (seconds < 10) {
        document.getElementById("expire").innerHTML =
          "Berlaku : " +
          "<b class='text-danger'>" +
          "0" +
          minutes +
          ":" +
          "0" +
          seconds;
        "</b>";
      }
      if (distance < 0) {
        // If the count down is over, write some text
        clearInterval(x);
        document.getElementById("expire").innerHTML = "OTP Code EXPIRED !";
      }
    }, 1000);
  }

  function count_kirimulang() {
    clearInterval(x);
    count_otp();
    let countDownDate = new Date(Date.now() + 62000).getTime(); // Update the count down every 1 second
    let y = setInterval(function() {
      // Get todays date and time
      let now = new Date().getTime();
      let distance = countDownDate - now; // Find the distance between now and the count down date
      let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)); // Time calculations for days, hours, minutes and seconds
      let seconds = Math.floor((distance % (1000 * 60)) / 1000);

      document.getElementById("count_kirimulang").innerHTML =
        "0" + minutes + ":" + seconds; // Output the result in an element with id="demo"
      document.getElementById("waiting").style.display = "block";

      document.getElementById("kirimulang").style.display = "none";
      if (seconds < 10) {
        document.getElementById("count_kirimulang").innerHTML =
          "0" + minutes + ":" + "0" + seconds;
      }
      if (distance < 0) {
        // If the count down is over, write some text
        clearInterval(y);
        document.getElementById("waiting").style.display = "none";
        document.getElementById("kirimulang").style.display = "block";
      }
    }, 1000);
  }

  function kirimulang() {
    loading = true;
    // countdownOTP(1);
    fetch(config.env_url + "/sendOTP", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ transactionId: transactionId })
    })
      .then(response => {
        if (response.status == 500) {
          loading = false;
          // this.redirect(404, 'Not Found');
        }
        return response.json();
      })
      .then(responseJson => {
        count_kirimulang();
        // console.log(responseJson);
        loading = false;
        // countdown(5);
      });
  }
</script>

<!--Alert-->
<div class="row animate-bottom mt-2" id="alert" style="display:none">
  <div class="col-md-12 mt-5 pt-2" style="position:absolute;">
    <Alert
      color="danger"
      class="float-right"
      style="z-index:99999;"
      isOpen="true">
      Kode OTP yang dimasukkan tidak sesuai
    </Alert>
  </div>
</div>

{#if loading == true}
  <Loader />
{/if}

<div class="row justify-content-center animate-bottom mt-5 pt-5">
  <div class="col-12" style="height: 100%; position: fixed;">
    <div class="row mt-5 justify-content-center align-items-center">
      <div class="col-md-6">
        <div class="col-md-12" id="layout-otp">

          <p class="text-center">
            Kode OTP (One Time Password) telah dikirimkan melalui telepon
            selular Anda
          </p>
          <p class="text-center">
            xxx-xxxx-{phoneNumber.substring(phoneNumber.length - 4)}
          </p>
          <p class="text-center">
            <strong class="text-danger" id="expire" />
          </p>
          <!-- <strong id="failed" class="text-danger text-center" style="display:none">Code OTP tidak sesuai</strong> -->
          <div class="form-group">
            <input
              type="text"
              class="form-control form-control-sm mt-2"
              placeholder="Kode OTP"
              id="kodeOTP"
              on:focus={focus}
              on:blur={blur} />
          </div>

          <input
            type="submit"
            id="Ajukan"
            class="btn btn-block btn-danger mb-2"
            on:click={submitPenawaran}
            value="Ajukan" />
          <Button
            id="kirimulang"
            class="btn btn-danger btn-block mt-2"
            style="display:block"
            on:click={kirimulang}>
            Kirim Ulang
          </Button>
          <Button
            id="waiting"
            class="btn btn-secondary btn-block mt-2"
            style="display:none"
            disabled>
            Kirim Ulang
            <span id="count_kirimulang" />
          </Button>
        </div>
      </div>
    </div>
  </div>
</div>
