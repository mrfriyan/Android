<script>
    import CampaignOutput from '../CampaignOutput';
	import * as PDFGenerator from '../CampaignOutput/PDFGenerator';
	import Button from '../../../node_modules/sveltestrap/src/Button';
	import Col from '../../../node_modules/sveltestrap/src/Col';
	import Row from '../../../node_modules/sveltestrap/src/Row';
	import Show from 'svelte-icons/fa/FaEye.svelte';
	import Hidden from 'svelte-icons/fa/FaEyeSlash.svelte';
	import { goto, stores } from '@sapper/app';
	import { onMount } from 'svelte';
	import browser from 'browser-detect';
	import mobile from 'mobile-detect';
	
	import Loader from '../../components/Loader';

	const browserDetect = browser();
	var loading;
	var md = new mobile(window.innerHeight.UserAgent);
	console.log(md.tablet());

	export let password = '';
	export let action;
	export let transactionId;

	let isPotrait = function(){
		if(window.innerHeight > window.innerWidth){
			return true;
		}else{
			return false;
		}
	}

	let focus = function(){
		var pwd = document.getElementById("rules");
		if(browserDetect.mobile === true &&  isPotrait() && !md.tablet()){ //mobile potrait
			console.log(window.innerHeight);
			pwd.style.marginTop = "-47%";
			pwd.style.transition = ".35s ease-in-out";
			console.log(pwd.style.marginTop);
		}
		else if(browserDetect.mobile === true && !isPotrait() && !md.tablet()){ // mobile landscape
			pwd.style.marginTop = "-30%";
			pwd.style.transition = ".35s ease-in-out";
		}
	}		

	let blur = function(){
		var pwd = document.getElementById("rules");
		if(browserDetect.mobile === true && isPotrait()){ //mobile potrait
			pwd.style.marginTop = "0%";
			pwd.style.transition = ".35s ease-in-out";
		}
		else if(browserDetect.mobile === true && !isPotrait()){ // mobile landscape
			pwd.style.marginTop = "0%";
			pwd.style.transition = ".35s ease-in-out";
		}
	}	
	
	onMount(async () => {
		console.log(browserDetect);

		if(browserDetect.mobile === true && isPotrait()){; //mobile potrait
			document.getElementById("rules").style.fontSize = "11px";
			document.getElementById("example").style.fontSize = "13px";
			document.getElementById("show").style.left = "90%";
			document.getElementById("hidden").style.left = "90%";		
        } 
		else if (browserDetect.mobile === true && !isPotrait()){; //mobile landscape
			document.getElementById("rules").style.fontSize = "11px";
			document.getElementById("example").style.fontSize = "14px";
			document.getElementById("show").style.left = "93%";
			document.getElementById("hidden").style.left = "93%";
		}
	});

	function passwords() {
		var pwd = document.getElementById("password");
		if (pwd.type === "password") {
			pwd.type = "text";
			document.getElementById("hidden").style.display = "block";
			document.getElementById("show").style.display = "none";
		} else {
			pwd.type = "password";
			document.getElementById("hidden").style.display = "none";
			document.getElementById("show").style.display = "block";
		}
	}
</script>

{#if loading == true}
	<Loader></Loader>
{/if}

<div id="verification" class="row justify-content-center">
	<div class="col-12 bg-danger mt-5 pt-5 mb-5 pb-5" style="height: 100%; position: fixed;" >
		<div id ="rules">
			<div class="align-items-center  text-white col-md-6 offset-md-3">
			<!-- <p class="text-center">Nomor Polis Anda ({transactionId.substring(transactionId.length-12).substring(0,8)})</p> -->
			<p class="text-center">Masukkan password Anda dengan format sebagai berikut ddMmmyy</p>
			<p class="text-center" id="example" style="font-size:18px;">Contoh (02Aug84)</p>
				<ul class="text-justify">
				<li>dd adalah 2 digit tanggal lahir Pemegang Polis.</li>
				<li>Mmm adalah tiga huruf pertama bulan lahir Pemegang Polis dalam Bahasa Inggris. Huruf pertama adalah huruf besar dan selanjutnya huruf kecil, contoh Dec, May, Jun.</li>
				<li>yy adalah 2 digit akhir tahun lahir Pemegang Polis.</li>
				</ul>
		</div>
		
		<form id="verification" class="align-items-center col-md-6 offset-md-3" on:submit|preventDefault={action} method="post">
				<div class="form-group">
					<input type="password" class="form-control form-control-sm" name="password" id="password" placeholder="Password" bind:value={password} on:focus={focus} on:blur={blur} required/>
					<div id="show" class="icon" on:click={passwords} style="display:block"><Show/></div>
					<div id="hidden" class="icon" on:click={passwords} style="display:none"><Hidden/></div>				
				</div>
				<div class="form-group">
					<Button class="btn-sm" block>Masuk</Button>
				</div>
			</form>	
				</div>
		</div>
</div>
