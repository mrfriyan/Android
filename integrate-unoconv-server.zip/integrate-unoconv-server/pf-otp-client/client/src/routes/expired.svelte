<script>
	export let status;
	export let error;

	const dev = process.env.NODE_ENV === 'development';
</script>

<!-- <style>
	h1, p {
		margin: 0 auto;
	}

	h1 {
		font-size: 2.8em;
		font-weight: 700;
		margin: 0 0 0.5em 0;
	}

	p {
		margin: 1em auto;
	}

	@media (min-width: 480px) {
		h1 {
			font-size: 4em;
		}
	}
</style> -->

<svelte:head>
	<title>404</title>
</svelte:head>

<div class="row " >
	<div class="text-center col-sm-1 rounded2 col-md-6 offset-md-3 mt-5 pt-5" style="height: 100%;position: fixed;">
		<img src="logo.jpg" style="width: 300px;opacity:0.4;" alt="logo"/>
		<h2 style="margin-bottom:0;" class="text-danger text-center">Expired</h2>
		<h5 class="text-bold text-center">Maaf Link Sudah Tidak Aktif</h5>
	</div>
</div>