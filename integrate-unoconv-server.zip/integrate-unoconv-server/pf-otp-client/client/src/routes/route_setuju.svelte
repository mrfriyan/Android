

<div class="row justify-content-center animate-bottom mt-4 pt-4">
	<div class="col-12" style="height: 100%; position: fixed;">
		<div class="row mt-5 justify-content-center align-items-center">
			<div class="col-md-6">
				<div class="col-md-12  text-center">
                    <h5 class="text-center">Pengajuan Setuju</h5>
                    <p>Pengajuan Anda telah kami terima dan akan segera diproses, hubungi Tenaga Pemasar Anda untuk informasi lebih lanjut.</p>
                    <p> Terima kasih</p>
					<img src="sent.png" style="width: 120px;" alt="sent"/>
                    <!-- <a href="/"><button class="btn btn-block btn-danger">Tutup</button></a> -->
				</div>
			</div>
		</div>
    </div>
</div>