<script context="module">
	export async function preload({ params }) {
		const { slug } = params;
		return { slug };
	}
</script>

<script>
	import { onMount } from 'svelte';
	import { goto, stores } from '@sapper/app';
	import rorre from '../rorre';
	import Loader from '../../components/Loader';

	const config = require('../../server/config/server-config.js');

	let photos = [];
	export let slug;
	
	onMount(async () => {
		let self = this;
		let dataUrl;
		console.log(slug);
		const result = await fetch(config.env_url+"/urlCheck",{
			method: 'POST',
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({slug: slug})
		}).then(response=>{
			return response.json();
		}).then(responseJson=>{
			if(responseJson.data[0] == slug){
				dataUrl = responseJson;
				return true;
			}else{
				return false;
			}
		})
		if(result){
			await fetch(config.env_url+"/checkStatus",{
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({transactionId: dataUrl.data[1]})
			}).then(function(response){
				return response.json();
			}).then(responseJson=>{
				if(responseJson.data.responseCode == "00"){
					if(responseJson.data.OTP.status == "APPROVE"){
						goto(config.basePath+'/route_setuju');
					}else if(responseJson.data.OTP.status == "REJECT"){
						goto(config.basePath+'/route_tidaksetuju');
					}else if(responseJson.data.OTP.status == "EXPIRED"){
						goto(config.basePath+'/expired');
					}else{
						goto(config.basePath+"?uid="+dataUrl.data[1]);
					}
				}else{
					goto(config.basePath+'/expired');
				}
			}).catch(function(err){
				goto(config.basePath+"?uid="+dataUrl.data[1]);
			})
		}else{
			goto(config.basePath+'/expired');
		}
	});
</script>

<!-- <style>
	h1, p {
		margin: 0 auto;
	}

	h1 {
		font-size: 2.8em;
		font-weight: 700;
		margin: 0 0 0.5em 0;
	}

	p {
		margin: 1em auto;
	}

	@media (min-width: 480px) {
		h1 {
			font-size: 4em;
		}
	}
</style> -->

<Loader></Loader>
<div class="row " >
	<div class="text-center col-sm-1 rounded2 col-md-6 offset-md-3" >
		<img src="logo.jpg" style="width: 300px;opacity:0.4; margin-top:30%;" alt="logo"/>
	</div>
</div>