
<svelte:head>
	<title>PDF Viewer</title>
</svelte:head>

<script context="module">

function setuju(){
      document.getElementById("setuju").style.display = "block";
      document.getElementById("pdf-container").style.display = "none";
      document.getElementById("pager").style.display = "none";
			return false;
}

function tidaksetuju(){      
      document.getElementById("tidaksetuju").style.display = "block ";
      document.getElementById("pdf-container").style.display = "none";
      document.getElementById("pager").style.display = "none";
			return false;
}

function zoomin(){
    PDFGenerator.zoomIn();
    var pdfzoom = document.getElementById("viewport");
    var currWidth = pdfzoom.clientWidth;
    if(currWidth == 2500) return false;
     else{
        pdfzoom.style.width = (currWidth + 100) + "px";
    } 
}

function zoomout(){
    PDFGenerator.zoomOut();
    var pdfzoom = document.getElementById("viewport");
    var currWidth = pdfzoom.clientWidth;
    if(currWidth == 100) return false;
     else{
        pdfzoom.style.width = (currWidth - 100) + "px";
    }
}

</script>

<script>
  import { onMount } from 'svelte';
  import * as PDFGenerator from './PDFGenerator';
  // import { Button,Input, ButtonGroup,Navbar, Col, Row } from 'sveltestrap';
  import Button from '../../../node_modules/sveltestrap/src/Button';
  import Input from '../../../node_modules/sveltestrap/src/Input';
  import ButtonGroup from '../../../node_modules/sveltestrap/src/ButtonGroup';
  import Navbar from '../../../node_modules/sveltestrap/src/Navbar';
  import Col from '../../../node_modules/sveltestrap/src/Col';
  import Row from '../../../node_modules/sveltestrap/src/Row';
  import Zoomin from 'svelte-icons/fa/FaPlus.svelte';
  import Zoomout from 'svelte-icons/fa/FaMinus.svelte';
  import browser from 'browser-detect';

  let today = new Date();
  let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
  let time = "23:59";
  let dateTime = date+' '+time;
  export let dataPdf;
  export let action_setuju;
  export let action_tidak_setuju;
  
  onMount(() => {
    document.getElementsByName("container_terms")[0].addEventListener("scroll", checkScrollHeight, false);
    function checkScrollHeight() {
      var agreementTextElement = document.getElementsByName("container_terms")[0];
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= agreementTextElement.scrollHeight) {
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= 1000) {
      if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= agreementTextElement.scrollHeight - 450) {
        document.getElementsByName("dsetuju")[0].style.display = "none";	
        document.getElementsByName("dnotsetuju")[0].style.display = "none";
        document.getElementsByName("setuju")[0].style.display = "block";	
        document.getElementsByName("notsetuju")[0].style.display = "block";	
      }
    }
    const viewport = document.querySelector("#viewport");
    // console.log(dataPdf);
    PDFGenerator.initPDFViewer({data:atob(dataPdf)});
    
    const browserDetect = browser();
    // console.log(browserDetect.mobile);
    var scale;
	  if(browserDetect.mobile === true){
        scale = PDFGenerator.scaleMobile();
        document.getElementById("viewport-container").style.paddingBottom = "25%";
        document.getElementById("pager").style.fontSize="12px";
      } else if(browserDetect.mobile === false) {
        scale = PDFGenerator.scaleWeb(); 
        document.getElementById("viewport-container").style.paddingTop = "5%";
        document.getElementById("zoomin").style.width = "20px";
        document.getElementById("zoomout").style.width = "20px";
        
    }
  
  });

  window.addEventListener("resize", function(e){
    // console.log("resize");
    PDFGenerator.render();
  });

</script>

<main>
  <div id="pdf-viewer" class="row justify-content-center animate-bottom ">
    <div class="col-12" style="height: 100%; position: fixed;" >
      <div class="justify-content-center align-items-center">
        <div id="pdf-container" onresize="resize">
          <div id="viewport-container"  name="container_terms" >
            <div  role="main" id="viewport"></div>
          </div>
        </div> 
        <Navbar id="pager" class="navbar bg-white fixed-bottom shadow-lg">  
            <div class="col-12">
              
              <p class="pt-2">Gulirkan layar hingga detail penawaran ini selesai untuk menyetujui. <br> Apakah anda setuju dengan penawaran ini ?</p>
              <small  class="font-italic font-weight-small">Penawaran ini berlaku hingga <strong class="text-danger">{dateTime}</strong></small>
            </div>
            
            <!--enable button-->
            <div class="col-6">
              <Button name="notsetuju" on:click = {action_tidak_setuju} class="btn btn-secondary" block style="display:none">Tidak Setuju</Button>
            </div>
            <div class="col-6">
              <Button  name="setuju" on:click = {action_setuju} class="btn btn-danger" block style="display:none">Setuju</Button>
            </div>

            <!--disable button-->
            <div class="col-6">
              <Button name="dnotsetuju" block disabled class="btn btn-secondary" style="display:block">Tidak Setuju</Button>
            </div>
            <div class="col-6">
              <Button  name="dsetuju" block disabled class="btn btn-secondary" style="display:block">Setuju</Button>
            </div>
            
            <Navbar  class="navbar navbar-expand-xs fixed-bottom   mb-5 pb-5">  
            <ul class="navbar-nav  ml-auto">
                <div  class ="col-12  fixed mb-5 pb-5">
                    <Button class="btn btn-dark btn-sm" style="border-radius:100%;"><div id="zoomin" style="font-size:8px; width: 8px; margin-bottom:1px;"  on:click = {zoomin}><Zoomin/></div> </Button>
                    <Button class="btn btn-dark btn-sm" style="border-radius:100%;"><div id="zoomout" style="font-size:8px; width: 8px; margin-bottom:1px;"  on:click = {zoomout}><Zoomout/></div></Button>
                </div>         
            </ul>
          </Navbar>  
        </Navbar>
      </div>
    </div>
  </div>
</main>
