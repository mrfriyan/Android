import sirv from 'sirv';
import compression from 'compression';
import * as sapper from '@sapper/server';
import CampaignOutputCtrl from './server/controllers/CampaignOutputCtrl';
import Utils from './server/controllers/Utils';
import sessionFileStore from 'session-file-store';

const config = require('./server/config/server-config.js');
const express = require("express");
const { RateLimiterRedis } = require('rate-limiter-flexible');
const rateLimiterRedisMiddleware = require('./server/config/rate-limiter');
const redis = require("redis");
const fs = require('fs');
const fsx = require('fs-extra');
const path = require('path');
const cors = require('cors');
const NodeFetch = require('node-fetch');
const bodyParser = require("body-parser");
const request = require("request");
const schedule = require("node-schedule");
const helmet = require('helmet');
const pdf2base64 = require('pdf-to-base64');
const timeout = require('connect-timeout');
const moment = require('moment');
moment.locale('en');
const _ = require('lodash');

const logOpts = {
    errorEventName: 'error',
    logDirectory: './log', // NOTE: folder must exist and be writable...
    fileNamePattern: 'roll-<DATE>.log',
    dateFormat: 'DD.MM.YYYY'
};

const log = require('simple-node-logger').createRollingFileLogger(logOpts);

const router = express.Router();
const app = express();

const client = redis.createClient({
    host: config.redis_host,
    port: config.redis_port
});

const redisClient = redis.createClient({
    host: config.redis_host,
    port: config.redis_port,
    enable_offline_queue: false,
});

CampaignOutputCtrl.setClient(client);
Utils.setClient(client);

const { PORT, NODE_ENV } = process.env;
const dev = NODE_ENV === 'development';

var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');

    next();
};

const campaignList = [{
        "notifEventId": "69",
        "notifReqId": "EZCAMPAIGN_APPROVE",
        "campaignType": "PLS-002"
    },
    {
        "notifEventId": "70",
        "notifReqId": "EZCAMPAIGN_REJECT",
        "campaignType": "PLS-002"
    },
    {
        "notifEventId": "71",
        "notifReqId": "EZCAMPAIGNPLUS_APPROVE",
        "campaignType": "PLS-001"
    },
    {
        "notifEventId": "72",
        "notifReqId": "EZCAMPAIGNPLUS_REJECT",
        "campaignType": "PLS-001"
    },
    {
        "notifEventId": "73",
        "notifReqId": "TUMPENGFLEKSIBEL_APPROVE",
        "campaignType": "CCA-002"
    },
    {
        "notifEventId": "74",
        "notifReqId": "TUMPENGFLEKSIBEL_REJECT",
        "campaignType": "CCA-002"
    },
    {
        "notifEventId": "75",
        "notifReqId": "TUMPENGPAKET_APPROVE",
        "campaignType": "CCA-001"
    },
    {
        "notifEventId": "76",
        "notifReqId": "TUMPENGPAKET_REJECT",
        "campaignType": "CCA-001"
    },
    {
        "notifEventId": "77",
        "notifReqId": "ALTERATION_APPROVE",
        "campaignType": ""
    },
    {
        "notifEventId": "78",
        "notifReqId": "ALTERATION_REJECT",
        "campaignType": ""
    }
];

app.use(allowCrossDomain);
app.use(timeout('30s'));
app.use(helmet());
app.use(bodyParser.json({ limit: '30mb' }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors({
    origin: '*',
    credentials: true
}));

const maxConsecutiveFailsByUsername = 50;

const limiterConsecutiveFailsByUsername = new RateLimiterRedis({
    redis: redisClient,
    keyPrefix: 'login_fail_consecutive_username',
    points: maxConsecutiveFailsByUsername,
    duration: 60 * 60 * 3, // Store number for three hours since first fail
    blockDuration: 60 * 15, // Block for 15 minutes
});

async function loginRoute(req, res) {
    const username = req.body.transactionId;
    const rlResUsername = await limiterConsecutiveFailsByUsername.get(username);
    if (rlResUsername !== null && rlResUsername.consumedPoints > maxConsecutiveFailsByUsername) {
        const retrySecs = Math.round(rlResUsername.msBeforeNext / 1000) || 1;
        res.set('Retry-After', String(retrySecs));
        res.status(429).send('Too Many Requests');
    } else {
        let user = await CampaignOutputCtrl.authorise(req.body.password, req.body.transactionId).then(function(e) {
            return e;
        }).catch(function(err) {
            console.log(err);
            return err;
        });

        if (!user.isLoggedIn) {
            try {
                await limiterConsecutiveFailsByUsername.consume(username);

                res.status(400).end('email or password is wrong');
            } catch (rlRejected) {
                if (rlRejected instanceof Error) {
                    throw rlRejected;
                } else {
                    res.set('Retry-After', String(Math.round(rlRejected.msBeforeNext / 1000)) || 1);
                    res.status(429).send('Too Many Requests');
                }
            }
        } else {
            if (rlResUsername !== null && rlResUsername.consumedPoints > 0) {
                // Reset on successful authorisation
                await limiterConsecutiveFailsByUsername.delete(username);
            }
            return res.status(200).send({
                'base64': user.base64,
                'policyNumber': user.policyNumber,
                'transactionId': req.body.transactionId,
                'isLoggedIn': user.isLoggedIn,
                'exists': user.exists,
                'campaignCode': user.campaignCode
            });
        }
    }
}

app.use(config.basePath + '/login', rateLimiterRedisMiddleware);

app.post(config.basePath + '/login', async(req, res) => {
    try {
        await loginRoute(req, res);
    } catch (err) {
        res.status(500).end();
    }
});

app.post(config.basePath + '/generatePDFNormal', async function(req, res) {
    try {
        let dataAfter = req.body.dataAfter;
        let obj = {};
        console.log("masuk generate PDF Normal");
        // console.log(req.body.option);
        // CampaignOutputCtrl.replaceOTP(dataAfter.policyNumber, req.body.option, dataAfter.campaignInfo.campaignCode).then(function(response) {
        const convertData = await CampaignOutputCtrl.generatePDF(
            dataAfter, 
            parseInt(req.body.option), 
            req.body.type, 
            req.body.agentDetail,
             false
        )

        // kode ini hanya berjalan ketika conver success
        // #2 ubah ke base64
        // membaca file PDF sebagai buffer
        const buffer = fs.readFileSync(convertData.pdf);

        // mengubah buffer menjadi base64 encoding
        const base64 = buffer.toString('base64');

        

        return res.status(200).send({
            message: 'success convert',
            data: convertData,
            base64
        })
        
        // .then(function(result) {
        //     pdf2base64(path.join(__dirname, '/public/output/' + dataAfter.policyNumber + req.body.option + dataAfter.campaignInfo.campaignCode + '.pdf')).then((base64) => {
        //         // console.log(base64);
        //         obj.base64OTP = base64;
        //         return res.status(200).send(obj);
        //     }).catch((error) => {
        //         // console.log(base64);
        //         return res.status(500).send(obj);
        //     })
        // })
        

        /**
         * gak perlu karena udah ada yg catch
         */
        // .catch(err => {
        //     // log.error(" fail generate pdf  ", dataAfter.policyNumber , " phoneNumber : ", req.body.phoneNumber);
        //     console.error(err);
            // return res.status(500).send({
            //     'code': 'fail generate pdf',
            //     'description': err
            // });
        // })
        // }).catch((err) => {
        //     // log.error("Cannot connect to otp services");
        //     return res.status(500).send(err);
        // })
    } catch (err) {
        console.error(err)
        return res.status(500).send({
            'code': 'fail generate pdf',
            // error: err.message
            'description': err
        });

        // return res.status(500).send({ "param error": err });
    }

});

app.post(config.basePath + '/generatePDF', async function(req, res) {
    try {
        moment.locale('en');
        let dataAfter = req.body.dataAlter.main.policyAfter;
        // console.log("ini data After : ", dataAfter);
        let dataAlter = req.body.dataAlter;
        dataAlter.main.policyAfter.agent = req.body.agentDetail;

        let mSecond = Date.now();
        let transactionId = mSecond + "" + dataAfter.policyNumber;

        if (req.body.phoneNumber.includes("X")) {
            return res.status(500).send({
                "code": "305",
                "message": "sms not sent",
                "description": "phone number xxx"
            });
        }

        log.info('Generate PDF  ', dataAfter.campaignInfo.campaignCode, " policy number ", dataAfter.policyNumber, " option : ", req.body.option); //(req.body.option);
        console.log("generate pdf ");
        CampaignOutputCtrl.replaceOTP(dataAfter.policyNumber, req.body.option, dataAfter.campaignInfo.campaignCode).then(function(response) {
            CampaignOutputCtrl.generatePDF(dataAfter, parseInt(req.body.option), req.body.type, req.body.agentDetail, true).then(function(result) {
                //set for password
                // let otp = dataAfter.policyNumber.substring(0,4) + moment(dataAfter.clientRoleOW.clientDob, "YYYYMMDD").format("DD") + moment(dataAfter.clientRoleOW.clientDob, "YYYYMMDD").format("MMM");
                let otp = moment(dataAfter.clientRoleOW.clientDob, "YYYYMMDD").format("DDMMMYY");
                let today = moment().format("DD-MMM-YYYY");
                let expired = today + " 23:59";
                Utils.createShortUrl(transactionId).then(function(resp) {
                    console.log(resp[0]);
                    var url = config.url_sms_template_message + resp[0];
                    var msg = config.sms_otp_template_1 + url + config.sms_otp_template_2 + expired + config.sms_otp_template_3;
                    var _campaignType = function() {
                        switch (dataAfter.campaignInfo.campaignCode) {
                            case 'PLS-001':
                                return 'ECA';
                            case 'PLS-002':
                                return 'ECE';
                            case 'CCA-001':
                                return 'ECT';
                            case 'CCA-002':
                                return 'ECF';
                            default:
                                return '';
                        }
                    }
                    var obj = {
                        campaignId: dataAfter.campaignInfo.campaignCode,
                        campaignCode: dataAfter.campaignInfo.campaignCode,
                        campaignType: _campaignType(),
                        transactionId: resp[1],
                        agentNumber: dataAfter.agentNumber,
                        policyNumber: dataAfter.policyNumber,
                        phoneNumber: config.setDefaultPhoneNumber === false ? req.body.phoneNumber : config.setDefaultPhoneNumber,
                        otp: otp,
                        data: JSON.stringify(dataAlter),
                        shortUrl: url,
                        status: '01',
                        option: req.body.option.toString().length == 1 ? "0" + req.body.option.toString() : req.body.option.toString(),
                        alasan: '',
                        dob: dataAfter.clientRoleOW.clientDob
                    }
                    log.info("Data createOTP with transactionId ", resp[1]);
                    console.log("masuk sini");
                    CampaignOutputCtrl.createOTP(obj).then(function(responseDB) {
                        if (responseDB.responseCode == "00") {
                            Utils.sendSMS(resp[1], config.setDefaultPhoneNumber === false ? req.body.phoneNumber : config.setDefaultPhoneNumber, msg).then(function(responseSms) {
                                log.info("pengajuan berhasil terkirim ", resp[1]);

                                return res.status(200).send({
                                    'code': "200",
                                    'message': 'sms sent',
                                    'data': responseSms,
                                    'transactionId': resp[1],
                                    "description": "success"
                                });
                            }).catch((error) => {
                                console.log("error", error);
                                // log.error(" Fail to send sms  ", dataAfter.policyNumber , " phoneNumber : ", req.body.phoneNumber);
                                return res.status(500).send({
                                    'code': "305",
                                    'message': "sms not sen",
                                    "description": error
                                });
                            })
                        } else {
                            // console.log("error2", error);
                            // log.error(" Fail to send sms  ", dataAfter.policyNumber , " phoneNumber : ", req.body.phoneNumber);
                            return res.status(500).send({
                                'code': "306",
                                'message': "cannot create data db",
                                "description": "balikan dari servie otp 01"
                            });
                        }
                    }).catch((error) => {
                        console.log("error db", error);
                        // log.error(" Fail to save to db ", transactionId);
                        return res.status(500).send({
                            'code': '306',
                            'message': "Fail to save to db",
                            "description": error
                        });
                    })
                }).catch((err) => {
                    // log.error(" Fail to create short url ", transactionId);
                    return res.status(500).send({
                        'code': '304',
                        'message': "fail to create short url",
                        "description": err
                    });
                })
            }).catch((err) => {
                console.log(err);
                return res.status(500).send({
                    'code': '303',
                    'message': "fail generate pdf",
                    'description': err
                });
            })
        }).catch((err) => {
            return res.status(500).send({
                'code': '301',
                "message": "cannot conect to otp service",
                'description': err
            });
        })
    } catch (err) {
        return res.status(500).send({
            'code': '301',
            "message": "error params",
            'description': "parameter tidak sesuai"
        });
    }

});



app.post(config.basePath + '/checkStatus', function(req, res) {
    CampaignOutputCtrl.getOTPByTransactionId(req.body.transactionId).then(function(responseDB) {
        if (responseDB.responseCode == "00") {
            let obj = {
                OTP: {

                }
            }
            obj.OTP.status = responseDB.OTP.status;
            obj.OTP.policyNumber = responseDB.OTP.policyNumber;
            obj.OTP.campaignType = responseDB.OTP.campaignType;
            obj.OTP.campaignCode = responseDB.OTP.campaignCode;
            obj.responseCode = responseDB.responseCode;
            obj.OTP.option = responseDB.OTP.option;
            responseDB = obj;
        }
        return res.status(200).send({
            'data': responseDB,
            'description': "success"
        });
    }).catch((err) => {
        log.error("checkStatus ");
        return res.status(500).send({
            'code': 'internal-server-error',
            'description': err
        });
    })
});

app.post(config.basePath + '/urlCheck', function(req, res) {

    // res.send("success");
    // var data = {};
    client.hmget(req.body.slug, ["uid", "uniqueId", "status", "createDate"], function(err, result) {
        console.log("hasil", result);
        if (result[0]) {
            return res.status(200).send({
                'data': result,
                'description': "success"
            });
        } else {
            return res.status(404).send({
                'data': [],
                'description': 'not found'
            });
        }
    });
});

app.post(config.basePath + '/sendOTP', function(req, res) {
    let otp = Utils.getRandomOtpCode();
    let transactionId = req.body.transactionId;
    log.info("otp ", otp);
    let msg = otp + config.sms_kode_otp_template;
    CampaignOutputCtrl.getOTPByTransactionId(req.body.transactionId).then(function(resp) {
        Utils.sendSMS(transactionId, resp.OTP.phoneNumber, msg).then(function(responseSms) {
            var obj = {
                otp: otp,
                transactionId: transactionId
            }
            client.hmset(transactionId, ["transactionId", transactionId, "otp", otp, "status", false, "createDate", Date.now()], function(err, reply) {
                client.expire(transactionId, config.otp_expire_time);
                client.hmget(transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {
                    log.info("result send otp ", result);
                    obj.data = result;
                    if (result[0]) {
                        return res.status(200).send({
                            data: obj
                        });
                    } else {
                        return res.status(500).send({
                            data: []
                        });
                    }
                });
            });

        }).catch(error => {
            log.error("fail to send SMS ");
            return res.status(500).send({
                'code': '500',
                'description': 'fail to send sms'
            });
        })

    }).catch(err => {
        log.error("fail to get OTP");
        return res.status(500).send({
            data: []
        });
    })



});

// app.post(config.basePath+'*', rateLimiterRedisMiddleware);

app.post(config.basePath + '/getOTP', function(req, res) {
    client.hmget(req.body.transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {
        console.log("hasil", result);
        if (result[0]) {
            res.status(200).send({
                data: result
            });
        } else {
            return res.status(500).send({
                data: []
            });
        }
    });
});

app.post(config.basePath + '/updateOTP', function(req, res) {
    console.log("masuk ke fungsi submit");
    let data = [];
    client.hmget(req.body.transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {
        console.log("hasil 1", result);
        console.log(req);
        if (result[0] && req.body.transactionId == result[0] && req.body.otp == result[1]) {
            if (result[1] == req.body.otp) {
                console.log(" data di redis ada");

                CampaignOutputCtrl.submit(req.body.transactionId).then(function(resSub) {
                    client.hmset(req.body.transactionId, ["transactionId", req.body.transactionId, "otp", req.body.otp, "status", true, "createDate", Date.now()], function(err, reply) {
                        client.hmget(req.body.transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {
                            console.log("hasil", result);
                            // obj.data = result;
                            if (result[0]) {
                                CampaignOutputCtrl.updateStatusOTP(req.body.transactionId, req.body.statusCode).then(function(resp) {
                                    CampaignOutputCtrl.getOTPByTransactionId(req.body.transactionId).then(function(dataOtp) {
                                        var notifEventId = "";
                                        var notifReqId = "";
                                        if (["EU", "EUP"].indexOf(dataOtp.OTP.campaignType) > -1) {
                                            if (dataOtp.OTP.campaignType == "EU") {
                                                notifReqId = "EZCAMPAIGN_APPROVE";
                                                notifEventId = "69";
                                            } else {
                                                notifReqId = "EZCAMPAIGNPLUS_APPROVE";
                                                notifEventId = "71";
                                            }
                                        } else {
                                            if (dataOtp.OTP.campaignType == undefined || dataOtp.OTP.campaignType == "") {
                                                notifEventId = campaignList.filter(x => x.campaignType == "" && x.notifReqId.includes("APPROVE"))[0].notifEventId;
                                                notifReqId = campaignList.filter(x => x.campaignType == "" && x.notifReqId.includes("APPROVE"))[0].notifReqId;
                                            } else {
                                                notifEventId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("APPROVE"))[0].notifEventId;
                                                notifReqId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("APPROVE"))[0].notifReqId;
                                            }

                                        }
                                        CampaignOutputCtrl.pushNotif(req.body.transactionId, dataOtp.OTP.agentNumber, dataOtp.OTP.policyNumber, notifEventId, notifEventId, "");
                                        console.log("end kirim notif");
                                        console.log(dataOtp.OTP.policyNumber);
                                        var key = req.body.transactionId.substr(req.body.transactionId.length - 4, 4);
                                        client.persist(key);
                                        CampaignOutputCtrl.getAllOTP(dataOtp.OTP.policyNumber).then(function(arrOtp) {
                                            arrOtp.OTP.map(each => {
                                                if (req.body.transactionId != each.transactionId) {
                                                    CampaignOutputCtrl.updateStatusOTP(each.transactionId, "06").then(function(updOtp) {
                                                        console.log("update success", updOtp);
                                                    });
                                                }
                                            });
                                            return res.status(200).send({
                                                data: resp
                                            });
                                        }).catch((err) => {
                                            return res.status(500).send({
                                                data: []
                                            });
                                        })
                                    }).catch((rr) => {
                                        return res.status(500).send({
                                            data: []
                                        });
                                    })

                                }).catch((rrr) => {
                                    return res.status(500).send({
                                        data: []
                                    });
                                })

                            } else {
                                return res.status(500).send({
                                    data: []
                                });
                            }
                        });
                    });
                }).catch(function(err) {
                    return res.status(500).send({
                        data: []
                    });
                });


            } else {
                return res.status(500).send({
                    data: []
                });
            }
            // }			
        } else {
            return res.status(500).send({
                data: []
            });
        }
    });
});

//start code Adhitya - Stability Resubmit OTP
app.post(config.basePath + '/resubmitOTP', function(req, res) {
    let data = [];
    // client.hmget(req.body.transactionId,["transactionId" ,"otp" ,"status" ,"createDate"], function(err, result){
    // console.log("hasil", result);
    // if(result[0] && req.body.transactionId == result[0] && req.body.otp == result[1]){
    // 		if(result[1] == req.body.otp){
    CampaignOutputCtrl.submit(req.body.transactionId).then(function(resSub) {
        client.hmset(req.body.transactionId, ["transactionId", req.body.transactionId, "otp", req.body.otp, "status", true, "createDate", Date.now()], function(err, reply) {
            client.hmget(req.body.transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {
                console.log("hasil", result);
                // obj.data = result;
                // if(result[0]){
                CampaignOutputCtrl.updateStatusOTP(req.body.transactionId, req.body.statusCode).then(function(resp) {
                    CampaignOutputCtrl.getOTPByTransactionId(req.body.transactionId).then(function(dataOtp) {
                        var notifEventId = "";
                        var notifReqId = "";
                        if (["EU", "EUP"].indexOf(dataOtp.OTP.campaignType) > -1) {
                            if (dataOtp.OTP.campaignType == "EU") {
                                notifReqId = "EZCAMPAIGN_APPROVE";
                                notifEventId = "69";
                            } else {
                                notifReqId = "EZCAMPAIGNPLUS_APPROVE";
                                notifEventId = "71";
                            }
                        } else {
                            notifEventId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("APPROVE"))[0].notifEventId;
                            notifReqId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("APPROVE"))[0].notifReqId;
                        }
                        CampaignOutputCtrl.pushNotif(req.body.transactionId, dataOtp.OTP.agentNumber, dataOtp.OTP.policyNumber, notifEventId, notifEventId, "");
                        console.log("end kirim notif");
                        var key = req.body.transactionId.substr(req.body.transactionId.length - 4, 4);
                        client.persist(key);
                        CampaignOutputCtrl.getAllOTP(dataOtp.OTP.policyNumber).then(function(arrOtp) {
                            arrOtp.OTP.map(each => {
                                if (req.body.transactionId != each.transactionId) {
                                    CampaignOutputCtrl.updateStatusOTP(each.transactionId, "06").then(function(updOtp) {
                                        console.log("update success", updOtp);
                                    });
                                }
                            });
                            return res.status(200).send({
                                data: resp
                            });
                        }).catch((err) => {
                            return res.status(500).send({
                                error: "GET ALL OTP FAILED",
                                data: []
                            });
                        })
                    }).catch((rr) => {
                        return res.status(500).send({
                            error: "GET OTP BY TRANSID FAILED",
                            data: []
                        });
                    })

                }).catch((rrr) => {
                    return res.status(500).send({
                        error: "OTP STATUS UPDATE FAILED",
                        data: []
                    });
                })

                // }else{
                // 	return res.status(500).send({
                // 		error: "GET DATA FROM REDIS FAILED",
                // 		data: []
                // 	});
                // }
            });
        });
    }).catch(function(err) {
        return res.status(500).send({
            error: "CMPGNOUTPUTCTRL SUBMIT METHOD FAILED",
            data: []
        })
    })

    // 		}else{
    // 			return res.status(500).send({
    // 				error: "OTP REQUEST MISMATCHED",
    // 				data: []
    // 			});
    // 		}
    // 	// }			
    // }else{
    // 	return res.status(500).send({
    // 		error: "DATA NONEXISTENT OR MISMATCHED REQUEST DATA",
    // 		data: []
    // 	});
    // }
    // });
});
//end code Adhitya - Stability Resubmit OTP

app.post(config.basePath + '/submitOTPAlter', function(req, res) {
    let data = [];
    client.hmget(req.body.transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {

        if (result[0] && req.body.transactionId == result[0] && req.body.otp == result[1]) {
            if (result[1] == req.body.otp) {

                CampaignOutputCtrl.submitAlter(req.body.transactionId).then(function(resSub) {
                    client.hmset(req.body.transactionId, ["transactionId", req.body.transactionId, "otp", req.body.otp, "status", true, "createDate", Date.now()], function(err, reply) {
                        client.hmget(req.body.transactionId, ["transactionId", "otp", "status", "createDate"], function(err, result) {
                            console.log("hasil", result);
                            // obj.data = result;
                            if (result[0]) {
                                CampaignOutputCtrl.updateStatusOTP(req.body.transactionId, req.body.statusCode).then(function(resp) {
                                    console.log("CampaignOutputCtrl.updateStatusOTP");
                                    console.log(resp);
                                    CampaignOutputCtrl.getOTPByTransactionId(req.body.transactionId).then(function(dataOtp) {
                                        console.log("data getOTPByTransactionId");
                                        console.log(dataOtp);
                                        var notifEventId = "";
                                        var notifReqId = "";

                                        if (dataOtp.OTP.campaignType == undefined || dataOtp.OTP.campaignType == "") {
                                            notifEventId = campaignList.filter(x => x.campaignType == "" && x.notifReqId.includes("APPROVE"))[0].notifEventId;
                                            notifReqId = campaignList.filter(x => x.campaignType == "" && x.notifReqId.includes("APPROVE"))[0].notifReqId;
                                        } else {
                                            notifEventId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("APPROVE"))[0].notifEventId;
                                            notifReqId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("APPROVE"))[0].notifReqId;
                                        }


                                        CampaignOutputCtrl.pushNotif(req.body.transactionId, dataOtp.OTP.agentNumber, dataOtp.OTP.policyNumber, notifEventId, notifEventId, "");
                                        console.log("end kirim notif");
                                        console.log(dataOtp.OTP.policyNumber);
                                        console.log("nomer policy di atas");
                                        var key = req.body.transactionId.substr(req.body.transactionId.length - 4, 4);
                                        client.persist(key);
                                        CampaignOutputCtrl.getAllOTP(dataOtp.OTP.policyNumber).then(function(arrOtp) {
                                            arrOtp.OTP.map(each => {
                                                if (req.body.transactionId != each.transactionId) {
                                                    CampaignOutputCtrl.updateStatusOTP(each.transactionId, "06").then(function(updOtp) {
                                                        console.log("update success", updOtp);
                                                    });
                                                }
                                            });
                                            return res.status(200).send({
                                                data: resp
                                            });
                                        }).catch((err) => {
                                            return res.status(500).send({
                                                data: []
                                            });
                                        })
                                    }).catch((rr) => {
                                        return res.status(500).send({
                                            data: []
                                        });
                                    })

                                }).catch((rrr) => {
                                    return res.status(500).send({
                                        data: []
                                    });
                                })

                            } else {
                                return res.status(500).send({
                                    data: []
                                });
                            }
                        });
                    });
                }).catch(function(err) {
                    return res.status(500).send({
                        data: []
                    });
                });


            } else {
                return res.status(500).send({
                    data: []
                });
            }
        } else {
            return res.status(500).send({
                data: []
            });
        }
    });

});

app.post(config.basePath + '/updateStatusReject', function(req, res) {
    CampaignOutputCtrl.getOTPByTransactionId(req.body.transactionId).then(function(dataOtp) {
        var notifEventId = "";
        var notifReqId = "";
        if (["EU", "EUP"].indexOf(dataOtp.OTP.campaignType) > -1) {
            if (dataOtp.OTP.campaignType == "EU") {
                notifReqId = "EZCAMPAIGN_REJECT";
                notifEventId = "70";
            } else {
                notifReqId = "EZCAMPAIGNPLUS_REJECT";
                notifEventId = "72";
            }
        } else {
            if (dataOtp.OTP.campaignType == undefined || dataOtp.OTP.campaignType == "") {
                notifEventId = campaignList.filter(x => x.campaignType == "" && x.notifReqId.includes("REJECT"))[0].notifEventId;
                notifReqId = campaignList.filter(x => x.campaignType == "" && x.notifReqId.includes("REJECT"))[0].notifReqId;
            } else {
                notifEventId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("REJECT"))[0].notifEventId;
                notifReqId = campaignList.filter(x => x.campaignType == dataOtp.OTP.campaignCode && x.notifReqId.includes("REJECT"))[0].notifReqId;
            }
        }
        CampaignOutputCtrl.pushNotif(req.body.transactionId, dataOtp.OTP.agentNumber, dataOtp.OTP.policyNumber, notifEventId, notifReqId, req.body.reason).then(function(response) {
            console.log("end kirim notif");
            log.info("kirim notification ke ", dataOtp.OTP.agentNumber);
            log.info("response  ", response);
            CampaignOutputCtrl.updateStatusOTP(req.body.transactionId, req.body.statusCode).then(function(resp) {
                return res.status(200).send({
                    data: resp
                });
            }).catch((rr) => {
                return res.status(500).send({
                    data: []
                });
            });
        });

    }).catch((err) => {
        return res.status(500).send({
            data: []
        });
    });
});

app.post(config.basePath + '/getAllOTP', function(req, res) {
    // if (!req.body.campaignCode) {
    // 	req.body.campaignCode = "PLS-001"
    // }
    CampaignOutputCtrl.getAllOTP(req.body.policyNumber).then(function(resp) {
        let arrOTP = [];
        let result = {};
        result.status = "NEW";
        let arrSub = [];
        arrOTP = _.filter(resp.OTP, function(obj) { return obj.status != "EXPIRED" && obj.campaignCode == req.body.campaignCode && moment(obj.createdDate, "YYYY-MM-DD").format("YYYY/MM/DD") == moment().format("YYYY/MM/DD") });
        result.data = [];
        if (arrOTP.length > 0) {
            var found = 0;
            for (let i = 0; i < arrOTP.length; i++) {
                log.info(moment(arrOTP[i].createdDate, "YYYY-MM-DD").format("YYYY/MM/DD"));
                log.info(moment().format("YYYY/MM/DD"));
                if (arrOTP[i].status == "SUBMITTED" || arrOTP[i].status == "APPROVE") {
                    result.data = [];
                    if (moment(arrOTP[i].createdDate, "YYYY-MM-DD").format("YYYY/MM/DD") == moment().format("YYYY/MM/DD")) {
                        result.status = arrOTP[i].status;
                        result.data.push(arrOTP[i])
                        break;
                    } else {
                        result.data = [];
                        result.status = "NEW";
                        break;
                    }
                } else if (arrOTP[i].status == "ACTIVE") {
                    result.status = arrOTP[i].status;
                    result.data.push(arrOTP[i]);
                    found += 1;
                } else if (arrOTP[i].status == "REJECT") {
                    result.data.push(arrOTP[i]);
                    if (found == 0) {
                        result.status = arrOTP[i].status;
                    }
                }
            }
        }
        return res.status(200).send(result);
    }).catch((err) => {
        return res.status(200).send({
            data: []
        });
    });
});

//code by FAOZI

app.post(config.basePath + '/getDetailDataOTPByQQ', function(req, res) {
    let arrResult = [];
    let result = {
        status: '',
        data: {}
    };

    let policyNumber = req.body.policyNumber;
    let option = req.body.option;
    let campaignCode = req.body.campaignCode;

    CampaignOutputCtrl.getAllOTP(policyNumber).then(function(resp) {
        // arrOTP = _.filter(resp.OTP, function (obj) { return obj.status != "EXPIRED" && obj.campaignCode == req.body.campaignCode && moment(obj.createdDate, "YYYY-MM-DD").format("YYYY/MM/DD") == moment().format("YYYY/MM/DD") })
        arrResult = _.filter(resp.OTP, function(obj) { return obj.status != "EXPIRED" && obj.campaignCode == campaignCode });

        if (arrResult.length > 0) {
            console.log("DATANYA ADA ");
            result.status = arrResult[0].status;
            result.data = arrResult[0];
        } else {
            console.log("GAK ADA DATA");
        }

        return res.status(200).send(result);
    }).catch((err) => {
        console.log("gagal ketika manggil otpService");
        return res.status(200).send(result);
    });
});

app.post(config.basePath + '/getDetailDataOTP', function(req, res) {
    let arrResult = [];
    let result = {
        status: '',
        data: {}
    };

    let policyNumber = req.body.policyNumber;
    let option = req.body.option;
    let campaignCode = req.body.campaignCode;

    CampaignOutputCtrl.getAllOTP(policyNumber).then(function(resp) {
        // arrOTP = _.filter(resp.OTP, function (obj) { return obj.status != "EXPIRED" && obj.campaignCode == req.body.campaignCode && moment(obj.createdDate, "YYYY-MM-DD").format("YYYY/MM/DD") == moment().format("YYYY/MM/DD") })
        arrResult = _.filter(resp.OTP, function(obj) { return obj.status != "EXPIRED" && obj.campaignCode == campaignCode });

        if (arrResult.length > 0) {
            console.log("DATANYA ADA ");
            result.status = arrResult[0].status;
            result.data = arrResult[0];
        } else {
            console.log("GAK ADA DATA");
        }

        return res.status(200).send(result);
    }).catch((err) => {
        console.log("gagal ketika manggil otpService");
        return res.status(200).send(result);
    });
});

//end of code by FAOZI

app.post(config.basePath + '/getDataOTP', function(req, res) {
    let obj = {};
    CampaignOutputCtrl.getDataOTPByTransactionId(req.body.transactionId).then(function(response) {
        // console.log(JSON.parse(response.OTP.data));
        if (response.responseCode == "00") {
            obj = JSON.parse(response.OTP.data);
            pdf2base64(path.join(__dirname, '/public/output/' + response.OTP.policyNumber + response.OTP.option + response.OTP.campaignCode + '.pdf')).then((base64) => {
                // console.log(base64);
                obj.main.policyAfter.base64OTP = base64;
                // obj.base64OTP = base64;
                return res.status(200).send(obj);
            }).catch((error) => {
                obj = {
                    message: "file not found"
                };
                // console.log(base64);
                return res.status(404).send(obj);
            })
        }
    }).catch((err) => {
        obj = {
            message: "file not found"
        };
        return res.status(404).send(obj);
    })
});

app.post(config.basePath + '/getPhoneNumberByTransactionId', function(req, res) {
    let obj = {};
    CampaignOutputCtrl.getDataOTPByTransactionId(req.body.transactionId).then(function(response) {
        // console.log(JSON.parse(response.OTP.data));
        if (response.responseCode == "00") {
            obj.phoneNumber = response.OTP.phoneNumber;
            return res.status(200).send(obj);
        } else {
            log.error("response code != 00 dari service ");
            return res.status(500).send(obj);
        }

    }).catch((err) => {
        log.error("get phone number from getDataOTPByTransactionId ");
        return res.status(404).send(obj);
    })
});

app.post(config.basePath + '/generateFreePA', function(req, res) {
    moment.locale('en'); //set locale en for password with dob
    let dob = moment(req.body.dob, "YYYY-MM-DD").format("DDMMMM").substring(0, 5);
    moment.locale('id'); //set locale id for all date except dob
    let today = moment().format("DD MMMM YYYY");
    let expDate = moment(req.body.createdDate, "YYYY-MM-DD").add(6, 'months').format("DD MMMM YYYY");
    let fileName = req.body.cerNumber;
    let createdDate = moment(req.body.createdDate, "YYYY-MM-DD").format("DD MMMM YYYY");

    let obj = {
        noPolis: req.body.policyNumber,
        noSertifikat: req.body.cerNumber,
        namaPeserta: req.body.fullName,
        tanggalAwal: createdDate,
        tanggalAkhir: expDate,
        today: today,
        dob: dob,
        fileName: fileName
    };

    CampaignOutputCtrl.generatePDFFreePA(obj).then(function(resp) {
        console.log(resp);
        if (resp.code == 200) {
            pdf2base64(path.join(__dirname, '/public/output/' + fileName + 'encrypt.pdf')).then((base64) => {
                console.log("success generate");
                resp.base64 = base64;
                return res.status(200).send(resp);
            }).catch((error) => {
                console.log("error generate");
                return res.status(500).send(resp);
            })
        } else {
            console.log("error generate");
            return res.status(500).send(resp);
        }
    }).catch((err) => {
        // log.error("get phone number from getDataOTPByTransactionId ");
        return res.status(500).send(err);
    })
});

app.post(config.basePath + '/generatePDFAlter', async function(req, res) {

    try {
        moment.locale('en');
        let dataAfter = req.body.dataAlter.main.policyAfter;
        let dataAlter = req.body.dataAlter;
        dataAlter.main.policyAfter.agent = req.body.agentDetail;

        let mSecond = Date.now();
        let transactionId = mSecond + "" + dataAfter.policyNumber;

        if (req.body.phoneNumber.includes("X")) {
            return res.status(500).send({
                "code": "305",
                "message": "sms not sen",
                "description": "phone number xxx"
            });
        }

        log.info('Generate PDF  ', dataAfter.campaignInfo.campaignCode, " policy number ", dataAfter.policyNumber, " option : ", req.body.option); //(req.body.option);
        CampaignOutputCtrl.replaceOTP(dataAfter.policyNumber, req.body.option, dataAfter.campaignInfo.campaignCode).then(function(response) {
            let otp = moment(dataAfter.clientRoleOW.clientDob, "YYYYMMDD").format("DDMMMYY");
            let today = moment().format("DD-MMM-YYYY");
            let expired = today + " 23:59";
            Utils.createShortUrl(transactionId).then(function(resp) {
                console.log(resp[0]);
                var url = config.url_sms_template_message + resp[0];
                var msg = "Ilustrasi Alter Polis " + dataAfter.policyNumber + " klik " + url + " .Kadaluarsa " + expired + " Tautan tidak dibagikan.";

                var obj = {
                    campaignId: dataAfter.campaignInfo.campaignCode,
                    campaignCode: '',
                    campaignType: '',
                    transactionId: resp[1],
                    agentNumber: dataAfter.agentNumber,
                    policyNumber: dataAfter.policyNumber,
                    phoneNumber: config.setDefaultPhoneNumber === false ? req.body.phoneNumber : config.setDefaultPhoneNumber,
                    otp: otp,
                    data: JSON.stringify(dataAlter),
                    shortUrl: url,
                    status: '01',
                    option: req.body.option.toString().length == 1 ? "0" + req.body.option.toString() : req.body.option.toString(),
                    alasan: '',
                    dob: dataAfter.clientRoleOW.clientDob
                };

                log.info("Data createOTP with transactionId ", resp[1]);
                console.log("masuk sini");
                CampaignOutputCtrl.createOTP(obj).then(function(responseDB) {
                    if (responseDB.responseCode == "00") {
                        Utils.sendSMS(resp[1], config.setDefaultPhoneNumber === false ? req.body.phoneNumber : config.setDefaultPhoneNumber, msg).then(function(responseSms) {
                            log.info("pengajuan berhasil terkirim ", resp[1]);

                            return res.status(200).send({
                                'code': "200",
                                'message': 'sms sent',
                                'data': responseSms,
                                'transactionId': resp[1],
                                "description": "success"
                            });
                        }).catch((error) => {
                            console.log("error", error);
                            return res.status(500).send({
                                'code': "305",
                                'message': "sms not sen",
                                "description": error
                            });
                        })
                    } else {
                        return res.status(500).send({
                            'code': "306",
                            'message': "cannot create data db",
                            "description": "balikan dari servie otp 01"
                        });
                    }
                }).catch((error) => {
                    console.log("error db", error);
                    // log.error(" Fail to save to db ", transactionId);
                    return res.status(500).send({
                        'code': '306',
                        'message': "Fail to save to db",
                        "description": error
                    });
                })
            }).catch((err) => {
                // log.error(" Fail to create short url ", transactionId);
                return res.status(500).send({
                    'code': '304',
                    'message': "fail to create short url",
                    "description": err
                });
            });

        }).catch((err) => {
            return res.status(500).send({
                'code': '301',
                "message": "cannot conect to otp service",
                'description': err
            });
        })
    } catch (err) {
        return res.status(500).send({
            'code': '301',
            "message": "error params",
            'description': "parameter tidak sesuai"
        });
    }



    // let dataAfter = req.body;
    // let dataAlter = req.body.dataAlter;
    // let mSecond = Date.now();
    // let documentSQS = req.body.additionalData.documentHTMLOutput;
    // let phone = dataAfter.phoneNumber;
    // let transactionId = mSecond + "" + dataAfter.policyNumber;
    // // let fileName = req.body.policyNumber;

    // let content = documentSQS;
    // let codeagent = dataAfter.agentNumber;
    // let nopolicy = dataAfter.policyNumber;

    // Utils.convertBase64(content, codeagent, nopolicy).then(function (resp) {
    // 	console.log("ini content", content);
    // 	// CampaignOutputCtrl.replaceOTP(dataAfter.policyNumber).then(function(response){
    // 	let otp = moment(dataAfter.clientRoleOW.clientDob, "YYYYMMDD").format("DDMMMYY");
    // 	let today = moment().format("DD-MMM-YYYY");
    // 	let expired = today + " 23:59";
    // 	Utils.createShortUrl(transactionId).then(function (resp) {
    // 		console.log(resp[0]);
    // 		var url = config.url_sms_template_message + resp[0];
    // 		var msg = "Ini penawaran dengan Nomor Polis " + dataAfter.policyNumber + " dari Prudential, klik " + url + " .Kadaluarsa " + expired + " Tautan tidak dibagikan.";
    // 		var obj = {
    // 			transactionId: resp[1],
    // 			agentNumber: dataAfter.agentNumber,
    // 			policyNumber: dataAfter.policyNumber,
    // 			phoneNumber: config.setDefaultPhoneNumber === false ? phone : config.setDefaultPhoneNumber,
    // 			otp: otp,
    // 			documentSQS: content,
    // 			data: JSON.stringify(dataAfter),
    // 			shortUrl: url,
    // 			status: '01',
    // 			alasan: '',
    // 			dob: dataAfter.clientRoleOW.clientDob
    // 		};

    // 		// log.info("Data createOTP with transactionId ", resp[1]);
    // 		console.log("ini adalah obj :", obj);
    // 		console.log("masuk sini");

    // 		Utils.sendSMS(resp[1], config.setDefaultPhoneNumber === false ? req.body.phoneNumber : config.setDefaultPhoneNumber, msg).then(function (responseSms) {
    // 			return res.status(200).json({
    // 				'code': "200",
    // 				'message': 'sms sent',
    // 				'data': responseSms,
    // 				'transactionId': resp[1],
    // 				"description": "success"
    // 			});
    // 		}).catch((error) => {
    // 			console.log("error", error);
    // 			log.error(" Fail to send sms  ", dataAfter.policyNumber, " phoneNumber : ", req.body.phoneNumber);
    // 			return res.status(500).json({
    // 				'code': "305",
    // 				'message': "sms not sen",
    // 				"description": error
    // 			});
    // 		})
    // 	}).catch((err) => {
    // 		log.error(" Fail to create short url ", transactionId);
    // 		return res.status(500).json({
    // 			'code': '304',
    // 			'message': "fail to create short url",
    // 			"description": err
    // 		});
    // 	}).catch((err) => {
    // 		console.log(err);
    // 		log.error(" Fail generate pdf ", dataAfter.policyNumber);
    // 		return res.status(500).json({
    // 			'code': '303',
    // 			'message': "fail generate pdf",
    // 			'description': err
    // 		});
    // 	}).catch((err) => {
    // 		return res.status(500).send({
    // 			'code': '301',
    // 			"message": "cannot conect to otp service",
    // 			'description': err
    // 		});
    // 	})
    // })
});

app.get(config.basePath + '/health', async(req, res) => {
    try {
        res.status(200).end();
    } catch (err) {
        res.status(500).end();
    }
});

var time = { hour: 23, minute: 59 };
var j = schedule.scheduleJob(time, function() {
    // scheduler
    log.info('scheduler Start');
    // const outputDir = path.join(__dirname, '/public/output');
    // if (fs.existsSync(outputDir)){
    // 	fsx.emptyDirSync(outputDir);
    // 	log.info('Empty Output Done !!');
    // };
});

// console.log(j.nextInvocation());
// console.log(__dirname);
// console.log(moment());

app.use(config.basePath, compression({ threshold: 0 }),
    sirv('static', { dev }),
    sapper.middleware()
).listen(PORT, err => {
    // log.info('Service started --------- ');
    if (err) console.log('error', err);
});