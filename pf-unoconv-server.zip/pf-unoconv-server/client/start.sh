#! /bin/bash

# Wait for MySQL
# until nc -z -v -w30 db 5432
# do
#   echo "Waiting for Postgres..."
#   sleep 1
# done

# echo "Postgres is up and running"

# Run Setup
# bin/setup

# start unoconv
echo "starting unoconv"
unoconv --listener

sleep 2

echo "build project"
npm run build

sleep 30
echo "finish build"

npm run start
echo "service starting"