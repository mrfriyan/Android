<script>
import { onMount } from 'svelte';
// import { Button,CustomInput, Input, Col, Row } from 'sveltestrap';

import Button from '../../../node_modules/sveltestrap/src/Button';
import Col from '../../../node_modules/sveltestrap/src/Col';
import Row from '../../../node_modules/sveltestrap/src/Row';
import Navbar from '../../../node_modules/sveltestrap/src/Navbar';
import Loader from '../../components/Loader';
import {Alert} from "sveltestrap";

const config = require('../../server/config/server-config.js');

import { goto, stores } from '@sapper/app';

// const { session } = stores();

export let transactionId;

let radioVal = "";
let loading;

// alert component config
	let alertVisible;
	let alertMessage;
	let alertType;

const showAlert = function(type, msg){
	alertVisible = true;
	alertType=type;
	alertMessage = msg;
	setTimeout(function() {
		alertVisible = false;
	}, 4000);
}

onMount(() => {
    
    if(!transactionId){
        loading = true;
        goto(config.basePath+"/rorre");
    }
    //   transactionId = $session.transactionId;
      let form = document.getElementById('roles');
        form.addEventListener('change', function(e) {
        if (e.target !== e.currentTarget) {
            let target = e.target;
            let label = target.nextSibling;
            let display = document.getElementById('display');
            let btn = document.querySelector('[type=submit]');
            btn.disabled = false;
        }
    }, false);  
  });

let act_tidak_setuju = async function(){
    loading = true;
    console.log(radioVal);
    if(radioVal != ""){
        const result = await fetch(config.env_url+"/updateStatusReject",{
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({transactionId: transactionId, statusCode:"99", reason:radioVal})
        }).then(response=>{
            return response.json();
        }).then(responseJson=>{
            goto(config.basePath+'/route_tidaksetuju');
        }).catch((err)=>{
            loading = false;
            alertVisible = true;
            console.log("cannot-connect-to-server");
        })
    }
    
};

</script>
{#if alertVisible}
	<div class="row animation-bottom" >
		<div class="col-md-12 mt-5 pt-2" style="position:absolute;" >
			<Alert color=danger class="float-right" style="z-index:99999;" isOpen="true" toggle={() => (alertVisible = false)}>
				Mohon Periksa Jaringan Anda
			</Alert>
		</div>
	</div>
{/if}

{#if loading == true}
	<Loader></Loader>
{/if}

<div class="row justify-content-center animate-bottom">
	<div class="col-12" style="height: 100%; position: fixed;">
		<div class="row mt-5 pt-3 justify-content-center align-items-center">
			<div id="container" class="col-md-7">
            <h6 class="text-center mb-3">Pengajuan Tidak Setuju</h6>
                <h6 class="text-center">{radioVal}</h6>
                <div class="col-md-12">
                    <form method="post" id="roles"  on:submit|preventDefault={act_tidak_setuju} >
                    <div class="animate-bottom text-justify pt-5 pb-3" style="font-size:12px;" >
                        <p class="text-justify">Terima kasih atas konfirmasi anda. Mohon pilih alasan ketidaksetujuan anda atas penawaran tersebut :</p>
                        <div class="pb-1">
                            <input type=radio bind:group={radioVal} value={"premi tidak sesuai"}>
                            Premi tidak sesuai.
                        </div>
                        <div class="pb-1">
                            <input type=radio bind:group={radioVal} value={"manfaat kesehatan yang ditawarkan tidak sesuai"}>
                            Manfaat Kesehatan yang ditawarkan tidak sesuai.
                        </div>
                        <div class="pb-1">
                            <input type=radio bind:group={radioVal} value={"belum berminat atas penawaran"}>
                            Belum berminat atas penawaran.
                        </div>
                       <br>
                        <p class="text-justify">Hubungi Tenaga Pemasar Anda untuk informasi lebih lanjut.</p>
                    </div>

                        <input type="submit" form="roles" id="submit" class="btn btn-block btn-danger" value="Submit" disabled/> 
                                          
                    </form>      
                </div>
			</div>
		</div>
	</div>
</div>

