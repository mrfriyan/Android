<script>
	export let status;
	export let error;

	const dev = process.env.NODE_ENV === 'development';
</script>

<!-- <style>
	h1, p {
		margin: 0 auto;
	}

	h1 {
		font-size: 2.8em;
		font-weight: 700;
		margin: 0 0 0.5em 0;
	}

	p {
		margin: 1em auto;
	}

	@media (min-width: 480px) {
		h1 {
			font-size: 4em;
		}
	}
</style> -->

<svelte:head>
	<title>404</title>
</svelte:head>

<div class="row " >
	<div class="text-center rounded2 col-md-6 offset-md-3 mt-5 pt-5" style="height: 100%;position: fixed;">
		<img src="logo.jpg" style="width: 300px;opacity:0.4;" alt="logo"/>
		<h2 style="margin-bottom:0;" class="text-danger text-center">Page not found, error 404</h2>
		<h5 class="text-bold text-center">We're really sorry, but we can't seem to find the page you're looking for.
Maybe the page has been moved or deleted - or maybe the address was incorrect.</h5>
	</div>
</div>

<!-- <br><br><br>
<img src="logo.jpg"  style="width: 220px; height:200px; opacity:0.4;"class="rounded mx-auto d-block mt-5" alt="logo"/>
<h1 class="text-danger text-center">404</h1>
<h5 class="text-bold text-center">Not Found</h5> -->
<!-- 
{#if dev && error.stack}
	<pre>{error.stack}</pre>
{/if} -->
