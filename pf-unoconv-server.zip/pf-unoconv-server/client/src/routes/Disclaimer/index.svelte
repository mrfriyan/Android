<script context="module">
  function setuju() {
    document.getElementById("setuju").style.display = "block";
    document.getElementById("pdf-container").style.display = "none";
    document.getElementById("pager").style.display = "none";
    return false;
  }

  function tidaksetuju() {
    document.getElementById("tidaksetuju").style.display = "block ";
    document.getElementById("pdf-container").style.display = "none";
    document.getElementById("pager").style.display = "none";
    return false;
  }
</script>

<script>
  import { onMount } from "svelte";
  import Button from "../../../node_modules/sveltestrap/src/Button";
  import Input from "../../../node_modules/sveltestrap/src/Input";
  import ButtonGroup from "../../../node_modules/sveltestrap/src/ButtonGroup";
  import Navbar from "../../../node_modules/sveltestrap/src/Navbar";
  import Col from "../../../node_modules/sveltestrap/src/Col";
  import Row from "../../../node_modules/sveltestrap/src/Row";
  import browser from "browser-detect";

  let today = new Date();
  let date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  let time = "23:59";
  let dateTime = date + " " + time;
  export let dataPdfAlter;
  export let actionSetujuAlter;
  export let actionTidakSetujuAlter;

  onMount(() => {
    document
      .getElementsByName("container_terms")[0]
      .addEventListener("scroll", checkScrollHeight, false);
    function checkScrollHeight() {
      var agreementTextElement = document.getElementsByName(
        "container_terms"
      )[0];
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= agreementTextElement.scrollHeight) {
      // if (agreementTextElement.clientHeight + agreementTextElement.scrollTop >= 1000) {
      if (
        agreementTextElement.clientHeight + agreementTextElement.scrollTop >=
        agreementTextElement.scrollHeight - 400
      ) {
        document.getElementsByName("dsetuju")[0].style.display = "none";
        document.getElementsByName("dnotsetuju")[0].style.display = "none";
        document.getElementsByName("setuju")[0].style.display = "block";
        document.getElementsByName("notsetuju")[0].style.display = "block";
      }
    }

    const browserDetect = browser();

    if (browserDetect.mobile === true) {
      document.getElementById("viewport-container").style.paddingBottom = "20%";
      document.getElementById("pager").style.fontSize = "12px";
      document.getElementById("title-syarat").style.fontSize = "11px";
      document.getElementById("container-title").style.width = "100%";
      document.getElementById("title-syarat2").style.fontSize = "11px";
      document.getElementById("subtitle-syarat1").style.fontSize = "10px";
      document.getElementById("subtitle-syarat2").style.fontSize = "10px";
      document.getElementById("subtitle-syarat3").style.fontSize = "10px";
      document.getElementById("subtitle-syarat4").style.fontSize = "10px";

    } else if (browserDetect.mobile === false) {
      document.getElementById("viewport-container").style.paddingTop = "5%";
      document.getElementById("container-title").style.width = "100%";
      document.getElementById("title-syarat").style.fontSize = "15px";
      document.getElementById("title-syarat2").style.fontSize = "15px";
      document.getElementById("subtitle-syarat1").style.fontSize = "14px";
      document.getElementById("subtitle-syarat2").style.fontSize = "14px";
      document.getElementById("subtitle-syarat3").style.fontSize = "14px";
      document.getElementById("subtitle-syarat4").style.fontSize = "14px";

    }
  });

</script>

<svelte:head>
  <title>Disclaimer</title>
</svelte:head>
<main>
  <div id="pdf-viewer" class="row justify-content-center animate-bottom ">
    <div class="col-12" style="height: 100%; position: fixed;">
      <div class="justify-content-center align-items-center">
        <div id="pdf-container" onresize="resize">
          <div id="viewport-container" name="container_terms">
            <div id="container-title" class="bg-danger ml-1 mr-1">
              <h5
                id="title-syarat"
                class="text-white text-bold text-justify ml-1 mr-1 pt-1">
                <strong>
                  I. PERSYARATAN DAN KETENTUAN PERUBAHAN MAYOR POLIS NON
                  SYARIAH/SYARIAH UNTUK PEMEGANG POLIS INDIVIDU
                </strong>
              </h5>
            </div>
            <div id="container-title" class="bg-secondary ml-1 mr-1">
              <h5
                id="subtitle-syarat1"
                class="text-white text-justify ml-1 mr-1 pb-1">
                A. Persyaratan/Dokumen yang harus diserahkan ke Kantor Pusat PT
                Prudential Life Assurance (“Prudential”):
              </h5>
            </div>
            <div id="container-title" class="bg-white ml-1 mr-1">
              <ul
                style="font-size:14px;"
                class="list-unstyled text-justify ml-1 mr-1 pb-1">
                <li>
                  1. Formulir Perubahan Mayor Polis Non Syariah/Syariah untuk
                  Pemegang Polis Individu (“Formulir”) asli yang telah diisi
                  lengkap dan jelas serta ditandatangani oleh Pemegang Polis dan
                  Tenaga Pemasar, dengan kondisi:
                  <ul>
                    <li>
                      Tanda tangan Pemegang Polis harus sama dengan spesimen
                      tanda tangan yang terdapat pada SPAJ, atau Kartu Identitas
                      Diri yang berlaku, atau Formulir Perubahan Tanda Tangan
                      (jika pernah mengajukan perubahan tanda tangan) yang
                      terakhir diajukan dan telah disetujui untuk diproses.
                    </li>
                    <li>
                      Tanggal pengajuan pada Formulir tidak boleh lebih dari 30
                      hari kalender sejak tanggal dokumen diterima di Kantor
                      Pusat Prudential.
                    </li>
                  </ul>
                </li>
                <li>
                  2. Ilustrasi Perubahan
                  <i>(Quotation Alteration)</i>
                  Mayor. Khusus untuk penambahan manfaat
                  <b>PRU</b>booster proteksi, tabel ilustrasi peningkatan manfaat yang
                  ditandatangani oleh Pemegang Polis.
                </li>
                <li>
                  3. Fotokopi Kartu Identitas Diri yang masih berlaku atas nama
                  Pemegang Polis, Tertanggung Utama/Peserta Utama (Yang
                  Diasuransikan), Tertanggung Tambahan/Peserta Tambahan (Yang
                  Diasuransikan) (jika ada), serta Pembayar Premi/Kontributor
                  (jika berbeda dengan Pemegang Polis).
                </li>
                <li>
                  4. Bukti pembayaran biaya/
                  <i>ujrah</i>
                  Perubahan Mayor sebesar Rp 50.000,00 (lima puluh ribu rupiah),
                  jika pembayaran dilakukan selain dengan cara pembatalan Unit.
                </li>
                <li>
                  5. Formulir Pembayar Premi/Kontributor (jika terdapat
                  perubahan/penggantian Pembayar Premi/Kontributor dari data
                  yang telah ada).
                </li>
                <li>
                  6. Formulir Pernyataan Kesehatan dan Hobi, jika pada pengajuan
                  perubahan Polis terdapat:
                  <ul>
                    <li>
                      Peningkatan manfaat Polis (Penambahan Asuransi Tambahan,
                      Perpanjangan Jangka Waktu Manfaat Asuransi Tambahan, serta
                      Penambahan Uang Pertanggungan/Santunan Asuransi); atau
                    </li>
                    <li>
                      Peningkatan/Penambahan Premi/Kontribusi
                      <b>PRU</b>link assurance account (PAA)/
                      <b>PRU</b>link syariah assurance account (PSAA) atau
                      <b>PRU</b>saver/
                      <b>PRU</b>saver syariah (
                      <i>Top-up</i>
                      Premi/Kontribusi Berkala); atau
                    </li>
                    <li>
                      Penambahan manfaat
                      <b>PRU</b>booster proteksi; atau
                    </li>
                    <li>
                      Polis tidak aktif
                      <i>(lapsed)</i>
                      > 1 (satu) tahun.
                    </li>
                  </ul>
                </li>
                <li>
                  7. Surat Pengajuan Asuransi Jiwa Tambahan (SPAJT), jika ada
                  penambahan untuk Tertanggung Tambahan/Peserta Tambahan (Yang
                  Diasuransikan).
                </li>
                <li>
                  8. Khusus untuk Polis dengan jaminan kolateral/
                  <i>Banker’s Clause</i>
                  wajib melampirkan:
                  <ul>
                    <li>
                      Surat Pernyataan Pengajuan Perubahan Polis yang
                      ditandatangani oleh Pejabat Bank Berwenang dengan dibubuhi
                      stempel perusahaan serta ditandatangani oleh Pemegang
                      Polis (jika terdapat perubahan Pejabat Bank Berwenang,
                      maka harus disertai dengan Surat Keterangan yang
                      menginformasikan nama Pejabat Bank Berwenang yang baru
                      menggantikan Pejabat Bank sebelumnya).
                    </li>
                    <li>
                      Fotokopi KTP yang masih berlaku atas nama Pejabat Bank
                      Berwenang.
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <div id="container-title" class="bg-secondary ml-1 mr-1">
              <h5
                id="subtitle-syarat2"
                class="text-white text-justify ml-1 mr-1 pb-1">
                B. Ketentuan Umum Perubahan Polis Mayor:
              </h5>
            </div>
            <div id="container-title" class="bg-white ml-1 mr-1">
              <ul
                style="font-size:14px;"
                class="list-unstyled text-justify ml-1 mr-1 pb-1">
                <li>
                  1. Polis dalam status aktif
                  <i>(inforce)</i>
                  *) dan tidak sedang mengajukan/telah disetujui Klaim Manfaat
                  Bebas Premi/Kontribusi.
                </li>
                <li>
                  2. Perubahan Mayor dapat melalui proses seleksi risiko
                  <i>(underwriting)</i>
                  sehingga terdapat kemungkinan untuk diminta melakukan
                  pemeriksaan kesehatan atau persyaratan lainnya.
                </li>
                <li>
                  3. Frekuensi Pembayaran seperti yang tertera di dalam halaman
                  ilustrasi yang terlampir (jika ada) tidak akan diproses
                  apabila Pemegang Polis tidak melampirkan Formulir Perubahan
                  Minor (untuk perubahan Frekuensi Pembayaran).
                </li>
                <li>
                  4. Periode pemenuhan kelengkapan pengajuan Perubahan Mayor
                  adalah 60 hari kalender sejak diterimanya dokumen di Kantor
                  Pusat Prudential. Apabila dalam jangka waktu tersebut tidak
                  dipenuhi, maka proses pengajuan tidak akan dilanjutkan.
                  Pemegang Polis harus mengisi Formulir yang baru untuk
                  melanjutkan proses Perubahan Mayor.
                </li>
                <li>
                  5. Jika Pembayar Premi/Kontributor adalah Ibu Rumah
                  Tangga/Pelajar/Mahasiswa yang tidak berpenghasilan, maka perlu
                  melakukan perubahan Pembayar Premi/Kontributor menjadi
                  pasangan/orang tua yang berpenghasilan.
                </li>
                <li>
                  6. Perubahan Premi/Kontribusi:
                  <ul>
                    <li class="list-unstyled">
                      a) Setiap perubahan Premi/Kontribusi
                      (peningkatan/penurunan Premi/Kontribusi) harus disertai
                      dengan pembayaran Premi/Kontribusi sebesar nilai
                      Premi/Kontribusi setelah perubahan disetujui.
                    </li>
                    <li class="list-unstyled">
                      b) Pemegang Polis harus melakukan pembayaran
                      Premi/Kontribusi sebesar nilai Pemi/Kontribusi sebelum
                      perubahan yang diajukan saat ini, apabila:
                      <ul>
                        <li>
                          Pengajuan perubahan Polis saat ini masih dalam proses
                          dan belum disetujui; atau
                        </li>
                        <li>
                          Sebelumnya Polis telah melakukan perubahan
                          Premi/Kontribusi namun belum ada Premi/Kontribusi yang
                          dibayarkan atas perubahan yang telah disetujui, dan
                          saat ini kembali diajukan perubahan Premi/Kontribusi
                          atas Polis tersebut.
                        </li>
                      </ul>
                    </li>
                    <li class="list-unstyled">
                      c) PT Prudential Life Assurance dapat meminta Pemegang
                      Polis untuk melakukan pembayaran sebesar selisih kenaikan
                      Premi/Kontribusi yang akan diberlakukan sebagai
                      Premi/Kontribusi
                      <i>Top-up</i>
                      Tunggal dalam hal tanggal efektif peningkatan
                      Premi/Kontribusi melampaui tanggal pembebanan Biaya
                      Asuransi sesuai dengan syarat dan ketentuan yang berlaku
                      di PT Prudential Life Assurance. Pembayaran selisih
                      kenaikan Premi/Kontribusi tidak diperkenankan untuk
                      dilakukan melalui pembayaran dengan kartu kredit atau
                      penarikan dana
                      <i>(withdrawal)</i>
                      dari Polis yang sedang mengajukan Perubahan Mayor.
                    </li>
                  </ul>
                </li>
                <li>
                  7. Berlakunya perubahan diatur sebagai berikut:
                  <ul>
                    <li class="list-unstyled">
                      a) Tanggal perubahan Premi/Kontribusi baru adalah pada
                      Tanggal Jatuh Tempo Premi/Kontribusi pada saat perubahan
                      Polis disetujui.
                    </li>
                    <li class="list-unstyled">
                      b) Tanggal berlaku perubahan Uang Pertanggungan/Santunan
                      Asuransi dan perubahan Manfaat Asuransi Tambahan adalah
                      pada tanggal pembebanan Biaya Asuransi dan Biaya/
                      <i>Ujrah</i>
                      Administrasi berikutnya setelah perubahan Polis disetujui.
                    </li>
                  </ul>
                </li>
                <li>
                  8. Formulir yang telah diterima oleh Prudential adalah
                  bersifat final dan akan digunakan sebagai dasar pengajuan
                  Perubahan Mayor Polis Non Syariah/Syariah untuk Pemegang Polis
                  Individu.
                </li>
                <li>
                  9. Perubahan Mayor yang telah disetujui dan diproses oleh
                  Penanggung/Pengelola tidak dapat dibatalkan.
                </li>
                <li>
                  *) Jika Perubahan Mayor diajukan dengan status Polis tidak
                  aktif
                  <i>(lapsed)</i>
                  , maka akan berlaku ketentuan pemulihan Polis dengan tanggal
                  berlaku perubahan pada tanggal pembebanan Biaya Asuransi dan
                  Biaya/
                  <i>Ujrah</i>
                  Administrasi yang terdekat sebelum Perubahan Mayor disetujui.
                </li>
              </ul>
            </div>
            <div id="container-title" class="bg-secondary ml-1 mr-1">
              <h5
                id="subtitle-syarat3"
                class="text-white text-justify ml-1 mr-1 pb-1">
                C. Ketentuan Pembayaran Biaya/<i>Ujrah</i> Perubahan Mayor dengan cara
                Pembatalan Unit:
              </h5>
            </div>
            <div id="container-title" class="bg-white ml-1 mr-1">
              <ul
                style="font-size:14px;"
                class="list-unstyled text-justify ml-1 mr-1 pb-1">
                <li>
                  1. Pembatalan Unit akan dilakukan setelah perubahan disetujui
                  dengan menggunakan harga Unit pada tanggal perhitungan
                  terdekat berikutnya setelah pembatalan Unit diproses.
                </li>
                <li>
                  2. Pembayaran biaya/
                  <i>ujrah</i>
                  Perubahan Mayor akan diproses dengan cara pembatalan Unit
                  apabila pembayaran secara transfer/tunai tidak diterima sampai
                  dengan pengajuan perubahan Mayor disetujui dan Polis memiliki
                  Nilai Tunai sebesar > Rp 250.000 (dua ratus lima puluh ribu
                  rupiah).
                </li>
                <li>
                  3. Minimum sisa Nilai Tunai Polis setelah pemotongan biaya/
                  <i>ujrah</i>
                  Perubahan Mayor adalah sebesar Rp 200.000 (dua ratus ribu
                  rupiah).
                </li>
                <li>
                  4. Apabila terdapat lebih dari 1 (satu) alokasi dana
                  investasi, maka pemotongan biaya/
                  <i>ujrah</i>
                  Perubahan Mayor akan diambil secara proporsional berdasarkan
                  jumlah dana investasi yang tersedia pada setiap alokasi
                  investasi yang ada.
                </li>
                <li>
                  5. Jika Nilai Tunai Polis tidak mencukupi pada saat pembatalan
                  Unit dilakukan, maka:
                  <ul>
                    <li class="list-unstyled">
                      a) Perubahan Mayor akan ditunda prosesnya dan Pemegang
                      Polis akan diminta untuk melakukan pembayaran biaya/
                      <i>ujrah</i>
                      Perubahan Mayor dengan cara tunai; atau
                    </li>
                    <li class="list-unstyled">
                      b) Apabila pada Polis terdapat Titipan dana sebesar Rp
                      50.000 (lima puluh ribu rupiah) atau lebih, maka
                      pembayaran biaya/
                      <i>ujrah</i>
                      Perubahan Mayor akan diambil dari dana tersebut.
                    </li>
                  </ul>
                </li>
                <li>
                  6. Pembayaran biaya/
                  <i>ujrah</i>
                  Perubahan Mayor tidak dapat dikembalikan kecuali apabila
                  pengajuan perubahan Polis tidak disetujui oleh Prudential.
                </li>
              </ul>
            </div>
            <div id="container-title" class="bg-secondary ml-1 mr-1">
              <h5
                id="subtitle-syarat4"
                class="text-white text-justify ml-1 mr-1 pb-1">
                D. Ketentuan Perubahan Polis
                <b>PRU</b>link generasi baru/
                <b>PRU</b>link syariah generasi baru:
              </h5>
            </div>
            <div id="container-title" class="bg-white ml-1 mr-1">
              <ul
                style="font-size:14px;"
                class="list-unstyled text-justify ml-1 mr-1 pb-1">
                <li>
                  1. Penambahan manfaat
                  <b>PRU</b>booster proteksi atas nama Tertanggung Utama/Peserta Utama
                  (Yang Diasuransikan) hanya dapat dilakukan apabila Polis telah
                  memiliki manfaat tersebut pada saat diterbitkan.
                </li>
                <li>
                  2. Manfaat
                  <b>PRU</b>booster proteksi dapat dibatalkan secara otomatis sesuai
                  dengan ketentuan Polis yang berlaku.
                </li>
                <li>
                  3. Dengan penambahan manfaat
                  <b>PRU</b>booster proteksi maka manfaat pertanggungan/kepesertaan
                  <b>PRU</b>link lifetime assurance dan
                  <b>PRU</b>link term/
                  <b>PRU</b>link term Syariah (jika ada) akan meningkat sebesar 5% dari
                  Uang Pertanggungan/Santunan Asuransi awal atau Uang
                  Pertanggungan/Santunan Asuransi yang berlaku setelah perubahan
                  Polis Mayor, mana yang lebih rendah setiap tahun s.d.
                  Tertanggung/Peserta (Yang Diasuransikan) berusia 55 tahun atau
                  10 tahun sebelum tanggal akhir pertanggungan/kepesertaan (mana
                  yang lebih dulu terjadi).
                </li>
                <li>
                  4. Akan dilakukan penilaian ulang untuk penambahan manfaat
                  <b>PRU</b>booster proteksi.
                </li>
              </ul>
              <div id="container-title" class="bg-danger ml-1 mr-1">
                <h6
                  id="title-syarat2"
                  class="text-white text-bold text-justify ml-1 mr-1 pt-1">
                  <strong>II. PERNYATAAN PEMEGANG POLIS</strong>
                </h6>
                <p
                  style="font-size:13px;"
                  class="text-white text-bold text-justify ml-1 mr-1">
                  <i>
                    (Harap dibaca dengan teliti sebelum menandatangani Formulir
                    Perubahan Mayor Polis Non Syariah/Syariah untuk Pemegang
                    Polis Individu)
                  </i>
                </p>
              </div>
              <div id="container-title" class="bg-white ml-1 mr-1">
                <ul
                  style="font-size:14px;"
                  class="list-unstyled text-justify ml-1 mr-1 pb-1">
                  <li>
                    1. SAYA sendiri yang menandatangani Formulir ini setelah
                    Formulir pengajuan ini terisi lengkap dan benar.
                  </li>
                  <li>
                    2. SAYA telah membaca seluruh persyaratan dan ketentuan yang
                    terdapat pada Formulir ini.
                  </li>
                  <li>
                    3. Semua keterangan yang diberikan di dalam Formulir ini dan
                    termasuk yang tercantum pada ilustrasi yang terlampir
                    bersama dengan Formulir ini adalah benar telah SAYA tuliskan
                    dan dibuat atas keinginan dan persetujuan SAYA, serta tidak
                    ada keterangan maupun hal-hal lain yang SAYA sembunyikan.
                    Segala risiko yang timbul, termasuk yang diakibatkan karena
                    Formulir ini ditandatangani dalam keadaan kosong/belum
                    terisi lengkap menjadi tanggung jawab SAYA.
                  </li>
                  <li>
                    4. SAYA mengerti dan telah mendapatkan penjelasan sepenuhnya
                    dari Tenaga Pemasar dan selanjutnya menyatakan setuju
                    mengenai hal-hal yang tersebut di bawah ini:
                    <ul>
                      <li class="list-unstyled">
                        a) Semua informasi yang tertulis di dalam Formulir ini
                        dan kepada Pemeriksa Kesehatan yang ditunjuk oleh
                        Prudential (jika ada) akan menjadi dasar dari
                        ketentuan-ketentuan dalam Polis.
                      </li>
                      <li class="list-unstyled">
                        b) Pertanggungan/Kepesertaan sesuai perubahan atas Polis
                        tidak akan berlaku sebelum perubahan Polis disetujui
                        yang ditandai dengan dikeluarkannya Endosemen sebagai
                        bagian yang tidak terpisahkan dari Polis.
                      </li>
                    </ul>
                  </li>
                  <li>
                    5. Ilustrasi mengenai nilai tunai yang terlampir (jika ada)
                    tidak berlaku.
                  </li>
                  <li>
                    6. Dengan memilih pembayaran Biaya/
                    <i>Ujrah</i>
                    Perubahan Polis melalui pembatalan Unit, atau dalam hal
                    pembayaran secara transfer/tunai tidak diterima sampai
                    dengan pengajuan Perubahan Mayor disetujui, atau apabila
                    kolom pilihan pembayaran Biaya/
                    <i>Ujrah</i>
                    Perubahan Polis tidak diisi, maka SAYA menyetujui untuk
                    melakukan pembayaran Biaya/
                    <i>Ujrah</i>
                    Perubahan Polis dengan cara pembatalan Unit dan dengan ini
                    mengesampingkan Ketentuan Umum Polis terkait dengan cara
                    pembayaran Biaya/
                    <i>Ujrah</i>
                    Perubahan Polis.
                  </li>
                  <li>
                    7. SAYA setuju untuk mengesampingkan ketentuan mengenai
                    perubahan manfaat dari Ketentuan Khusus Manfaat Asuransi
                    Tambahan yang memberikan manfaat rawat inap dan/atau
                    tindakan bedah serta manfaat rawat jalan yang memiliki
                    fasilitas Kartu Peserta, sehingga perubahan
                    pertanggungan/kepesertaan pada Manfaat Asuransi Tambahan
                    berlaku pada Ulang Bulan tanggal mulai
                    pertanggungan/kepesertaan pada Manfaat Asuransi Tambahan
                    yang memberikan manfaat rawat inap dan/atau tindakan bedah
                    serta manfaat rawat jalan yang memiliki fasilitas Kartu
                    Peserta.
                  </li>
                  <li>
                    8. Apabila Polis saat ini dalam kondisi Cuti Premi/Cuti
                    Kontribusi
                    <i>(Premium Holiday)</i>
                    dan tidak melampirkan Formulir Penghentian Cuti Premi/Cuti
                    Kontribusi maka jika perubahan Premi/Kontribusi pada
                    pengajuan ini disetujui dengan demikian Pemegang Polis juga
                    setuju untuk melakukan penghentian Cuti Premi/Cuti
                    Kontribusi
                    <i>(Premium Holiday)</i>
                    dan tanggal jatuh tempo Premi/Kontribusi berikutnya sesuai
                    dengan tanggal efektif perubahan Premi/Kontribusi.
                    Pembayaran Premi/Kontribusi akan dilakukan kembali setelah
                    penghentian Cuti Premi/Cuti Kontribusi <i>(Premium Holiday)</i>
                    diproses. Jika pembayaran Premi/Kontribusi melalui
                    pendebitan Kartu Kredit/Rekening, maka akan dilakukan
                    pendebitan kembali saat jatuh tempo sesuai siklus
                    pendebitan.
                  </li>
                  <li>
                    9. Apabila SAYA dan/atau Tertanggung/Peserta (Yang
                    Diasuransikan) melakukan pemeriksaan kesehatan atau
                    mengajukan klaim sebelum perubahan Polis disetujui di luar
                    pengetahuan Penanggung/Pengelola, di mana hasil pemeriksaan
                    atau data pada klaim tersebut dapat mempengaruhi/mengubah
                    keputusan seleksi risiko
                    <i>(underwriting)</i>
                    , maka pengajuan perubahan Polis akan ditinjau ulang oleh
                    Penanggung/Pengelola dan penilaian ulang tersebut dapat
                    menyebabkan pembatalan pengajuan perubahan Polis atau
                    pembatalan Polis.
                  </li>
                  <li>
                    10. Apabila ditemukan ketidakbenaran dan/atau
                    ketidaklengkapan pengisian Formulir Perubahan Mayor Polis
                    Non Syariah/Syariah untuk Pemegang Polis Individu, maka:
                    <ul>
                      <li class="list-unstyled">
                        a) Apabila ketidakbenaran dan/atau ketidaklengkapan
                        tersebut terjadi sebelum pertanggungan/kepesertaan pada
                        Polis diadakan, maka akan merujuk pada Ketentuan Umum
                        Polis mengenai Dasar Pertanggungan/Kepesertaan.
                      </li>
                      <li class="list-unstyled">
                        b) Apabila ketidakbenaran dan/atau ketidaklengkapan
                        tersebut terjadi setelah pertanggungan/kepesertaan pada
                        Polis diadakan namun sebelum perubahan Polis Mayor
                        terakhir disetujui, dan Penanggung/Pengelola tidak
                        pernah menyatakan secara tertulis bahwa
                        Penanggung/Pengelola setuju untuk mengesampingkan
                        ketidakbenaran dan/atau ketidaklengkapan tersebut
                        apabila diketahui setelah tanggal berlaku perubahan
                        Polis, maka:
                        <ul>
                          <li class="list-unstyled">
                            i. Perubahan dan/atau Polis tidak akan diadakan
                            (batal); atau
                          </li>
                          <li class="list-unstyled">
                            ii. Perubahan dan/atau Polis tidak akan diadakan
                            dengan syarat/keputusan yang sama; atau
                          </li>
                          <li class="list-unstyled">
                            iii. Dikenakan suatu persyaratan dan ketentuan yang
                            disampaikan oleh Penanggung/Pengelola setelah
                            Penanggung/Pengelola melakukan penilaian atas
                            risiko.
                          </li>
                        </ul>
                      </li>
                      <li class="list-unstyled">
                        c) Dalam hal terjadi keadaan sebagaimana dimaksud pada
                        butir b (i) di atas, maka:
                        <ul>
                          <li class="list-unstyled">
                            i. Perubahan Asuransi Dasar dan/atau Asuransi
                            Tambahan Polis menjadi batal sejak perubahan
                            tersebut disetujui dan dianggap tidak pernah berlaku
                            sehingga tidak ada Manfaat Asuransi yang dapat
                            dibayarkan. Dengan demikian
                            pertanggungan/kepesertaan pada Polis akan kembali
                            pada kondisi sebelum perubahan Polis disetujui dan
                            berlaku sejak tanggal penagihan Biaya Asuransi dan
                            Premi/Kontribusi berikutnya.
                          </li>
                          <li class="list-unstyled">
                            ii. Dalam hal perubahan Asuransi Dasar dan/atau
                            Asuransi Tambahan batal sebagaimana dimaksud dalam
                            butir c (i), Pemegang Polis bertanggung jawab atas
                            kerugian dan biaya/
                            <i>ujrah</i>
                            yang timbul dan Penanggung/Pengelola wajib
                            mengembalikan selisih Biaya Asuransi yang telah
                            dibebankan sebelum perubahan Polis disetujui.
                            Pengembalian yang dimaksud akan dialokasikan dalam
                            bentuk Unit yang penempatannya sesuai dengan alokasi
                            Dana Investasi
                            <b>PRU</b>link pada Premi/Kontribusi Berkala yang terakhir
                            tercatat pada Penanggung/Pengelola.
                          </li>
                        </ul>
                      </li>
                      <li class="list-unstyled">
                        d) Apabila hal sebagaimana dimaksud dalam butir (a) dan
                        (b) diketahui setelah dilakukan pembayaran Manfaat
                        Asuransi Dasar dan/atau Asuransi Tambahan, maka Pemegang
                        Polis wajib untuk mengembalikan kepada
                        Penanggung/Pengelola Manfaat Asuransi yang telah
                        diterima, sesuai Ketentuan Umum Polis mengenai Dasar
                        Pertanggungan/ Kepesertaan
                      </li>
                      <li class="list-unstyled">
                        e) Pengembalian Manfaat Asuransi harus dikembalikan
                        kepada Penanggung/Pengelola tanpa perlu memperhatikan
                        apakah Tertanggung/Peserta (Yang Diasuransikan) masih
                        hidup atau telah meninggal dunia.
                      </li>
                      <li class="list-unstyled">
                        f) Dalam hal Pemegang Polis telah meninggal dunia,
                        pengembalian Manfaat Asuransi sebagaimana dimaksud dalam
                        butir (e) di atas wajib dilakukan oleh Penerima Manfaat
                        atau pihak lain yang menerima Manfaat Asuransi
                        sebagaimana diatur dalam Polis.
                      </li>
                    </ul>
                  </li>
                  <li>
                    11. Dalam hal Pemegang Polis dan/atau Tertanggung/Peserta
                    (Yang Diasuransikan) memiliki Polis lain di Prudential
                    (“Polis Prudential”) dan data Pemegang Polis dan/atau
                    Tertanggung/Peserta (Yang Diasuransikan) berbeda dengan data
                    terbaru pada Formulir ini (tidak termasuk data nama), maka
                    SAYA setuju bahwa Penanggung/Pengelola dapat mengganti data
                    Polis Prudential dengan data yang tertera pada Formulir ini
                    (sebagaimana relevan).
                  </li>
                  <li>
                    12. SAYA mengerti bahwa dengan dilakukannya Perubahan Mayor
                    Polis Non Syariah/Syariah, fasilitas garansi Polis tetap
                    aktif menjadi tidak berlaku sesuai dengan yang tercantum
                    pada Ketentuan Umum Polis yang berlaku.
                  </li>
                  <li>
                    13. Penanggung/Pengelola dapat meminta dokumen berupa bukti
                    penghasilan atau dokumen lainnya yang diperlukan untuk
                    memastikan kesesuaian profil SAYA dan/atau
                    Tertanggung/Peserta (Yang Diasuransikan) dan/atau Pembayar
                    Premi/Kontributor. Dalam hal dokumen yang diperlukan
                    tersebut tidak diterima Penanggung/Pengelola atau dokumen
                    yang diperlukan tersebut mempunyai informasi yang berbeda
                    dengan informasi yang sebelumnya diterima oleh
                    Penanggung/Pengelola, SAYA menyetujui bahwa Penanggung/
                    Pengelola dapat menangguhkan transaksi yang SAYA ajukan atau
                    membatalkan pertanggungan/kepesertaan pada Asuransi Dasar
                    dan Asuransi Tambahan.
                  </li>
                  <li>
                    14. Transaksi keuangan yang dilakukan pada PT Prudential
                    Life Assurance (selanjutnya disebut “Prudential”) tidak
                    berasal dari/untuk tujuan tindak pidana pencucian uang
                    <i>(money laundering)</i>
                    sebagaimana dimaksud UU No. 8 tahun 2010 tentang Pencegahan
                    dan Pemberantasan Tindak Pidana Pencucian Uang, serta UU No.
                    9 tahun 2013 tentang Pencegahan dan Pemberantasan Tindak
                    Pidana Pendanaan Terorisme. Apabila transaksi yang dilakukan
                    terindikasi sebagai transaksi keuangan yang mencurigakan,
                    maka Prudential akan melaksanakan kewajibannya sesuai dengan
                    ketentuan yang berlaku, termasuk melakukan kewajiban
                    pelaporan atas transaksi keuangan yang mencurigakan.
                  </li>
                  <li>
                    15. Penanggung/Pengelola dari waktu ke waktu dapat
                    menggunakan informasi pribadi (termasuk namun tidak terbatas
                    pada nama, alamat surat menyurat, alamat
                    <i>E-mail</i>
                    , nomor telepon rumah, nomor telepon genggam, dan lainnya)
                    yang SAYA berikan dalam Formulir ini, serta informasi
                    terkait Polis SAYA termasuk memberikannya kepada pihak
                    ketiga sepanjang dianggap perlu oleh Penanggung/Pengelola
                    dalam rangka memberikan pelayanan atas Polis, atau untuk
                    tujuan lain seperti informasi produk, dan layanan terbaru
                    sehubungan dengan pertanggungan/kepesertaan SAYA berdasarkan
                    Polis, dengan tunduk pada peraturan perundang-undangan yang
                    berlaku.
                  </li>
                  <li>
                    16. Penanggung/Pengelola dapat menghubungi SAYA untuk
                    menyampaikan informasi mengenai Polis, informasi terkait
                    produk, atau layanan Prudential. Dalam hal informasi
                    tersebut diberikan melalui
                    <i>Short Message Service</i>
                    (SMS), SAYA menyetujui bahwa SMS tersebut dapat terkirim
                    baik pada atau di luar hari/jam kerja.
                  </li>
                  <li>
                    17. Dengan ini SAYA memberikan kuasa kepada Dokter,
                    klinik/laboratorium, rumah sakit, perusahaan asuransi,
                    instansi lain atau perorangan yang mempunyai
                    catatan/keterangan tentang diri Saya dan/atau
                    Tertanggung/Peserta (Yang Diasuransikan) berhubungan dengan
                    riwayat kesehatan, penyakit, atau perawatan SAYA dan/atau
                    Tertanggung/Peserta (Yang Diasuransikan) untuk diberikan
                    kepada Prudential atau petugas yang ditunjuk oleh
                    Prudential. Kuasa ini tidak berakhir apabila tidak ada
                    permintaan pembatalan dari SAYA, maupun oleh sebab-sebab
                    yang disebutkan dalam Pasal 1813, Pasal 1814, dan Pasal 1816
                    Kitab Undang-Undang Hukum Perdata Indonesia. Salinan kuasa
                    ini berlaku sama kuat dengan aslinya.
                  </li>
                  <li class="mb-3 pb-5">
                    18. Dengan ini SAYA menyatakan bahwa tidak ada perubahan
                    data pada Kartu Tanda Penduduk (KTP) Pemegang Polis dan
                    Tertanggung. Jika terdapat perubahan data pada KTP, maka
                    SAYA akan menginformasikan perubahan tersebut melalui
                    Perubahan Polis Minor dan melampirkan Foto Kopi KTP terbaru
                    yang masih berlaku
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <Navbar id="pager" class="navbar bg-white fixed-bottom shadow-lg">
            <div class="col-12">
              <p class="pt-2">
                Gulirkan layar hingga detail penawaran ini selesai untuk
                menyetujuinya
              </p>
              <p>Apakah anda setuju dengan penawaran ini ?</p>
              <small class="font-italic font-weight-small">
                Penawaran ini berlaku hingga
                <strong class="text-danger">{dateTime}</strong>
              </small>
            </div>
            <!--enable button-->
            <div class="col-6">
              <Button
                name="notsetuju"
                on:click={actionTidakSetujuAlter}
                class="btn btn-secondary"
                block
                style="display:none">
                Tidak Setuju
              </Button>
            </div>
            <div class="col-6">
              <Button
                name="setuju"
                on:click={actionSetujuAlter}
                class="btn btn-danger"
                block
                style="display:none">
                Setuju
              </Button>
            </div>

            <!--disable button-->
            <div class="col-6">
              <Button
                name="dnotsetuju"
                block
                disabled
                class="btn btn-secondary"
                style="display:block">
                Tidak Setuju
              </Button>
            </div>
            <div class="col-6">
              <Button
                name="dsetuju"
                block
                disabled
                class="btn btn-secondary"
                style="display:block">
                Setuju
              </Button>
            </div>
          </Navbar>
        </div>
      </div>
    </div>
  </div>
</main>
