import sirv from 'sirv';
import compression from 'compression';
import * as sapper from '@sapper/server';
import { generatePDFUsingUnoConvServer } from './server/controllers/unoconv';
import Utils from './server/controllers/Utils';
import sessionFileStore from 'session-file-store';

const config = require('./server/config/server-config.js');
const express = require("express");
const { RateLimiterRedis } = require('rate-limiter-flexible');
const rateLimiterRedisMiddleware = require('./server/config/rate-limiter');
const redis = require("redis");
const fs = require('fs');
const fsx = require('fs-extra');
const path = require('path');
const cors = require('cors');
const NodeFetch = require('node-fetch');
const bodyParser = require("body-parser");
const request = require("request");
const schedule = require("node-schedule");
const helmet = require('helmet');
const pdf2base64 = require('pdf-to-base64');
const timeout = require('connect-timeout');
const moment = require('moment');
moment.locale('en');
const _ = require('lodash');

const logOpts = {
    errorEventName: 'error',
    logDirectory: './log', // NOTE: folder must exist and be writable...
    fileNamePattern: 'roll-<DATE>.log',
    dateFormat: 'DD.MM.YYYY'
};

const log = require('simple-node-logger').createRollingFileLogger(logOpts);

const router = express.Router();
const app = express();

const client = redis.createClient({
    host: config.redis_host,
    port: config.redis_port
});

const redisClient = redis.createClient({
    host: config.redis_host,
    port: config.redis_port,
    enable_offline_queue: false,
});

Utils.setClient(client);

const { PORT, NODE_ENV } = process.env;
const dev = NODE_ENV === 'development';

var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');

    next();
};

app.use(allowCrossDomain);
app.use(timeout('30s'));
app.use(helmet());
app.use(bodyParser.json({ limit: '30mb' }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors({
    origin: '*',
    credentials: true
}));

app.post(config.basePath + '/format/pdf', async(req, res) => {
    try {
        Utils.baseTodocx(req.body.base64,req.body.filename);
        generatePDFUsingUnoConvServer(path.join(__dirname, '/public/output/' + req.body.filename + '.docx'),
        path.join(__dirname, '/public/output/' + req.body.filename + '.pdf')).then(()=>{
            const content = fs.readFileSync(path.join(__dirname, '/public/output/' + req.body.filename + ".pdf"), 'base64');
            return res.status(200).send({base64OTP:content});
        })
    } catch (err) {
        res.status(500).end();
    }
});

app.use(config.basePath, compression({ threshold: 0 }),
    sirv('static', { dev }),
    sapper.middleware()
).listen(PORT, err => {
    // log.info('Service started --------- ');
    if (err) console.log('error', err);
});