const axios = require('axios');
const fs = require('fs');
const path = require('path');



export const generatePDFUsingUnoConvServer = async (filePath, outputPath) => {

    const file = fs.createReadStream(__dirname + filePath);
    const fileInfo = path.parse(filePath);

    const destination = outputPath

    const headers = {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': `attachment; filename="${fileInfo.base}"`
    };


axios({
    method: 'POST',
    url: 'http://127.0.0.1:4000/convert/format/pdf/output/'+ fileInfo.name + '.pdf',
    data: file,
    headers: headers,
    responseType: 'stream'
  })
    .then(response => {
      response.data.pipe(fs.createWriteStream(__dirname + destination));
    })
    .catch(error => {
      console.log(error);
    });

}