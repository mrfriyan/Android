const config = require('../config/server-config.js');
const fs = require('fs');
const path = require('path');
const btoa = require('btoa');
const request = require("request");
const unoconv = require("unoconv-promise");
const qpdf = require('node-qpdf');
const exec = require('child_process').exec;
const atob = require("atob");


const baseTodocx = function(b64string,filename) {
    var sBase64 = b64string.replace(/(\r\n|\n|\r)/gm, "");
    var sBinaryString = atob(sBase64);
    var len = sBinaryString.length;
    var aBytes = new Uint8Array(len);

    for (var i=0; i<len; i++) {
        aBytes[i] = sBinaryString.charCodeAt(i);
    }

    var blob = Buffer.from(aBytes.buffer);
    
    return new Promise((resolve, reject) => {
     fs.writeFileSync(path.join(__dirname, '/public/output/' + filename + '.docx'), blob);
    });
    console.log("converted to docx!");
}

let client;

module.exports = {
    setClient: function(inClient) { client = inClient; },
    baseTodocx: baseTodocx
}