# How to run project locally?

Edit this configuration
client/src/server/config/server-config.js

```js
export const service_url = 'http://10.170.49.104'; //service ip configuration SIT 104 UAT 214
export const otp_expire_time = 300; //OTP code expired time in second
export const url_expire_at = '';
export const basePath = '/campaign'; //set up base path / context root
export const env_url = 'http://localhost:3000/campaign'; //expressjs api url
export const url_sms_template_message = "http://localhost:3000/campaign/red/"; //template message 1
export const otp_sms_template_message = '';
export const random_code_url_length = 4; //random short url code length 
export const random_code_otp_length = 5; //random OTP code length
export const setDefaultPhoneNumber = '089676754922'; //set false for use roleOW phoneNumber
export const sms_otp_template_1 = 'Anda dapat penawaran khusus dr Prudential, silakan klik ';
export const sms_otp_template_2 = ' Mohon utk tdk menyebarkan tautan kpd siapapun';
export const sms_kode_otp_template = 'Berikut adalah kode OTP untuk konfirmasi persetujuan penawaran anda ';
export const redis_port = 6379 //default redis port
export const channelIdSMS = "pruforce" //channelId for smsapi
```

```bash
$ docker-compose down
$ docker-compose up -d --build
$ docker-compose start client
$ docker exec -it pf-easy-campaign-client bash 
```

```bash
$ npm run start
```

dont forget to build local first